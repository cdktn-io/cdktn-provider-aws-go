/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAccountaccessApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/accountaccess_application#arn DataAwsAccountaccessApplication#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/accountaccess_application#identity_center_instance_arn DataAwsAccountaccessApplication#identity_center_instance_arn}
    */
    readonly identityCenterInstanceArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/accountaccess_application#region DataAwsAccountaccessApplication#region}
    */
    readonly region?: string;
}
export interface DataAwsAccountaccessApplicationIdentitySourceIdentityCenter {
}
export declare function dataAwsAccountaccessApplicationIdentitySourceIdentityCenterToTerraform(struct?: DataAwsAccountaccessApplicationIdentitySourceIdentityCenter): any;
export declare function dataAwsAccountaccessApplicationIdentitySourceIdentityCenterToHclTerraform(struct?: DataAwsAccountaccessApplicationIdentitySourceIdentityCenter): any;
export declare class DataAwsAccountaccessApplicationIdentitySourceIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessApplicationIdentitySourceIdentityCenter | undefined;
    set internalValue(value: DataAwsAccountaccessApplicationIdentitySourceIdentityCenter | undefined);
    get applicationArn(): string;
    get instanceArn(): string;
}
export declare class DataAwsAccountaccessApplicationIdentitySourceIdentityCenterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessApplicationIdentitySourceIdentityCenterOutputReference;
}
export interface DataAwsAccountaccessApplicationIdentitySource {
}
export declare function dataAwsAccountaccessApplicationIdentitySourceToTerraform(struct?: DataAwsAccountaccessApplicationIdentitySource): any;
export declare function dataAwsAccountaccessApplicationIdentitySourceToHclTerraform(struct?: DataAwsAccountaccessApplicationIdentitySource): any;
export declare class DataAwsAccountaccessApplicationIdentitySourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessApplicationIdentitySource | undefined;
    set internalValue(value: DataAwsAccountaccessApplicationIdentitySource | undefined);
    private _identityCenter;
    get identityCenter(): DataAwsAccountaccessApplicationIdentitySourceIdentityCenterList;
}
export declare class DataAwsAccountaccessApplicationIdentitySourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessApplicationIdentitySourceOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/accountaccess_application aws_accountaccess_application}
*/
export declare class DataAwsAccountaccessApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_accountaccess_application";
    /**
    * Generates CDKTN code for importing a DataAwsAccountaccessApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAccountaccessApplication to import
    * @param importFromId The id of the existing DataAwsAccountaccessApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/accountaccess_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAccountaccessApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/accountaccess_application aws_accountaccess_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAccountaccessApplicationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsAccountaccessApplicationConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get createdAt(): string;
    private _identityCenterInstanceArn?;
    get identityCenterInstanceArn(): string;
    set identityCenterInstanceArn(value: string);
    resetIdentityCenterInstanceArn(): void;
    get identityCenterInstanceArnInput(): string | undefined;
    private _identitySource;
    get identitySource(): DataAwsAccountaccessApplicationIdentitySourceList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get tenantId(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
