/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockEvaluationJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#application_type BedrockEvaluationJob#application_type}
    */
    readonly applicationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#customer_encryption_key_id BedrockEvaluationJob#customer_encryption_key_id}
    */
    readonly customerEncryptionKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#job_description BedrockEvaluationJob#job_description}
    */
    readonly jobDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#job_name BedrockEvaluationJob#job_name}
    */
    readonly jobName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#region BedrockEvaluationJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#role_arn BedrockEvaluationJob#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#skip_destroy BedrockEvaluationJob#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#tags BedrockEvaluationJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * evaluation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#evaluation_config BedrockEvaluationJob#evaluation_config}
    */
    readonly evaluationConfig?: BedrockEvaluationJobEvaluationConfig[] | cdktn.IResolvable;
    /**
    * inference_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#inference_config BedrockEvaluationJob#inference_config}
    */
    readonly inferenceConfig?: BedrockEvaluationJobInferenceConfig[] | cdktn.IResolvable;
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#output_data_config BedrockEvaluationJob#output_data_config}
    */
    readonly outputDataConfig?: BedrockEvaluationJobOutputDataConfig[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#timeouts BedrockEvaluationJob#timeouts}
    */
    readonly timeouts?: BedrockEvaluationJobTimeouts;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#float_value BedrockEvaluationJob#float_value}
    */
    readonly floatValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#string_value BedrockEvaluationJob#string_value}
    */
    readonly stringValue?: string;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValueToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValueToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue | cdktn.IResolvable | undefined);
    private _floatValue?;
    get floatValue(): number;
    set floatValue(value: number);
    resetFloatValue(): void;
    get floatValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValueList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValueOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#definition BedrockEvaluationJob#definition}
    */
    readonly definition: string;
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#value BedrockEvaluationJob#value}
    */
    readonly value?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _value;
    get value(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValueList;
    putValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleValue[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#instructions BedrockEvaluationJob#instructions}
    */
    readonly instructions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#name BedrockEvaluationJob#name}
    */
    readonly name: string;
    /**
    * rating_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#rating_scale BedrockEvaluationJob#rating_scale}
    */
    readonly ratingScale?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition | cdktn.IResolvable | undefined);
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    get instructionsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ratingScale;
    get ratingScale(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScaleList;
    putRatingScale(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale[] | cdktn.IResolvable): void;
    resetRatingScale(): void;
    get ratingScaleInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionRatingScale[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric {
    /**
    * custom_metric_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#custom_metric_definition BedrockEvaluationJob#custom_metric_definition}
    */
    readonly customMetricDefinition?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric | cdktn.IResolvable | undefined);
    private _customMetricDefinition;
    get customMetricDefinition(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinitionList;
    putCustomMetricDefinition(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition[] | cdktn.IResolvable): void;
    resetCustomMetricDefinition(): void;
    get customMetricDefinitionInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricCustomMetricDefinition[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#model_identifier BedrockEvaluationJob#model_identifier}
    */
    readonly modelIdentifier: string;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable | undefined);
    private _modelIdentifier?;
    get modelIdentifier(): string;
    set modelIdentifier(value: string);
    get modelIdentifierInput(): string | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig {
    /**
    * bedrock_evaluator_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#bedrock_evaluator_model BedrockEvaluationJob#bedrock_evaluator_model}
    */
    readonly bedrockEvaluatorModel?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig | cdktn.IResolvable | undefined);
    private _bedrockEvaluatorModel;
    get bedrockEvaluatorModel(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelList;
    putBedrockEvaluatorModel(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel[] | cdktn.IResolvable): void;
    resetBedrockEvaluatorModel(): void;
    get bedrockEvaluatorModelInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModel[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig {
    /**
    * custom_metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#custom_metric BedrockEvaluationJob#custom_metric}
    */
    readonly customMetric?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric[] | cdktn.IResolvable;
    /**
    * evaluator_model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#evaluator_model_config BedrockEvaluationJob#evaluator_model_config}
    */
    readonly evaluatorModelConfig?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig | cdktn.IResolvable | undefined);
    private _customMetric;
    get customMetric(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricList;
    putCustomMetric(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric[] | cdktn.IResolvable): void;
    resetCustomMetric(): void;
    get customMetricInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetric[] | undefined;
    private _evaluatorModelConfig;
    get evaluatorModelConfig(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigList;
    putEvaluatorModelConfig(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig[] | cdktn.IResolvable): void;
    resetEvaluatorModelConfig(): void;
    get evaluatorModelConfigInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfig[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#s3_uri BedrockEvaluationJob#s3_uri}
    */
    readonly s3Uri: string;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable | undefined);
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    get s3UriInput(): string | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#name BedrockEvaluationJob#name}
    */
    readonly name: string;
    /**
    * dataset_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#dataset_location BedrockEvaluationJob#dataset_location}
    */
    readonly datasetLocation?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _datasetLocation;
    get datasetLocation(): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationList;
    putDatasetLocation(value: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation[] | cdktn.IResolvable): void;
    resetDatasetLocation(): void;
    get datasetLocationInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocation[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#metric_names BedrockEvaluationJob#metric_names}
    */
    readonly metricNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#task_type BedrockEvaluationJob#task_type}
    */
    readonly taskType: string;
    /**
    * dataset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#dataset BedrockEvaluationJob#dataset}
    */
    readonly dataset?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    get metricNamesInput(): string[] | undefined;
    private _taskType?;
    get taskType(): string;
    set taskType(value: string);
    get taskTypeInput(): string | undefined;
    private _dataset;
    get dataset(): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetList;
    putDataset(value: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset[] | cdktn.IResolvable): void;
    resetDataset(): void;
    get datasetInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDataset[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#model_identifier BedrockEvaluationJob#model_identifier}
    */
    readonly modelIdentifier: string;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel | cdktn.IResolvable | undefined);
    private _modelIdentifier?;
    get modelIdentifier(): string;
    set modelIdentifier(value: string);
    get modelIdentifierInput(): string | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig {
    /**
    * bedrock_evaluator_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#bedrock_evaluator_model BedrockEvaluationJob#bedrock_evaluator_model}
    */
    readonly bedrockEvaluatorModel?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig | cdktn.IResolvable | undefined);
    private _bedrockEvaluatorModel;
    get bedrockEvaluatorModel(): BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelList;
    putBedrockEvaluatorModel(value: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel[] | cdktn.IResolvable): void;
    resetBedrockEvaluatorModel(): void;
    get bedrockEvaluatorModelInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModel[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigAutomated {
    /**
    * custom_metric_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#custom_metric_config BedrockEvaluationJob#custom_metric_config}
    */
    readonly customMetricConfig?: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig[] | cdktn.IResolvable;
    /**
    * dataset_metric_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#dataset_metric_config BedrockEvaluationJob#dataset_metric_config}
    */
    readonly datasetMetricConfig?: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig[] | cdktn.IResolvable;
    /**
    * evaluator_model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#evaluator_model_config BedrockEvaluationJob#evaluator_model_config}
    */
    readonly evaluatorModelConfig?: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigAutomatedToTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomated | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigAutomatedToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigAutomated | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigAutomatedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigAutomated | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigAutomated | cdktn.IResolvable | undefined);
    private _customMetricConfig;
    get customMetricConfig(): BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigList;
    putCustomMetricConfig(value: BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig[] | cdktn.IResolvable): void;
    resetCustomMetricConfig(): void;
    get customMetricConfigInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfig[] | undefined;
    private _datasetMetricConfig;
    get datasetMetricConfig(): BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigList;
    putDatasetMetricConfig(value: BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig[] | cdktn.IResolvable): void;
    resetDatasetMetricConfig(): void;
    get datasetMetricConfigInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfig[] | undefined;
    private _evaluatorModelConfig;
    get evaluatorModelConfig(): BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigList;
    putEvaluatorModelConfig(value: BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig[] | cdktn.IResolvable): void;
    resetEvaluatorModelConfig(): void;
    get evaluatorModelConfigInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfig[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigAutomatedList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigAutomated[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigAutomatedOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigHumanCustomMetric {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#description BedrockEvaluationJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#name BedrockEvaluationJob#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#rating_method BedrockEvaluationJob#rating_method}
    */
    readonly ratingMethod: string;
}
export declare function bedrockEvaluationJobEvaluationConfigHumanCustomMetricToTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanCustomMetric | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigHumanCustomMetricToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanCustomMetric | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigHumanCustomMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigHumanCustomMetric | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigHumanCustomMetric | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ratingMethod?;
    get ratingMethod(): string;
    set ratingMethod(value: string);
    get ratingMethodInput(): string | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigHumanCustomMetricList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigHumanCustomMetric[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigHumanCustomMetricOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#s3_uri BedrockEvaluationJob#s3_uri}
    */
    readonly s3Uri: string;
}
export declare function bedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationToTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation | cdktn.IResolvable | undefined);
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    get s3UriInput(): string | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#name BedrockEvaluationJob#name}
    */
    readonly name: string;
    /**
    * dataset_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#dataset_location BedrockEvaluationJob#dataset_location}
    */
    readonly datasetLocation?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetToTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _datasetLocation;
    get datasetLocation(): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationList;
    putDatasetLocation(value: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation[] | cdktn.IResolvable): void;
    resetDatasetLocation(): void;
    get datasetLocationInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocation[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#metric_names BedrockEvaluationJob#metric_names}
    */
    readonly metricNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#task_type BedrockEvaluationJob#task_type}
    */
    readonly taskType: string;
    /**
    * dataset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#dataset BedrockEvaluationJob#dataset}
    */
    readonly dataset?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigToTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    get metricNamesInput(): string[] | undefined;
    private _taskType?;
    get taskType(): string;
    set taskType(value: string);
    get taskTypeInput(): string | undefined;
    private _dataset;
    get dataset(): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetList;
    putDataset(value: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset[] | cdktn.IResolvable): void;
    resetDataset(): void;
    get datasetInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDataset[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#flow_definition_arn BedrockEvaluationJob#flow_definition_arn}
    */
    readonly flowDefinitionArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#instructions BedrockEvaluationJob#instructions}
    */
    readonly instructions?: string;
}
export declare function bedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfigToTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfigToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig | cdktn.IResolvable | undefined);
    private _flowDefinitionArn?;
    get flowDefinitionArn(): string;
    set flowDefinitionArn(value: string);
    get flowDefinitionArnInput(): string | undefined;
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    resetInstructions(): void;
    get instructionsInput(): string | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfigOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfigHuman {
    /**
    * custom_metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#custom_metric BedrockEvaluationJob#custom_metric}
    */
    readonly customMetric?: BedrockEvaluationJobEvaluationConfigHumanCustomMetric[] | cdktn.IResolvable;
    /**
    * dataset_metric_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#dataset_metric_config BedrockEvaluationJob#dataset_metric_config}
    */
    readonly datasetMetricConfig?: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig[] | cdktn.IResolvable;
    /**
    * human_workflow_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#human_workflow_config BedrockEvaluationJob#human_workflow_config}
    */
    readonly humanWorkflowConfig?: BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigHumanToTerraform(struct?: BedrockEvaluationJobEvaluationConfigHuman | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigHumanToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfigHuman | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigHumanOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfigHuman | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfigHuman | cdktn.IResolvable | undefined);
    private _customMetric;
    get customMetric(): BedrockEvaluationJobEvaluationConfigHumanCustomMetricList;
    putCustomMetric(value: BedrockEvaluationJobEvaluationConfigHumanCustomMetric[] | cdktn.IResolvable): void;
    resetCustomMetric(): void;
    get customMetricInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigHumanCustomMetric[] | undefined;
    private _datasetMetricConfig;
    get datasetMetricConfig(): BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigList;
    putDatasetMetricConfig(value: BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig[] | cdktn.IResolvable): void;
    resetDatasetMetricConfig(): void;
    get datasetMetricConfigInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfig[] | undefined;
    private _humanWorkflowConfig;
    get humanWorkflowConfig(): BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfigList;
    putHumanWorkflowConfig(value: BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig[] | cdktn.IResolvable): void;
    resetHumanWorkflowConfig(): void;
    get humanWorkflowConfigInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigHumanHumanWorkflowConfig[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigHumanList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfigHuman[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigHumanOutputReference;
}
export interface BedrockEvaluationJobEvaluationConfig {
    /**
    * automated block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#automated BedrockEvaluationJob#automated}
    */
    readonly automated?: BedrockEvaluationJobEvaluationConfigAutomated[] | cdktn.IResolvable;
    /**
    * human block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#human BedrockEvaluationJob#human}
    */
    readonly human?: BedrockEvaluationJobEvaluationConfigHuman[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobEvaluationConfigToTerraform(struct?: BedrockEvaluationJobEvaluationConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobEvaluationConfigToHclTerraform(struct?: BedrockEvaluationJobEvaluationConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobEvaluationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobEvaluationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobEvaluationConfig | cdktn.IResolvable | undefined);
    private _automated;
    get automated(): BedrockEvaluationJobEvaluationConfigAutomatedList;
    putAutomated(value: BedrockEvaluationJobEvaluationConfigAutomated[] | cdktn.IResolvable): void;
    resetAutomated(): void;
    get automatedInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigAutomated[] | undefined;
    private _human;
    get human(): BedrockEvaluationJobEvaluationConfigHumanList;
    putHuman(value: BedrockEvaluationJobEvaluationConfigHuman[] | cdktn.IResolvable): void;
    resetHuman(): void;
    get humanInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfigHuman[] | undefined;
}
export declare class BedrockEvaluationJobEvaluationConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobEvaluationConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobEvaluationConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#latency BedrockEvaluationJob#latency}
    */
    readonly latency?: string;
}
export declare function bedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig | cdktn.IResolvable | undefined);
    private _latency?;
    get latency(): string;
    set latency(value: string);
    resetLatency(): void;
    get latencyInput(): string | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigModelBedrockModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#inference_params BedrockEvaluationJob#inference_params}
    */
    readonly inferenceParams?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#model_identifier BedrockEvaluationJob#model_identifier}
    */
    readonly modelIdentifier: string;
    /**
    * performance_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#performance_config BedrockEvaluationJob#performance_config}
    */
    readonly performanceConfig?: BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigModelBedrockModelToTerraform(struct?: BedrockEvaluationJobInferenceConfigModelBedrockModel | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigModelBedrockModelToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigModelBedrockModel | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigModelBedrockModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigModelBedrockModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigModelBedrockModel | cdktn.IResolvable | undefined);
    private _inferenceParams?;
    get inferenceParams(): string;
    set inferenceParams(value: string);
    resetInferenceParams(): void;
    get inferenceParamsInput(): string | undefined;
    private _modelIdentifier?;
    get modelIdentifier(): string;
    set modelIdentifier(value: string);
    get modelIdentifierInput(): string | undefined;
    private _performanceConfig;
    get performanceConfig(): BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfigList;
    putPerformanceConfig(value: BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig[] | cdktn.IResolvable): void;
    resetPerformanceConfig(): void;
    get performanceConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigModelBedrockModelPerformanceConfig[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigModelBedrockModelList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigModelBedrockModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigModelBedrockModelOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#inference_source_identifier BedrockEvaluationJob#inference_source_identifier}
    */
    readonly inferenceSourceIdentifier: string;
}
export declare function bedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSourceToTerraform(struct?: BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSourceToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource | cdktn.IResolvable | undefined);
    private _inferenceSourceIdentifier?;
    get inferenceSourceIdentifier(): string;
    set inferenceSourceIdentifier(value: string);
    get inferenceSourceIdentifierInput(): string | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSourceList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSourceOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigModel {
    /**
    * bedrock_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#bedrock_model BedrockEvaluationJob#bedrock_model}
    */
    readonly bedrockModel?: BedrockEvaluationJobInferenceConfigModelBedrockModel[] | cdktn.IResolvable;
    /**
    * precomputed_inference_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#precomputed_inference_source BedrockEvaluationJob#precomputed_inference_source}
    */
    readonly precomputedInferenceSource?: BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigModelToTerraform(struct?: BedrockEvaluationJobInferenceConfigModel | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigModelToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigModel | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigModel | cdktn.IResolvable | undefined);
    private _bedrockModel;
    get bedrockModel(): BedrockEvaluationJobInferenceConfigModelBedrockModelList;
    putBedrockModel(value: BedrockEvaluationJobInferenceConfigModelBedrockModel[] | cdktn.IResolvable): void;
    resetBedrockModel(): void;
    get bedrockModelInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigModelBedrockModel[] | undefined;
    private _precomputedInferenceSource;
    get precomputedInferenceSource(): BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSourceList;
    putPrecomputedInferenceSource(value: BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource[] | cdktn.IResolvable): void;
    resetPrecomputedInferenceSource(): void;
    get precomputedInferenceSourceInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigModelPrecomputedInferenceSource[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigModelList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigModelOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#number_of_results BedrockEvaluationJob#number_of_results}
    */
    readonly numberOfResults?: number;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable | undefined);
    private _numberOfResults?;
    get numberOfResults(): number;
    set numberOfResults(value: number);
    resetNumberOfResults(): void;
    get numberOfResultsInput(): number | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration {
    /**
    * vector_search_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#vector_search_configuration BedrockEvaluationJob#vector_search_configuration}
    */
    readonly vectorSearchConfiguration?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration | cdktn.IResolvable | undefined);
    private _vectorSearchConfiguration;
    get vectorSearchConfiguration(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationList;
    putVectorSearchConfiguration(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration[] | cdktn.IResolvable): void;
    resetVectorSearchConfiguration(): void;
    get vectorSearchConfigurationInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfiguration[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#knowledge_base_id BedrockEvaluationJob#knowledge_base_id}
    */
    readonly knowledgeBaseId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#model_arn BedrockEvaluationJob#model_arn}
    */
    readonly modelArn: string;
    /**
    * retrieval_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#retrieval_configuration BedrockEvaluationJob#retrieval_configuration}
    */
    readonly retrievalConfiguration?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig | cdktn.IResolvable | undefined);
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    get knowledgeBaseIdInput(): string | undefined;
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    get modelArnInput(): string | undefined;
    private _retrievalConfiguration;
    get retrievalConfiguration(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationList;
    putRetrievalConfiguration(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration[] | cdktn.IResolvable): void;
    resetRetrievalConfiguration(): void;
    get retrievalConfigurationInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfiguration[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#number_of_results BedrockEvaluationJob#number_of_results}
    */
    readonly numberOfResults?: number;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration | cdktn.IResolvable | undefined);
    private _numberOfResults?;
    get numberOfResults(): number;
    set numberOfResults(value: number);
    resetNumberOfResults(): void;
    get numberOfResultsInput(): number | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration {
    /**
    * vector_search_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#vector_search_configuration BedrockEvaluationJob#vector_search_configuration}
    */
    readonly vectorSearchConfiguration?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration | cdktn.IResolvable | undefined);
    private _vectorSearchConfiguration;
    get vectorSearchConfiguration(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationList;
    putVectorSearchConfiguration(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration[] | cdktn.IResolvable): void;
    resetVectorSearchConfiguration(): void;
    get vectorSearchConfigurationInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfiguration[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#knowledge_base_id BedrockEvaluationJob#knowledge_base_id}
    */
    readonly knowledgeBaseId: string;
    /**
    * knowledge_base_retrieval_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#knowledge_base_retrieval_configuration BedrockEvaluationJob#knowledge_base_retrieval_configuration}
    */
    readonly knowledgeBaseRetrievalConfiguration?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig | cdktn.IResolvable | undefined);
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    get knowledgeBaseIdInput(): string | undefined;
    private _knowledgeBaseRetrievalConfiguration;
    get knowledgeBaseRetrievalConfiguration(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationList;
    putKnowledgeBaseRetrievalConfiguration(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration[] | cdktn.IResolvable): void;
    resetKnowledgeBaseRetrievalConfiguration(): void;
    get knowledgeBaseRetrievalConfigurationInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfiguration[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig {
    /**
    * retrieve_and_generate_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#retrieve_and_generate_config BedrockEvaluationJob#retrieve_and_generate_config}
    */
    readonly retrieveAndGenerateConfig?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig[] | cdktn.IResolvable;
    /**
    * retrieve_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#retrieve_config BedrockEvaluationJob#retrieve_config}
    */
    readonly retrieveConfig?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig | cdktn.IResolvable | undefined);
    private _retrieveAndGenerateConfig;
    get retrieveAndGenerateConfig(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigList;
    putRetrieveAndGenerateConfig(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig[] | cdktn.IResolvable): void;
    resetRetrieveAndGenerateConfig(): void;
    get retrieveAndGenerateConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfig[] | undefined;
    private _retrieveConfig;
    get retrieveConfig(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigList;
    putRetrieveConfig(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig[] | cdktn.IResolvable): void;
    resetRetrieveConfig(): void;
    get retrieveConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfig[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#rag_source_identifier BedrockEvaluationJob#rag_source_identifier}
    */
    readonly ragSourceIdentifier: string;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig | cdktn.IResolvable | undefined);
    private _ragSourceIdentifier?;
    get ragSourceIdentifier(): string;
    set ragSourceIdentifier(value: string);
    get ragSourceIdentifierInput(): string | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#rag_source_identifier BedrockEvaluationJob#rag_source_identifier}
    */
    readonly ragSourceIdentifier: string;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig | cdktn.IResolvable | undefined);
    private _ragSourceIdentifier?;
    get ragSourceIdentifier(): string;
    set ragSourceIdentifier(value: string);
    get ragSourceIdentifierInput(): string | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig {
    /**
    * retrieve_and_generate_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#retrieve_and_generate_source_config BedrockEvaluationJob#retrieve_and_generate_source_config}
    */
    readonly retrieveAndGenerateSourceConfig?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig[] | cdktn.IResolvable;
    /**
    * retrieve_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#retrieve_source_config BedrockEvaluationJob#retrieve_source_config}
    */
    readonly retrieveSourceConfig?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig | cdktn.IResolvable | undefined);
    private _retrieveAndGenerateSourceConfig;
    get retrieveAndGenerateSourceConfig(): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfigList;
    putRetrieveAndGenerateSourceConfig(value: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig[] | cdktn.IResolvable): void;
    resetRetrieveAndGenerateSourceConfig(): void;
    get retrieveAndGenerateSourceConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveAndGenerateSourceConfig[] | undefined;
    private _retrieveSourceConfig;
    get retrieveSourceConfig(): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfigList;
    putRetrieveSourceConfig(value: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig[] | cdktn.IResolvable): void;
    resetRetrieveSourceConfig(): void;
    get retrieveSourceConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigRetrieveSourceConfig[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfigRagConfig {
    /**
    * knowledge_base_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#knowledge_base_config BedrockEvaluationJob#knowledge_base_config}
    */
    readonly knowledgeBaseConfig?: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig[] | cdktn.IResolvable;
    /**
    * precomputed_rag_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#precomputed_rag_source_config BedrockEvaluationJob#precomputed_rag_source_config}
    */
    readonly precomputedRagSourceConfig?: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigRagConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigRagConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfigRagConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigRagConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfigRagConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfigRagConfig | cdktn.IResolvable | undefined);
    private _knowledgeBaseConfig;
    get knowledgeBaseConfig(): BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigList;
    putKnowledgeBaseConfig(value: BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig[] | cdktn.IResolvable): void;
    resetKnowledgeBaseConfig(): void;
    get knowledgeBaseConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfig[] | undefined;
    private _precomputedRagSourceConfig;
    get precomputedRagSourceConfig(): BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfigList;
    putPrecomputedRagSourceConfig(value: BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig[] | cdktn.IResolvable): void;
    resetPrecomputedRagSourceConfig(): void;
    get precomputedRagSourceConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfigPrecomputedRagSourceConfig[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigRagConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfigRagConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigRagConfigOutputReference;
}
export interface BedrockEvaluationJobInferenceConfig {
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#model BedrockEvaluationJob#model}
    */
    readonly model?: BedrockEvaluationJobInferenceConfigModel[] | cdktn.IResolvable;
    /**
    * rag_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#rag_config BedrockEvaluationJob#rag_config}
    */
    readonly ragConfig?: BedrockEvaluationJobInferenceConfigRagConfig[] | cdktn.IResolvable;
}
export declare function bedrockEvaluationJobInferenceConfigToTerraform(struct?: BedrockEvaluationJobInferenceConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobInferenceConfigToHclTerraform(struct?: BedrockEvaluationJobInferenceConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobInferenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobInferenceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobInferenceConfig | cdktn.IResolvable | undefined);
    private _model;
    get model(): BedrockEvaluationJobInferenceConfigModelList;
    putModel(value: BedrockEvaluationJobInferenceConfigModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigModel[] | undefined;
    private _ragConfig;
    get ragConfig(): BedrockEvaluationJobInferenceConfigRagConfigList;
    putRagConfig(value: BedrockEvaluationJobInferenceConfigRagConfig[] | cdktn.IResolvable): void;
    resetRagConfig(): void;
    get ragConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfigRagConfig[] | undefined;
}
export declare class BedrockEvaluationJobInferenceConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobInferenceConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobInferenceConfigOutputReference;
}
export interface BedrockEvaluationJobOutputDataConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#s3_uri BedrockEvaluationJob#s3_uri}
    */
    readonly s3Uri: string;
}
export declare function bedrockEvaluationJobOutputDataConfigToTerraform(struct?: BedrockEvaluationJobOutputDataConfig | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobOutputDataConfigToHclTerraform(struct?: BedrockEvaluationJobOutputDataConfig | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobOutputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEvaluationJobOutputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobOutputDataConfig | cdktn.IResolvable | undefined);
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    get s3UriInput(): string | undefined;
}
export declare class BedrockEvaluationJobOutputDataConfigList extends cdktn.ComplexList {
    internalValue?: BedrockEvaluationJobOutputDataConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEvaluationJobOutputDataConfigOutputReference;
}
export interface BedrockEvaluationJobTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#create BedrockEvaluationJob#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#delete BedrockEvaluationJob#delete}
    */
    readonly delete?: string;
}
export declare function bedrockEvaluationJobTimeoutsToTerraform(struct?: BedrockEvaluationJobTimeouts | cdktn.IResolvable): any;
export declare function bedrockEvaluationJobTimeoutsToHclTerraform(struct?: BedrockEvaluationJobTimeouts | cdktn.IResolvable): any;
export declare class BedrockEvaluationJobTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockEvaluationJobTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEvaluationJobTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job aws_bedrock_evaluation_job}
*/
export declare class BedrockEvaluationJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_evaluation_job";
    /**
    * Generates CDKTN code for importing a BedrockEvaluationJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockEvaluationJob to import
    * @param importFromId The id of the existing BedrockEvaluationJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockEvaluationJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_evaluation_job aws_bedrock_evaluation_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockEvaluationJobConfig
    */
    constructor(scope: Construct, id: string, config: BedrockEvaluationJobConfig);
    private _applicationType?;
    get applicationType(): string;
    set applicationType(value: string);
    resetApplicationType(): void;
    get applicationTypeInput(): string | undefined;
    get createdAt(): string;
    private _customerEncryptionKeyId?;
    get customerEncryptionKeyId(): string;
    set customerEncryptionKeyId(value: string);
    resetCustomerEncryptionKeyId(): void;
    get customerEncryptionKeyIdInput(): string | undefined;
    get failureMessages(): string[];
    get jobArn(): string;
    private _jobDescription?;
    get jobDescription(): string;
    set jobDescription(value: string);
    resetJobDescription(): void;
    get jobDescriptionInput(): string | undefined;
    private _jobName?;
    get jobName(): string;
    set jobName(value: string);
    get jobNameInput(): string | undefined;
    get jobType(): string;
    get lastModifiedTime(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _evaluationConfig;
    get evaluationConfig(): BedrockEvaluationJobEvaluationConfigList;
    putEvaluationConfig(value: BedrockEvaluationJobEvaluationConfig[] | cdktn.IResolvable): void;
    resetEvaluationConfig(): void;
    get evaluationConfigInput(): cdktn.IResolvable | BedrockEvaluationJobEvaluationConfig[] | undefined;
    private _inferenceConfig;
    get inferenceConfig(): BedrockEvaluationJobInferenceConfigList;
    putInferenceConfig(value: BedrockEvaluationJobInferenceConfig[] | cdktn.IResolvable): void;
    resetInferenceConfig(): void;
    get inferenceConfigInput(): cdktn.IResolvable | BedrockEvaluationJobInferenceConfig[] | undefined;
    private _outputDataConfig;
    get outputDataConfig(): BedrockEvaluationJobOutputDataConfigList;
    putOutputDataConfig(value: BedrockEvaluationJobOutputDataConfig[] | cdktn.IResolvable): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | BedrockEvaluationJobOutputDataConfig[] | undefined;
    private _timeouts;
    get timeouts(): BedrockEvaluationJobTimeoutsOutputReference;
    putTimeouts(value: BedrockEvaluationJobTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockEvaluationJobTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
