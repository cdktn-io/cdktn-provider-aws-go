/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountaccessApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#region AccountaccessApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#tags AccountaccessApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * identity_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#identity_source AccountaccessApplication#identity_source}
    */
    readonly identitySource?: AccountaccessApplicationIdentitySource[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#timeouts AccountaccessApplication#timeouts}
    */
    readonly timeouts?: AccountaccessApplicationTimeouts;
}
export interface AccountaccessApplicationIdentitySourceIdentityCenter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#instance_arn AccountaccessApplication#instance_arn}
    */
    readonly instanceArn: string;
}
export declare function accountaccessApplicationIdentitySourceIdentityCenterToTerraform(struct?: AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable): any;
export declare function accountaccessApplicationIdentitySourceIdentityCenterToHclTerraform(struct?: AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable): any;
export declare class AccountaccessApplicationIdentitySourceIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessApplicationIdentitySourceIdentityCenter | cdktn.IResolvable | undefined);
    get applicationArn(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
}
export declare class AccountaccessApplicationIdentitySourceIdentityCenterList extends cdktn.ComplexList {
    internalValue?: AccountaccessApplicationIdentitySourceIdentityCenter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountaccessApplicationIdentitySourceIdentityCenterOutputReference;
}
export interface AccountaccessApplicationIdentitySource {
    /**
    * identity_center block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#identity_center AccountaccessApplication#identity_center}
    */
    readonly identityCenter?: AccountaccessApplicationIdentitySourceIdentityCenter[] | cdktn.IResolvable;
}
export declare function accountaccessApplicationIdentitySourceToTerraform(struct?: AccountaccessApplicationIdentitySource | cdktn.IResolvable): any;
export declare function accountaccessApplicationIdentitySourceToHclTerraform(struct?: AccountaccessApplicationIdentitySource | cdktn.IResolvable): any;
export declare class AccountaccessApplicationIdentitySourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountaccessApplicationIdentitySource | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessApplicationIdentitySource | cdktn.IResolvable | undefined);
    private _identityCenter;
    get identityCenter(): AccountaccessApplicationIdentitySourceIdentityCenterList;
    putIdentityCenter(value: AccountaccessApplicationIdentitySourceIdentityCenter[] | cdktn.IResolvable): void;
    resetIdentityCenter(): void;
    get identityCenterInput(): cdktn.IResolvable | AccountaccessApplicationIdentitySourceIdentityCenter[] | undefined;
}
export declare class AccountaccessApplicationIdentitySourceList extends cdktn.ComplexList {
    internalValue?: AccountaccessApplicationIdentitySource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountaccessApplicationIdentitySourceOutputReference;
}
export interface AccountaccessApplicationTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#create AccountaccessApplication#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#delete AccountaccessApplication#delete}
    */
    readonly delete?: string;
}
export declare function accountaccessApplicationTimeoutsToTerraform(struct?: AccountaccessApplicationTimeouts | cdktn.IResolvable): any;
export declare function accountaccessApplicationTimeoutsToHclTerraform(struct?: AccountaccessApplicationTimeouts | cdktn.IResolvable): any;
export declare class AccountaccessApplicationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountaccessApplicationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessApplicationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application aws_accountaccess_application}
*/
export declare class AccountaccessApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_accountaccess_application";
    /**
    * Generates CDKTN code for importing a AccountaccessApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountaccessApplication to import
    * @param importFromId The id of the existing AccountaccessApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountaccessApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/accountaccess_application aws_accountaccess_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountaccessApplicationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AccountaccessApplicationConfig);
    get arn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get tenantId(): string;
    private _identitySource;
    get identitySource(): AccountaccessApplicationIdentitySourceList;
    putIdentitySource(value: AccountaccessApplicationIdentitySource[] | cdktn.IResolvable): void;
    resetIdentitySource(): void;
    get identitySourceInput(): cdktn.IResolvable | AccountaccessApplicationIdentitySource[] | undefined;
    private _timeouts;
    get timeouts(): AccountaccessApplicationTimeoutsOutputReference;
    putTimeouts(value: AccountaccessApplicationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccountaccessApplicationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
