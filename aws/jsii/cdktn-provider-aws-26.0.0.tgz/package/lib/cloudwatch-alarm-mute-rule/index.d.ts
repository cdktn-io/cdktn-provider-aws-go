/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchAlarmMuteRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#description CloudwatchAlarmMuteRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#expire_date CloudwatchAlarmMuteRule#expire_date}
    */
    readonly expireDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#name CloudwatchAlarmMuteRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#region CloudwatchAlarmMuteRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#start_date CloudwatchAlarmMuteRule#start_date}
    */
    readonly startDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#tags CloudwatchAlarmMuteRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * mute_targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#mute_targets CloudwatchAlarmMuteRule#mute_targets}
    */
    readonly muteTargets?: CloudwatchAlarmMuteRuleMuteTargets[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#rule CloudwatchAlarmMuteRule#rule}
    */
    readonly rule?: CloudwatchAlarmMuteRuleRule[] | cdktn.IResolvable;
}
export interface CloudwatchAlarmMuteRuleMuteTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#alarm_names CloudwatchAlarmMuteRule#alarm_names}
    */
    readonly alarmNames: string[];
}
export declare function cloudwatchAlarmMuteRuleMuteTargetsToTerraform(struct?: CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMuteRuleMuteTargetsToHclTerraform(struct?: CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMuteRuleMuteTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMuteRuleMuteTargets | cdktn.IResolvable | undefined);
    private _alarmNames?;
    get alarmNames(): string[];
    set alarmNames(value: string[]);
    get alarmNamesInput(): string[] | undefined;
}
export declare class CloudwatchAlarmMuteRuleMuteTargetsList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmMuteRuleMuteTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmMuteRuleMuteTargetsOutputReference;
}
export interface CloudwatchAlarmMuteRuleRuleSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#duration CloudwatchAlarmMuteRule#duration}
    */
    readonly duration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#expression CloudwatchAlarmMuteRule#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#timezone CloudwatchAlarmMuteRule#timezone}
    */
    readonly timezone?: string;
}
export declare function cloudwatchAlarmMuteRuleRuleScheduleToTerraform(struct?: CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMuteRuleRuleScheduleToHclTerraform(struct?: CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMuteRuleRuleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMuteRuleRuleSchedule | cdktn.IResolvable | undefined);
    private _duration?;
    get duration(): string;
    set duration(value: string);
    get durationInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export declare class CloudwatchAlarmMuteRuleRuleScheduleList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmMuteRuleRuleSchedule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmMuteRuleRuleScheduleOutputReference;
}
export interface CloudwatchAlarmMuteRuleRule {
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#schedule CloudwatchAlarmMuteRule#schedule}
    */
    readonly schedule?: CloudwatchAlarmMuteRuleRuleSchedule[] | cdktn.IResolvable;
}
export declare function cloudwatchAlarmMuteRuleRuleToTerraform(struct?: CloudwatchAlarmMuteRuleRule | cdktn.IResolvable): any;
export declare function cloudwatchAlarmMuteRuleRuleToHclTerraform(struct?: CloudwatchAlarmMuteRuleRule | cdktn.IResolvable): any;
export declare class CloudwatchAlarmMuteRuleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchAlarmMuteRuleRule | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchAlarmMuteRuleRule | cdktn.IResolvable | undefined);
    private _schedule;
    get schedule(): CloudwatchAlarmMuteRuleRuleScheduleList;
    putSchedule(value: CloudwatchAlarmMuteRuleRuleSchedule[] | cdktn.IResolvable): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | CloudwatchAlarmMuteRuleRuleSchedule[] | undefined;
}
export declare class CloudwatchAlarmMuteRuleRuleList extends cdktn.ComplexList {
    internalValue?: CloudwatchAlarmMuteRuleRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchAlarmMuteRuleRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule aws_cloudwatch_alarm_mute_rule}
*/
export declare class CloudwatchAlarmMuteRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_alarm_mute_rule";
    /**
    * Generates CDKTN code for importing a CloudwatchAlarmMuteRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchAlarmMuteRule to import
    * @param importFromId The id of the existing CloudwatchAlarmMuteRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchAlarmMuteRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_alarm_mute_rule aws_cloudwatch_alarm_mute_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchAlarmMuteRuleConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchAlarmMuteRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expireDate?;
    get expireDate(): string;
    set expireDate(value: string);
    resetExpireDate(): void;
    get expireDateInput(): string | undefined;
    get lastUpdatedTimestamp(): string;
    get muteType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _muteTargets;
    get muteTargets(): CloudwatchAlarmMuteRuleMuteTargetsList;
    putMuteTargets(value: CloudwatchAlarmMuteRuleMuteTargets[] | cdktn.IResolvable): void;
    resetMuteTargets(): void;
    get muteTargetsInput(): cdktn.IResolvable | CloudwatchAlarmMuteRuleMuteTargets[] | undefined;
    private _rule;
    get rule(): CloudwatchAlarmMuteRuleRuleList;
    putRule(value: CloudwatchAlarmMuteRuleRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | CloudwatchAlarmMuteRuleRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
