/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAccountRegionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/account_regions#account_id DataAwsAccountRegions#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/account_regions#region_opt_status_contains DataAwsAccountRegions#region_opt_status_contains}
    */
    readonly regionOptStatusContains?: string[];
}
export interface DataAwsAccountRegionsRegions {
}
export declare function dataAwsAccountRegionsRegionsToTerraform(struct?: DataAwsAccountRegionsRegions): any;
export declare function dataAwsAccountRegionsRegionsToHclTerraform(struct?: DataAwsAccountRegionsRegions): any;
export declare class DataAwsAccountRegionsRegionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountRegionsRegions | undefined;
    set internalValue(value: DataAwsAccountRegionsRegions | undefined);
    get regionName(): string;
    get regionOptStatus(): string;
}
export declare class DataAwsAccountRegionsRegionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountRegionsRegionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/account_regions aws_account_regions}
*/
export declare class DataAwsAccountRegions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_account_regions";
    /**
    * Generates CDKTN code for importing a DataAwsAccountRegions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAccountRegions to import
    * @param importFromId The id of the existing DataAwsAccountRegions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/account_regions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAccountRegions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/account_regions aws_account_regions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAccountRegionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsAccountRegionsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _regionOptStatusContains?;
    get regionOptStatusContains(): string[];
    set regionOptStatusContains(value: string[]);
    resetRegionOptStatusContains(): void;
    get regionOptStatusContainsInput(): string[] | undefined;
    private _regions;
    get regions(): DataAwsAccountRegionsRegionsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
