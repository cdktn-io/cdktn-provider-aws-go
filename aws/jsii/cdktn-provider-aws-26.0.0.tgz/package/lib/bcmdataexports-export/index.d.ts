/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BcmdataexportsExportConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#tags BcmdataexportsExport#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * export block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#export BcmdataexportsExport#export}
    */
    readonly export?: BcmdataexportsExportExport[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#timeouts BcmdataexportsExport#timeouts}
    */
    readonly timeouts?: BcmdataexportsExportTimeouts;
}
export interface BcmdataexportsExportExportDataQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#query_statement BcmdataexportsExport#query_statement}
    */
    readonly queryStatement: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#table_configurations BcmdataexportsExport#table_configurations}
    */
    readonly tableConfigurations?: {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable;
}
export declare function bcmdataexportsExportExportDataQueryToTerraform(struct?: BcmdataexportsExportExportDataQuery | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDataQueryToHclTerraform(struct?: BcmdataexportsExportExportDataQuery | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDataQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmdataexportsExportExportDataQuery | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDataQuery | cdktn.IResolvable | undefined);
    private _queryStatement?;
    get queryStatement(): string;
    set queryStatement(value: string);
    get queryStatementInput(): string | undefined;
    private _tableConfigurations?;
    get tableConfigurations(): {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable;
    set tableConfigurations(value: {
        [key: string]: {
            [key: string]: string;
        };
    } | cdktn.IResolvable);
    resetTableConfigurations(): void;
    get tableConfigurationsInput(): cdktn.IResolvable | {
        [key: string]: {
            [key: string]: string;
        };
    } | undefined;
}
export declare class BcmdataexportsExportExportDataQueryList extends cdktn.ComplexList {
    internalValue?: BcmdataexportsExportExportDataQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmdataexportsExportExportDataQueryOutputReference;
}
export interface BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#compression BcmdataexportsExport#compression}
    */
    readonly compression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#format BcmdataexportsExport#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#output_type BcmdataexportsExport#output_type}
    */
    readonly outputType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#overwrite BcmdataexportsExport#overwrite}
    */
    readonly overwrite: string;
}
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsToTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsToHclTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations | cdktn.IResolvable | undefined);
    private _compression?;
    get compression(): string;
    set compression(value: string);
    get compressionInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _outputType?;
    get outputType(): string;
    set outputType(value: string);
    get outputTypeInput(): string | undefined;
    private _overwrite?;
    get overwrite(): string;
    set overwrite(value: string);
    get overwriteInput(): string | undefined;
}
export declare class BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsList extends cdktn.ComplexList {
    internalValue?: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsOutputReference;
}
export interface BcmdataexportsExportExportDestinationConfigurationsS3Destination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#s3_bucket BcmdataexportsExport#s3_bucket}
    */
    readonly s3Bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#s3_prefix BcmdataexportsExport#s3_prefix}
    */
    readonly s3Prefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#s3_region BcmdataexportsExport#s3_region}
    */
    readonly s3Region: string;
    /**
    * s3_output_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#s3_output_configurations BcmdataexportsExport#s3_output_configurations}
    */
    readonly s3OutputConfigurations?: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations[] | cdktn.IResolvable;
}
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationToTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDestinationConfigurationsS3DestinationToHclTerraform(struct?: BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDestinationConfigurationsS3DestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDestinationConfigurationsS3Destination | cdktn.IResolvable | undefined);
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    get s3BucketInput(): string | undefined;
    private _s3Prefix?;
    get s3Prefix(): string;
    set s3Prefix(value: string);
    get s3PrefixInput(): string | undefined;
    private _s3Region?;
    get s3Region(): string;
    set s3Region(value: string);
    get s3RegionInput(): string | undefined;
    private _s3OutputConfigurations;
    get s3OutputConfigurations(): BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurationsList;
    putS3OutputConfigurations(value: BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations[] | cdktn.IResolvable): void;
    resetS3OutputConfigurations(): void;
    get s3OutputConfigurationsInput(): cdktn.IResolvable | BcmdataexportsExportExportDestinationConfigurationsS3DestinationS3OutputConfigurations[] | undefined;
}
export declare class BcmdataexportsExportExportDestinationConfigurationsS3DestinationList extends cdktn.ComplexList {
    internalValue?: BcmdataexportsExportExportDestinationConfigurationsS3Destination[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmdataexportsExportExportDestinationConfigurationsS3DestinationOutputReference;
}
export interface BcmdataexportsExportExportDestinationConfigurations {
    /**
    * s3_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#s3_destination BcmdataexportsExport#s3_destination}
    */
    readonly s3Destination?: BcmdataexportsExportExportDestinationConfigurationsS3Destination[] | cdktn.IResolvable;
}
export declare function bcmdataexportsExportExportDestinationConfigurationsToTerraform(struct?: BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportDestinationConfigurationsToHclTerraform(struct?: BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportDestinationConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportDestinationConfigurations | cdktn.IResolvable | undefined);
    private _s3Destination;
    get s3Destination(): BcmdataexportsExportExportDestinationConfigurationsS3DestinationList;
    putS3Destination(value: BcmdataexportsExportExportDestinationConfigurationsS3Destination[] | cdktn.IResolvable): void;
    resetS3Destination(): void;
    get s3DestinationInput(): cdktn.IResolvable | BcmdataexportsExportExportDestinationConfigurationsS3Destination[] | undefined;
}
export declare class BcmdataexportsExportExportDestinationConfigurationsList extends cdktn.ComplexList {
    internalValue?: BcmdataexportsExportExportDestinationConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmdataexportsExportExportDestinationConfigurationsOutputReference;
}
export interface BcmdataexportsExportExportRefreshCadence {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#frequency BcmdataexportsExport#frequency}
    */
    readonly frequency: string;
}
export declare function bcmdataexportsExportExportRefreshCadenceToTerraform(struct?: BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportRefreshCadenceToHclTerraform(struct?: BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportRefreshCadenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExportRefreshCadence | cdktn.IResolvable | undefined);
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    get frequencyInput(): string | undefined;
}
export declare class BcmdataexportsExportExportRefreshCadenceList extends cdktn.ComplexList {
    internalValue?: BcmdataexportsExportExportRefreshCadence[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmdataexportsExportExportRefreshCadenceOutputReference;
}
export interface BcmdataexportsExportExport {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#description BcmdataexportsExport#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#name BcmdataexportsExport#name}
    */
    readonly name: string;
    /**
    * data_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#data_query BcmdataexportsExport#data_query}
    */
    readonly dataQuery?: BcmdataexportsExportExportDataQuery[] | cdktn.IResolvable;
    /**
    * destination_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#destination_configurations BcmdataexportsExport#destination_configurations}
    */
    readonly destinationConfigurations?: BcmdataexportsExportExportDestinationConfigurations[] | cdktn.IResolvable;
    /**
    * refresh_cadence block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#refresh_cadence BcmdataexportsExport#refresh_cadence}
    */
    readonly refreshCadence?: BcmdataexportsExportExportRefreshCadence[] | cdktn.IResolvable;
}
export declare function bcmdataexportsExportExportToTerraform(struct?: BcmdataexportsExportExport | cdktn.IResolvable): any;
export declare function bcmdataexportsExportExportToHclTerraform(struct?: BcmdataexportsExportExport | cdktn.IResolvable): any;
export declare class BcmdataexportsExportExportOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BcmdataexportsExportExport | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportExport | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get exportArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _dataQuery;
    get dataQuery(): BcmdataexportsExportExportDataQueryList;
    putDataQuery(value: BcmdataexportsExportExportDataQuery[] | cdktn.IResolvable): void;
    resetDataQuery(): void;
    get dataQueryInput(): cdktn.IResolvable | BcmdataexportsExportExportDataQuery[] | undefined;
    private _destinationConfigurations;
    get destinationConfigurations(): BcmdataexportsExportExportDestinationConfigurationsList;
    putDestinationConfigurations(value: BcmdataexportsExportExportDestinationConfigurations[] | cdktn.IResolvable): void;
    resetDestinationConfigurations(): void;
    get destinationConfigurationsInput(): cdktn.IResolvable | BcmdataexportsExportExportDestinationConfigurations[] | undefined;
    private _refreshCadence;
    get refreshCadence(): BcmdataexportsExportExportRefreshCadenceList;
    putRefreshCadence(value: BcmdataexportsExportExportRefreshCadence[] | cdktn.IResolvable): void;
    resetRefreshCadence(): void;
    get refreshCadenceInput(): cdktn.IResolvable | BcmdataexportsExportExportRefreshCadence[] | undefined;
}
export declare class BcmdataexportsExportExportList extends cdktn.ComplexList {
    internalValue?: BcmdataexportsExportExport[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BcmdataexportsExportExportOutputReference;
}
export interface BcmdataexportsExportTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#create BcmdataexportsExport#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#update BcmdataexportsExport#update}
    */
    readonly update?: string;
}
export declare function bcmdataexportsExportTimeoutsToTerraform(struct?: BcmdataexportsExportTimeouts | cdktn.IResolvable): any;
export declare function bcmdataexportsExportTimeoutsToHclTerraform(struct?: BcmdataexportsExportTimeouts | cdktn.IResolvable): any;
export declare class BcmdataexportsExportTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BcmdataexportsExportTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BcmdataexportsExportTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export aws_bcmdataexports_export}
*/
export declare class BcmdataexportsExport extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bcmdataexports_export";
    /**
    * Generates CDKTN code for importing a BcmdataexportsExport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BcmdataexportsExport to import
    * @param importFromId The id of the existing BcmdataexportsExport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BcmdataexportsExport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bcmdataexports_export aws_bcmdataexports_export} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BcmdataexportsExportConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BcmdataexportsExportConfig);
    get arn(): string;
    get id(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _export;
    get export(): BcmdataexportsExportExportList;
    putExport(value: BcmdataexportsExportExport[] | cdktn.IResolvable): void;
    resetExport(): void;
    get exportInput(): cdktn.IResolvable | BcmdataexportsExportExport[] | undefined;
    private _timeouts;
    get timeouts(): BcmdataexportsExportTimeoutsOutputReference;
    putTimeouts(value: BcmdataexportsExportTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BcmdataexportsExportTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
