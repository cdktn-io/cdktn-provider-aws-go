/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchMetricAlarmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#actions_enabled CloudwatchMetricAlarm#actions_enabled}
    */
    readonly actionsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#alarm_actions CloudwatchMetricAlarm#alarm_actions}
    */
    readonly alarmActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#alarm_description CloudwatchMetricAlarm#alarm_description}
    */
    readonly alarmDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#alarm_name CloudwatchMetricAlarm#alarm_name}
    */
    readonly alarmName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#comparison_operator CloudwatchMetricAlarm#comparison_operator}
    */
    readonly comparisonOperator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#datapoints_to_alarm CloudwatchMetricAlarm#datapoints_to_alarm}
    */
    readonly datapointsToAlarm?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#dimensions CloudwatchMetricAlarm#dimensions}
    */
    readonly dimensions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#evaluate_low_sample_count_percentiles CloudwatchMetricAlarm#evaluate_low_sample_count_percentiles}
    */
    readonly evaluateLowSampleCountPercentiles?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#evaluation_interval CloudwatchMetricAlarm#evaluation_interval}
    */
    readonly evaluationInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#evaluation_periods CloudwatchMetricAlarm#evaluation_periods}
    */
    readonly evaluationPeriods?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#extended_statistic CloudwatchMetricAlarm#extended_statistic}
    */
    readonly extendedStatistic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#id CloudwatchMetricAlarm#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#insufficient_data_actions CloudwatchMetricAlarm#insufficient_data_actions}
    */
    readonly insufficientDataActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#metric_name CloudwatchMetricAlarm#metric_name}
    */
    readonly metricName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#namespace CloudwatchMetricAlarm#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#ok_actions CloudwatchMetricAlarm#ok_actions}
    */
    readonly okActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#period CloudwatchMetricAlarm#period}
    */
    readonly period?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#region CloudwatchMetricAlarm#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#statistic CloudwatchMetricAlarm#statistic}
    */
    readonly statistic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#tags CloudwatchMetricAlarm#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#tags_all CloudwatchMetricAlarm#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#threshold CloudwatchMetricAlarm#threshold}
    */
    readonly threshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#threshold_metric_id CloudwatchMetricAlarm#threshold_metric_id}
    */
    readonly thresholdMetricId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#treat_missing_data CloudwatchMetricAlarm#treat_missing_data}
    */
    readonly treatMissingData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#unit CloudwatchMetricAlarm#unit}
    */
    readonly unit?: string;
    /**
    * evaluation_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#evaluation_criteria CloudwatchMetricAlarm#evaluation_criteria}
    */
    readonly evaluationCriteria?: CloudwatchMetricAlarmEvaluationCriteria;
    /**
    * evaluation_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#evaluation_window CloudwatchMetricAlarm#evaluation_window}
    */
    readonly evaluationWindow?: CloudwatchMetricAlarmEvaluationWindow;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#metric_query CloudwatchMetricAlarm#metric_query}
    */
    readonly metricQuery?: CloudwatchMetricAlarmMetricQuery[] | cdktn.IResolvable;
    /**
    * warm_up_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#warm_up_configuration CloudwatchMetricAlarm#warm_up_configuration}
    */
    readonly warmUpConfiguration?: CloudwatchMetricAlarmWarmUpConfiguration;
}
export interface CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#pending_period CloudwatchMetricAlarm#pending_period}
    */
    readonly pendingPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#query CloudwatchMetricAlarm#query}
    */
    readonly query: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#recovery_period CloudwatchMetricAlarm#recovery_period}
    */
    readonly recoveryPeriod?: number;
}
export declare function cloudwatchMetricAlarmEvaluationCriteriaPromqlCriteriaToTerraform(struct?: CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteriaOutputReference | CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria): any;
export declare function cloudwatchMetricAlarmEvaluationCriteriaPromqlCriteriaToHclTerraform(struct?: CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteriaOutputReference | CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria): any;
export declare class CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria | undefined;
    set internalValue(value: CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria | undefined);
    private _pendingPeriod?;
    get pendingPeriod(): number;
    set pendingPeriod(value: number);
    resetPendingPeriod(): void;
    get pendingPeriodInput(): number | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
    private _recoveryPeriod?;
    get recoveryPeriod(): number;
    set recoveryPeriod(value: number);
    resetRecoveryPeriod(): void;
    get recoveryPeriodInput(): number | undefined;
}
export interface CloudwatchMetricAlarmEvaluationCriteria {
    /**
    * promql_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#promql_criteria CloudwatchMetricAlarm#promql_criteria}
    */
    readonly promqlCriteria: CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria;
}
export declare function cloudwatchMetricAlarmEvaluationCriteriaToTerraform(struct?: CloudwatchMetricAlarmEvaluationCriteriaOutputReference | CloudwatchMetricAlarmEvaluationCriteria): any;
export declare function cloudwatchMetricAlarmEvaluationCriteriaToHclTerraform(struct?: CloudwatchMetricAlarmEvaluationCriteriaOutputReference | CloudwatchMetricAlarmEvaluationCriteria): any;
export declare class CloudwatchMetricAlarmEvaluationCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchMetricAlarmEvaluationCriteria | undefined;
    set internalValue(value: CloudwatchMetricAlarmEvaluationCriteria | undefined);
    private _promqlCriteria;
    get promqlCriteria(): CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteriaOutputReference;
    putPromqlCriteria(value: CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria): void;
    get promqlCriteriaInput(): CloudwatchMetricAlarmEvaluationCriteriaPromqlCriteria | undefined;
}
export interface CloudwatchMetricAlarmEvaluationWindowWallClockWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#timezone CloudwatchMetricAlarm#timezone}
    */
    readonly timezone?: string;
}
export declare function cloudwatchMetricAlarmEvaluationWindowWallClockWindowToTerraform(struct?: CloudwatchMetricAlarmEvaluationWindowWallClockWindowOutputReference | CloudwatchMetricAlarmEvaluationWindowWallClockWindow): any;
export declare function cloudwatchMetricAlarmEvaluationWindowWallClockWindowToHclTerraform(struct?: CloudwatchMetricAlarmEvaluationWindowWallClockWindowOutputReference | CloudwatchMetricAlarmEvaluationWindowWallClockWindow): any;
export declare class CloudwatchMetricAlarmEvaluationWindowWallClockWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchMetricAlarmEvaluationWindowWallClockWindow | undefined;
    set internalValue(value: CloudwatchMetricAlarmEvaluationWindowWallClockWindow | undefined);
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export interface CloudwatchMetricAlarmEvaluationWindow {
    /**
    * wall_clock_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#wall_clock_window CloudwatchMetricAlarm#wall_clock_window}
    */
    readonly wallClockWindow: CloudwatchMetricAlarmEvaluationWindowWallClockWindow;
}
export declare function cloudwatchMetricAlarmEvaluationWindowToTerraform(struct?: CloudwatchMetricAlarmEvaluationWindowOutputReference | CloudwatchMetricAlarmEvaluationWindow): any;
export declare function cloudwatchMetricAlarmEvaluationWindowToHclTerraform(struct?: CloudwatchMetricAlarmEvaluationWindowOutputReference | CloudwatchMetricAlarmEvaluationWindow): any;
export declare class CloudwatchMetricAlarmEvaluationWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchMetricAlarmEvaluationWindow | undefined;
    set internalValue(value: CloudwatchMetricAlarmEvaluationWindow | undefined);
    private _wallClockWindow;
    get wallClockWindow(): CloudwatchMetricAlarmEvaluationWindowWallClockWindowOutputReference;
    putWallClockWindow(value: CloudwatchMetricAlarmEvaluationWindowWallClockWindow): void;
    get wallClockWindowInput(): CloudwatchMetricAlarmEvaluationWindowWallClockWindow | undefined;
}
export interface CloudwatchMetricAlarmMetricQueryMetric {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#dimensions CloudwatchMetricAlarm#dimensions}
    */
    readonly dimensions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#metric_name CloudwatchMetricAlarm#metric_name}
    */
    readonly metricName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#namespace CloudwatchMetricAlarm#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#period CloudwatchMetricAlarm#period}
    */
    readonly period: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#stat CloudwatchMetricAlarm#stat}
    */
    readonly stat: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#unit CloudwatchMetricAlarm#unit}
    */
    readonly unit?: string;
}
export declare function cloudwatchMetricAlarmMetricQueryMetricToTerraform(struct?: CloudwatchMetricAlarmMetricQueryMetricOutputReference | CloudwatchMetricAlarmMetricQueryMetric): any;
export declare function cloudwatchMetricAlarmMetricQueryMetricToHclTerraform(struct?: CloudwatchMetricAlarmMetricQueryMetricOutputReference | CloudwatchMetricAlarmMetricQueryMetric): any;
export declare class CloudwatchMetricAlarmMetricQueryMetricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchMetricAlarmMetricQueryMetric | undefined;
    set internalValue(value: CloudwatchMetricAlarmMetricQueryMetric | undefined);
    private _dimensions?;
    get dimensions(): {
        [key: string]: string;
    };
    set dimensions(value: {
        [key: string]: string;
    });
    resetDimensions(): void;
    get dimensionsInput(): {
        [key: string]: string;
    } | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    get periodInput(): number | undefined;
    private _stat?;
    get stat(): string;
    set stat(value: string);
    get statInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
}
export interface CloudwatchMetricAlarmMetricQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#account_id CloudwatchMetricAlarm#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#expression CloudwatchMetricAlarm#expression}
    */
    readonly expression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#id CloudwatchMetricAlarm#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#label CloudwatchMetricAlarm#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#period CloudwatchMetricAlarm#period}
    */
    readonly period?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#return_data CloudwatchMetricAlarm#return_data}
    */
    readonly returnData?: boolean | cdktn.IResolvable;
    /**
    * metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#metric CloudwatchMetricAlarm#metric}
    */
    readonly metric?: CloudwatchMetricAlarmMetricQueryMetric;
}
export declare function cloudwatchMetricAlarmMetricQueryToTerraform(struct?: CloudwatchMetricAlarmMetricQuery | cdktn.IResolvable): any;
export declare function cloudwatchMetricAlarmMetricQueryToHclTerraform(struct?: CloudwatchMetricAlarmMetricQuery | cdktn.IResolvable): any;
export declare class CloudwatchMetricAlarmMetricQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchMetricAlarmMetricQuery | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchMetricAlarmMetricQuery | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _returnData?;
    get returnData(): boolean | cdktn.IResolvable;
    set returnData(value: boolean | cdktn.IResolvable);
    resetReturnData(): void;
    get returnDataInput(): boolean | cdktn.IResolvable | undefined;
    private _metric;
    get metric(): CloudwatchMetricAlarmMetricQueryMetricOutputReference;
    putMetric(value: CloudwatchMetricAlarmMetricQueryMetric): void;
    resetMetric(): void;
    get metricInput(): CloudwatchMetricAlarmMetricQueryMetric | undefined;
}
export declare class CloudwatchMetricAlarmMetricQueryList extends cdktn.ComplexList {
    internalValue?: CloudwatchMetricAlarmMetricQuery[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchMetricAlarmMetricQueryOutputReference;
}
export interface CloudwatchMetricAlarmWarmUpConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#only_start_evaluating_after_warm_up_period_ends CloudwatchMetricAlarm#only_start_evaluating_after_warm_up_period_ends}
    */
    readonly onlyStartEvaluatingAfterWarmUpPeriodEnds?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#warm_up_period_duration_in_minutes CloudwatchMetricAlarm#warm_up_period_duration_in_minutes}
    */
    readonly warmUpPeriodDurationInMinutes: number;
}
export declare function cloudwatchMetricAlarmWarmUpConfigurationToTerraform(struct?: CloudwatchMetricAlarmWarmUpConfigurationOutputReference | CloudwatchMetricAlarmWarmUpConfiguration): any;
export declare function cloudwatchMetricAlarmWarmUpConfigurationToHclTerraform(struct?: CloudwatchMetricAlarmWarmUpConfigurationOutputReference | CloudwatchMetricAlarmWarmUpConfiguration): any;
export declare class CloudwatchMetricAlarmWarmUpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchMetricAlarmWarmUpConfiguration | undefined;
    set internalValue(value: CloudwatchMetricAlarmWarmUpConfiguration | undefined);
    private _onlyStartEvaluatingAfterWarmUpPeriodEnds?;
    get onlyStartEvaluatingAfterWarmUpPeriodEnds(): boolean | cdktn.IResolvable;
    set onlyStartEvaluatingAfterWarmUpPeriodEnds(value: boolean | cdktn.IResolvable);
    resetOnlyStartEvaluatingAfterWarmUpPeriodEnds(): void;
    get onlyStartEvaluatingAfterWarmUpPeriodEndsInput(): boolean | cdktn.IResolvable | undefined;
    private _warmUpPeriodDurationInMinutes?;
    get warmUpPeriodDurationInMinutes(): number;
    set warmUpPeriodDurationInMinutes(value: number);
    get warmUpPeriodDurationInMinutesInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm aws_cloudwatch_metric_alarm}
*/
export declare class CloudwatchMetricAlarm extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_metric_alarm";
    /**
    * Generates CDKTN code for importing a CloudwatchMetricAlarm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchMetricAlarm to import
    * @param importFromId The id of the existing CloudwatchMetricAlarm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchMetricAlarm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatch_metric_alarm aws_cloudwatch_metric_alarm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchMetricAlarmConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchMetricAlarmConfig);
    private _actionsEnabled?;
    get actionsEnabled(): boolean | cdktn.IResolvable;
    set actionsEnabled(value: boolean | cdktn.IResolvable);
    resetActionsEnabled(): void;
    get actionsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _alarmActions?;
    get alarmActions(): string[];
    set alarmActions(value: string[]);
    resetAlarmActions(): void;
    get alarmActionsInput(): string[] | undefined;
    private _alarmDescription?;
    get alarmDescription(): string;
    set alarmDescription(value: string);
    resetAlarmDescription(): void;
    get alarmDescriptionInput(): string | undefined;
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    get alarmNameInput(): string | undefined;
    get arn(): string;
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    resetComparisonOperator(): void;
    get comparisonOperatorInput(): string | undefined;
    private _datapointsToAlarm?;
    get datapointsToAlarm(): number;
    set datapointsToAlarm(value: number);
    resetDatapointsToAlarm(): void;
    get datapointsToAlarmInput(): number | undefined;
    private _dimensions?;
    get dimensions(): {
        [key: string]: string;
    };
    set dimensions(value: {
        [key: string]: string;
    });
    resetDimensions(): void;
    get dimensionsInput(): {
        [key: string]: string;
    } | undefined;
    private _evaluateLowSampleCountPercentiles?;
    get evaluateLowSampleCountPercentiles(): string;
    set evaluateLowSampleCountPercentiles(value: string);
    resetEvaluateLowSampleCountPercentiles(): void;
    get evaluateLowSampleCountPercentilesInput(): string | undefined;
    private _evaluationInterval?;
    get evaluationInterval(): number;
    set evaluationInterval(value: number);
    resetEvaluationInterval(): void;
    get evaluationIntervalInput(): number | undefined;
    private _evaluationPeriods?;
    get evaluationPeriods(): number;
    set evaluationPeriods(value: number);
    resetEvaluationPeriods(): void;
    get evaluationPeriodsInput(): number | undefined;
    private _extendedStatistic?;
    get extendedStatistic(): string;
    set extendedStatistic(value: string);
    resetExtendedStatistic(): void;
    get extendedStatisticInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _insufficientDataActions?;
    get insufficientDataActions(): string[];
    set insufficientDataActions(value: string[]);
    resetInsufficientDataActions(): void;
    get insufficientDataActionsInput(): string[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _okActions?;
    get okActions(): string[];
    set okActions(value: string[]);
    resetOkActions(): void;
    get okActionsInput(): string[] | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    resetStatistic(): void;
    get statisticInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
    private _thresholdMetricId?;
    get thresholdMetricId(): string;
    set thresholdMetricId(value: string);
    resetThresholdMetricId(): void;
    get thresholdMetricIdInput(): string | undefined;
    private _treatMissingData?;
    get treatMissingData(): string;
    set treatMissingData(value: string);
    resetTreatMissingData(): void;
    get treatMissingDataInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _evaluationCriteria;
    get evaluationCriteria(): CloudwatchMetricAlarmEvaluationCriteriaOutputReference;
    putEvaluationCriteria(value: CloudwatchMetricAlarmEvaluationCriteria): void;
    resetEvaluationCriteria(): void;
    get evaluationCriteriaInput(): CloudwatchMetricAlarmEvaluationCriteria | undefined;
    private _evaluationWindow;
    get evaluationWindow(): CloudwatchMetricAlarmEvaluationWindowOutputReference;
    putEvaluationWindow(value: CloudwatchMetricAlarmEvaluationWindow): void;
    resetEvaluationWindow(): void;
    get evaluationWindowInput(): CloudwatchMetricAlarmEvaluationWindow | undefined;
    private _metricQuery;
    get metricQuery(): CloudwatchMetricAlarmMetricQueryList;
    putMetricQuery(value: CloudwatchMetricAlarmMetricQuery[] | cdktn.IResolvable): void;
    resetMetricQuery(): void;
    get metricQueryInput(): cdktn.IResolvable | CloudwatchMetricAlarmMetricQuery[] | undefined;
    private _warmUpConfiguration;
    get warmUpConfiguration(): CloudwatchMetricAlarmWarmUpConfigurationOutputReference;
    putWarmUpConfiguration(value: CloudwatchMetricAlarmWarmUpConfiguration): void;
    resetWarmUpConfiguration(): void;
    get warmUpConfigurationInput(): CloudwatchMetricAlarmWarmUpConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
