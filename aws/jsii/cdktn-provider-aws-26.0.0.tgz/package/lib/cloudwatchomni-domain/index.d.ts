/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchomniDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain#identity_providers CloudwatchomniDomain#identity_providers}
    */
    readonly identityProviders: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain#name CloudwatchomniDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain#region CloudwatchomniDomain#region}
    */
    readonly region?: string;
    /**
    * identity_provider_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain#identity_provider_configuration CloudwatchomniDomain#identity_provider_configuration}
    */
    readonly identityProviderConfiguration?: CloudwatchomniDomainIdentityProviderConfiguration[] | cdktn.IResolvable;
}
export interface CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain#identity_center_instance_arn CloudwatchomniDomain#identity_center_instance_arn}
    */
    readonly identityCenterInstanceArn: string;
}
export declare function cloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfigurationToTerraform(struct?: CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfigurationToHclTerraform(struct?: CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterInstanceArn?;
    get identityCenterInstanceArn(): string;
    set identityCenterInstanceArn(value: string);
    get identityCenterInstanceArnInput(): string | undefined;
}
export declare class CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfigurationList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfigurationOutputReference;
}
export interface CloudwatchomniDomainIdentityProviderConfiguration {
    /**
    * identity_center_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain#identity_center_configuration CloudwatchomniDomain#identity_center_configuration}
    */
    readonly identityCenterConfiguration?: CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | cdktn.IResolvable;
}
export declare function cloudwatchomniDomainIdentityProviderConfigurationToTerraform(struct?: CloudwatchomniDomainIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchomniDomainIdentityProviderConfigurationToHclTerraform(struct?: CloudwatchomniDomainIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchomniDomainIdentityProviderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniDomainIdentityProviderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniDomainIdentityProviderConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterConfiguration;
    get identityCenterConfiguration(): CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfigurationList;
    putIdentityCenterConfiguration(value: CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | cdktn.IResolvable): void;
    resetIdentityCenterConfiguration(): void;
    get identityCenterConfigurationInput(): cdktn.IResolvable | CloudwatchomniDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | undefined;
}
export declare class CloudwatchomniDomainIdentityProviderConfigurationList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniDomainIdentityProviderConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniDomainIdentityProviderConfigurationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain aws_cloudwatchomni_domain}
*/
export declare class CloudwatchomniDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatchomni_domain";
    /**
    * Generates CDKTN code for importing a CloudwatchomniDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchomniDomain to import
    * @param importFromId The id of the existing CloudwatchomniDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchomniDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_domain aws_cloudwatchomni_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchomniDomainConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchomniDomainConfig);
    get arn(): string;
    get customEndpointUrls(): string[];
    get domainEndpointUrl(): string;
    get domainId(): string;
    get identityCenterApplicationArn(): string;
    private _identityProviders?;
    get identityProviders(): string[];
    set identityProviders(value: string[]);
    get identityProvidersInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _identityProviderConfiguration;
    get identityProviderConfiguration(): CloudwatchomniDomainIdentityProviderConfigurationList;
    putIdentityProviderConfiguration(value: CloudwatchomniDomainIdentityProviderConfiguration[] | cdktn.IResolvable): void;
    resetIdentityProviderConfiguration(): void;
    get identityProviderConfigurationInput(): cdktn.IResolvable | CloudwatchomniDomainIdentityProviderConfiguration[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
