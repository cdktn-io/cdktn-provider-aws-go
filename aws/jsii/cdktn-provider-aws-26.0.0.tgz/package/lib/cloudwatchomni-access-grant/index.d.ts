/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchomniAccessGrantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#domain_id CloudwatchomniAccessGrant#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#name CloudwatchomniAccessGrant#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#permission CloudwatchomniAccessGrant#permission}
    */
    readonly permission: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#region CloudwatchomniAccessGrant#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#space_id CloudwatchomniAccessGrant#space_id}
    */
    readonly spaceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#tags CloudwatchomniAccessGrant#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#principal CloudwatchomniAccessGrant#principal}
    */
    readonly principal?: CloudwatchomniAccessGrantPrincipal[] | cdktn.IResolvable;
    /**
    * scoped_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#scoped_action CloudwatchomniAccessGrant#scoped_action}
    */
    readonly scopedAction?: CloudwatchomniAccessGrantScopedAction[] | cdktn.IResolvable;
}
export interface CloudwatchomniAccessGrantPrincipalPrincipalAttribute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#key CloudwatchomniAccessGrant#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#value CloudwatchomniAccessGrant#value}
    */
    readonly value: string;
}
export declare function cloudwatchomniAccessGrantPrincipalPrincipalAttributeToTerraform(struct?: CloudwatchomniAccessGrantPrincipalPrincipalAttribute | cdktn.IResolvable): any;
export declare function cloudwatchomniAccessGrantPrincipalPrincipalAttributeToHclTerraform(struct?: CloudwatchomniAccessGrantPrincipalPrincipalAttribute | cdktn.IResolvable): any;
export declare class CloudwatchomniAccessGrantPrincipalPrincipalAttributeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniAccessGrantPrincipalPrincipalAttribute | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniAccessGrantPrincipalPrincipalAttribute | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CloudwatchomniAccessGrantPrincipalPrincipalAttributeList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniAccessGrantPrincipalPrincipalAttribute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniAccessGrantPrincipalPrincipalAttributeOutputReference;
}
export interface CloudwatchomniAccessGrantPrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#principal_id CloudwatchomniAccessGrant#principal_id}
    */
    readonly principalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#principal_type CloudwatchomniAccessGrant#principal_type}
    */
    readonly principalType: string;
    /**
    * principal_attribute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#principal_attribute CloudwatchomniAccessGrant#principal_attribute}
    */
    readonly principalAttribute?: CloudwatchomniAccessGrantPrincipalPrincipalAttribute[] | cdktn.IResolvable;
}
export declare function cloudwatchomniAccessGrantPrincipalToTerraform(struct?: CloudwatchomniAccessGrantPrincipal | cdktn.IResolvable): any;
export declare function cloudwatchomniAccessGrantPrincipalToHclTerraform(struct?: CloudwatchomniAccessGrantPrincipal | cdktn.IResolvable): any;
export declare class CloudwatchomniAccessGrantPrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniAccessGrantPrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniAccessGrantPrincipal | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): string;
    set principalId(value: string);
    resetPrincipalId(): void;
    get principalIdInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    get principalTypeInput(): string | undefined;
    private _principalAttribute;
    get principalAttribute(): CloudwatchomniAccessGrantPrincipalPrincipalAttributeList;
    putPrincipalAttribute(value: CloudwatchomniAccessGrantPrincipalPrincipalAttribute[] | cdktn.IResolvable): void;
    resetPrincipalAttribute(): void;
    get principalAttributeInput(): cdktn.IResolvable | CloudwatchomniAccessGrantPrincipalPrincipalAttribute[] | undefined;
}
export declare class CloudwatchomniAccessGrantPrincipalList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniAccessGrantPrincipal[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniAccessGrantPrincipalOutputReference;
}
export interface CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#field CloudwatchomniAccessGrant#field}
    */
    readonly field: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#operator CloudwatchomniAccessGrant#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#values CloudwatchomniAccessGrant#values}
    */
    readonly values: string[];
}
export declare function cloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScopeToTerraform(struct?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope | cdktn.IResolvable): any;
export declare function cloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScopeToHclTerraform(struct?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope | cdktn.IResolvable): any;
export declare class CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope | cdktn.IResolvable | undefined);
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScopeList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScopeOutputReference;
}
export interface CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup {
    /**
    * row_scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#row_scope CloudwatchomniAccessGrant#row_scope}
    */
    readonly rowScope?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope[] | cdktn.IResolvable;
}
export declare function cloudwatchomniAccessGrantScopedActionResourceRowScopeGroupToTerraform(struct?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup | cdktn.IResolvable): any;
export declare function cloudwatchomniAccessGrantScopedActionResourceRowScopeGroupToHclTerraform(struct?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup | cdktn.IResolvable): any;
export declare class CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup | cdktn.IResolvable | undefined);
    private _rowScope;
    get rowScope(): CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScopeList;
    putRowScope(value: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope[] | cdktn.IResolvable): void;
    resetRowScope(): void;
    get rowScopeInput(): cdktn.IResolvable | CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupRowScope[] | undefined;
}
export declare class CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupOutputReference;
}
export interface CloudwatchomniAccessGrantScopedActionResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#resource_arns CloudwatchomniAccessGrant#resource_arns}
    */
    readonly resourceArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#resource_type CloudwatchomniAccessGrant#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#signal_types CloudwatchomniAccessGrant#signal_types}
    */
    readonly signalTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#tags CloudwatchomniAccessGrant#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * row_scope_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#row_scope_group CloudwatchomniAccessGrant#row_scope_group}
    */
    readonly rowScopeGroup?: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup[] | cdktn.IResolvable;
}
export declare function cloudwatchomniAccessGrantScopedActionResourceToTerraform(struct?: CloudwatchomniAccessGrantScopedActionResource | cdktn.IResolvable): any;
export declare function cloudwatchomniAccessGrantScopedActionResourceToHclTerraform(struct?: CloudwatchomniAccessGrantScopedActionResource | cdktn.IResolvable): any;
export declare class CloudwatchomniAccessGrantScopedActionResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniAccessGrantScopedActionResource | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniAccessGrantScopedActionResource | cdktn.IResolvable | undefined);
    private _resourceArns?;
    get resourceArns(): string[];
    set resourceArns(value: string[]);
    resetResourceArns(): void;
    get resourceArnsInput(): string[] | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _signalTypes?;
    get signalTypes(): string[];
    set signalTypes(value: string[]);
    resetSignalTypes(): void;
    get signalTypesInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _rowScopeGroup;
    get rowScopeGroup(): CloudwatchomniAccessGrantScopedActionResourceRowScopeGroupList;
    putRowScopeGroup(value: CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup[] | cdktn.IResolvable): void;
    resetRowScopeGroup(): void;
    get rowScopeGroupInput(): cdktn.IResolvable | CloudwatchomniAccessGrantScopedActionResourceRowScopeGroup[] | undefined;
}
export declare class CloudwatchomniAccessGrantScopedActionResourceList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniAccessGrantScopedActionResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniAccessGrantScopedActionResourceOutputReference;
}
export interface CloudwatchomniAccessGrantScopedAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#actions CloudwatchomniAccessGrant#actions}
    */
    readonly actions: string[];
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#resource CloudwatchomniAccessGrant#resource}
    */
    readonly resource?: CloudwatchomniAccessGrantScopedActionResource[] | cdktn.IResolvable;
}
export declare function cloudwatchomniAccessGrantScopedActionToTerraform(struct?: CloudwatchomniAccessGrantScopedAction | cdktn.IResolvable): any;
export declare function cloudwatchomniAccessGrantScopedActionToHclTerraform(struct?: CloudwatchomniAccessGrantScopedAction | cdktn.IResolvable): any;
export declare class CloudwatchomniAccessGrantScopedActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniAccessGrantScopedAction | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniAccessGrantScopedAction | cdktn.IResolvable | undefined);
    private _actions?;
    get actions(): string[];
    set actions(value: string[]);
    get actionsInput(): string[] | undefined;
    private _resource;
    get resource(): CloudwatchomniAccessGrantScopedActionResourceList;
    putResource(value: CloudwatchomniAccessGrantScopedActionResource[] | cdktn.IResolvable): void;
    resetResource(): void;
    get resourceInput(): cdktn.IResolvable | CloudwatchomniAccessGrantScopedActionResource[] | undefined;
}
export declare class CloudwatchomniAccessGrantScopedActionList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniAccessGrantScopedAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniAccessGrantScopedActionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant aws_cloudwatchomni_access_grant}
*/
export declare class CloudwatchomniAccessGrant extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatchomni_access_grant";
    /**
    * Generates CDKTN code for importing a CloudwatchomniAccessGrant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchomniAccessGrant to import
    * @param importFromId The id of the existing CloudwatchomniAccessGrant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchomniAccessGrant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudwatchomni_access_grant aws_cloudwatchomni_access_grant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchomniAccessGrantConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchomniAccessGrantConfig);
    get arn(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    get grantId(): string;
    get grantType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _principal;
    get principal(): CloudwatchomniAccessGrantPrincipalList;
    putPrincipal(value: CloudwatchomniAccessGrantPrincipal[] | cdktn.IResolvable): void;
    resetPrincipal(): void;
    get principalInput(): cdktn.IResolvable | CloudwatchomniAccessGrantPrincipal[] | undefined;
    private _scopedAction;
    get scopedAction(): CloudwatchomniAccessGrantScopedActionList;
    putScopedAction(value: CloudwatchomniAccessGrantScopedAction[] | cdktn.IResolvable): void;
    resetScopedAction(): void;
    get scopedActionInput(): cdktn.IResolvable | CloudwatchomniAccessGrantScopedAction[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
