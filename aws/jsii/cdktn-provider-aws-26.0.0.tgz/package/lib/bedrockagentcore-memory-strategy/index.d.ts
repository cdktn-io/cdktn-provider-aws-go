/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreMemoryStrategyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#description BedrockagentcoreMemoryStrategy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#memory_execution_role_arn BedrockagentcoreMemoryStrategy#memory_execution_role_arn}
    */
    readonly memoryExecutionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#memory_id BedrockagentcoreMemoryStrategy#memory_id}
    */
    readonly memoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#name BedrockagentcoreMemoryStrategy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#namespace_templates BedrockagentcoreMemoryStrategy#namespace_templates}
    */
    readonly namespaceTemplates?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#namespaces BedrockagentcoreMemoryStrategy#namespaces}
    */
    readonly namespaces?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#region BedrockagentcoreMemoryStrategy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#type BedrockagentcoreMemoryStrategy#type}
    */
    readonly type: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#configuration BedrockagentcoreMemoryStrategy#configuration}
    */
    readonly configuration?: BedrockagentcoreMemoryStrategyConfiguration[] | cdktn.IResolvable;
    /**
    * memory_record_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#memory_record_schema BedrockagentcoreMemoryStrategy#memory_record_schema}
    */
    readonly memoryRecordSchema?: BedrockagentcoreMemoryStrategyMemoryRecordSchema[] | cdktn.IResolvable;
    /**
    * reflection_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#reflection_configuration BedrockagentcoreMemoryStrategy#reflection_configuration}
    */
    readonly reflectionConfiguration?: BedrockagentcoreMemoryStrategyReflectionConfiguration[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#timeouts BedrockagentcoreMemoryStrategy#timeouts}
    */
    readonly timeouts?: BedrockagentcoreMemoryStrategyTimeouts;
}
export interface BedrockagentcoreMemoryStrategyConfigurationConsolidation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#append_to_prompt BedrockagentcoreMemoryStrategy#append_to_prompt}
    */
    readonly appendToPrompt: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#model_id BedrockagentcoreMemoryStrategy#model_id}
    */
    readonly modelId: string;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationConsolidationToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationConsolidation | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationConsolidationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationConsolidation | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationConsolidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationConsolidation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationConsolidation | cdktn.IResolvable | undefined);
    private _appendToPrompt?;
    get appendToPrompt(): string;
    set appendToPrompt(value: string);
    get appendToPromptInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationConsolidationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationConsolidation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationConsolidationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationExtraction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#append_to_prompt BedrockagentcoreMemoryStrategy#append_to_prompt}
    */
    readonly appendToPrompt: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#model_id BedrockagentcoreMemoryStrategy#model_id}
    */
    readonly modelId: string;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationExtractionToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationExtraction | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationExtractionToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationExtraction | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationExtractionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationExtraction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationExtraction | cdktn.IResolvable | undefined);
    private _appendToPrompt?;
    get appendToPrompt(): string;
    set appendToPrompt(value: string);
    get appendToPromptInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationExtractionList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationExtraction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationExtractionOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationReflection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#append_to_prompt BedrockagentcoreMemoryStrategy#append_to_prompt}
    */
    readonly appendToPrompt: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#model_id BedrockagentcoreMemoryStrategy#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#namespace_templates BedrockagentcoreMemoryStrategy#namespace_templates}
    */
    readonly namespaceTemplates: string[];
}
export declare function bedrockagentcoreMemoryStrategyConfigurationReflectionToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationReflection | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationReflectionToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationReflection | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationReflectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationReflection | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationReflection | cdktn.IResolvable | undefined);
    private _appendToPrompt?;
    get appendToPrompt(): string;
    set appendToPrompt(value: string);
    get appendToPromptInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _namespaceTemplates?;
    get namespaceTemplates(): string[];
    set namespaceTemplates(value: string[]);
    get namespaceTemplatesInput(): string[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationReflectionList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationReflection[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationReflectionOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTrigger {
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTrigger): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTrigger): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTrigger | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTrigger | undefined);
    get messageCount(): number;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTrigger {
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTrigger): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTrigger): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTrigger | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTrigger | undefined);
    get idleSessionTimeout(): number;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTrigger {
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTrigger): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTrigger): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTrigger | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTrigger | undefined);
    get tokenCount(): number;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActual {
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActual): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActual): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActual | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActual | undefined);
    private _messageBasedTrigger;
    get messageBasedTrigger(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerList;
    private _timeBasedTrigger;
    get timeBasedTrigger(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerList;
    private _tokenBasedTrigger;
    get tokenBasedTrigger(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerList;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#payload_delivery_bucket_name BedrockagentcoreMemoryStrategy#payload_delivery_bucket_name}
    */
    readonly payloadDeliveryBucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#topic_arn BedrockagentcoreMemoryStrategy#topic_arn}
    */
    readonly topicArn: string;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfigurationToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfigurationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration | cdktn.IResolvable | undefined);
    private _payloadDeliveryBucketName?;
    get payloadDeliveryBucketName(): string;
    set payloadDeliveryBucketName(value: string);
    get payloadDeliveryBucketNameInput(): string | undefined;
    private _topicArn?;
    get topicArn(): string;
    set topicArn(value: string);
    get topicArnInput(): string | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfigurationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#message_count BedrockagentcoreMemoryStrategy#message_count}
    */
    readonly messageCount: number;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger | cdktn.IResolvable | undefined);
    private _messageCount?;
    get messageCount(): number;
    set messageCount(value: number);
    get messageCountInput(): number | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#idle_session_timeout BedrockagentcoreMemoryStrategy#idle_session_timeout}
    */
    readonly idleSessionTimeout: number;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger | cdktn.IResolvable | undefined);
    private _idleSessionTimeout?;
    get idleSessionTimeout(): number;
    set idleSessionTimeout(value: number);
    get idleSessionTimeoutInput(): number | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#token_count BedrockagentcoreMemoryStrategy#token_count}
    */
    readonly tokenCount: number;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger | cdktn.IResolvable | undefined);
    private _tokenCount?;
    get tokenCount(): number;
    set tokenCount(value: number);
    get tokenCountInput(): number | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions {
    /**
    * message_based_trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#message_based_trigger BedrockagentcoreMemoryStrategy#message_based_trigger}
    */
    readonly messageBasedTrigger?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger[] | cdktn.IResolvable;
    /**
    * time_based_trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#time_based_trigger BedrockagentcoreMemoryStrategy#time_based_trigger}
    */
    readonly timeBasedTrigger?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger[] | cdktn.IResolvable;
    /**
    * token_based_trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#token_based_trigger BedrockagentcoreMemoryStrategy#token_based_trigger}
    */
    readonly tokenBasedTrigger?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions | cdktn.IResolvable | undefined);
    private _messageBasedTrigger;
    get messageBasedTrigger(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerList;
    putMessageBasedTrigger(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger[] | cdktn.IResolvable): void;
    resetMessageBasedTrigger(): void;
    get messageBasedTriggerInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTrigger[] | undefined;
    private _timeBasedTrigger;
    get timeBasedTrigger(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerList;
    putTimeBasedTrigger(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger[] | cdktn.IResolvable): void;
    resetTimeBasedTrigger(): void;
    get timeBasedTriggerInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTrigger[] | undefined;
    private _tokenBasedTrigger;
    get tokenBasedTrigger(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerList;
    putTokenBasedTrigger(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger[] | cdktn.IResolvable): void;
    resetTokenBasedTrigger(): void;
    get tokenBasedTriggerInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTrigger[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#historical_context_window_size BedrockagentcoreMemoryStrategy#historical_context_window_size}
    */
    readonly historicalContextWindowSize?: number;
    /**
    * invocation_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#invocation_configuration BedrockagentcoreMemoryStrategy#invocation_configuration}
    */
    readonly invocationConfiguration?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration[] | cdktn.IResolvable;
    /**
    * trigger_conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#trigger_conditions BedrockagentcoreMemoryStrategy#trigger_conditions}
    */
    readonly triggerConditions?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationToTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration | cdktn.IResolvable | undefined);
    private _historicalContextWindowSize?;
    get historicalContextWindowSize(): number;
    set historicalContextWindowSize(value: number);
    resetHistoricalContextWindowSize(): void;
    get historicalContextWindowSizeInput(): number | undefined;
    private _triggerConditionsActual;
    get triggerConditionsActual(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualList;
    private _invocationConfiguration;
    get invocationConfiguration(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfigurationList;
    putInvocationConfiguration(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration[] | cdktn.IResolvable): void;
    resetInvocationConfiguration(): void;
    get invocationConfigurationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationInvocationConfiguration[] | undefined;
    private _triggerConditions;
    get triggerConditions(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsList;
    putTriggerConditions(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions[] | cdktn.IResolvable): void;
    resetTriggerConditions(): void;
    get triggerConditionsInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditions[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#type BedrockagentcoreMemoryStrategy#type}
    */
    readonly type: string;
    /**
    * consolidation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#consolidation BedrockagentcoreMemoryStrategy#consolidation}
    */
    readonly consolidation?: BedrockagentcoreMemoryStrategyConfigurationConsolidation[] | cdktn.IResolvable;
    /**
    * extraction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#extraction BedrockagentcoreMemoryStrategy#extraction}
    */
    readonly extraction?: BedrockagentcoreMemoryStrategyConfigurationExtraction[] | cdktn.IResolvable;
    /**
    * reflection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#reflection BedrockagentcoreMemoryStrategy#reflection}
    */
    readonly reflection?: BedrockagentcoreMemoryStrategyConfigurationReflection[] | cdktn.IResolvable;
    /**
    * self_managed_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#self_managed_configuration BedrockagentcoreMemoryStrategy#self_managed_configuration}
    */
    readonly selfManagedConfiguration?: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyConfigurationToTerraform(struct?: BedrockagentcoreMemoryStrategyConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyConfigurationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyConfiguration | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _consolidation;
    get consolidation(): BedrockagentcoreMemoryStrategyConfigurationConsolidationList;
    putConsolidation(value: BedrockagentcoreMemoryStrategyConfigurationConsolidation[] | cdktn.IResolvable): void;
    resetConsolidation(): void;
    get consolidationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationConsolidation[] | undefined;
    private _extraction;
    get extraction(): BedrockagentcoreMemoryStrategyConfigurationExtractionList;
    putExtraction(value: BedrockagentcoreMemoryStrategyConfigurationExtraction[] | cdktn.IResolvable): void;
    resetExtraction(): void;
    get extractionInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationExtraction[] | undefined;
    private _reflection;
    get reflection(): BedrockagentcoreMemoryStrategyConfigurationReflectionList;
    putReflection(value: BedrockagentcoreMemoryStrategyConfigurationReflection[] | cdktn.IResolvable): void;
    resetReflection(): void;
    get reflectionInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationReflection[] | undefined;
    private _selfManagedConfiguration;
    get selfManagedConfiguration(): BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationList;
    putSelfManagedConfiguration(value: BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration[] | cdktn.IResolvable): void;
    resetSelfManagedConfiguration(): void;
    get selfManagedConfigurationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfigurationSelfManagedConfiguration[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyConfigurationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#max_value BedrockagentcoreMemoryStrategy#max_value}
    */
    readonly maxValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#min_value BedrockagentcoreMemoryStrategy#min_value}
    */
    readonly minValue?: number;
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidationToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation | cdktn.IResolvable | undefined);
    private _maxValue?;
    get maxValue(): number;
    set maxValue(value: number);
    resetMaxValue(): void;
    get maxValueInput(): number | undefined;
    private _minValue?;
    get minValue(): number;
    set minValue(value: number);
    resetMinValue(): void;
    get minValueInput(): number | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#allowed_values BedrockagentcoreMemoryStrategy#allowed_values}
    */
    readonly allowedValues?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#max_items BedrockagentcoreMemoryStrategy#max_items}
    */
    readonly maxItems?: number;
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidationToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation | cdktn.IResolvable | undefined);
    private _allowedValues?;
    get allowedValues(): string[];
    set allowedValues(value: string[]);
    resetAllowedValues(): void;
    get allowedValuesInput(): string[] | undefined;
    private _maxItems?;
    get maxItems(): number;
    set maxItems(value: number);
    resetMaxItems(): void;
    get maxItemsInput(): number | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#allowed_values BedrockagentcoreMemoryStrategy#allowed_values}
    */
    readonly allowedValues: string[];
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidationToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation | cdktn.IResolvable | undefined);
    private _allowedValues?;
    get allowedValues(): string[];
    set allowedValues(value: string[]);
    get allowedValuesInput(): string[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation {
    /**
    * number_validation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#number_validation BedrockagentcoreMemoryStrategy#number_validation}
    */
    readonly numberValidation?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation[] | cdktn.IResolvable;
    /**
    * string_list_validation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#string_list_validation BedrockagentcoreMemoryStrategy#string_list_validation}
    */
    readonly stringListValidation?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation[] | cdktn.IResolvable;
    /**
    * string_validation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#string_validation BedrockagentcoreMemoryStrategy#string_validation}
    */
    readonly stringValidation?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation | cdktn.IResolvable | undefined);
    private _numberValidation;
    get numberValidation(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidationList;
    putNumberValidation(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation[] | cdktn.IResolvable): void;
    resetNumberValidation(): void;
    get numberValidationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationNumberValidation[] | undefined;
    private _stringListValidation;
    get stringListValidation(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidationList;
    putStringListValidation(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation[] | cdktn.IResolvable): void;
    resetStringListValidation(): void;
    get stringListValidationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringListValidation[] | undefined;
    private _stringValidation;
    get stringValidation(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidationList;
    putStringValidation(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation[] | cdktn.IResolvable): void;
    resetStringValidation(): void;
    get stringValidationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationStringValidation[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#definition BedrockagentcoreMemoryStrategy#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#llm_extraction_instruction BedrockagentcoreMemoryStrategy#llm_extraction_instruction}
    */
    readonly llmExtractionInstruction?: string;
    /**
    * validation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#validation BedrockagentcoreMemoryStrategy#validation}
    */
    readonly validation?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _llmExtractionInstruction?;
    get llmExtractionInstruction(): string;
    set llmExtractionInstruction(value: string);
    resetLlmExtractionInstruction(): void;
    get llmExtractionInstructionInput(): string | undefined;
    private _validation;
    get validation(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidationList;
    putValidation(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation[] | cdktn.IResolvable): void;
    resetValidation(): void;
    get validationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigValidation[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig {
    /**
    * llm_extraction_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#llm_extraction_config BedrockagentcoreMemoryStrategy#llm_extraction_config}
    */
    readonly llmExtractionConfig?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig | cdktn.IResolvable | undefined);
    private _llmExtractionConfig;
    get llmExtractionConfig(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfigList;
    putLlmExtractionConfig(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig[] | cdktn.IResolvable): void;
    resetLlmExtractionConfig(): void;
    get llmExtractionConfigInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigLlmExtractionConfig[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#extraction_type BedrockagentcoreMemoryStrategy#extraction_type}
    */
    readonly extractionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#key BedrockagentcoreMemoryStrategy#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#type BedrockagentcoreMemoryStrategy#type}
    */
    readonly type?: string;
    /**
    * extraction_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#extraction_config BedrockagentcoreMemoryStrategy#extraction_config}
    */
    readonly extractionConfig?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema | cdktn.IResolvable | undefined);
    private _extractionType?;
    get extractionType(): string;
    set extractionType(value: string);
    resetExtractionType(): void;
    get extractionTypeInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _extractionConfig;
    get extractionConfig(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfigList;
    putExtractionConfig(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig[] | cdktn.IResolvable): void;
    resetExtractionConfig(): void;
    get extractionConfigInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaExtractionConfig[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaOutputReference;
}
export interface BedrockagentcoreMemoryStrategyMemoryRecordSchema {
    /**
    * metadata_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#metadata_schema BedrockagentcoreMemoryStrategy#metadata_schema}
    */
    readonly metadataSchema?: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaToTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyMemoryRecordSchemaToHclTerraform(struct?: BedrockagentcoreMemoryStrategyMemoryRecordSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyMemoryRecordSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyMemoryRecordSchema | cdktn.IResolvable | undefined);
    private _metadataSchema;
    get metadataSchema(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchemaList;
    putMetadataSchema(value: BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema[] | cdktn.IResolvable): void;
    resetMetadataSchema(): void;
    get metadataSchemaInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchemaMetadataSchema[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyMemoryRecordSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyMemoryRecordSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyMemoryRecordSchemaOutputReference;
}
export interface BedrockagentcoreMemoryStrategyReflectionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#namespace_templates BedrockagentcoreMemoryStrategy#namespace_templates}
    */
    readonly namespaceTemplates: string[];
}
export declare function bedrockagentcoreMemoryStrategyReflectionConfigurationToTerraform(struct?: BedrockagentcoreMemoryStrategyReflectionConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyReflectionConfigurationToHclTerraform(struct?: BedrockagentcoreMemoryStrategyReflectionConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyReflectionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStrategyReflectionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyReflectionConfiguration | cdktn.IResolvable | undefined);
    private _namespaceTemplates?;
    get namespaceTemplates(): string[];
    set namespaceTemplates(value: string[]);
    get namespaceTemplatesInput(): string[] | undefined;
}
export declare class BedrockagentcoreMemoryStrategyReflectionConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStrategyReflectionConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStrategyReflectionConfigurationOutputReference;
}
export interface BedrockagentcoreMemoryStrategyTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#create BedrockagentcoreMemoryStrategy#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#delete BedrockagentcoreMemoryStrategy#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#update BedrockagentcoreMemoryStrategy#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcoreMemoryStrategyTimeoutsToTerraform(struct?: BedrockagentcoreMemoryStrategyTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStrategyTimeoutsToHclTerraform(struct?: BedrockagentcoreMemoryStrategyTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStrategyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreMemoryStrategyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStrategyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy aws_bedrockagentcore_memory_strategy}
*/
export declare class BedrockagentcoreMemoryStrategy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_memory_strategy";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreMemoryStrategy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreMemoryStrategy to import
    * @param importFromId The id of the existing BedrockagentcoreMemoryStrategy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreMemoryStrategy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_memory_strategy aws_bedrockagentcore_memory_strategy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreMemoryStrategyConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreMemoryStrategyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _memoryExecutionRoleArn?;
    get memoryExecutionRoleArn(): string;
    set memoryExecutionRoleArn(value: string);
    resetMemoryExecutionRoleArn(): void;
    get memoryExecutionRoleArnInput(): string | undefined;
    private _memoryId?;
    get memoryId(): string;
    set memoryId(value: string);
    get memoryIdInput(): string | undefined;
    get memoryStrategyId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespaceTemplates?;
    get namespaceTemplates(): string[];
    set namespaceTemplates(value: string[]);
    resetNamespaceTemplates(): void;
    get namespaceTemplatesInput(): string[] | undefined;
    private _namespaces?;
    get namespaces(): string[];
    set namespaces(value: string[]);
    resetNamespaces(): void;
    get namespacesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): BedrockagentcoreMemoryStrategyConfigurationList;
    putConfiguration(value: BedrockagentcoreMemoryStrategyConfiguration[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyConfiguration[] | undefined;
    private _memoryRecordSchema;
    get memoryRecordSchema(): BedrockagentcoreMemoryStrategyMemoryRecordSchemaList;
    putMemoryRecordSchema(value: BedrockagentcoreMemoryStrategyMemoryRecordSchema[] | cdktn.IResolvable): void;
    resetMemoryRecordSchema(): void;
    get memoryRecordSchemaInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyMemoryRecordSchema[] | undefined;
    private _reflectionConfiguration;
    get reflectionConfiguration(): BedrockagentcoreMemoryStrategyReflectionConfigurationList;
    putReflectionConfiguration(value: BedrockagentcoreMemoryStrategyReflectionConfiguration[] | cdktn.IResolvable): void;
    resetReflectionConfiguration(): void;
    get reflectionConfigurationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyReflectionConfiguration[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreMemoryStrategyTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreMemoryStrategyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreMemoryStrategyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
