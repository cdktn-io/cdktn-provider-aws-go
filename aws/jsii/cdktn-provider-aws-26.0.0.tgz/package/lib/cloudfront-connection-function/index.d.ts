/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontConnectionFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#connection_function_code CloudfrontConnectionFunction#connection_function_code}
    */
    readonly connectionFunctionCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#name CloudfrontConnectionFunction#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#publish CloudfrontConnectionFunction#publish}
    */
    readonly publish?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#tags CloudfrontConnectionFunction#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * connection_function_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#connection_function_config CloudfrontConnectionFunction#connection_function_config}
    */
    readonly connectionFunctionConfig?: CloudfrontConnectionFunctionConnectionFunctionConfig[] | cdktn.IResolvable;
}
export interface CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#key_value_store_arn CloudfrontConnectionFunction#key_value_store_arn}
    */
    readonly keyValueStoreArn: string;
}
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationToTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation | cdktn.IResolvable): any;
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationToHclTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation | cdktn.IResolvable): any;
export declare class CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation | cdktn.IResolvable | undefined);
    private _keyValueStoreArn?;
    get keyValueStoreArn(): string;
    set keyValueStoreArn(value: string);
    get keyValueStoreArnInput(): string | undefined;
}
export declare class CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationList extends cdktn.ComplexList {
    internalValue?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationOutputReference;
}
export interface CloudfrontConnectionFunctionConnectionFunctionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#comment CloudfrontConnectionFunction#comment}
    */
    readonly comment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#runtime CloudfrontConnectionFunction#runtime}
    */
    readonly runtime: string;
    /**
    * key_value_store_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#key_value_store_association CloudfrontConnectionFunction#key_value_store_association}
    */
    readonly keyValueStoreAssociation?: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation[] | cdktn.IResolvable;
}
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigToTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable): any;
export declare function cloudfrontConnectionFunctionConnectionFunctionConfigToHclTerraform(struct?: CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable): any;
export declare class CloudfrontConnectionFunctionConnectionFunctionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontConnectionFunctionConnectionFunctionConfig | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    get commentInput(): string | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    get runtimeInput(): string | undefined;
    private _keyValueStoreAssociation;
    get keyValueStoreAssociation(): CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociationList;
    putKeyValueStoreAssociation(value: CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation[] | cdktn.IResolvable): void;
    resetKeyValueStoreAssociation(): void;
    get keyValueStoreAssociationInput(): cdktn.IResolvable | CloudfrontConnectionFunctionConnectionFunctionConfigKeyValueStoreAssociation[] | undefined;
}
export declare class CloudfrontConnectionFunctionConnectionFunctionConfigList extends cdktn.ComplexList {
    internalValue?: CloudfrontConnectionFunctionConnectionFunctionConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontConnectionFunctionConnectionFunctionConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function aws_cloudfront_connection_function}
*/
export declare class CloudfrontConnectionFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_connection_function";
    /**
    * Generates CDKTN code for importing a CloudfrontConnectionFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontConnectionFunction to import
    * @param importFromId The id of the existing CloudfrontConnectionFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontConnectionFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/cloudfront_connection_function aws_cloudfront_connection_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontConnectionFunctionConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontConnectionFunctionConfig);
    get connectionFunctionArn(): string;
    private _connectionFunctionCode?;
    get connectionFunctionCode(): string;
    set connectionFunctionCode(value: string);
    get connectionFunctionCodeInput(): string | undefined;
    get etag(): string;
    get id(): string;
    get liveStageEtag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publish?;
    get publish(): boolean | cdktn.IResolvable;
    set publish(value: boolean | cdktn.IResolvable);
    resetPublish(): void;
    get publishInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _connectionFunctionConfig;
    get connectionFunctionConfig(): CloudfrontConnectionFunctionConnectionFunctionConfigList;
    putConnectionFunctionConfig(value: CloudfrontConnectionFunctionConnectionFunctionConfig[] | cdktn.IResolvable): void;
    resetConnectionFunctionConfig(): void;
    get connectionFunctionConfigInput(): cdktn.IResolvable | CloudfrontConnectionFunctionConnectionFunctionConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
