/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAlbConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#arn DataAwsAlb#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#id DataAwsAlb#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#name DataAwsAlb#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#region DataAwsAlb#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#tags DataAwsAlb#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#timeouts DataAwsAlb#timeouts}
    */
    readonly timeouts?: DataAwsAlbTimeouts;
}
export interface DataAwsAlbAccessLogs {
}
export declare function dataAwsAlbAccessLogsToTerraform(struct?: DataAwsAlbAccessLogs): any;
export declare function dataAwsAlbAccessLogsToHclTerraform(struct?: DataAwsAlbAccessLogs): any;
export declare class DataAwsAlbAccessLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAlbAccessLogs | undefined;
    set internalValue(value: DataAwsAlbAccessLogs | undefined);
    get bucket(): string;
    get enabled(): cdktn.IResolvable;
    get prefix(): string;
}
export declare class DataAwsAlbAccessLogsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAlbAccessLogsOutputReference;
}
export interface DataAwsAlbConnectionLogs {
}
export declare function dataAwsAlbConnectionLogsToTerraform(struct?: DataAwsAlbConnectionLogs): any;
export declare function dataAwsAlbConnectionLogsToHclTerraform(struct?: DataAwsAlbConnectionLogs): any;
export declare class DataAwsAlbConnectionLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAlbConnectionLogs | undefined;
    set internalValue(value: DataAwsAlbConnectionLogs | undefined);
    get bucket(): string;
    get enabled(): cdktn.IResolvable;
    get prefix(): string;
}
export declare class DataAwsAlbConnectionLogsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAlbConnectionLogsOutputReference;
}
export interface DataAwsAlbHealthCheckLogs {
}
export declare function dataAwsAlbHealthCheckLogsToTerraform(struct?: DataAwsAlbHealthCheckLogs): any;
export declare function dataAwsAlbHealthCheckLogsToHclTerraform(struct?: DataAwsAlbHealthCheckLogs): any;
export declare class DataAwsAlbHealthCheckLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAlbHealthCheckLogs | undefined;
    set internalValue(value: DataAwsAlbHealthCheckLogs | undefined);
    get bucket(): string;
    get enabled(): cdktn.IResolvable;
    get prefix(): string;
}
export declare class DataAwsAlbHealthCheckLogsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAlbHealthCheckLogsOutputReference;
}
export interface DataAwsAlbIpamPools {
}
export declare function dataAwsAlbIpamPoolsToTerraform(struct?: DataAwsAlbIpamPools): any;
export declare function dataAwsAlbIpamPoolsToHclTerraform(struct?: DataAwsAlbIpamPools): any;
export declare class DataAwsAlbIpamPoolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAlbIpamPools | undefined;
    set internalValue(value: DataAwsAlbIpamPools | undefined);
    get ipv4IpamPoolId(): string;
}
export declare class DataAwsAlbIpamPoolsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAlbIpamPoolsOutputReference;
}
export interface DataAwsAlbSubnetMapping {
}
export declare function dataAwsAlbSubnetMappingToTerraform(struct?: DataAwsAlbSubnetMapping): any;
export declare function dataAwsAlbSubnetMappingToHclTerraform(struct?: DataAwsAlbSubnetMapping): any;
export declare class DataAwsAlbSubnetMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAlbSubnetMapping | undefined;
    set internalValue(value: DataAwsAlbSubnetMapping | undefined);
    get allocationId(): string;
    get ipv6Address(): string;
    get outpostId(): string;
    get privateIpv4Address(): string;
    get subnetId(): string;
}
export declare class DataAwsAlbSubnetMappingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAlbSubnetMappingOutputReference;
}
export interface DataAwsAlbTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#read DataAwsAlb#read}
    */
    readonly read?: string;
}
export declare function dataAwsAlbTimeoutsToTerraform(struct?: DataAwsAlbTimeouts | cdktn.IResolvable): any;
export declare function dataAwsAlbTimeoutsToHclTerraform(struct?: DataAwsAlbTimeouts | cdktn.IResolvable): any;
export declare class DataAwsAlbTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAwsAlbTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAwsAlbTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb aws_alb}
*/
export declare class DataAwsAlb extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_alb";
    /**
    * Generates CDKTN code for importing a DataAwsAlb resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAlb to import
    * @param importFromId The id of the existing DataAwsAlb that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAlb to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/data-sources/alb aws_alb} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAlbConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsAlbConfig);
    private _accessLogs;
    get accessLogs(): DataAwsAlbAccessLogsList;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get arnSuffix(): string;
    get clientKeepAlive(): number;
    private _connectionLogs;
    get connectionLogs(): DataAwsAlbConnectionLogsList;
    get customerOwnedIpv4Pool(): string;
    get desyncMitigationMode(): string;
    get dnsName(): string;
    get dnsRecordClientRoutingPolicy(): string;
    get dropInvalidHeaderFields(): cdktn.IResolvable;
    get enableCrossZoneLoadBalancing(): cdktn.IResolvable;
    get enableDeletionProtection(): cdktn.IResolvable;
    get enableHttp2(): cdktn.IResolvable;
    get enablePrefixForIpv6SourceNat(): string;
    get enableTlsVersionAndCipherSuiteHeaders(): cdktn.IResolvable;
    get enableWafFailOpen(): cdktn.IResolvable;
    get enableXffClientPort(): cdktn.IResolvable;
    get enableZonalShift(): cdktn.IResolvable;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): string;
    private _healthCheckLogs;
    get healthCheckLogs(): DataAwsAlbHealthCheckLogsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get idleTimeout(): number;
    get internal(): cdktn.IResolvable;
    get ipAddressType(): string;
    private _ipamPools;
    get ipamPools(): DataAwsAlbIpamPoolsList;
    get loadBalancerType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get preserveHostHeader(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secondaryIpsAutoAssignedPerSubnet(): number;
    get securityGroups(): string[];
    private _subnetMapping;
    get subnetMapping(): DataAwsAlbSubnetMappingList;
    get subnets(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    get xffHeaderProcessingMode(): string;
    get zoneId(): string;
    private _timeouts;
    get timeouts(): DataAwsAlbTimeoutsOutputReference;
    putTimeouts(value: DataAwsAlbTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsAlbTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
