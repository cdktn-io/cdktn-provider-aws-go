/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreCodeInterpreterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#description BedrockagentcoreCodeInterpreter#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#execution_role_arn BedrockagentcoreCodeInterpreter#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#name BedrockagentcoreCodeInterpreter#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#region BedrockagentcoreCodeInterpreter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#tags BedrockagentcoreCodeInterpreter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#certificate BedrockagentcoreCodeInterpreter#certificate}
    */
    readonly certificate?: BedrockagentcoreCodeInterpreterCertificate[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#network_configuration BedrockagentcoreCodeInterpreter#network_configuration}
    */
    readonly networkConfiguration?: BedrockagentcoreCodeInterpreterNetworkConfiguration[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#timeouts BedrockagentcoreCodeInterpreter#timeouts}
    */
    readonly timeouts?: BedrockagentcoreCodeInterpreterTimeouts;
}
export interface BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#secret_arn BedrockagentcoreCodeInterpreter#secret_arn}
    */
    readonly secretArn: string;
}
export declare function bedrockagentcoreCodeInterpreterCertificateLocationSecretsManagerToTerraform(struct?: BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterCertificateLocationSecretsManagerToHclTerraform(struct?: BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterCertificateLocationSecretsManagerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager | cdktn.IResolvable | undefined);
    private _secretArn?;
    get secretArn(): string;
    set secretArn(value: string);
    get secretArnInput(): string | undefined;
}
export declare class BedrockagentcoreCodeInterpreterCertificateLocationSecretsManagerList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCodeInterpreterCertificateLocationSecretsManagerOutputReference;
}
export interface BedrockagentcoreCodeInterpreterCertificateLocation {
    /**
    * secrets_manager block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#secrets_manager BedrockagentcoreCodeInterpreter#secrets_manager}
    */
    readonly secretsManager?: BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreCodeInterpreterCertificateLocationToTerraform(struct?: BedrockagentcoreCodeInterpreterCertificateLocation | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterCertificateLocationToHclTerraform(struct?: BedrockagentcoreCodeInterpreterCertificateLocation | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterCertificateLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCodeInterpreterCertificateLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterCertificateLocation | cdktn.IResolvable | undefined);
    private _secretsManager;
    get secretsManager(): BedrockagentcoreCodeInterpreterCertificateLocationSecretsManagerList;
    putSecretsManager(value: BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager[] | cdktn.IResolvable): void;
    resetSecretsManager(): void;
    get secretsManagerInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterCertificateLocationSecretsManager[] | undefined;
}
export declare class BedrockagentcoreCodeInterpreterCertificateLocationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCodeInterpreterCertificateLocation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCodeInterpreterCertificateLocationOutputReference;
}
export interface BedrockagentcoreCodeInterpreterCertificate {
    /**
    * location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#location BedrockagentcoreCodeInterpreter#location}
    */
    readonly location?: BedrockagentcoreCodeInterpreterCertificateLocation[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreCodeInterpreterCertificateToTerraform(struct?: BedrockagentcoreCodeInterpreterCertificate | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterCertificateToHclTerraform(struct?: BedrockagentcoreCodeInterpreterCertificate | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCodeInterpreterCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterCertificate | cdktn.IResolvable | undefined);
    private _location;
    get location(): BedrockagentcoreCodeInterpreterCertificateLocationList;
    putLocation(value: BedrockagentcoreCodeInterpreterCertificateLocation[] | cdktn.IResolvable): void;
    resetLocation(): void;
    get locationInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterCertificateLocation[] | undefined;
}
export declare class BedrockagentcoreCodeInterpreterCertificateList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCodeInterpreterCertificate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCodeInterpreterCertificateOutputReference;
}
export interface BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#security_groups BedrockagentcoreCodeInterpreter#security_groups}
    */
    readonly securityGroups: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#subnets BedrockagentcoreCodeInterpreter#subnets}
    */
    readonly subnets: string[];
}
export declare function bedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfigToTerraform(struct?: BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfigToHclTerraform(struct?: BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    get subnetsInput(): string[] | undefined;
}
export declare class BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfigOutputReference;
}
export interface BedrockagentcoreCodeInterpreterNetworkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#network_mode BedrockagentcoreCodeInterpreter#network_mode}
    */
    readonly networkMode: string;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#vpc_config BedrockagentcoreCodeInterpreter#vpc_config}
    */
    readonly vpcConfig?: BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreCodeInterpreterNetworkConfigurationToTerraform(struct?: BedrockagentcoreCodeInterpreterNetworkConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreCodeInterpreterNetworkConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreCodeInterpreterNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterNetworkConfiguration | cdktn.IResolvable | undefined);
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    get networkModeInput(): string | undefined;
    private _vpcConfig;
    get vpcConfig(): BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfigList;
    putVpcConfig(value: BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterNetworkConfigurationVpcConfig[] | undefined;
}
export declare class BedrockagentcoreCodeInterpreterNetworkConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreCodeInterpreterNetworkConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreCodeInterpreterNetworkConfigurationOutputReference;
}
export interface BedrockagentcoreCodeInterpreterTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#create BedrockagentcoreCodeInterpreter#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#delete BedrockagentcoreCodeInterpreter#delete}
    */
    readonly delete?: string;
}
export declare function bedrockagentcoreCodeInterpreterTimeoutsToTerraform(struct?: BedrockagentcoreCodeInterpreterTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreCodeInterpreterTimeoutsToHclTerraform(struct?: BedrockagentcoreCodeInterpreterTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreCodeInterpreterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreCodeInterpreterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreCodeInterpreterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter aws_bedrockagentcore_code_interpreter}
*/
export declare class BedrockagentcoreCodeInterpreter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_code_interpreter";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreCodeInterpreter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreCodeInterpreter to import
    * @param importFromId The id of the existing BedrockagentcoreCodeInterpreter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreCodeInterpreter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_code_interpreter aws_bedrockagentcore_code_interpreter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreCodeInterpreterConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreCodeInterpreterConfig);
    get codeInterpreterArn(): string;
    get codeInterpreterId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _certificate;
    get certificate(): BedrockagentcoreCodeInterpreterCertificateList;
    putCertificate(value: BedrockagentcoreCodeInterpreterCertificate[] | cdktn.IResolvable): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterCertificate[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreCodeInterpreterNetworkConfigurationList;
    putNetworkConfiguration(value: BedrockagentcoreCodeInterpreterNetworkConfiguration[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterNetworkConfiguration[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreCodeInterpreterTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreCodeInterpreterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreCodeInterpreterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
