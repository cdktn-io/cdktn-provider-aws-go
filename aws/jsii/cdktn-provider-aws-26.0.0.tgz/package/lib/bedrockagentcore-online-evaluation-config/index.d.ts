/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreOnlineEvaluationConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#description BedrockagentcoreOnlineEvaluationConfig#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#enable_on_create BedrockagentcoreOnlineEvaluationConfig#enable_on_create}
    */
    readonly enableOnCreate: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluation_execution_role_arn BedrockagentcoreOnlineEvaluationConfig#evaluation_execution_role_arn}
    */
    readonly evaluationExecutionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#execution_status BedrockagentcoreOnlineEvaluationConfig#execution_status}
    */
    readonly executionStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#online_evaluation_config_name BedrockagentcoreOnlineEvaluationConfig#online_evaluation_config_name}
    */
    readonly onlineEvaluationConfigName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#region BedrockagentcoreOnlineEvaluationConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#tags BedrockagentcoreOnlineEvaluationConfig#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * data_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#data_source_config BedrockagentcoreOnlineEvaluationConfig#data_source_config}
    */
    readonly dataSourceConfig?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig[] | cdktn.IResolvable;
    /**
    * evaluator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluator BedrockagentcoreOnlineEvaluationConfig#evaluator}
    */
    readonly evaluator?: BedrockagentcoreOnlineEvaluationConfigEvaluator[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#rule BedrockagentcoreOnlineEvaluationConfig#rule}
    */
    readonly rule?: BedrockagentcoreOnlineEvaluationConfigRule[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#timeouts BedrockagentcoreOnlineEvaluationConfig#timeouts}
    */
    readonly timeouts?: BedrockagentcoreOnlineEvaluationConfigTimeouts;
}
export interface BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig {
}
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig): any;
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig): any;
export declare class BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfig | undefined);
    get logGroupName(): string;
}
export declare class BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigOutputConfig {
}
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfig): any;
export declare function bedrockagentcoreOnlineEvaluationConfigOutputConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigOutputConfig): any;
export declare class BedrockagentcoreOnlineEvaluationConfigOutputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigOutputConfig | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigOutputConfig | undefined);
    private _cloudwatchConfig;
    get cloudwatchConfig(): BedrockagentcoreOnlineEvaluationConfigOutputConfigCloudwatchConfigList;
}
export declare class BedrockagentcoreOnlineEvaluationConfigOutputConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigOutputConfigOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#log_group_names BedrockagentcoreOnlineEvaluationConfig#log_group_names}
    */
    readonly logGroupNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#service_names BedrockagentcoreOnlineEvaluationConfig#service_names}
    */
    readonly serviceNames: string[];
}
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs | cdktn.IResolvable | undefined);
    private _logGroupNames?;
    get logGroupNames(): string[];
    set logGroupNames(value: string[]);
    get logGroupNamesInput(): string[] | undefined;
    private _serviceNames?;
    get serviceNames(): string[];
    set serviceNames(value: string[]);
    get serviceNamesInput(): string[] | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigDataSourceConfig {
    /**
    * cloudwatch_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#cloudwatch_logs BedrockagentcoreOnlineEvaluationConfig#cloudwatch_logs}
    */
    readonly cloudwatchLogs?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigDataSourceConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigDataSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig | cdktn.IResolvable | undefined);
    private _cloudwatchLogs;
    get cloudwatchLogs(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogsList;
    putCloudwatchLogs(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs[] | cdktn.IResolvable): void;
    resetCloudwatchLogs(): void;
    get cloudwatchLogsInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigDataSourceConfigCloudwatchLogs[] | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigDataSourceConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigEvaluator {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluator_id BedrockagentcoreOnlineEvaluationConfig#evaluator_id}
    */
    readonly evaluatorId: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigEvaluatorToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigEvaluator | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigEvaluatorToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigEvaluator | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigEvaluatorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigEvaluator | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigEvaluator | cdktn.IResolvable | undefined);
    private _evaluatorId?;
    get evaluatorId(): string;
    set evaluatorId(value: string);
    get evaluatorIdInput(): string | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigEvaluatorList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigEvaluator[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigEvaluatorOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleFilterValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#boolean_value BedrockagentcoreOnlineEvaluationConfig#boolean_value}
    */
    readonly booleanValue?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#double_value BedrockagentcoreOnlineEvaluationConfig#double_value}
    */
    readonly doubleValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#string_value BedrockagentcoreOnlineEvaluationConfig#string_value}
    */
    readonly stringValue?: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFilterValueToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFilterValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFilterValueToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFilterValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleFilterValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleFilterValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleFilterValue | cdktn.IResolvable | undefined);
    private _booleanValue?;
    get booleanValue(): boolean | cdktn.IResolvable;
    set booleanValue(value: boolean | cdktn.IResolvable);
    resetBooleanValue(): void;
    get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigRuleFilterValueList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigRuleFilterValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigRuleFilterValueOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#key BedrockagentcoreOnlineEvaluationConfig#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#operator BedrockagentcoreOnlineEvaluationConfig#operator}
    */
    readonly operator: string;
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#value BedrockagentcoreOnlineEvaluationConfig#value}
    */
    readonly value?: BedrockagentcoreOnlineEvaluationConfigRuleFilterValue[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFilterToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFilter | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleFilterToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleFilter | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleFilter | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _value;
    get value(): BedrockagentcoreOnlineEvaluationConfigRuleFilterValueList;
    putValue(value: BedrockagentcoreOnlineEvaluationConfigRuleFilterValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleFilterValue[] | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigRuleFilterList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigRuleFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigRuleFilterOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#sampling_percentage BedrockagentcoreOnlineEvaluationConfig#sampling_percentage}
    */
    readonly samplingPercentage: number;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig | cdktn.IResolvable | undefined);
    private _samplingPercentage?;
    get samplingPercentage(): number;
    set samplingPercentage(value: number);
    get samplingPercentageInput(): number | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#session_timeout_minutes BedrockagentcoreOnlineEvaluationConfig#session_timeout_minutes}
    */
    readonly sessionTimeoutMinutes: number;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSessionConfigToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleSessionConfigToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleSessionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig | cdktn.IResolvable | undefined);
    private _sessionTimeoutMinutes?;
    get sessionTimeoutMinutes(): number;
    set sessionTimeoutMinutes(value: number);
    get sessionTimeoutMinutesInput(): number | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigRuleSessionConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigRuleSessionConfigOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigRule {
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#filter BedrockagentcoreOnlineEvaluationConfig#filter}
    */
    readonly filter?: BedrockagentcoreOnlineEvaluationConfigRuleFilter[] | cdktn.IResolvable;
    /**
    * sampling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#sampling_config BedrockagentcoreOnlineEvaluationConfig#sampling_config}
    */
    readonly samplingConfig?: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig[] | cdktn.IResolvable;
    /**
    * session_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#session_config BedrockagentcoreOnlineEvaluationConfig#session_config}
    */
    readonly sessionConfig?: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreOnlineEvaluationConfigRuleToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigRuleToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigRule | cdktn.IResolvable | undefined);
    private _filter;
    get filter(): BedrockagentcoreOnlineEvaluationConfigRuleFilterList;
    putFilter(value: BedrockagentcoreOnlineEvaluationConfigRuleFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleFilter[] | undefined;
    private _samplingConfig;
    get samplingConfig(): BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfigList;
    putSamplingConfig(value: BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig[] | cdktn.IResolvable): void;
    resetSamplingConfig(): void;
    get samplingConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleSamplingConfig[] | undefined;
    private _sessionConfig;
    get sessionConfig(): BedrockagentcoreOnlineEvaluationConfigRuleSessionConfigList;
    putSessionConfig(value: BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig[] | cdktn.IResolvable): void;
    resetSessionConfig(): void;
    get sessionConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRuleSessionConfig[] | undefined;
}
export declare class BedrockagentcoreOnlineEvaluationConfigRuleList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreOnlineEvaluationConfigRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreOnlineEvaluationConfigRuleOutputReference;
}
export interface BedrockagentcoreOnlineEvaluationConfigTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#create BedrockagentcoreOnlineEvaluationConfig#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#delete BedrockagentcoreOnlineEvaluationConfig#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#update BedrockagentcoreOnlineEvaluationConfig#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcoreOnlineEvaluationConfigTimeoutsToTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreOnlineEvaluationConfigTimeoutsToHclTerraform(struct?: BedrockagentcoreOnlineEvaluationConfigTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreOnlineEvaluationConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreOnlineEvaluationConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreOnlineEvaluationConfigTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config aws_bedrockagentcore_online_evaluation_config}
*/
export declare class BedrockagentcoreOnlineEvaluationConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_online_evaluation_config";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreOnlineEvaluationConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreOnlineEvaluationConfig to import
    * @param importFromId The id of the existing BedrockagentcoreOnlineEvaluationConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreOnlineEvaluationConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrockagentcore_online_evaluation_config aws_bedrockagentcore_online_evaluation_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreOnlineEvaluationConfigConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreOnlineEvaluationConfigConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableOnCreate?;
    get enableOnCreate(): boolean | cdktn.IResolvable;
    set enableOnCreate(value: boolean | cdktn.IResolvable);
    get enableOnCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _evaluationExecutionRoleArn?;
    get evaluationExecutionRoleArn(): string;
    set evaluationExecutionRoleArn(value: string);
    get evaluationExecutionRoleArnInput(): string | undefined;
    private _executionStatus?;
    get executionStatus(): string;
    set executionStatus(value: string);
    resetExecutionStatus(): void;
    get executionStatusInput(): string | undefined;
    get onlineEvaluationConfigArn(): string;
    get onlineEvaluationConfigId(): string;
    private _onlineEvaluationConfigName?;
    get onlineEvaluationConfigName(): string;
    set onlineEvaluationConfigName(value: string);
    get onlineEvaluationConfigNameInput(): string | undefined;
    private _outputConfig;
    get outputConfig(): BedrockagentcoreOnlineEvaluationConfigOutputConfigList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _dataSourceConfig;
    get dataSourceConfig(): BedrockagentcoreOnlineEvaluationConfigDataSourceConfigList;
    putDataSourceConfig(value: BedrockagentcoreOnlineEvaluationConfigDataSourceConfig[] | cdktn.IResolvable): void;
    resetDataSourceConfig(): void;
    get dataSourceConfigInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigDataSourceConfig[] | undefined;
    private _evaluator;
    get evaluator(): BedrockagentcoreOnlineEvaluationConfigEvaluatorList;
    putEvaluator(value: BedrockagentcoreOnlineEvaluationConfigEvaluator[] | cdktn.IResolvable): void;
    resetEvaluator(): void;
    get evaluatorInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigEvaluator[] | undefined;
    private _rule;
    get rule(): BedrockagentcoreOnlineEvaluationConfigRuleList;
    putRule(value: BedrockagentcoreOnlineEvaluationConfigRule[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigRule[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreOnlineEvaluationConfigTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreOnlineEvaluationConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreOnlineEvaluationConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
