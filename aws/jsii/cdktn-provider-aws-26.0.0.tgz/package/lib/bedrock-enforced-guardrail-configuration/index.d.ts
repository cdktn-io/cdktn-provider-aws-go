/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockEnforcedGuardrailConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#guardrail_arn BedrockEnforcedGuardrailConfiguration#guardrail_arn}
    */
    readonly guardrailArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#guardrail_version BedrockEnforcedGuardrailConfiguration#guardrail_version}
    */
    readonly guardrailVersion: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#region BedrockEnforcedGuardrailConfiguration#region}
    */
    readonly region?: string;
    /**
    * model_enforcement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#model_enforcement BedrockEnforcedGuardrailConfiguration#model_enforcement}
    */
    readonly modelEnforcement?: BedrockEnforcedGuardrailConfigurationModelEnforcement[] | cdktn.IResolvable;
    /**
    * selective_content_guarding block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#selective_content_guarding BedrockEnforcedGuardrailConfiguration#selective_content_guarding}
    */
    readonly selectiveContentGuarding?: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding[] | cdktn.IResolvable;
}
export interface BedrockEnforcedGuardrailConfigurationModelEnforcement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#excluded_models BedrockEnforcedGuardrailConfiguration#excluded_models}
    */
    readonly excludedModels: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#included_models BedrockEnforcedGuardrailConfiguration#included_models}
    */
    readonly includedModels: string[];
}
export declare function bedrockEnforcedGuardrailConfigurationModelEnforcementToTerraform(struct?: BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable): any;
export declare function bedrockEnforcedGuardrailConfigurationModelEnforcementToHclTerraform(struct?: BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable): any;
export declare class BedrockEnforcedGuardrailConfigurationModelEnforcementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEnforcedGuardrailConfigurationModelEnforcement | cdktn.IResolvable | undefined);
    private _excludedModels?;
    get excludedModels(): string[];
    set excludedModels(value: string[]);
    get excludedModelsInput(): string[] | undefined;
    private _includedModels?;
    get includedModels(): string[];
    set includedModels(value: string[]);
    get includedModelsInput(): string[] | undefined;
}
export declare class BedrockEnforcedGuardrailConfigurationModelEnforcementList extends cdktn.ComplexList {
    internalValue?: BedrockEnforcedGuardrailConfigurationModelEnforcement[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEnforcedGuardrailConfigurationModelEnforcementOutputReference;
}
export interface BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#messages BedrockEnforcedGuardrailConfiguration#messages}
    */
    readonly messages?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#system BedrockEnforcedGuardrailConfiguration#system}
    */
    readonly systemAttribute?: string;
}
export declare function bedrockEnforcedGuardrailConfigurationSelectiveContentGuardingToTerraform(struct?: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable): any;
export declare function bedrockEnforcedGuardrailConfigurationSelectiveContentGuardingToHclTerraform(struct?: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable): any;
export declare class BedrockEnforcedGuardrailConfigurationSelectiveContentGuardingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding | cdktn.IResolvable | undefined);
    private _messages?;
    get messages(): string;
    set messages(value: string);
    resetMessages(): void;
    get messagesInput(): string | undefined;
    private _system?;
    get systemAttribute(): string;
    set systemAttribute(value: string);
    resetSystemAttribute(): void;
    get systemAttributeInput(): string | undefined;
}
export declare class BedrockEnforcedGuardrailConfigurationSelectiveContentGuardingList extends cdktn.ComplexList {
    internalValue?: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockEnforcedGuardrailConfigurationSelectiveContentGuardingOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration aws_bedrock_enforced_guardrail_configuration}
*/
export declare class BedrockEnforcedGuardrailConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_enforced_guardrail_configuration";
    /**
    * Generates CDKTN code for importing a BedrockEnforcedGuardrailConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockEnforcedGuardrailConfiguration to import
    * @param importFromId The id of the existing BedrockEnforcedGuardrailConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockEnforcedGuardrailConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.70.0/docs/resources/bedrock_enforced_guardrail_configuration aws_bedrock_enforced_guardrail_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockEnforcedGuardrailConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: BedrockEnforcedGuardrailConfigurationConfig);
    get configId(): string;
    private _guardrailArn?;
    get guardrailArn(): string;
    set guardrailArn(value: string);
    get guardrailArnInput(): string | undefined;
    get guardrailId(): string;
    private _guardrailVersion?;
    get guardrailVersion(): string;
    set guardrailVersion(value: string);
    get guardrailVersionInput(): string | undefined;
    get owner(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _modelEnforcement;
    get modelEnforcement(): BedrockEnforcedGuardrailConfigurationModelEnforcementList;
    putModelEnforcement(value: BedrockEnforcedGuardrailConfigurationModelEnforcement[] | cdktn.IResolvable): void;
    resetModelEnforcement(): void;
    get modelEnforcementInput(): cdktn.IResolvable | BedrockEnforcedGuardrailConfigurationModelEnforcement[] | undefined;
    private _selectiveContentGuarding;
    get selectiveContentGuarding(): BedrockEnforcedGuardrailConfigurationSelectiveContentGuardingList;
    putSelectiveContentGuarding(value: BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding[] | cdktn.IResolvable): void;
    resetSelectiveContentGuarding(): void;
    get selectiveContentGuardingInput(): cdktn.IResolvable | BedrockEnforcedGuardrailConfigurationSelectiveContentGuarding[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
