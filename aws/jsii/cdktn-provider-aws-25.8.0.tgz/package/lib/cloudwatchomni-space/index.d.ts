/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchomniSpaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#agent_core_evaluation_role_arn CloudwatchomniSpace#agent_core_evaluation_role_arn}
    */
    readonly agentCoreEvaluationRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#data_access_role_arn CloudwatchomniSpace#data_access_role_arn}
    */
    readonly dataAccessRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#domain_id CloudwatchomniSpace#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#name CloudwatchomniSpace#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#region CloudwatchomniSpace#region}
    */
    readonly region?: string;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#encryption_configuration CloudwatchomniSpace#encryption_configuration}
    */
    readonly encryptionConfiguration?: CloudwatchomniSpaceEncryptionConfiguration[] | cdktn.IResolvable;
}
export interface CloudwatchomniSpaceEncryptionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#encryption_strategy CloudwatchomniSpace#encryption_strategy}
    */
    readonly encryptionStrategy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#kms_key_arn CloudwatchomniSpace#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
}
export declare function cloudwatchomniSpaceEncryptionConfigurationToTerraform(struct?: CloudwatchomniSpaceEncryptionConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchomniSpaceEncryptionConfigurationToHclTerraform(struct?: CloudwatchomniSpaceEncryptionConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchomniSpaceEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniSpaceEncryptionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniSpaceEncryptionConfiguration | cdktn.IResolvable | undefined);
    private _encryptionStrategy?;
    get encryptionStrategy(): string;
    set encryptionStrategy(value: string);
    get encryptionStrategyInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
}
export declare class CloudwatchomniSpaceEncryptionConfigurationList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniSpaceEncryptionConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniSpaceEncryptionConfigurationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space aws_cloudwatchomni_space}
*/
export declare class CloudwatchomniSpace extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatchomni_space";
    /**
    * Generates CDKTN code for importing a CloudwatchomniSpace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchomniSpace to import
    * @param importFromId The id of the existing CloudwatchomniSpace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchomniSpace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatchomni_space aws_cloudwatchomni_space} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchomniSpaceConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchomniSpaceConfig);
    private _agentCoreEvaluationRoleArn?;
    get agentCoreEvaluationRoleArn(): string;
    set agentCoreEvaluationRoleArn(value: string);
    resetAgentCoreEvaluationRoleArn(): void;
    get agentCoreEvaluationRoleArnInput(): string | undefined;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    get dataAccessRoleArnInput(): string | undefined;
    get domainArn(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get spaceArn(): string;
    get spaceId(): string;
    get status(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): CloudwatchomniSpaceEncryptionConfigurationList;
    putEncryptionConfiguration(value: CloudwatchomniSpaceEncryptionConfiguration[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | CloudwatchomniSpaceEncryptionConfiguration[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
