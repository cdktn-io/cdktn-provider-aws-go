/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArczonalshiftZonalAutoshiftConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * List of time windows during which practice runs are allowed, in the format `Day:HH:MM-Day:HH:MM` (e.g., `Mon:09:00-Mon:17:00`). Cannot be used together with `blocked_windows`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#allowed_windows ArczonalshiftZonalAutoshiftConfiguration#allowed_windows}
    */
    readonly allowedWindows?: string[];
    /**
    * List of dates when practice runs should not be started, in the format `YYYY-MM-DD`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocked_dates ArczonalshiftZonalAutoshiftConfiguration#blocked_dates}
    */
    readonly blockedDates?: string[];
    /**
    * List of time windows during which practice runs should not be started, in the format `Day:HH:MM-Day:HH:MM` (e.g., `Mon:00:00-Mon:08:00`). Cannot be used together with `allowed_windows`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocked_windows ArczonalshiftZonalAutoshiftConfiguration#blocked_windows}
    */
    readonly blockedWindows?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#region ArczonalshiftZonalAutoshiftConfiguration#region}
    */
    readonly region?: string;
    /**
    * The ARN of the managed resource to configure zonal autoshift for (e.g., an Application Load Balancer). Changing this creates a new resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#resource_arn ArczonalshiftZonalAutoshiftConfiguration#resource_arn}
    */
    readonly resourceArn: string;
    /**
    * The status of zonal autoshift. Valid values: `ENABLED`, `DISABLED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#zonal_autoshift_status ArczonalshiftZonalAutoshiftConfiguration#zonal_autoshift_status}
    */
    readonly zonalAutoshiftStatus: string;
    /**
    * blocking_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#blocking_alarms ArczonalshiftZonalAutoshiftConfiguration#blocking_alarms}
    */
    readonly blockingAlarms?: ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms[] | cdktn.IResolvable;
    /**
    * outcome_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#outcome_alarms ArczonalshiftZonalAutoshiftConfiguration#outcome_alarms}
    */
    readonly outcomeAlarms?: ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms[] | cdktn.IResolvable;
}
export interface ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms {
    /**
    * ARN of the CloudWatch alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#alarm_identifier ArczonalshiftZonalAutoshiftConfiguration#alarm_identifier}
    */
    readonly alarmIdentifier: string;
    /**
    * Type of control condition. Valid value: `CLOUDWATCH`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#type ArczonalshiftZonalAutoshiftConfiguration#type}
    */
    readonly type: string;
}
export declare function arczonalshiftZonalAutoshiftConfigurationBlockingAlarmsToTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms | cdktn.IResolvable): any;
export declare function arczonalshiftZonalAutoshiftConfigurationBlockingAlarmsToHclTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms | cdktn.IResolvable): any;
export declare class ArczonalshiftZonalAutoshiftConfigurationBlockingAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms | cdktn.IResolvable | undefined);
    private _alarmIdentifier?;
    get alarmIdentifier(): string;
    set alarmIdentifier(value: string);
    get alarmIdentifierInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ArczonalshiftZonalAutoshiftConfigurationBlockingAlarmsList extends cdktn.ComplexList {
    internalValue?: ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArczonalshiftZonalAutoshiftConfigurationBlockingAlarmsOutputReference;
}
export interface ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms {
    /**
    * ARN of the CloudWatch alarm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#alarm_identifier ArczonalshiftZonalAutoshiftConfiguration#alarm_identifier}
    */
    readonly alarmIdentifier: string;
    /**
    * Type of control condition. Valid value: `CLOUDWATCH`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#type ArczonalshiftZonalAutoshiftConfiguration#type}
    */
    readonly type: string;
}
export declare function arczonalshiftZonalAutoshiftConfigurationOutcomeAlarmsToTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms | cdktn.IResolvable): any;
export declare function arczonalshiftZonalAutoshiftConfigurationOutcomeAlarmsToHclTerraform(struct?: ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms | cdktn.IResolvable): any;
export declare class ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms | cdktn.IResolvable | undefined);
    private _alarmIdentifier?;
    get alarmIdentifier(): string;
    set alarmIdentifier(value: string);
    get alarmIdentifierInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarmsList extends cdktn.ComplexList {
    internalValue?: ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarmsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration aws_arczonalshift_zonal_autoshift_configuration}
*/
export declare class ArczonalshiftZonalAutoshiftConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_arczonalshift_zonal_autoshift_configuration";
    /**
    * Generates CDKTN code for importing a ArczonalshiftZonalAutoshiftConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArczonalshiftZonalAutoshiftConfiguration to import
    * @param importFromId The id of the existing ArczonalshiftZonalAutoshiftConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArczonalshiftZonalAutoshiftConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/arczonalshift_zonal_autoshift_configuration aws_arczonalshift_zonal_autoshift_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArczonalshiftZonalAutoshiftConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: ArczonalshiftZonalAutoshiftConfigurationConfig);
    private _allowedWindows?;
    get allowedWindows(): string[];
    set allowedWindows(value: string[]);
    resetAllowedWindows(): void;
    get allowedWindowsInput(): string[] | undefined;
    private _blockedDates?;
    get blockedDates(): string[];
    set blockedDates(value: string[]);
    resetBlockedDates(): void;
    get blockedDatesInput(): string[] | undefined;
    private _blockedWindows?;
    get blockedWindows(): string[];
    set blockedWindows(value: string[]);
    resetBlockedWindows(): void;
    get blockedWindowsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    private _zonalAutoshiftStatus?;
    get zonalAutoshiftStatus(): string;
    set zonalAutoshiftStatus(value: string);
    get zonalAutoshiftStatusInput(): string | undefined;
    private _blockingAlarms;
    get blockingAlarms(): ArczonalshiftZonalAutoshiftConfigurationBlockingAlarmsList;
    putBlockingAlarms(value: ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms[] | cdktn.IResolvable): void;
    resetBlockingAlarms(): void;
    get blockingAlarmsInput(): cdktn.IResolvable | ArczonalshiftZonalAutoshiftConfigurationBlockingAlarms[] | undefined;
    private _outcomeAlarms;
    get outcomeAlarms(): ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarmsList;
    putOutcomeAlarms(value: ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms[] | cdktn.IResolvable): void;
    resetOutcomeAlarms(): void;
    get outcomeAlarmsInput(): cdktn.IResolvable | ArczonalshiftZonalAutoshiftConfigurationOutcomeAlarms[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
