/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentAgentActionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#action_group_name BedrockagentAgentActionGroup#action_group_name}
    */
    readonly actionGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#action_group_state BedrockagentAgentActionGroup#action_group_state}
    */
    readonly actionGroupState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#agent_id BedrockagentAgentActionGroup#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#agent_version BedrockagentAgentActionGroup#agent_version}
    */
    readonly agentVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#description BedrockagentAgentActionGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#parent_action_group_signature BedrockagentAgentActionGroup#parent_action_group_signature}
    */
    readonly parentActionGroupSignature?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#prepare_agent BedrockagentAgentActionGroup#prepare_agent}
    */
    readonly prepareAgent?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#region BedrockagentAgentActionGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#skip_resource_in_use_check BedrockagentAgentActionGroup#skip_resource_in_use_check}
    */
    readonly skipResourceInUseCheck?: boolean | cdktn.IResolvable;
    /**
    * action_group_executor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#action_group_executor BedrockagentAgentActionGroup#action_group_executor}
    */
    readonly actionGroupExecutor?: BedrockagentAgentActionGroupActionGroupExecutor[] | cdktn.IResolvable;
    /**
    * api_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#api_schema BedrockagentAgentActionGroup#api_schema}
    */
    readonly apiSchema?: BedrockagentAgentActionGroupApiSchema[] | cdktn.IResolvable;
    /**
    * function_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#function_schema BedrockagentAgentActionGroup#function_schema}
    */
    readonly functionSchema?: BedrockagentAgentActionGroupFunctionSchema[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#timeouts BedrockagentAgentActionGroup#timeouts}
    */
    readonly timeouts?: BedrockagentAgentActionGroupTimeouts;
}
export interface BedrockagentAgentActionGroupActionGroupExecutor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#custom_control BedrockagentAgentActionGroup#custom_control}
    */
    readonly customControl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#lambda BedrockagentAgentActionGroup#lambda}
    */
    readonly lambda?: string;
}
export declare function bedrockagentAgentActionGroupActionGroupExecutorToTerraform(struct?: BedrockagentAgentActionGroupActionGroupExecutor | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupActionGroupExecutorToHclTerraform(struct?: BedrockagentAgentActionGroupActionGroupExecutor | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupActionGroupExecutorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentAgentActionGroupActionGroupExecutor | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupActionGroupExecutor | cdktn.IResolvable | undefined);
    private _customControl?;
    get customControl(): string;
    set customControl(value: string);
    resetCustomControl(): void;
    get customControlInput(): string | undefined;
    private _lambda?;
    get lambda(): string;
    set lambda(value: string);
    resetLambda(): void;
    get lambdaInput(): string | undefined;
}
export declare class BedrockagentAgentActionGroupActionGroupExecutorList extends cdktn.ComplexList {
    internalValue?: BedrockagentAgentActionGroupActionGroupExecutor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentAgentActionGroupActionGroupExecutorOutputReference;
}
export interface BedrockagentAgentActionGroupApiSchemaS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#s3_bucket_name BedrockagentAgentActionGroup#s3_bucket_name}
    */
    readonly s3BucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#s3_object_key BedrockagentAgentActionGroup#s3_object_key}
    */
    readonly s3ObjectKey?: string;
}
export declare function bedrockagentAgentActionGroupApiSchemaS3ToTerraform(struct?: BedrockagentAgentActionGroupApiSchemaS3 | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupApiSchemaS3ToHclTerraform(struct?: BedrockagentAgentActionGroupApiSchemaS3 | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupApiSchemaS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentAgentActionGroupApiSchemaS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupApiSchemaS3 | cdktn.IResolvable | undefined);
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    resetS3BucketName(): void;
    get s3BucketNameInput(): string | undefined;
    private _s3ObjectKey?;
    get s3ObjectKey(): string;
    set s3ObjectKey(value: string);
    resetS3ObjectKey(): void;
    get s3ObjectKeyInput(): string | undefined;
}
export declare class BedrockagentAgentActionGroupApiSchemaS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentAgentActionGroupApiSchemaS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentAgentActionGroupApiSchemaS3OutputReference;
}
export interface BedrockagentAgentActionGroupApiSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#payload BedrockagentAgentActionGroup#payload}
    */
    readonly payload?: string;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#s3 BedrockagentAgentActionGroup#s3}
    */
    readonly s3?: BedrockagentAgentActionGroupApiSchemaS3[] | cdktn.IResolvable;
}
export declare function bedrockagentAgentActionGroupApiSchemaToTerraform(struct?: BedrockagentAgentActionGroupApiSchema | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupApiSchemaToHclTerraform(struct?: BedrockagentAgentActionGroupApiSchema | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupApiSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentAgentActionGroupApiSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupApiSchema | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    resetPayload(): void;
    get payloadInput(): string | undefined;
    private _s3;
    get s3(): BedrockagentAgentActionGroupApiSchemaS3List;
    putS3(value: BedrockagentAgentActionGroupApiSchemaS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentAgentActionGroupApiSchemaS3[] | undefined;
}
export declare class BedrockagentAgentActionGroupApiSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentAgentActionGroupApiSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentAgentActionGroupApiSchemaOutputReference;
}
export interface BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#description BedrockagentAgentActionGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#map_block_key BedrockagentAgentActionGroup#map_block_key}
    */
    readonly mapBlockKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#required BedrockagentAgentActionGroup#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#type BedrockagentAgentActionGroup#type}
    */
    readonly type: string;
}
export declare function bedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParametersToTerraform(struct?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParametersToHclTerraform(struct?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _mapBlockKey?;
    get mapBlockKey(): string;
    set mapBlockKey(value: string);
    get mapBlockKeyInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParametersList extends cdktn.ComplexList {
    internalValue?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParametersOutputReference;
}
export interface BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#description BedrockagentAgentActionGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#name BedrockagentAgentActionGroup#name}
    */
    readonly name: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#parameters BedrockagentAgentActionGroup#parameters}
    */
    readonly parameters?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters[] | cdktn.IResolvable;
}
export declare function bedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsToTerraform(struct?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsToHclTerraform(struct?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParametersList;
    putParameters(value: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsParameters[] | undefined;
}
export declare class BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsList extends cdktn.ComplexList {
    internalValue?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsOutputReference;
}
export interface BedrockagentAgentActionGroupFunctionSchemaMemberFunctions {
    /**
    * functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#functions BedrockagentAgentActionGroup#functions}
    */
    readonly functions?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions[] | cdktn.IResolvable;
}
export declare function bedrockagentAgentActionGroupFunctionSchemaMemberFunctionsToTerraform(struct?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctions | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupFunctionSchemaMemberFunctionsToHclTerraform(struct?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctions | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentAgentActionGroupFunctionSchemaMemberFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupFunctionSchemaMemberFunctions | cdktn.IResolvable | undefined);
    private _functions;
    get functions(): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctionsList;
    putFunctions(value: BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions[] | cdktn.IResolvable): void;
    resetFunctions(): void;
    get functionsInput(): cdktn.IResolvable | BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsFunctions[] | undefined;
}
export declare class BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsList extends cdktn.ComplexList {
    internalValue?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsOutputReference;
}
export interface BedrockagentAgentActionGroupFunctionSchema {
    /**
    * member_functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#member_functions BedrockagentAgentActionGroup#member_functions}
    */
    readonly memberFunctions?: BedrockagentAgentActionGroupFunctionSchemaMemberFunctions[] | cdktn.IResolvable;
}
export declare function bedrockagentAgentActionGroupFunctionSchemaToTerraform(struct?: BedrockagentAgentActionGroupFunctionSchema | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupFunctionSchemaToHclTerraform(struct?: BedrockagentAgentActionGroupFunctionSchema | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupFunctionSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentAgentActionGroupFunctionSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupFunctionSchema | cdktn.IResolvable | undefined);
    private _memberFunctions;
    get memberFunctions(): BedrockagentAgentActionGroupFunctionSchemaMemberFunctionsList;
    putMemberFunctions(value: BedrockagentAgentActionGroupFunctionSchemaMemberFunctions[] | cdktn.IResolvable): void;
    resetMemberFunctions(): void;
    get memberFunctionsInput(): cdktn.IResolvable | BedrockagentAgentActionGroupFunctionSchemaMemberFunctions[] | undefined;
}
export declare class BedrockagentAgentActionGroupFunctionSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentAgentActionGroupFunctionSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentAgentActionGroupFunctionSchemaOutputReference;
}
export interface BedrockagentAgentActionGroupTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#create BedrockagentAgentActionGroup#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#update BedrockagentAgentActionGroup#update}
    */
    readonly update?: string;
}
export declare function bedrockagentAgentActionGroupTimeoutsToTerraform(struct?: BedrockagentAgentActionGroupTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentAgentActionGroupTimeoutsToHclTerraform(struct?: BedrockagentAgentActionGroupTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentAgentActionGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentAgentActionGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentAgentActionGroupTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group aws_bedrockagent_agent_action_group}
*/
export declare class BedrockagentAgentActionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_agent_action_group";
    /**
    * Generates CDKTN code for importing a BedrockagentAgentActionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentAgentActionGroup to import
    * @param importFromId The id of the existing BedrockagentAgentActionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentAgentActionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagent_agent_action_group aws_bedrockagent_agent_action_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentAgentActionGroupConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentAgentActionGroupConfig);
    get actionGroupId(): string;
    private _actionGroupName?;
    get actionGroupName(): string;
    set actionGroupName(value: string);
    get actionGroupNameInput(): string | undefined;
    private _actionGroupState?;
    get actionGroupState(): string;
    set actionGroupState(value: string);
    resetActionGroupState(): void;
    get actionGroupStateInput(): string | undefined;
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _agentVersion?;
    get agentVersion(): string;
    set agentVersion(value: string);
    get agentVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _parentActionGroupSignature?;
    get parentActionGroupSignature(): string;
    set parentActionGroupSignature(value: string);
    resetParentActionGroupSignature(): void;
    get parentActionGroupSignatureInput(): string | undefined;
    private _prepareAgent?;
    get prepareAgent(): boolean | cdktn.IResolvable;
    set prepareAgent(value: boolean | cdktn.IResolvable);
    resetPrepareAgent(): void;
    get prepareAgentInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipResourceInUseCheck?;
    get skipResourceInUseCheck(): boolean | cdktn.IResolvable;
    set skipResourceInUseCheck(value: boolean | cdktn.IResolvable);
    resetSkipResourceInUseCheck(): void;
    get skipResourceInUseCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _actionGroupExecutor;
    get actionGroupExecutor(): BedrockagentAgentActionGroupActionGroupExecutorList;
    putActionGroupExecutor(value: BedrockagentAgentActionGroupActionGroupExecutor[] | cdktn.IResolvable): void;
    resetActionGroupExecutor(): void;
    get actionGroupExecutorInput(): cdktn.IResolvable | BedrockagentAgentActionGroupActionGroupExecutor[] | undefined;
    private _apiSchema;
    get apiSchema(): BedrockagentAgentActionGroupApiSchemaList;
    putApiSchema(value: BedrockagentAgentActionGroupApiSchema[] | cdktn.IResolvable): void;
    resetApiSchema(): void;
    get apiSchemaInput(): cdktn.IResolvable | BedrockagentAgentActionGroupApiSchema[] | undefined;
    private _functionSchema;
    get functionSchema(): BedrockagentAgentActionGroupFunctionSchemaList;
    putFunctionSchema(value: BedrockagentAgentActionGroupFunctionSchema[] | cdktn.IResolvable): void;
    resetFunctionSchema(): void;
    get functionSchemaInput(): cdktn.IResolvable | BedrockagentAgentActionGroupFunctionSchema[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentAgentActionGroupTimeoutsOutputReference;
    putTimeouts(value: BedrockagentAgentActionGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentAgentActionGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
