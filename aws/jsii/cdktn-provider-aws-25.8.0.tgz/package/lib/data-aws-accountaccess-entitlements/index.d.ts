/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAccountaccessEntitlementsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#application_arn DataAwsAccountaccessEntitlements#application_arn}
    */
    readonly applicationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#region DataAwsAccountaccessEntitlements#region}
    */
    readonly region?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#filter DataAwsAccountaccessEntitlements#filter}
    */
    readonly filter?: DataAwsAccountaccessEntitlementsFilter[] | cdktn.IResolvable;
}
export interface DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenter {
}
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenterToTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenter): any;
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenterToHclTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenter): any;
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenter | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenter | undefined);
    get groupId(): string;
    get userId(): string;
}
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenterOutputReference;
}
export interface DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipal {
}
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalToTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipal): any;
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalToHclTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipal): any;
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipal | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipal | undefined);
    private _identityCenter;
    get identityCenter(): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalIdentityCenterList;
}
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalOutputReference;
}
export interface DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRole {
}
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRoleToTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRole): any;
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRoleToHclTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRole): any;
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRole | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRole | undefined);
    get accountId(): string;
    get accountName(): string;
    private _principal;
    get principal(): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRolePrincipalList;
    get roleArn(): string;
}
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRoleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRoleOutputReference;
}
export interface DataAwsAccountaccessEntitlementsEntitlementsEntitlement {
}
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementToTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlement): any;
export declare function dataAwsAccountaccessEntitlementsEntitlementsEntitlementToHclTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlementsEntitlement): any;
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsEntitlementsEntitlement | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsEntitlementsEntitlement | undefined);
    private _principalRole;
    get principalRole(): DataAwsAccountaccessEntitlementsEntitlementsEntitlementPrincipalRoleList;
}
export declare class DataAwsAccountaccessEntitlementsEntitlementsEntitlementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsEntitlementsEntitlementOutputReference;
}
export interface DataAwsAccountaccessEntitlementsEntitlements {
}
export declare function dataAwsAccountaccessEntitlementsEntitlementsToTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlements): any;
export declare function dataAwsAccountaccessEntitlementsEntitlementsToHclTerraform(struct?: DataAwsAccountaccessEntitlementsEntitlements): any;
export declare class DataAwsAccountaccessEntitlementsEntitlementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsEntitlements | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsEntitlements | undefined);
    get createdAt(): string;
    private _entitlement;
    get entitlement(): DataAwsAccountaccessEntitlementsEntitlementsEntitlementList;
    get entitlementId(): string;
}
export declare class DataAwsAccountaccessEntitlementsEntitlementsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsEntitlementsOutputReference;
}
export interface DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#group_id DataAwsAccountaccessEntitlements#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#user_id DataAwsAccountaccessEntitlements#user_id}
    */
    readonly userId?: string;
}
export declare function dataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenterToTerraform(struct?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable): any;
export declare function dataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenterToHclTerraform(struct?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable): any;
export declare class DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable | undefined);
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
}
export declare class DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenterList extends cdktn.ComplexList {
    internalValue?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenterOutputReference;
}
export interface DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal {
    /**
    * identity_center block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#identity_center DataAwsAccountaccessEntitlements#identity_center}
    */
    readonly identityCenter?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter[] | cdktn.IResolvable;
}
export declare function dataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalToTerraform(struct?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal | cdktn.IResolvable): any;
export declare function dataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalToHclTerraform(struct?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal | cdktn.IResolvable): any;
export declare class DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal | cdktn.IResolvable | undefined);
    private _identityCenter;
    get identityCenter(): DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenterList;
    putIdentityCenter(value: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter[] | cdktn.IResolvable): void;
    resetIdentityCenter(): void;
    get identityCenterInput(): cdktn.IResolvable | DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalIdentityCenter[] | undefined;
}
export declare class DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalList extends cdktn.ComplexList {
    internalValue?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalOutputReference;
}
export interface DataAwsAccountaccessEntitlementsFilterPrincipalRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#account_id DataAwsAccountaccessEntitlements#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#role_arn DataAwsAccountaccessEntitlements#role_arn}
    */
    readonly roleArn?: string;
    /**
    * principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#principal DataAwsAccountaccessEntitlements#principal}
    */
    readonly principal?: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal[] | cdktn.IResolvable;
}
export declare function dataAwsAccountaccessEntitlementsFilterPrincipalRoleToTerraform(struct?: DataAwsAccountaccessEntitlementsFilterPrincipalRole | cdktn.IResolvable): any;
export declare function dataAwsAccountaccessEntitlementsFilterPrincipalRoleToHclTerraform(struct?: DataAwsAccountaccessEntitlementsFilterPrincipalRole | cdktn.IResolvable): any;
export declare class DataAwsAccountaccessEntitlementsFilterPrincipalRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsFilterPrincipalRole | cdktn.IResolvable | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsFilterPrincipalRole | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _principal;
    get principal(): DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipalList;
    putPrincipal(value: DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal[] | cdktn.IResolvable): void;
    resetPrincipal(): void;
    get principalInput(): cdktn.IResolvable | DataAwsAccountaccessEntitlementsFilterPrincipalRolePrincipal[] | undefined;
}
export declare class DataAwsAccountaccessEntitlementsFilterPrincipalRoleList extends cdktn.ComplexList {
    internalValue?: DataAwsAccountaccessEntitlementsFilterPrincipalRole[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsFilterPrincipalRoleOutputReference;
}
export interface DataAwsAccountaccessEntitlementsFilter {
    /**
    * principal_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#principal_role DataAwsAccountaccessEntitlements#principal_role}
    */
    readonly principalRole?: DataAwsAccountaccessEntitlementsFilterPrincipalRole[] | cdktn.IResolvable;
}
export declare function dataAwsAccountaccessEntitlementsFilterToTerraform(struct?: DataAwsAccountaccessEntitlementsFilter | cdktn.IResolvable): any;
export declare function dataAwsAccountaccessEntitlementsFilterToHclTerraform(struct?: DataAwsAccountaccessEntitlementsFilter | cdktn.IResolvable): any;
export declare class DataAwsAccountaccessEntitlementsFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAccountaccessEntitlementsFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataAwsAccountaccessEntitlementsFilter | cdktn.IResolvable | undefined);
    private _principalRole;
    get principalRole(): DataAwsAccountaccessEntitlementsFilterPrincipalRoleList;
    putPrincipalRole(value: DataAwsAccountaccessEntitlementsFilterPrincipalRole[] | cdktn.IResolvable): void;
    resetPrincipalRole(): void;
    get principalRoleInput(): cdktn.IResolvable | DataAwsAccountaccessEntitlementsFilterPrincipalRole[] | undefined;
}
export declare class DataAwsAccountaccessEntitlementsFilterList extends cdktn.ComplexList {
    internalValue?: DataAwsAccountaccessEntitlementsFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAccountaccessEntitlementsFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements aws_accountaccess_entitlements}
*/
export declare class DataAwsAccountaccessEntitlements extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_accountaccess_entitlements";
    /**
    * Generates CDKTN code for importing a DataAwsAccountaccessEntitlements resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAccountaccessEntitlements to import
    * @param importFromId The id of the existing DataAwsAccountaccessEntitlements that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAccountaccessEntitlements to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/data-sources/accountaccess_entitlements aws_accountaccess_entitlements} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAccountaccessEntitlementsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsAccountaccessEntitlementsConfig);
    private _applicationArn?;
    get applicationArn(): string;
    set applicationArn(value: string);
    get applicationArnInput(): string | undefined;
    private _entitlements;
    get entitlements(): DataAwsAccountaccessEntitlementsEntitlementsList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filter;
    get filter(): DataAwsAccountaccessEntitlementsFilterList;
    putFilter(value: DataAwsAccountaccessEntitlementsFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsAccountaccessEntitlementsFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
