/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoManagedLoginBrandingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#client_id CognitoManagedLoginBranding#client_id}
    */
    readonly clientId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#region CognitoManagedLoginBranding#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#settings CognitoManagedLoginBranding#settings}
    */
    readonly settings?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#use_cognito_provided_values CognitoManagedLoginBranding#use_cognito_provided_values}
    */
    readonly useCognitoProvidedValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#user_pool_id CognitoManagedLoginBranding#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * asset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#asset CognitoManagedLoginBranding#asset}
    */
    readonly asset?: CognitoManagedLoginBrandingAsset[] | cdktn.IResolvable;
}
export interface CognitoManagedLoginBrandingAsset {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#bytes CognitoManagedLoginBranding#bytes}
    */
    readonly bytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#category CognitoManagedLoginBranding#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#color_mode CognitoManagedLoginBranding#color_mode}
    */
    readonly colorMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#extension CognitoManagedLoginBranding#extension}
    */
    readonly extension: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#resource_id CognitoManagedLoginBranding#resource_id}
    */
    readonly resourceId?: string;
}
export declare function cognitoManagedLoginBrandingAssetToTerraform(struct?: CognitoManagedLoginBrandingAsset | cdktn.IResolvable): any;
export declare function cognitoManagedLoginBrandingAssetToHclTerraform(struct?: CognitoManagedLoginBrandingAsset | cdktn.IResolvable): any;
export declare class CognitoManagedLoginBrandingAssetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoManagedLoginBrandingAsset | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoManagedLoginBrandingAsset | cdktn.IResolvable | undefined);
    private _bytes?;
    get bytes(): string;
    set bytes(value: string);
    resetBytes(): void;
    get bytesInput(): string | undefined;
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _colorMode?;
    get colorMode(): string;
    set colorMode(value: string);
    get colorModeInput(): string | undefined;
    private _extension?;
    get extension(): string;
    set extension(value: string);
    get extensionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
}
export declare class CognitoManagedLoginBrandingAssetList extends cdktn.ComplexList {
    internalValue?: CognitoManagedLoginBrandingAsset[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoManagedLoginBrandingAssetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding aws_cognito_managed_login_branding}
*/
export declare class CognitoManagedLoginBranding extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_managed_login_branding";
    /**
    * Generates CDKTN code for importing a CognitoManagedLoginBranding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoManagedLoginBranding to import
    * @param importFromId The id of the existing CognitoManagedLoginBranding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoManagedLoginBranding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cognito_managed_login_branding aws_cognito_managed_login_branding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoManagedLoginBrandingConfig
    */
    constructor(scope: Construct, id: string, config: CognitoManagedLoginBrandingConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    get managedLoginBrandingId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _settings?;
    get settings(): string;
    set settings(value: string);
    resetSettings(): void;
    get settingsInput(): string | undefined;
    get settingsAll(): string;
    private _useCognitoProvidedValues?;
    get useCognitoProvidedValues(): boolean | cdktn.IResolvable;
    set useCognitoProvidedValues(value: boolean | cdktn.IResolvable);
    resetUseCognitoProvidedValues(): void;
    get useCognitoProvidedValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _asset;
    get asset(): CognitoManagedLoginBrandingAssetList;
    putAsset(value: CognitoManagedLoginBrandingAsset[] | cdktn.IResolvable): void;
    resetAsset(): void;
    get assetInput(): cdktn.IResolvable | CognitoManagedLoginBrandingAsset[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
