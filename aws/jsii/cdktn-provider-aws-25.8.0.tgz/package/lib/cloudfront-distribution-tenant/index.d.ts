/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontDistributionTenantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#connection_group_id CloudfrontDistributionTenant#connection_group_id}
    */
    readonly connectionGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#distribution_id CloudfrontDistributionTenant#distribution_id}
    */
    readonly distributionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#enabled CloudfrontDistributionTenant#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#name CloudfrontDistributionTenant#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#tags CloudfrontDistributionTenant#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#wait_for_deployment CloudfrontDistributionTenant#wait_for_deployment}
    */
    readonly waitForDeployment?: boolean | cdktn.IResolvable;
    /**
    * customizations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#customizations CloudfrontDistributionTenant#customizations}
    */
    readonly customizations?: CloudfrontDistributionTenantCustomizations[] | cdktn.IResolvable;
    /**
    * domain block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#domain CloudfrontDistributionTenant#domain}
    */
    readonly domain?: CloudfrontDistributionTenantDomain[] | cdktn.IResolvable;
    /**
    * managed_certificate_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#managed_certificate_request CloudfrontDistributionTenant#managed_certificate_request}
    */
    readonly managedCertificateRequest?: CloudfrontDistributionTenantManagedCertificateRequest[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#parameter CloudfrontDistributionTenant#parameter}
    */
    readonly parameter?: CloudfrontDistributionTenantParameter[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#timeouts CloudfrontDistributionTenant#timeouts}
    */
    readonly timeouts?: CloudfrontDistributionTenantTimeouts;
}
export interface CloudfrontDistributionTenantCustomizationsCertificate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#arn CloudfrontDistributionTenant#arn}
    */
    readonly arn?: string;
}
export declare function cloudfrontDistributionTenantCustomizationsCertificateToTerraform(struct?: CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsCertificateToHclTerraform(struct?: CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizationsCertificate | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
}
export declare class CloudfrontDistributionTenantCustomizationsCertificateList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantCustomizationsCertificate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantCustomizationsCertificateOutputReference;
}
export interface CloudfrontDistributionTenantCustomizationsGeoRestriction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#locations CloudfrontDistributionTenant#locations}
    */
    readonly locations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#restriction_type CloudfrontDistributionTenant#restriction_type}
    */
    readonly restrictionType?: string;
}
export declare function cloudfrontDistributionTenantCustomizationsGeoRestrictionToTerraform(struct?: CloudfrontDistributionTenantCustomizationsGeoRestriction | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsGeoRestrictionToHclTerraform(struct?: CloudfrontDistributionTenantCustomizationsGeoRestriction | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsGeoRestrictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantCustomizationsGeoRestriction | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizationsGeoRestriction | cdktn.IResolvable | undefined);
    private _locations?;
    get locations(): string[];
    set locations(value: string[]);
    resetLocations(): void;
    get locationsInput(): string[] | undefined;
    private _restrictionType?;
    get restrictionType(): string;
    set restrictionType(value: string);
    resetRestrictionType(): void;
    get restrictionTypeInput(): string | undefined;
}
export declare class CloudfrontDistributionTenantCustomizationsGeoRestrictionList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantCustomizationsGeoRestriction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantCustomizationsGeoRestrictionOutputReference;
}
export interface CloudfrontDistributionTenantCustomizationsWebAcl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#action CloudfrontDistributionTenant#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#arn CloudfrontDistributionTenant#arn}
    */
    readonly arn?: string;
}
export declare function cloudfrontDistributionTenantCustomizationsWebAclToTerraform(struct?: CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsWebAclToHclTerraform(struct?: CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsWebAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizationsWebAcl | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
}
export declare class CloudfrontDistributionTenantCustomizationsWebAclList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantCustomizationsWebAcl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantCustomizationsWebAclOutputReference;
}
export interface CloudfrontDistributionTenantCustomizations {
    /**
    * certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#certificate CloudfrontDistributionTenant#certificate}
    */
    readonly certificate?: CloudfrontDistributionTenantCustomizationsCertificate[] | cdktn.IResolvable;
    /**
    * geo_restriction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#geo_restriction CloudfrontDistributionTenant#geo_restriction}
    */
    readonly geoRestriction?: CloudfrontDistributionTenantCustomizationsGeoRestriction[] | cdktn.IResolvable;
    /**
    * web_acl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#web_acl CloudfrontDistributionTenant#web_acl}
    */
    readonly webAcl?: CloudfrontDistributionTenantCustomizationsWebAcl[] | cdktn.IResolvable;
}
export declare function cloudfrontDistributionTenantCustomizationsToTerraform(struct?: CloudfrontDistributionTenantCustomizations | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantCustomizationsToHclTerraform(struct?: CloudfrontDistributionTenantCustomizations | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantCustomizationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantCustomizations | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantCustomizations | cdktn.IResolvable | undefined);
    private _certificate;
    get certificate(): CloudfrontDistributionTenantCustomizationsCertificateList;
    putCertificate(value: CloudfrontDistributionTenantCustomizationsCertificate[] | cdktn.IResolvable): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizationsCertificate[] | undefined;
    private _geoRestriction;
    get geoRestriction(): CloudfrontDistributionTenantCustomizationsGeoRestrictionList;
    putGeoRestriction(value: CloudfrontDistributionTenantCustomizationsGeoRestriction[] | cdktn.IResolvable): void;
    resetGeoRestriction(): void;
    get geoRestrictionInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizationsGeoRestriction[] | undefined;
    private _webAcl;
    get webAcl(): CloudfrontDistributionTenantCustomizationsWebAclList;
    putWebAcl(value: CloudfrontDistributionTenantCustomizationsWebAcl[] | cdktn.IResolvable): void;
    resetWebAcl(): void;
    get webAclInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizationsWebAcl[] | undefined;
}
export declare class CloudfrontDistributionTenantCustomizationsList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantCustomizations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantCustomizationsOutputReference;
}
export interface CloudfrontDistributionTenantDomain {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#domain CloudfrontDistributionTenant#domain}
    */
    readonly domain: string;
}
export declare function cloudfrontDistributionTenantDomainToTerraform(struct?: CloudfrontDistributionTenantDomain | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantDomainToHclTerraform(struct?: CloudfrontDistributionTenantDomain | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantDomainOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantDomain | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantDomain | cdktn.IResolvable | undefined);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    get status(): string;
}
export declare class CloudfrontDistributionTenantDomainList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantDomain[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantDomainOutputReference;
}
export interface CloudfrontDistributionTenantManagedCertificateRequest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#certificate_transparency_logging_preference CloudfrontDistributionTenant#certificate_transparency_logging_preference}
    */
    readonly certificateTransparencyLoggingPreference?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#primary_domain_name CloudfrontDistributionTenant#primary_domain_name}
    */
    readonly primaryDomainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#validation_token_host CloudfrontDistributionTenant#validation_token_host}
    */
    readonly validationTokenHost?: string;
}
export declare function cloudfrontDistributionTenantManagedCertificateRequestToTerraform(struct?: CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantManagedCertificateRequestToHclTerraform(struct?: CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantManagedCertificateRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantManagedCertificateRequest | cdktn.IResolvable | undefined);
    private _certificateTransparencyLoggingPreference?;
    get certificateTransparencyLoggingPreference(): string;
    set certificateTransparencyLoggingPreference(value: string);
    resetCertificateTransparencyLoggingPreference(): void;
    get certificateTransparencyLoggingPreferenceInput(): string | undefined;
    private _primaryDomainName?;
    get primaryDomainName(): string;
    set primaryDomainName(value: string);
    resetPrimaryDomainName(): void;
    get primaryDomainNameInput(): string | undefined;
    private _validationTokenHost?;
    get validationTokenHost(): string;
    set validationTokenHost(value: string);
    resetValidationTokenHost(): void;
    get validationTokenHostInput(): string | undefined;
}
export declare class CloudfrontDistributionTenantManagedCertificateRequestList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantManagedCertificateRequest[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantManagedCertificateRequestOutputReference;
}
export interface CloudfrontDistributionTenantParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#name CloudfrontDistributionTenant#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#value CloudfrontDistributionTenant#value}
    */
    readonly value: string;
}
export declare function cloudfrontDistributionTenantParameterToTerraform(struct?: CloudfrontDistributionTenantParameter | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantParameterToHclTerraform(struct?: CloudfrontDistributionTenantParameter | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontDistributionTenantParameter | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantParameter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CloudfrontDistributionTenantParameterList extends cdktn.ComplexList {
    internalValue?: CloudfrontDistributionTenantParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontDistributionTenantParameterOutputReference;
}
export interface CloudfrontDistributionTenantTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#create CloudfrontDistributionTenant#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#delete CloudfrontDistributionTenant#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#update CloudfrontDistributionTenant#update}
    */
    readonly update?: string;
}
export declare function cloudfrontDistributionTenantTimeoutsToTerraform(struct?: CloudfrontDistributionTenantTimeouts | cdktn.IResolvable): any;
export declare function cloudfrontDistributionTenantTimeoutsToHclTerraform(struct?: CloudfrontDistributionTenantTimeouts | cdktn.IResolvable): any;
export declare class CloudfrontDistributionTenantTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontDistributionTenantTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontDistributionTenantTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant}
*/
export declare class CloudfrontDistributionTenant extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_distribution_tenant";
    /**
    * Generates CDKTN code for importing a CloudfrontDistributionTenant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontDistributionTenant to import
    * @param importFromId The id of the existing CloudfrontDistributionTenant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontDistributionTenant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontDistributionTenantConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontDistributionTenantConfig);
    get arn(): string;
    private _connectionGroupId?;
    get connectionGroupId(): string;
    set connectionGroupId(value: string);
    resetConnectionGroupId(): void;
    get connectionGroupIdInput(): string | undefined;
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _waitForDeployment?;
    get waitForDeployment(): boolean | cdktn.IResolvable;
    set waitForDeployment(value: boolean | cdktn.IResolvable);
    resetWaitForDeployment(): void;
    get waitForDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _customizations;
    get customizations(): CloudfrontDistributionTenantCustomizationsList;
    putCustomizations(value: CloudfrontDistributionTenantCustomizations[] | cdktn.IResolvable): void;
    resetCustomizations(): void;
    get customizationsInput(): cdktn.IResolvable | CloudfrontDistributionTenantCustomizations[] | undefined;
    private _domain;
    get domain(): CloudfrontDistributionTenantDomainList;
    putDomain(value: CloudfrontDistributionTenantDomain[] | cdktn.IResolvable): void;
    resetDomain(): void;
    get domainInput(): cdktn.IResolvable | CloudfrontDistributionTenantDomain[] | undefined;
    private _managedCertificateRequest;
    get managedCertificateRequest(): CloudfrontDistributionTenantManagedCertificateRequestList;
    putManagedCertificateRequest(value: CloudfrontDistributionTenantManagedCertificateRequest[] | cdktn.IResolvable): void;
    resetManagedCertificateRequest(): void;
    get managedCertificateRequestInput(): cdktn.IResolvable | CloudfrontDistributionTenantManagedCertificateRequest[] | undefined;
    private _parameter;
    get parameter(): CloudfrontDistributionTenantParameterList;
    putParameter(value: CloudfrontDistributionTenantParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | CloudfrontDistributionTenantParameter[] | undefined;
    private _timeouts;
    get timeouts(): CloudfrontDistributionTenantTimeoutsOutputReference;
    putTimeouts(value: CloudfrontDistributionTenantTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudfrontDistributionTenantTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
