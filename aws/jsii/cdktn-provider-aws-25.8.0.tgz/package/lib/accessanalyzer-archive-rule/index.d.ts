/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessanalyzerArchiveRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#analyzer_name AccessanalyzerArchiveRule#analyzer_name}
    */
    readonly analyzerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#id AccessanalyzerArchiveRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#region AccessanalyzerArchiveRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#rule_name AccessanalyzerArchiveRule#rule_name}
    */
    readonly ruleName: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#filter AccessanalyzerArchiveRule#filter}
    */
    readonly filter: AccessanalyzerArchiveRuleFilter[] | cdktn.IResolvable;
}
export interface AccessanalyzerArchiveRuleFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#contains AccessanalyzerArchiveRule#contains}
    */
    readonly contains?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#criteria AccessanalyzerArchiveRule#criteria}
    */
    readonly criteria: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#eq AccessanalyzerArchiveRule#eq}
    */
    readonly eq?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#exists AccessanalyzerArchiveRule#exists}
    */
    readonly exists?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#neq AccessanalyzerArchiveRule#neq}
    */
    readonly neq?: string[];
}
export declare function accessanalyzerArchiveRuleFilterToTerraform(struct?: AccessanalyzerArchiveRuleFilter | cdktn.IResolvable): any;
export declare function accessanalyzerArchiveRuleFilterToHclTerraform(struct?: AccessanalyzerArchiveRuleFilter | cdktn.IResolvable): any;
export declare class AccessanalyzerArchiveRuleFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerArchiveRuleFilter | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerArchiveRuleFilter | cdktn.IResolvable | undefined);
    private _contains?;
    get contains(): string[];
    set contains(value: string[]);
    resetContains(): void;
    get containsInput(): string[] | undefined;
    private _criteria?;
    get criteria(): string;
    set criteria(value: string);
    get criteriaInput(): string | undefined;
    private _eq?;
    get eq(): string[];
    set eq(value: string[]);
    resetEq(): void;
    get eqInput(): string[] | undefined;
    private _exists?;
    get exists(): string;
    set exists(value: string);
    resetExists(): void;
    get existsInput(): string | undefined;
    private _neq?;
    get neq(): string[];
    set neq(value: string[]);
    resetNeq(): void;
    get neqInput(): string[] | undefined;
}
export declare class AccessanalyzerArchiveRuleFilterList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerArchiveRuleFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerArchiveRuleFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule aws_accessanalyzer_archive_rule}
*/
export declare class AccessanalyzerArchiveRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_accessanalyzer_archive_rule";
    /**
    * Generates CDKTN code for importing a AccessanalyzerArchiveRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessanalyzerArchiveRule to import
    * @param importFromId The id of the existing AccessanalyzerArchiveRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessanalyzerArchiveRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/accessanalyzer_archive_rule aws_accessanalyzer_archive_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessanalyzerArchiveRuleConfig
    */
    constructor(scope: Construct, id: string, config: AccessanalyzerArchiveRuleConfig);
    private _analyzerName?;
    get analyzerName(): string;
    set analyzerName(value: string);
    get analyzerNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _filter;
    get filter(): AccessanalyzerArchiveRuleFilterList;
    putFilter(value: AccessanalyzerArchiveRuleFilter[] | cdktn.IResolvable): void;
    get filterInput(): cdktn.IResolvable | AccessanalyzerArchiveRuleFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
