/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectRoutingProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#default_outbound_queue_id ConnectRoutingProfile#default_outbound_queue_id}
    */
    readonly defaultOutboundQueueId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#description ConnectRoutingProfile#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#id ConnectRoutingProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#instance_id ConnectRoutingProfile#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#name ConnectRoutingProfile#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#region ConnectRoutingProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#tags ConnectRoutingProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#tags_all ConnectRoutingProfile#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * media_concurrencies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#media_concurrencies ConnectRoutingProfile#media_concurrencies}
    */
    readonly mediaConcurrencies: ConnectRoutingProfileMediaConcurrencies[] | cdktn.IResolvable;
    /**
    * queue_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#queue_configs ConnectRoutingProfile#queue_configs}
    */
    readonly queueConfigs?: ConnectRoutingProfileQueueConfigs[] | cdktn.IResolvable;
}
export interface ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#behavior_type ConnectRoutingProfile#behavior_type}
    */
    readonly behaviorType: string;
}
export declare function connectRoutingProfileMediaConcurrenciesCrossChannelBehaviorToTerraform(struct?: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehaviorOutputReference | ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior): any;
export declare function connectRoutingProfileMediaConcurrenciesCrossChannelBehaviorToHclTerraform(struct?: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehaviorOutputReference | ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior): any;
export declare class ConnectRoutingProfileMediaConcurrenciesCrossChannelBehaviorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | undefined;
    set internalValue(value: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | undefined);
    private _behaviorType?;
    get behaviorType(): string;
    set behaviorType(value: string);
    get behaviorTypeInput(): string | undefined;
}
export interface ConnectRoutingProfileMediaConcurrencies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#channel ConnectRoutingProfile#channel}
    */
    readonly channel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#concurrency ConnectRoutingProfile#concurrency}
    */
    readonly concurrency: number;
    /**
    * cross_channel_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#cross_channel_behavior ConnectRoutingProfile#cross_channel_behavior}
    */
    readonly crossChannelBehavior?: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior;
}
export declare function connectRoutingProfileMediaConcurrenciesToTerraform(struct?: ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable): any;
export declare function connectRoutingProfileMediaConcurrenciesToHclTerraform(struct?: ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileMediaConcurrenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileMediaConcurrencies | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _concurrency?;
    get concurrency(): number;
    set concurrency(value: number);
    get concurrencyInput(): number | undefined;
    private _crossChannelBehavior;
    get crossChannelBehavior(): ConnectRoutingProfileMediaConcurrenciesCrossChannelBehaviorOutputReference;
    putCrossChannelBehavior(value: ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior): void;
    resetCrossChannelBehavior(): void;
    get crossChannelBehaviorInput(): ConnectRoutingProfileMediaConcurrenciesCrossChannelBehavior | undefined;
}
export declare class ConnectRoutingProfileMediaConcurrenciesList extends cdktn.ComplexList {
    internalValue?: ConnectRoutingProfileMediaConcurrencies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectRoutingProfileMediaConcurrenciesOutputReference;
}
export interface ConnectRoutingProfileQueueConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#channel ConnectRoutingProfile#channel}
    */
    readonly channel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#delay ConnectRoutingProfile#delay}
    */
    readonly delay: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#priority ConnectRoutingProfile#priority}
    */
    readonly priority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#queue_id ConnectRoutingProfile#queue_id}
    */
    readonly queueId: string;
}
export declare function connectRoutingProfileQueueConfigsToTerraform(struct?: ConnectRoutingProfileQueueConfigs | cdktn.IResolvable): any;
export declare function connectRoutingProfileQueueConfigsToHclTerraform(struct?: ConnectRoutingProfileQueueConfigs | cdktn.IResolvable): any;
export declare class ConnectRoutingProfileQueueConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectRoutingProfileQueueConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: ConnectRoutingProfileQueueConfigs | cdktn.IResolvable | undefined);
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
    private _delay?;
    get delay(): number;
    set delay(value: number);
    get delayInput(): number | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    get queueArn(): string;
    private _queueId?;
    get queueId(): string;
    set queueId(value: string);
    get queueIdInput(): string | undefined;
    get queueName(): string;
}
export declare class ConnectRoutingProfileQueueConfigsList extends cdktn.ComplexList {
    internalValue?: ConnectRoutingProfileQueueConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectRoutingProfileQueueConfigsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile aws_connect_routing_profile}
*/
export declare class ConnectRoutingProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_routing_profile";
    /**
    * Generates CDKTN code for importing a ConnectRoutingProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConnectRoutingProfile to import
    * @param importFromId The id of the existing ConnectRoutingProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConnectRoutingProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/connect_routing_profile aws_connect_routing_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectRoutingProfileConfig
    */
    constructor(scope: Construct, id: string, config: ConnectRoutingProfileConfig);
    get arn(): string;
    private _defaultOutboundQueueId?;
    get defaultOutboundQueueId(): string;
    set defaultOutboundQueueId(value: string);
    get defaultOutboundQueueIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routingProfileId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _mediaConcurrencies;
    get mediaConcurrencies(): ConnectRoutingProfileMediaConcurrenciesList;
    putMediaConcurrencies(value: ConnectRoutingProfileMediaConcurrencies[] | cdktn.IResolvable): void;
    get mediaConcurrenciesInput(): cdktn.IResolvable | ConnectRoutingProfileMediaConcurrencies[] | undefined;
    private _queueConfigs;
    get queueConfigs(): ConnectRoutingProfileQueueConfigsList;
    putQueueConfigs(value: ConnectRoutingProfileQueueConfigs[] | cdktn.IResolvable): void;
    resetQueueConfigs(): void;
    get queueConfigsInput(): cdktn.IResolvable | ConnectRoutingProfileQueueConfigs[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
