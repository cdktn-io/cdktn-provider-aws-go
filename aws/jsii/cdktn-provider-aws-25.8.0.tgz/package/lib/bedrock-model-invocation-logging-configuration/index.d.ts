/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockModelInvocationLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#region BedrockModelInvocationLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#logging_config BedrockModelInvocationLoggingConfiguration#logging_config}
    */
    readonly loggingConfig?: BedrockModelInvocationLoggingConfigurationLoggingConfig[] | cdktn.IResolvable;
}
export interface BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#bucket_name BedrockModelInvocationLoggingConfiguration#bucket_name}
    */
    readonly bucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#key_prefix BedrockModelInvocationLoggingConfiguration#key_prefix}
    */
    readonly keyPrefix?: string;
}
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3ConfigToTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config | cdktn.IResolvable): any;
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3ConfigToHclTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config | cdktn.IResolvable): any;
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _keyPrefix?;
    get keyPrefix(): string;
    set keyPrefix(value: string);
    resetKeyPrefix(): void;
    get keyPrefixInput(): string | undefined;
}
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3ConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3ConfigOutputReference;
}
export interface BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#log_group_name BedrockModelInvocationLoggingConfiguration#log_group_name}
    */
    readonly logGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#role_arn BedrockModelInvocationLoggingConfiguration#role_arn}
    */
    readonly roleArn: string;
    /**
    * large_data_delivery_s3_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#large_data_delivery_s3_config BedrockModelInvocationLoggingConfiguration#large_data_delivery_s3_config}
    */
    readonly largeDataDeliveryS3Config?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config[] | cdktn.IResolvable;
}
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigToTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig | cdktn.IResolvable): any;
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigToHclTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig | cdktn.IResolvable): any;
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig | cdktn.IResolvable | undefined);
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    get logGroupNameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _largeDataDeliveryS3Config;
    get largeDataDeliveryS3Config(): BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3ConfigList;
    putLargeDataDeliveryS3Config(value: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config[] | cdktn.IResolvable): void;
    resetLargeDataDeliveryS3Config(): void;
    get largeDataDeliveryS3ConfigInput(): cdktn.IResolvable | BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigLargeDataDeliveryS3Config[] | undefined;
}
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigOutputReference;
}
export interface BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#bucket_name BedrockModelInvocationLoggingConfiguration#bucket_name}
    */
    readonly bucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#key_prefix BedrockModelInvocationLoggingConfiguration#key_prefix}
    */
    readonly keyPrefix?: string;
}
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigS3ConfigToTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config | cdktn.IResolvable): any;
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigS3ConfigToHclTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config | cdktn.IResolvable): any;
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigS3ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    private _keyPrefix?;
    get keyPrefix(): string;
    set keyPrefix(value: string);
    resetKeyPrefix(): void;
    get keyPrefixInput(): string | undefined;
}
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigS3ConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationLoggingConfigurationLoggingConfigS3ConfigOutputReference;
}
export interface BedrockModelInvocationLoggingConfigurationLoggingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#embedding_data_delivery_enabled BedrockModelInvocationLoggingConfiguration#embedding_data_delivery_enabled}
    */
    readonly embeddingDataDeliveryEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#image_data_delivery_enabled BedrockModelInvocationLoggingConfiguration#image_data_delivery_enabled}
    */
    readonly imageDataDeliveryEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#text_data_delivery_enabled BedrockModelInvocationLoggingConfiguration#text_data_delivery_enabled}
    */
    readonly textDataDeliveryEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#video_data_delivery_enabled BedrockModelInvocationLoggingConfiguration#video_data_delivery_enabled}
    */
    readonly videoDataDeliveryEnabled?: boolean | cdktn.IResolvable;
    /**
    * cloudwatch_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#cloudwatch_config BedrockModelInvocationLoggingConfiguration#cloudwatch_config}
    */
    readonly cloudwatchConfig?: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig[] | cdktn.IResolvable;
    /**
    * s3_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#s3_config BedrockModelInvocationLoggingConfiguration#s3_config}
    */
    readonly s3Config?: BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config[] | cdktn.IResolvable;
}
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigToTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfig | cdktn.IResolvable): any;
export declare function bedrockModelInvocationLoggingConfigurationLoggingConfigToHclTerraform(struct?: BedrockModelInvocationLoggingConfigurationLoggingConfig | cdktn.IResolvable): any;
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationLoggingConfigurationLoggingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationLoggingConfigurationLoggingConfig | cdktn.IResolvable | undefined);
    private _embeddingDataDeliveryEnabled?;
    get embeddingDataDeliveryEnabled(): boolean | cdktn.IResolvable;
    set embeddingDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
    resetEmbeddingDataDeliveryEnabled(): void;
    get embeddingDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _imageDataDeliveryEnabled?;
    get imageDataDeliveryEnabled(): boolean | cdktn.IResolvable;
    set imageDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
    resetImageDataDeliveryEnabled(): void;
    get imageDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _textDataDeliveryEnabled?;
    get textDataDeliveryEnabled(): boolean | cdktn.IResolvable;
    set textDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
    resetTextDataDeliveryEnabled(): void;
    get textDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _videoDataDeliveryEnabled?;
    get videoDataDeliveryEnabled(): boolean | cdktn.IResolvable;
    set videoDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
    resetVideoDataDeliveryEnabled(): void;
    get videoDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _cloudwatchConfig;
    get cloudwatchConfig(): BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfigList;
    putCloudwatchConfig(value: BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig[] | cdktn.IResolvable): void;
    resetCloudwatchConfig(): void;
    get cloudwatchConfigInput(): cdktn.IResolvable | BedrockModelInvocationLoggingConfigurationLoggingConfigCloudwatchConfig[] | undefined;
    private _s3Config;
    get s3Config(): BedrockModelInvocationLoggingConfigurationLoggingConfigS3ConfigList;
    putS3Config(value: BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config[] | cdktn.IResolvable): void;
    resetS3Config(): void;
    get s3ConfigInput(): cdktn.IResolvable | BedrockModelInvocationLoggingConfigurationLoggingConfigS3Config[] | undefined;
}
export declare class BedrockModelInvocationLoggingConfigurationLoggingConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationLoggingConfigurationLoggingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationLoggingConfigurationLoggingConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration aws_bedrock_model_invocation_logging_configuration}
*/
export declare class BedrockModelInvocationLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_model_invocation_logging_configuration";
    /**
    * Generates CDKTN code for importing a BedrockModelInvocationLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockModelInvocationLoggingConfiguration to import
    * @param importFromId The id of the existing BedrockModelInvocationLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockModelInvocationLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrock_model_invocation_logging_configuration aws_bedrock_model_invocation_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockModelInvocationLoggingConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BedrockModelInvocationLoggingConfigurationConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _loggingConfig;
    get loggingConfig(): BedrockModelInvocationLoggingConfigurationLoggingConfigList;
    putLoggingConfig(value: BedrockModelInvocationLoggingConfigurationLoggingConfig[] | cdktn.IResolvable): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): cdktn.IResolvable | BedrockModelInvocationLoggingConfigurationLoggingConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
