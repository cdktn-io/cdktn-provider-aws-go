/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreHarnessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#allowed_tools BedrockagentcoreHarness#allowed_tools}
    */
    readonly allowedTools?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#environment_variables BedrockagentcoreHarness#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#execution_role_arn BedrockagentcoreHarness#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#harness_name BedrockagentcoreHarness#harness_name}
    */
    readonly harnessName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#max_iterations BedrockagentcoreHarness#max_iterations}
    */
    readonly maxIterations?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#region BedrockagentcoreHarness#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#tags BedrockagentcoreHarness#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#timeout_seconds BedrockagentcoreHarness#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#truncation BedrockagentcoreHarness#truncation}
    */
    readonly truncation?: BedrockagentcoreHarnessTruncation[] | cdktn.IResolvable;
    /**
    * authorizer_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#authorizer_configuration BedrockagentcoreHarness#authorizer_configuration}
    */
    readonly authorizerConfiguration?: BedrockagentcoreHarnessAuthorizerConfiguration[] | cdktn.IResolvable;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#environment BedrockagentcoreHarness#environment}
    */
    readonly environment?: BedrockagentcoreHarnessEnvironment[] | cdktn.IResolvable;
    /**
    * environment_artifact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#environment_artifact BedrockagentcoreHarness#environment_artifact}
    */
    readonly environmentArtifact?: BedrockagentcoreHarnessEnvironmentArtifact[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#memory BedrockagentcoreHarness#memory}
    */
    readonly memory?: BedrockagentcoreHarnessMemory[] | cdktn.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#model BedrockagentcoreHarness#model}
    */
    readonly model?: BedrockagentcoreHarnessModel[] | cdktn.IResolvable;
    /**
    * skill block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#skill BedrockagentcoreHarness#skill}
    */
    readonly skill?: BedrockagentcoreHarnessSkill[] | cdktn.IResolvable;
    /**
    * system_prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#system_prompt BedrockagentcoreHarness#system_prompt}
    */
    readonly systemPrompt?: BedrockagentcoreHarnessSystemPrompt[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#timeouts BedrockagentcoreHarness#timeouts}
    */
    readonly timeouts?: BedrockagentcoreHarnessTimeouts;
    /**
    * tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#tool BedrockagentcoreHarness#tool}
    */
    readonly tool?: BedrockagentcoreHarnessTool[] | cdktn.IResolvable;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint | undefined);
    get accessPointArn(): string;
    get mountPath(): string;
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint | undefined);
    get accessPointArn(): string;
    get mountPath(): string;
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage | undefined);
    get mountPath(): string;
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfiguration {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfiguration): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfiguration): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfiguration | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfiguration | undefined);
    private _efsAccessPoint;
    get efsAccessPoint(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointList;
    private _s3FilesAccessPoint;
    get s3FilesAccessPoint(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointList;
    private _sessionStorage;
    get sessionStorage(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageList;
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfiguration {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfiguration): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfiguration): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfiguration | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfiguration | undefined);
    get idleRuntimeSessionTimeout(): number;
    get maxLifetime(): number;
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | undefined);
    get requireServiceS3Endpoint(): cdktn.IResolvable;
    get securityGroups(): string[];
    get subnets(): string[];
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfiguration {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfiguration): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfiguration): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfiguration | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfiguration | undefined);
    get networkMode(): string;
    private _networkModeConfig;
    get networkModeConfig(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigList;
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironment {
}
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironment): any;
export declare function bedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironment): any;
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironment | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironment | undefined);
    get agentRuntimeArn(): string;
    get agentRuntimeId(): string;
    get agentRuntimeName(): string;
    private _filesystemConfiguration;
    get filesystemConfiguration(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationList;
    private _lifecycleConfiguration;
    get lifecycleConfiguration(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationList;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationList;
}
export declare class BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentActual {
}
export declare function bedrockagentcoreHarnessEnvironmentActualToTerraform(struct?: BedrockagentcoreHarnessEnvironmentActual): any;
export declare function bedrockagentcoreHarnessEnvironmentActualToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentActual): any;
export declare class BedrockagentcoreHarnessEnvironmentActualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentActual | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentActual | undefined);
    private _agentcoreRuntimeEnvironment;
    get agentcoreRuntimeEnvironment(): BedrockagentcoreHarnessEnvironmentActualAgentcoreRuntimeEnvironmentList;
}
export declare class BedrockagentcoreHarnessEnvironmentActualList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentActualOutputReference;
}
export interface BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfig {
}
export declare function bedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigToTerraform(struct?: BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfig): any;
export declare function bedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigToHclTerraform(struct?: BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfig): any;
export declare class BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfig | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfig | undefined);
    get mapBlockKey(): string;
    get relevanceScore(): number;
    get strategyId(): string;
    get topK(): number;
}
export declare class BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigOutputReference;
}
export interface BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfiguration {
}
export declare function bedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationToTerraform(struct?: BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfiguration): any;
export declare function bedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfiguration): any;
export declare class BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfiguration | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfiguration | undefined);
    get actorId(): string;
    get arn(): string;
    get messagesCount(): number;
    private _retrievalConfig;
    get retrievalConfig(): BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigList;
}
export declare class BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessMemoryActualDisabled {
}
export declare function bedrockagentcoreHarnessMemoryActualDisabledToTerraform(struct?: BedrockagentcoreHarnessMemoryActualDisabled): any;
export declare function bedrockagentcoreHarnessMemoryActualDisabledToHclTerraform(struct?: BedrockagentcoreHarnessMemoryActualDisabled): any;
export declare class BedrockagentcoreHarnessMemoryActualDisabledOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryActualDisabled | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryActualDisabled | undefined);
}
export declare class BedrockagentcoreHarnessMemoryActualDisabledList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryActualDisabledOutputReference;
}
export interface BedrockagentcoreHarnessMemoryActualManagedMemoryConfiguration {
}
export declare function bedrockagentcoreHarnessMemoryActualManagedMemoryConfigurationToTerraform(struct?: BedrockagentcoreHarnessMemoryActualManagedMemoryConfiguration): any;
export declare function bedrockagentcoreHarnessMemoryActualManagedMemoryConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessMemoryActualManagedMemoryConfiguration): any;
export declare class BedrockagentcoreHarnessMemoryActualManagedMemoryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryActualManagedMemoryConfiguration | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryActualManagedMemoryConfiguration | undefined);
    get arn(): string;
    get encryptionKeyArn(): string;
    get eventExpiryDuration(): number;
    get strategies(): string[];
}
export declare class BedrockagentcoreHarnessMemoryActualManagedMemoryConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryActualManagedMemoryConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessMemoryActual {
}
export declare function bedrockagentcoreHarnessMemoryActualToTerraform(struct?: BedrockagentcoreHarnessMemoryActual): any;
export declare function bedrockagentcoreHarnessMemoryActualToHclTerraform(struct?: BedrockagentcoreHarnessMemoryActual): any;
export declare class BedrockagentcoreHarnessMemoryActualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryActual | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryActual | undefined);
    private _agentcoreMemoryConfiguration;
    get agentcoreMemoryConfiguration(): BedrockagentcoreHarnessMemoryActualAgentcoreMemoryConfigurationList;
    private _disabled;
    get disabled(): BedrockagentcoreHarnessMemoryActualDisabledList;
    private _managedMemoryConfiguration;
    get managedMemoryConfiguration(): BedrockagentcoreHarnessMemoryActualManagedMemoryConfigurationList;
}
export declare class BedrockagentcoreHarnessMemoryActualList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryActualOutputReference;
}
export interface BedrockagentcoreHarnessTruncationConfigSlidingWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#messages_count BedrockagentcoreHarness#messages_count}
    */
    readonly messagesCount?: number;
}
export declare function bedrockagentcoreHarnessTruncationConfigSlidingWindowToTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationConfigSlidingWindowToHclTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationConfigSlidingWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncationConfigSlidingWindow | cdktn.IResolvable | undefined);
    private _messagesCount?;
    get messagesCount(): number;
    set messagesCount(value: number);
    resetMessagesCount(): void;
    get messagesCountInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessTruncationConfigSlidingWindowList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessTruncationConfigSlidingWindow[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessTruncationConfigSlidingWindowOutputReference;
}
export interface BedrockagentcoreHarnessTruncationConfigSummarization {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#preserve_recent_messages BedrockagentcoreHarness#preserve_recent_messages}
    */
    readonly preserveRecentMessages?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#summarization_system_prompt BedrockagentcoreHarness#summarization_system_prompt}
    */
    readonly summarizationSystemPrompt?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#summary_ratio BedrockagentcoreHarness#summary_ratio}
    */
    readonly summaryRatio?: number;
}
export declare function bedrockagentcoreHarnessTruncationConfigSummarizationToTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationConfigSummarizationToHclTerraform(struct?: BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationConfigSummarizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncationConfigSummarization | cdktn.IResolvable | undefined);
    private _preserveRecentMessages?;
    get preserveRecentMessages(): number;
    set preserveRecentMessages(value: number);
    resetPreserveRecentMessages(): void;
    get preserveRecentMessagesInput(): number | undefined;
    private _summarizationSystemPrompt?;
    get summarizationSystemPrompt(): string;
    set summarizationSystemPrompt(value: string);
    resetSummarizationSystemPrompt(): void;
    get summarizationSystemPromptInput(): string | undefined;
    private _summaryRatio?;
    get summaryRatio(): number;
    set summaryRatio(value: number);
    resetSummaryRatio(): void;
    get summaryRatioInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessTruncationConfigSummarizationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessTruncationConfigSummarization[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessTruncationConfigSummarizationOutputReference;
}
export interface BedrockagentcoreHarnessTruncationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#sliding_window BedrockagentcoreHarness#sliding_window}
    */
    readonly slidingWindow?: BedrockagentcoreHarnessTruncationConfigSlidingWindow[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#summarization BedrockagentcoreHarness#summarization}
    */
    readonly summarization?: BedrockagentcoreHarnessTruncationConfigSummarization[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessTruncationConfigToTerraform(struct?: BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationConfigToHclTerraform(struct?: BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncationConfig | cdktn.IResolvable | undefined);
    private _slidingWindow;
    get slidingWindow(): BedrockagentcoreHarnessTruncationConfigSlidingWindowList;
    putSlidingWindow(value: BedrockagentcoreHarnessTruncationConfigSlidingWindow[] | cdktn.IResolvable): void;
    resetSlidingWindow(): void;
    get slidingWindowInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncationConfigSlidingWindow[] | undefined;
    private _summarization;
    get summarization(): BedrockagentcoreHarnessTruncationConfigSummarizationList;
    putSummarization(value: BedrockagentcoreHarnessTruncationConfigSummarization[] | cdktn.IResolvable): void;
    resetSummarization(): void;
    get summarizationInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncationConfigSummarization[] | undefined;
}
export declare class BedrockagentcoreHarnessTruncationConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessTruncationConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessTruncationConfigOutputReference;
}
export interface BedrockagentcoreHarnessTruncation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#config BedrockagentcoreHarness#config}
    */
    readonly config?: BedrockagentcoreHarnessTruncationConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#strategy BedrockagentcoreHarness#strategy}
    */
    readonly strategy?: string;
}
export declare function bedrockagentcoreHarnessTruncationToTerraform(struct?: BedrockagentcoreHarnessTruncation | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTruncationToHclTerraform(struct?: BedrockagentcoreHarnessTruncation | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTruncationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessTruncation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTruncation | cdktn.IResolvable | undefined);
    private _config;
    get config(): BedrockagentcoreHarnessTruncationConfigList;
    putConfig(value: BedrockagentcoreHarnessTruncationConfig[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncationConfig[] | undefined;
    private _strategy?;
    get strategy(): string;
    set strategy(value: string);
    resetStrategy(): void;
    get strategyInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessTruncationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessTruncation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessTruncationOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#arn BedrockagentcoreHarness#arn}
    */
    readonly arn: string;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#workload_identities BedrockagentcoreHarness#workload_identities}
    */
    readonly workloadIdentities?: string[];
    /**
    * hosting_environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#hosting_environment BedrockagentcoreHarness#hosting_environment}
    */
    readonly hostingEnvironment?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration | cdktn.IResolvable | undefined);
    private _workloadIdentities?;
    get workloadIdentities(): string[];
    set workloadIdentities(value: string[]);
    resetWorkloadIdentities(): void;
    get workloadIdentitiesInput(): string[] | undefined;
    private _hostingEnvironment;
    get hostingEnvironment(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironmentList;
    putHostingEnvironment(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment[] | cdktn.IResolvable): void;
    resetHostingEnvironment(): void;
    get hostingEnvironmentInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationHostingEnvironment[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#match_value_string BedrockagentcoreHarness#match_value_string}
    */
    readonly matchValueString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#match_value_string_list BedrockagentcoreHarness#match_value_string_list}
    */
    readonly matchValueStringList?: string[];
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValueToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValueToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue | cdktn.IResolvable | undefined);
    private _matchValueString?;
    get matchValueString(): string;
    set matchValueString(value: string);
    resetMatchValueString(): void;
    get matchValueStringInput(): string | undefined;
    private _matchValueStringList?;
    get matchValueStringList(): string[];
    set matchValueStringList(value: string[]);
    resetMatchValueStringList(): void;
    get matchValueStringListInput(): string[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValueList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValueOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#claim_match_operator BedrockagentcoreHarness#claim_match_operator}
    */
    readonly claimMatchOperator: string;
    /**
    * claim_match_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#claim_match_value BedrockagentcoreHarness#claim_match_value}
    */
    readonly claimMatchValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue | cdktn.IResolvable | undefined);
    private _claimMatchOperator?;
    get claimMatchOperator(): string;
    set claimMatchOperator(value: string);
    get claimMatchOperatorInput(): string | undefined;
    private _claimMatchValue;
    get claimMatchValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValueList;
    putClaimMatchValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue[] | cdktn.IResolvable): void;
    resetClaimMatchValue(): void;
    get claimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueClaimMatchValue[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#inbound_token_claim_name BedrockagentcoreHarness#inbound_token_claim_name}
    */
    readonly inboundTokenClaimName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#inbound_token_claim_value_type BedrockagentcoreHarness#inbound_token_claim_value_type}
    */
    readonly inboundTokenClaimValueType: string;
    /**
    * authorizing_claim_match_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#authorizing_claim_match_value BedrockagentcoreHarness#authorizing_claim_match_value}
    */
    readonly authorizingClaimMatchValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim | cdktn.IResolvable | undefined);
    private _inboundTokenClaimName?;
    get inboundTokenClaimName(): string;
    set inboundTokenClaimName(value: string);
    get inboundTokenClaimNameInput(): string | undefined;
    private _inboundTokenClaimValueType?;
    get inboundTokenClaimValueType(): string;
    set inboundTokenClaimValueType(value: string);
    get inboundTokenClaimValueTypeInput(): string | undefined;
    private _authorizingClaimMatchValue;
    get authorizingClaimMatchValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValueList;
    putAuthorizingClaimMatchValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue[] | cdktn.IResolvable): void;
    resetAuthorizingClaimMatchValue(): void;
    get authorizingClaimMatchValueInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimAuthorizingClaimMatchValue[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#endpoint_ip_address_type BedrockagentcoreHarness#endpoint_ip_address_type}
    */
    readonly endpointIpAddressType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#routing_domain BedrockagentcoreHarness#routing_domain}
    */
    readonly routingDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#security_group_ids BedrockagentcoreHarness#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#subnet_ids BedrockagentcoreHarness#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#tags BedrockagentcoreHarness#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#vpc_identifier BedrockagentcoreHarness#vpc_identifier}
    */
    readonly vpcIdentifier: string;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined);
    private _endpointIpAddressType?;
    get endpointIpAddressType(): string;
    set endpointIpAddressType(value: string);
    get endpointIpAddressTypeInput(): string | undefined;
    private _routingDomain?;
    get routingDomain(): string;
    set routingDomain(value: string);
    resetRoutingDomain(): void;
    get routingDomainInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    get vpcIdentifierInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#resource_configuration_identifier BedrockagentcoreHarness#resource_configuration_identifier}
    */
    readonly resourceConfigurationIdentifier?: string;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined);
    private _resourceConfigurationIdentifier?;
    get resourceConfigurationIdentifier(): string;
    set resourceConfigurationIdentifier(value: string);
    resetResourceConfigurationIdentifier(): void;
    get resourceConfigurationIdentifierInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint {
    /**
    * managed_vpc_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#managed_vpc_resource BedrockagentcoreHarness#managed_vpc_resource}
    */
    readonly managedVpcResource?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource[] | cdktn.IResolvable;
    /**
    * self_managed_lattice_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#self_managed_lattice_resource BedrockagentcoreHarness#self_managed_lattice_resource}
    */
    readonly selfManagedLatticeResource?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint | cdktn.IResolvable | undefined);
    private _managedVpcResource;
    get managedVpcResource(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceList;
    putManagedVpcResource(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource[] | cdktn.IResolvable): void;
    resetManagedVpcResource(): void;
    get managedVpcResourceInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResource[] | undefined;
    private _selfManagedLatticeResource;
    get selfManagedLatticeResource(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceList;
    putSelfManagedLatticeResource(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable): void;
    resetSelfManagedLatticeResource(): void;
    get selfManagedLatticeResourceInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResource[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#endpoint_ip_address_type BedrockagentcoreHarness#endpoint_ip_address_type}
    */
    readonly endpointIpAddressType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#routing_domain BedrockagentcoreHarness#routing_domain}
    */
    readonly routingDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#security_group_ids BedrockagentcoreHarness#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#subnet_ids BedrockagentcoreHarness#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#tags BedrockagentcoreHarness#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#vpc_identifier BedrockagentcoreHarness#vpc_identifier}
    */
    readonly vpcIdentifier: string;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined);
    private _endpointIpAddressType?;
    get endpointIpAddressType(): string;
    set endpointIpAddressType(value: string);
    get endpointIpAddressTypeInput(): string | undefined;
    private _routingDomain?;
    get routingDomain(): string;
    set routingDomain(value: string);
    resetRoutingDomain(): void;
    get routingDomainInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    get vpcIdentifierInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#resource_configuration_identifier BedrockagentcoreHarness#resource_configuration_identifier}
    */
    readonly resourceConfigurationIdentifier?: string;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined);
    private _resourceConfigurationIdentifier?;
    get resourceConfigurationIdentifier(): string;
    set resourceConfigurationIdentifier(value: string);
    resetResourceConfigurationIdentifier(): void;
    get resourceConfigurationIdentifierInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint {
    /**
    * managed_vpc_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#managed_vpc_resource BedrockagentcoreHarness#managed_vpc_resource}
    */
    readonly managedVpcResource?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource[] | cdktn.IResolvable;
    /**
    * self_managed_lattice_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#self_managed_lattice_resource BedrockagentcoreHarness#self_managed_lattice_resource}
    */
    readonly selfManagedLatticeResource?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint | cdktn.IResolvable | undefined);
    private _managedVpcResource;
    get managedVpcResource(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceList;
    putManagedVpcResource(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource[] | cdktn.IResolvable): void;
    resetManagedVpcResource(): void;
    get managedVpcResourceInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResource[] | undefined;
    private _selfManagedLatticeResource;
    get selfManagedLatticeResource(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceList;
    putSelfManagedLatticeResource(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable): void;
    resetSelfManagedLatticeResource(): void;
    get selfManagedLatticeResourceInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResource[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#domain BedrockagentcoreHarness#domain}
    */
    readonly domain: string;
    /**
    * private_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#private_endpoint BedrockagentcoreHarness#private_endpoint}
    */
    readonly privateEndpoint?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides | cdktn.IResolvable | undefined);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _privateEndpoint;
    get privateEndpoint(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointList;
    putPrivateEndpoint(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint[] | cdktn.IResolvable): void;
    resetPrivateEndpoint(): void;
    get privateEndpointInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpoint[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#allowed_audience BedrockagentcoreHarness#allowed_audience}
    */
    readonly allowedAudience?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#allowed_clients BedrockagentcoreHarness#allowed_clients}
    */
    readonly allowedClients?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#allowed_scopes BedrockagentcoreHarness#allowed_scopes}
    */
    readonly allowedScopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#discovery_url BedrockagentcoreHarness#discovery_url}
    */
    readonly discoveryUrl: string;
    /**
    * allowed_workload_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#allowed_workload_configuration BedrockagentcoreHarness#allowed_workload_configuration}
    */
    readonly allowedWorkloadConfiguration?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration[] | cdktn.IResolvable;
    /**
    * custom_claim block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#custom_claim BedrockagentcoreHarness#custom_claim}
    */
    readonly customClaim?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim[] | cdktn.IResolvable;
    /**
    * private_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#private_endpoint BedrockagentcoreHarness#private_endpoint}
    */
    readonly privateEndpoint?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint[] | cdktn.IResolvable;
    /**
    * private_endpoint_overrides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#private_endpoint_overrides BedrockagentcoreHarness#private_endpoint_overrides}
    */
    readonly privateEndpointOverrides?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer | cdktn.IResolvable | undefined);
    private _allowedAudience?;
    get allowedAudience(): string[];
    set allowedAudience(value: string[]);
    resetAllowedAudience(): void;
    get allowedAudienceInput(): string[] | undefined;
    private _allowedClients?;
    get allowedClients(): string[];
    set allowedClients(value: string[]);
    resetAllowedClients(): void;
    get allowedClientsInput(): string[] | undefined;
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
    private _discoveryUrl?;
    get discoveryUrl(): string;
    set discoveryUrl(value: string);
    get discoveryUrlInput(): string | undefined;
    private _allowedWorkloadConfiguration;
    get allowedWorkloadConfiguration(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfigurationList;
    putAllowedWorkloadConfiguration(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration[] | cdktn.IResolvable): void;
    resetAllowedWorkloadConfiguration(): void;
    get allowedWorkloadConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerAllowedWorkloadConfiguration[] | undefined;
    private _customClaim;
    get customClaim(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaimList;
    putCustomClaim(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim[] | cdktn.IResolvable): void;
    resetCustomClaim(): void;
    get customClaimInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerCustomClaim[] | undefined;
    private _privateEndpoint;
    get privateEndpoint(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointList;
    putPrivateEndpoint(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint[] | cdktn.IResolvable): void;
    resetPrivateEndpoint(): void;
    get privateEndpointInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpoint[] | undefined;
    private _privateEndpointOverrides;
    get privateEndpointOverrides(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesList;
    putPrivateEndpointOverrides(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | cdktn.IResolvable): void;
    resetPrivateEndpointOverrides(): void;
    get privateEndpointOverridesInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverrides[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerOutputReference;
}
export interface BedrockagentcoreHarnessAuthorizerConfiguration {
    /**
    * custom_jwt_authorizer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#custom_jwt_authorizer BedrockagentcoreHarness#custom_jwt_authorizer}
    */
    readonly customJwtAuthorizer?: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessAuthorizerConfigurationToTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessAuthorizerConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessAuthorizerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessAuthorizerConfiguration | cdktn.IResolvable | undefined);
    private _customJwtAuthorizer;
    get customJwtAuthorizer(): BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizerList;
    putCustomJwtAuthorizer(value: BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer[] | cdktn.IResolvable): void;
    resetCustomJwtAuthorizer(): void;
    get customJwtAuthorizerInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfigurationCustomJwtAuthorizer[] | undefined;
}
export declare class BedrockagentcoreHarnessAuthorizerConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessAuthorizerConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessAuthorizerConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#idle_runtime_session_timeout BedrockagentcoreHarness#idle_runtime_session_timeout}
    */
    readonly idleRuntimeSessionTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#max_lifetime BedrockagentcoreHarness#max_lifetime}
    */
    readonly maxLifetime?: number;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration | cdktn.IResolvable | undefined);
    private _idleRuntimeSessionTimeout?;
    get idleRuntimeSessionTimeout(): number;
    set idleRuntimeSessionTimeout(value: number);
    resetIdleRuntimeSessionTimeout(): void;
    get idleRuntimeSessionTimeoutInput(): number | undefined;
    private _maxLifetime?;
    get maxLifetime(): number;
    set maxLifetime(value: number);
    resetMaxLifetime(): void;
    get maxLifetimeInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#access_point_arn BedrockagentcoreHarness#access_point_arn}
    */
    readonly accessPointArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#mount_path BedrockagentcoreHarness#mount_path}
    */
    readonly mountPath: string;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    get accessPointArnInput(): string | undefined;
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#access_point_arn BedrockagentcoreHarness#access_point_arn}
    */
    readonly accessPointArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#mount_path BedrockagentcoreHarness#mount_path}
    */
    readonly mountPath: string;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint | cdktn.IResolvable | undefined);
    private _accessPointArn?;
    get accessPointArn(): string;
    set accessPointArn(value: string);
    get accessPointArnInput(): string | undefined;
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#mount_path BedrockagentcoreHarness#mount_path}
    */
    readonly mountPath: string;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage | cdktn.IResolvable | undefined);
    private _mountPath?;
    get mountPath(): string;
    set mountPath(value: string);
    get mountPathInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration {
    /**
    * efs_access_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#efs_access_point BedrockagentcoreHarness#efs_access_point}
    */
    readonly efsAccessPoint?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint[] | cdktn.IResolvable;
    /**
    * s3_files_access_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#s3_files_access_point BedrockagentcoreHarness#s3_files_access_point}
    */
    readonly s3FilesAccessPoint?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint[] | cdktn.IResolvable;
    /**
    * session_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#session_storage BedrockagentcoreHarness#session_storage}
    */
    readonly sessionStorage?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration | cdktn.IResolvable | undefined);
    private _efsAccessPoint;
    get efsAccessPoint(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointList;
    putEfsAccessPoint(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint[] | cdktn.IResolvable): void;
    resetEfsAccessPoint(): void;
    get efsAccessPointInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPoint[] | undefined;
    private _s3FilesAccessPoint;
    get s3FilesAccessPoint(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointList;
    putS3FilesAccessPoint(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint[] | cdktn.IResolvable): void;
    resetS3FilesAccessPoint(): void;
    get s3FilesAccessPointInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPoint[] | undefined;
    private _sessionStorage;
    get sessionStorage(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageList;
    putSessionStorage(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage[] | cdktn.IResolvable): void;
    resetSessionStorage(): void;
    get sessionStorageInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorage[] | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#security_groups BedrockagentcoreHarness#security_groups}
    */
    readonly securityGroups: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#subnets BedrockagentcoreHarness#subnets}
    */
    readonly subnets: string[];
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig | cdktn.IResolvable | undefined);
    get requireServiceS3Endpoint(): cdktn.IResolvable;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    get subnetsInput(): string[] | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#network_mode BedrockagentcoreHarness#network_mode}
    */
    readonly networkMode: string;
    /**
    * network_mode_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#network_mode_config BedrockagentcoreHarness#network_mode_config}
    */
    readonly networkModeConfig?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration | cdktn.IResolvable | undefined);
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    get networkModeInput(): string | undefined;
    private _networkModeConfig;
    get networkModeConfig(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigList;
    putNetworkModeConfig(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig[] | cdktn.IResolvable): void;
    resetNetworkModeConfig(): void;
    get networkModeConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfig[] | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#lifecycle_configuration BedrockagentcoreHarness#lifecycle_configuration}
    */
    readonly lifecycleConfiguration?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration[] | cdktn.IResolvable;
    /**
    * filesystem_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#filesystem_configuration BedrockagentcoreHarness#filesystem_configuration}
    */
    readonly filesystemConfiguration?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#network_configuration BedrockagentcoreHarness#network_configuration}
    */
    readonly networkConfiguration?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentToTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment | cdktn.IResolvable | undefined);
    get agentRuntimeArn(): string;
    get agentRuntimeId(): string;
    get agentRuntimeName(): string;
    private _lifecycleConfiguration;
    get lifecycleConfiguration(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationList;
    putLifecycleConfiguration(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration[] | cdktn.IResolvable): void;
    resetLifecycleConfiguration(): void;
    get lifecycleConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfiguration[] | undefined;
    private _filesystemConfiguration;
    get filesystemConfiguration(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationList;
    putFilesystemConfiguration(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration[] | cdktn.IResolvable): void;
    resetFilesystemConfiguration(): void;
    get filesystemConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfiguration[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationList;
    putNetworkConfiguration(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfiguration[] | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentOutputReference;
}
export interface BedrockagentcoreHarnessEnvironment {
    /**
    * agentcore_runtime_environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#agentcore_runtime_environment BedrockagentcoreHarness#agentcore_runtime_environment}
    */
    readonly agentcoreRuntimeEnvironment?: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessEnvironmentToTerraform(struct?: BedrockagentcoreHarnessEnvironment | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentToHclTerraform(struct?: BedrockagentcoreHarnessEnvironment | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironment | cdktn.IResolvable | undefined);
    private _agentcoreRuntimeEnvironment;
    get agentcoreRuntimeEnvironment(): BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironmentList;
    putAgentcoreRuntimeEnvironment(value: BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment[] | cdktn.IResolvable): void;
    resetAgentcoreRuntimeEnvironment(): void;
    get agentcoreRuntimeEnvironmentInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentAgentcoreRuntimeEnvironment[] | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#container_uri BedrockagentcoreHarness#container_uri}
    */
    readonly containerUri: string;
}
export declare function bedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationToTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration | cdktn.IResolvable | undefined);
    private _containerUri?;
    get containerUri(): string;
    set containerUri(value: string);
    get containerUriInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessEnvironmentArtifact {
    /**
    * container_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#container_configuration BedrockagentcoreHarness#container_configuration}
    */
    readonly containerConfiguration?: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessEnvironmentArtifactToTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessEnvironmentArtifactToHclTerraform(struct?: BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessEnvironmentArtifactOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessEnvironmentArtifact | cdktn.IResolvable | undefined);
    private _containerConfiguration;
    get containerConfiguration(): BedrockagentcoreHarnessEnvironmentArtifactContainerConfigurationList;
    putContainerConfiguration(value: BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration[] | cdktn.IResolvable): void;
    resetContainerConfiguration(): void;
    get containerConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentArtifactContainerConfiguration[] | undefined;
}
export declare class BedrockagentcoreHarnessEnvironmentArtifactList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessEnvironmentArtifact[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessEnvironmentArtifactOutputReference;
}
export interface BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#map_block_key BedrockagentcoreHarness#map_block_key}
    */
    readonly mapBlockKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#relevance_score BedrockagentcoreHarness#relevance_score}
    */
    readonly relevanceScore?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#strategy_id BedrockagentcoreHarness#strategy_id}
    */
    readonly strategyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#top_k BedrockagentcoreHarness#top_k}
    */
    readonly topK?: number;
}
export declare function bedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigToTerraform(struct?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigToHclTerraform(struct?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig | cdktn.IResolvable | undefined);
    private _mapBlockKey?;
    get mapBlockKey(): string;
    set mapBlockKey(value: string);
    get mapBlockKeyInput(): string | undefined;
    private _relevanceScore?;
    get relevanceScore(): number;
    set relevanceScore(value: number);
    resetRelevanceScore(): void;
    get relevanceScoreInput(): number | undefined;
    private _strategyId?;
    get strategyId(): string;
    set strategyId(value: string);
    resetStrategyId(): void;
    get strategyIdInput(): string | undefined;
    private _topK?;
    get topK(): number;
    set topK(value: number);
    resetTopK(): void;
    get topKInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigOutputReference;
}
export interface BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#actor_id BedrockagentcoreHarness#actor_id}
    */
    readonly actorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#arn BedrockagentcoreHarness#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#messages_count BedrockagentcoreHarness#messages_count}
    */
    readonly messagesCount?: number;
    /**
    * retrieval_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#retrieval_config BedrockagentcoreHarness#retrieval_config}
    */
    readonly retrievalConfig?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationToTerraform(struct?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration | cdktn.IResolvable | undefined);
    private _actorId?;
    get actorId(): string;
    set actorId(value: string);
    resetActorId(): void;
    get actorIdInput(): string | undefined;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _messagesCount?;
    get messagesCount(): number;
    set messagesCount(value: number);
    resetMessagesCount(): void;
    get messagesCountInput(): number | undefined;
    private _retrievalConfig;
    get retrievalConfig(): BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigList;
    putRetrievalConfig(value: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig[] | cdktn.IResolvable): void;
    resetRetrievalConfig(): void;
    get retrievalConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfig[] | undefined;
}
export declare class BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessMemoryDisabled {
}
export declare function bedrockagentcoreHarnessMemoryDisabledToTerraform(struct?: BedrockagentcoreHarnessMemoryDisabled | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryDisabledToHclTerraform(struct?: BedrockagentcoreHarnessMemoryDisabled | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryDisabledOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryDisabled | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryDisabled | cdktn.IResolvable | undefined);
}
export declare class BedrockagentcoreHarnessMemoryDisabledList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessMemoryDisabled[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryDisabledOutputReference;
}
export interface BedrockagentcoreHarnessMemoryManagedMemoryConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#encryption_key_arn BedrockagentcoreHarness#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#event_expiry_duration BedrockagentcoreHarness#event_expiry_duration}
    */
    readonly eventExpiryDuration?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#strategies BedrockagentcoreHarness#strategies}
    */
    readonly strategies?: string[];
}
export declare function bedrockagentcoreHarnessMemoryManagedMemoryConfigurationToTerraform(struct?: BedrockagentcoreHarnessMemoryManagedMemoryConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryManagedMemoryConfigurationToHclTerraform(struct?: BedrockagentcoreHarnessMemoryManagedMemoryConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryManagedMemoryConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemoryManagedMemoryConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemoryManagedMemoryConfiguration | cdktn.IResolvable | undefined);
    get arn(): string;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    private _eventExpiryDuration?;
    get eventExpiryDuration(): number;
    set eventExpiryDuration(value: number);
    resetEventExpiryDuration(): void;
    get eventExpiryDurationInput(): number | undefined;
    private _strategies?;
    get strategies(): string[];
    set strategies(value: string[]);
    resetStrategies(): void;
    get strategiesInput(): string[] | undefined;
}
export declare class BedrockagentcoreHarnessMemoryManagedMemoryConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessMemoryManagedMemoryConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryManagedMemoryConfigurationOutputReference;
}
export interface BedrockagentcoreHarnessMemory {
    /**
    * agentcore_memory_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#agentcore_memory_configuration BedrockagentcoreHarness#agentcore_memory_configuration}
    */
    readonly agentcoreMemoryConfiguration?: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration[] | cdktn.IResolvable;
    /**
    * disabled block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#disabled BedrockagentcoreHarness#disabled}
    */
    readonly disabled?: BedrockagentcoreHarnessMemoryDisabled[] | cdktn.IResolvable;
    /**
    * managed_memory_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#managed_memory_configuration BedrockagentcoreHarness#managed_memory_configuration}
    */
    readonly managedMemoryConfiguration?: BedrockagentcoreHarnessMemoryManagedMemoryConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessMemoryToTerraform(struct?: BedrockagentcoreHarnessMemory | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessMemoryToHclTerraform(struct?: BedrockagentcoreHarnessMemory | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessMemoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessMemory | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessMemory | cdktn.IResolvable | undefined);
    private _agentcoreMemoryConfiguration;
    get agentcoreMemoryConfiguration(): BedrockagentcoreHarnessMemoryAgentcoreMemoryConfigurationList;
    putAgentcoreMemoryConfiguration(value: BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration[] | cdktn.IResolvable): void;
    resetAgentcoreMemoryConfiguration(): void;
    get agentcoreMemoryConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessMemoryAgentcoreMemoryConfiguration[] | undefined;
    private _disabled;
    get disabled(): BedrockagentcoreHarnessMemoryDisabledList;
    putDisabled(value: BedrockagentcoreHarnessMemoryDisabled[] | cdktn.IResolvable): void;
    resetDisabled(): void;
    get disabledInput(): cdktn.IResolvable | BedrockagentcoreHarnessMemoryDisabled[] | undefined;
    private _managedMemoryConfiguration;
    get managedMemoryConfiguration(): BedrockagentcoreHarnessMemoryManagedMemoryConfigurationList;
    putManagedMemoryConfiguration(value: BedrockagentcoreHarnessMemoryManagedMemoryConfiguration[] | cdktn.IResolvable): void;
    resetManagedMemoryConfiguration(): void;
    get managedMemoryConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessMemoryManagedMemoryConfiguration[] | undefined;
}
export declare class BedrockagentcoreHarnessMemoryList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessMemory[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessMemoryOutputReference;
}
export interface BedrockagentcoreHarnessModelBedrockModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#additional_params BedrockagentcoreHarness#additional_params}
    */
    readonly additionalParams?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#api_format BedrockagentcoreHarness#api_format}
    */
    readonly apiFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#model_id BedrockagentcoreHarness#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#temperature BedrockagentcoreHarness#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#top_p BedrockagentcoreHarness#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreHarnessModelBedrockModelConfigToTerraform(struct?: BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelBedrockModelConfigToHclTerraform(struct?: BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelBedrockModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModelBedrockModelConfig | cdktn.IResolvable | undefined);
    private _additionalParams?;
    get additionalParams(): string;
    set additionalParams(value: string);
    resetAdditionalParams(): void;
    get additionalParamsInput(): string | undefined;
    private _apiFormat?;
    get apiFormat(): string;
    set apiFormat(value: string);
    resetApiFormat(): void;
    get apiFormatInput(): string | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessModelBedrockModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessModelBedrockModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessModelBedrockModelConfigOutputReference;
}
export interface BedrockagentcoreHarnessModelGeminiModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#additional_params BedrockagentcoreHarness#additional_params}
    */
    readonly additionalParams?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#api_key_arn BedrockagentcoreHarness#api_key_arn}
    */
    readonly apiKeyArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#model_id BedrockagentcoreHarness#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#temperature BedrockagentcoreHarness#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#top_k BedrockagentcoreHarness#top_k}
    */
    readonly topK?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#top_p BedrockagentcoreHarness#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreHarnessModelGeminiModelConfigToTerraform(struct?: BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelGeminiModelConfigToHclTerraform(struct?: BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelGeminiModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModelGeminiModelConfig | cdktn.IResolvable | undefined);
    private _additionalParams?;
    get additionalParams(): string;
    set additionalParams(value: string);
    resetAdditionalParams(): void;
    get additionalParamsInput(): string | undefined;
    private _apiKeyArn?;
    get apiKeyArn(): string;
    set apiKeyArn(value: string);
    get apiKeyArnInput(): string | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topK?;
    get topK(): number;
    set topK(value: number);
    resetTopK(): void;
    get topKInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessModelGeminiModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessModelGeminiModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessModelGeminiModelConfigOutputReference;
}
export interface BedrockagentcoreHarnessModelLitellmModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#additional_params BedrockagentcoreHarness#additional_params}
    */
    readonly additionalParams?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#api_base BedrockagentcoreHarness#api_base}
    */
    readonly apiBase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#api_key_arn BedrockagentcoreHarness#api_key_arn}
    */
    readonly apiKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#model_id BedrockagentcoreHarness#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#temperature BedrockagentcoreHarness#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#top_p BedrockagentcoreHarness#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreHarnessModelLitellmModelConfigToTerraform(struct?: BedrockagentcoreHarnessModelLitellmModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelLitellmModelConfigToHclTerraform(struct?: BedrockagentcoreHarnessModelLitellmModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelLitellmModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessModelLitellmModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModelLitellmModelConfig | cdktn.IResolvable | undefined);
    private _additionalParams?;
    get additionalParams(): string;
    set additionalParams(value: string);
    resetAdditionalParams(): void;
    get additionalParamsInput(): string | undefined;
    private _apiBase?;
    get apiBase(): string;
    set apiBase(value: string);
    resetApiBase(): void;
    get apiBaseInput(): string | undefined;
    private _apiKeyArn?;
    get apiKeyArn(): string;
    set apiKeyArn(value: string);
    resetApiKeyArn(): void;
    get apiKeyArnInput(): string | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessModelLitellmModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessModelLitellmModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessModelLitellmModelConfigOutputReference;
}
export interface BedrockagentcoreHarnessModelOpenaiModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#additional_params BedrockagentcoreHarness#additional_params}
    */
    readonly additionalParams?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#api_format BedrockagentcoreHarness#api_format}
    */
    readonly apiFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#api_key_arn BedrockagentcoreHarness#api_key_arn}
    */
    readonly apiKeyArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#max_tokens BedrockagentcoreHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#model_id BedrockagentcoreHarness#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#temperature BedrockagentcoreHarness#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#top_p BedrockagentcoreHarness#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreHarnessModelOpenaiModelConfigToTerraform(struct?: BedrockagentcoreHarnessModelOpenaiModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelOpenaiModelConfigToHclTerraform(struct?: BedrockagentcoreHarnessModelOpenaiModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelOpenaiModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessModelOpenaiModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModelOpenaiModelConfig | cdktn.IResolvable | undefined);
    private _additionalParams?;
    get additionalParams(): string;
    set additionalParams(value: string);
    resetAdditionalParams(): void;
    get additionalParamsInput(): string | undefined;
    private _apiFormat?;
    get apiFormat(): string;
    set apiFormat(value: string);
    resetApiFormat(): void;
    get apiFormatInput(): string | undefined;
    private _apiKeyArn?;
    get apiKeyArn(): string;
    set apiKeyArn(value: string);
    get apiKeyArnInput(): string | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentcoreHarnessModelOpenaiModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessModelOpenaiModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessModelOpenaiModelConfigOutputReference;
}
export interface BedrockagentcoreHarnessModel {
    /**
    * bedrock_model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#bedrock_model_config BedrockagentcoreHarness#bedrock_model_config}
    */
    readonly bedrockModelConfig?: BedrockagentcoreHarnessModelBedrockModelConfig[] | cdktn.IResolvable;
    /**
    * gemini_model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#gemini_model_config BedrockagentcoreHarness#gemini_model_config}
    */
    readonly geminiModelConfig?: BedrockagentcoreHarnessModelGeminiModelConfig[] | cdktn.IResolvable;
    /**
    * litellm_model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#litellm_model_config BedrockagentcoreHarness#litellm_model_config}
    */
    readonly litellmModelConfig?: BedrockagentcoreHarnessModelLitellmModelConfig[] | cdktn.IResolvable;
    /**
    * openai_model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#openai_model_config BedrockagentcoreHarness#openai_model_config}
    */
    readonly openaiModelConfig?: BedrockagentcoreHarnessModelOpenaiModelConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessModelToTerraform(struct?: BedrockagentcoreHarnessModel | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessModelToHclTerraform(struct?: BedrockagentcoreHarnessModel | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessModel | cdktn.IResolvable | undefined);
    private _bedrockModelConfig;
    get bedrockModelConfig(): BedrockagentcoreHarnessModelBedrockModelConfigList;
    putBedrockModelConfig(value: BedrockagentcoreHarnessModelBedrockModelConfig[] | cdktn.IResolvable): void;
    resetBedrockModelConfig(): void;
    get bedrockModelConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessModelBedrockModelConfig[] | undefined;
    private _geminiModelConfig;
    get geminiModelConfig(): BedrockagentcoreHarnessModelGeminiModelConfigList;
    putGeminiModelConfig(value: BedrockagentcoreHarnessModelGeminiModelConfig[] | cdktn.IResolvable): void;
    resetGeminiModelConfig(): void;
    get geminiModelConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessModelGeminiModelConfig[] | undefined;
    private _litellmModelConfig;
    get litellmModelConfig(): BedrockagentcoreHarnessModelLitellmModelConfigList;
    putLitellmModelConfig(value: BedrockagentcoreHarnessModelLitellmModelConfig[] | cdktn.IResolvable): void;
    resetLitellmModelConfig(): void;
    get litellmModelConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessModelLitellmModelConfig[] | undefined;
    private _openaiModelConfig;
    get openaiModelConfig(): BedrockagentcoreHarnessModelOpenaiModelConfigList;
    putOpenaiModelConfig(value: BedrockagentcoreHarnessModelOpenaiModelConfig[] | cdktn.IResolvable): void;
    resetOpenaiModelConfig(): void;
    get openaiModelConfigInput(): cdktn.IResolvable | BedrockagentcoreHarnessModelOpenaiModelConfig[] | undefined;
}
export declare class BedrockagentcoreHarnessModelList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessModelOutputReference;
}
export interface BedrockagentcoreHarnessSkillAwsSkills {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#paths BedrockagentcoreHarness#paths}
    */
    readonly paths?: string[];
}
export declare function bedrockagentcoreHarnessSkillAwsSkillsToTerraform(struct?: BedrockagentcoreHarnessSkillAwsSkills | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSkillAwsSkillsToHclTerraform(struct?: BedrockagentcoreHarnessSkillAwsSkills | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSkillAwsSkillsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSkillAwsSkills | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSkillAwsSkills | cdktn.IResolvable | undefined);
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    resetPaths(): void;
    get pathsInput(): string[] | undefined;
}
export declare class BedrockagentcoreHarnessSkillAwsSkillsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSkillAwsSkills[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSkillAwsSkillsOutputReference;
}
export interface BedrockagentcoreHarnessSkillGitAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#credential_arn BedrockagentcoreHarness#credential_arn}
    */
    readonly credentialArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#username BedrockagentcoreHarness#username}
    */
    readonly username?: string;
}
export declare function bedrockagentcoreHarnessSkillGitAuthToTerraform(struct?: BedrockagentcoreHarnessSkillGitAuth | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSkillGitAuthToHclTerraform(struct?: BedrockagentcoreHarnessSkillGitAuth | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSkillGitAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSkillGitAuth | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSkillGitAuth | cdktn.IResolvable | undefined);
    private _credentialArn?;
    get credentialArn(): string;
    set credentialArn(value: string);
    get credentialArnInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessSkillGitAuthList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSkillGitAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSkillGitAuthOutputReference;
}
export interface BedrockagentcoreHarnessSkillGit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#path BedrockagentcoreHarness#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#url BedrockagentcoreHarness#url}
    */
    readonly url: string;
    /**
    * auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#auth BedrockagentcoreHarness#auth}
    */
    readonly auth?: BedrockagentcoreHarnessSkillGitAuth[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessSkillGitToTerraform(struct?: BedrockagentcoreHarnessSkillGit | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSkillGitToHclTerraform(struct?: BedrockagentcoreHarnessSkillGit | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSkillGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSkillGit | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSkillGit | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _auth;
    get auth(): BedrockagentcoreHarnessSkillGitAuthList;
    putAuth(value: BedrockagentcoreHarnessSkillGitAuth[] | cdktn.IResolvable): void;
    resetAuth(): void;
    get authInput(): cdktn.IResolvable | BedrockagentcoreHarnessSkillGitAuth[] | undefined;
}
export declare class BedrockagentcoreHarnessSkillGitList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSkillGit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSkillGitOutputReference;
}
export interface BedrockagentcoreHarnessSkillS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#uri BedrockagentcoreHarness#uri}
    */
    readonly uri: string;
}
export declare function bedrockagentcoreHarnessSkillS3ToTerraform(struct?: BedrockagentcoreHarnessSkillS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSkillS3ToHclTerraform(struct?: BedrockagentcoreHarnessSkillS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSkillS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSkillS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSkillS3 | cdktn.IResolvable | undefined);
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessSkillS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSkillS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSkillS3OutputReference;
}
export interface BedrockagentcoreHarnessSkill {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#path BedrockagentcoreHarness#path}
    */
    readonly path?: string;
    /**
    * aws_skills block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#aws_skills BedrockagentcoreHarness#aws_skills}
    */
    readonly awsSkills?: BedrockagentcoreHarnessSkillAwsSkills[] | cdktn.IResolvable;
    /**
    * git block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#git BedrockagentcoreHarness#git}
    */
    readonly git?: BedrockagentcoreHarnessSkillGit[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#s3 BedrockagentcoreHarness#s3}
    */
    readonly s3?: BedrockagentcoreHarnessSkillS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessSkillToTerraform(struct?: BedrockagentcoreHarnessSkill | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSkillToHclTerraform(struct?: BedrockagentcoreHarnessSkill | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSkillOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSkill | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSkill | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _awsSkills;
    get awsSkills(): BedrockagentcoreHarnessSkillAwsSkillsList;
    putAwsSkills(value: BedrockagentcoreHarnessSkillAwsSkills[] | cdktn.IResolvable): void;
    resetAwsSkills(): void;
    get awsSkillsInput(): cdktn.IResolvable | BedrockagentcoreHarnessSkillAwsSkills[] | undefined;
    private _git;
    get git(): BedrockagentcoreHarnessSkillGitList;
    putGit(value: BedrockagentcoreHarnessSkillGit[] | cdktn.IResolvable): void;
    resetGit(): void;
    get gitInput(): cdktn.IResolvable | BedrockagentcoreHarnessSkillGit[] | undefined;
    private _s3;
    get s3(): BedrockagentcoreHarnessSkillS3List;
    putS3(value: BedrockagentcoreHarnessSkillS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreHarnessSkillS3[] | undefined;
}
export declare class BedrockagentcoreHarnessSkillList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSkill[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSkillOutputReference;
}
export interface BedrockagentcoreHarnessSystemPrompt {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#text BedrockagentcoreHarness#text}
    */
    readonly text?: string;
}
export declare function bedrockagentcoreHarnessSystemPromptToTerraform(struct?: BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessSystemPromptToHclTerraform(struct?: BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessSystemPromptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessSystemPrompt | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessSystemPromptList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessSystemPrompt[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessSystemPromptOutputReference;
}
export interface BedrockagentcoreHarnessTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#create BedrockagentcoreHarness#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#delete BedrockagentcoreHarness#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#update BedrockagentcoreHarness#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcoreHarnessTimeoutsToTerraform(struct?: BedrockagentcoreHarnessTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessTimeoutsToHclTerraform(struct?: BedrockagentcoreHarnessTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreHarnessTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface BedrockagentcoreHarnessToolConfigAgentcoreBrowser {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#browser_arn BedrockagentcoreHarness#browser_arn}
    */
    readonly browserArn?: string;
}
export declare function bedrockagentcoreHarnessToolConfigAgentcoreBrowserToTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreBrowser | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigAgentcoreBrowserToHclTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreBrowser | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigAgentcoreBrowserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfigAgentcoreBrowser | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfigAgentcoreBrowser | cdktn.IResolvable | undefined);
    private _browserArn?;
    get browserArn(): string;
    set browserArn(value: string);
    resetBrowserArn(): void;
    get browserArnInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigAgentcoreBrowserList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfigAgentcoreBrowser[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigAgentcoreBrowserOutputReference;
}
export interface BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#code_interpreter_arn BedrockagentcoreHarness#code_interpreter_arn}
    */
    readonly codeInterpreterArn?: string;
}
export declare function bedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreterToTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreterToHclTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter | cdktn.IResolvable | undefined);
    private _codeInterpreterArn?;
    get codeInterpreterArn(): string;
    set codeInterpreterArn(value: string);
    resetCodeInterpreterArn(): void;
    get codeInterpreterArnInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreterList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreterOutputReference;
}
export interface BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#custom_parameters BedrockagentcoreHarness#custom_parameters}
    */
    readonly customParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#default_return_url BedrockagentcoreHarness#default_return_url}
    */
    readonly defaultReturnUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#grant_type BedrockagentcoreHarness#grant_type}
    */
    readonly grantType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#provider_arn BedrockagentcoreHarness#provider_arn}
    */
    readonly providerArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#scopes BedrockagentcoreHarness#scopes}
    */
    readonly scopes: string[];
}
export declare function bedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauthToTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauthToHclTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth | cdktn.IResolvable | undefined);
    private _customParameters?;
    get customParameters(): {
        [key: string]: string;
    };
    set customParameters(value: {
        [key: string]: string;
    });
    resetCustomParameters(): void;
    get customParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultReturnUrl?;
    get defaultReturnUrl(): string;
    set defaultReturnUrl(value: string);
    resetDefaultReturnUrl(): void;
    get defaultReturnUrlInput(): string | undefined;
    private _grantType?;
    get grantType(): string;
    set grantType(value: string);
    resetGrantType(): void;
    get grantTypeInput(): string | undefined;
    private _providerArn?;
    get providerArn(): string;
    set providerArn(value: string);
    get providerArnInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauthList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauthOutputReference;
}
export interface BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#aws_iam BedrockagentcoreHarness#aws_iam}
    */
    readonly awsIam?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#none BedrockagentcoreHarness#none}
    */
    readonly none?: boolean | cdktn.IResolvable;
    /**
    * oauth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#oauth BedrockagentcoreHarness#oauth}
    */
    readonly oauth?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthToTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthToHclTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth | cdktn.IResolvable | undefined);
    private _awsIam?;
    get awsIam(): boolean | cdktn.IResolvable;
    set awsIam(value: boolean | cdktn.IResolvable);
    resetAwsIam(): void;
    get awsIamInput(): boolean | cdktn.IResolvable | undefined;
    private _none?;
    get none(): boolean | cdktn.IResolvable;
    set none(value: boolean | cdktn.IResolvable);
    resetNone(): void;
    get noneInput(): boolean | cdktn.IResolvable | undefined;
    private _oauth;
    get oauth(): BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauthList;
    putOauth(value: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth[] | cdktn.IResolvable): void;
    resetOauth(): void;
    get oauthInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOauth[] | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthOutputReference;
}
export interface BedrockagentcoreHarnessToolConfigAgentcoreGateway {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#gateway_arn BedrockagentcoreHarness#gateway_arn}
    */
    readonly gatewayArn: string;
    /**
    * outbound_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#outbound_auth BedrockagentcoreHarness#outbound_auth}
    */
    readonly outboundAuth?: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessToolConfigAgentcoreGatewayToTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreGateway | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigAgentcoreGatewayToHclTerraform(struct?: BedrockagentcoreHarnessToolConfigAgentcoreGateway | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfigAgentcoreGateway | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfigAgentcoreGateway | cdktn.IResolvable | undefined);
    private _gatewayArn?;
    get gatewayArn(): string;
    set gatewayArn(value: string);
    get gatewayArnInput(): string | undefined;
    private _outboundAuth;
    get outboundAuth(): BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuthList;
    putOutboundAuth(value: BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth[] | cdktn.IResolvable): void;
    resetOutboundAuth(): void;
    get outboundAuthInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutboundAuth[] | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigAgentcoreGatewayList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfigAgentcoreGateway[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigAgentcoreGatewayOutputReference;
}
export interface BedrockagentcoreHarnessToolConfigInlineFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#description BedrockagentcoreHarness#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#input_schema BedrockagentcoreHarness#input_schema}
    */
    readonly inputSchema: string;
}
export declare function bedrockagentcoreHarnessToolConfigInlineFunctionToTerraform(struct?: BedrockagentcoreHarnessToolConfigInlineFunction | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigInlineFunctionToHclTerraform(struct?: BedrockagentcoreHarnessToolConfigInlineFunction | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigInlineFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfigInlineFunction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfigInlineFunction | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _inputSchema?;
    get inputSchema(): string;
    set inputSchema(value: string);
    get inputSchemaInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigInlineFunctionList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfigInlineFunction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigInlineFunctionOutputReference;
}
export interface BedrockagentcoreHarnessToolConfigRemoteMcp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#headers BedrockagentcoreHarness#headers}
    */
    readonly headers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#url BedrockagentcoreHarness#url}
    */
    readonly url: string;
}
export declare function bedrockagentcoreHarnessToolConfigRemoteMcpToTerraform(struct?: BedrockagentcoreHarnessToolConfigRemoteMcp | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigRemoteMcpToHclTerraform(struct?: BedrockagentcoreHarnessToolConfigRemoteMcp | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigRemoteMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfigRemoteMcp | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfigRemoteMcp | cdktn.IResolvable | undefined);
    private _headers?;
    get headers(): {
        [key: string]: string;
    };
    set headers(value: {
        [key: string]: string;
    });
    resetHeaders(): void;
    get headersInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigRemoteMcpList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfigRemoteMcp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigRemoteMcpOutputReference;
}
export interface BedrockagentcoreHarnessToolConfig {
    /**
    * agentcore_browser block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#agentcore_browser BedrockagentcoreHarness#agentcore_browser}
    */
    readonly agentcoreBrowser?: BedrockagentcoreHarnessToolConfigAgentcoreBrowser[] | cdktn.IResolvable;
    /**
    * agentcore_code_interpreter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#agentcore_code_interpreter BedrockagentcoreHarness#agentcore_code_interpreter}
    */
    readonly agentcoreCodeInterpreter?: BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter[] | cdktn.IResolvable;
    /**
    * agentcore_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#agentcore_gateway BedrockagentcoreHarness#agentcore_gateway}
    */
    readonly agentcoreGateway?: BedrockagentcoreHarnessToolConfigAgentcoreGateway[] | cdktn.IResolvable;
    /**
    * inline_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#inline_function BedrockagentcoreHarness#inline_function}
    */
    readonly inlineFunction?: BedrockagentcoreHarnessToolConfigInlineFunction[] | cdktn.IResolvable;
    /**
    * remote_mcp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#remote_mcp BedrockagentcoreHarness#remote_mcp}
    */
    readonly remoteMcp?: BedrockagentcoreHarnessToolConfigRemoteMcp[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessToolConfigToTerraform(struct?: BedrockagentcoreHarnessToolConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolConfigToHclTerraform(struct?: BedrockagentcoreHarnessToolConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessToolConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessToolConfig | cdktn.IResolvable | undefined);
    private _agentcoreBrowser;
    get agentcoreBrowser(): BedrockagentcoreHarnessToolConfigAgentcoreBrowserList;
    putAgentcoreBrowser(value: BedrockagentcoreHarnessToolConfigAgentcoreBrowser[] | cdktn.IResolvable): void;
    resetAgentcoreBrowser(): void;
    get agentcoreBrowserInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfigAgentcoreBrowser[] | undefined;
    private _agentcoreCodeInterpreter;
    get agentcoreCodeInterpreter(): BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreterList;
    putAgentcoreCodeInterpreter(value: BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter[] | cdktn.IResolvable): void;
    resetAgentcoreCodeInterpreter(): void;
    get agentcoreCodeInterpreterInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfigAgentcoreCodeInterpreter[] | undefined;
    private _agentcoreGateway;
    get agentcoreGateway(): BedrockagentcoreHarnessToolConfigAgentcoreGatewayList;
    putAgentcoreGateway(value: BedrockagentcoreHarnessToolConfigAgentcoreGateway[] | cdktn.IResolvable): void;
    resetAgentcoreGateway(): void;
    get agentcoreGatewayInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfigAgentcoreGateway[] | undefined;
    private _inlineFunction;
    get inlineFunction(): BedrockagentcoreHarnessToolConfigInlineFunctionList;
    putInlineFunction(value: BedrockagentcoreHarnessToolConfigInlineFunction[] | cdktn.IResolvable): void;
    resetInlineFunction(): void;
    get inlineFunctionInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfigInlineFunction[] | undefined;
    private _remoteMcp;
    get remoteMcp(): BedrockagentcoreHarnessToolConfigRemoteMcpList;
    putRemoteMcp(value: BedrockagentcoreHarnessToolConfigRemoteMcp[] | cdktn.IResolvable): void;
    resetRemoteMcp(): void;
    get remoteMcpInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfigRemoteMcp[] | undefined;
}
export declare class BedrockagentcoreHarnessToolConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessToolConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolConfigOutputReference;
}
export interface BedrockagentcoreHarnessTool {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#name BedrockagentcoreHarness#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#type BedrockagentcoreHarness#type}
    */
    readonly type: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#config BedrockagentcoreHarness#config}
    */
    readonly config?: BedrockagentcoreHarnessToolConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreHarnessToolToTerraform(struct?: BedrockagentcoreHarnessTool | cdktn.IResolvable): any;
export declare function bedrockagentcoreHarnessToolToHclTerraform(struct?: BedrockagentcoreHarnessTool | cdktn.IResolvable): any;
export declare class BedrockagentcoreHarnessToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreHarnessTool | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreHarnessTool | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _config;
    get config(): BedrockagentcoreHarnessToolConfigList;
    putConfig(value: BedrockagentcoreHarnessToolConfig[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | BedrockagentcoreHarnessToolConfig[] | undefined;
}
export declare class BedrockagentcoreHarnessToolList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreHarnessTool[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreHarnessToolOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness aws_bedrockagentcore_harness}
*/
export declare class BedrockagentcoreHarness extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_harness";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreHarness resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreHarness to import
    * @param importFromId The id of the existing BedrockagentcoreHarness that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreHarness to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/bedrockagentcore_harness aws_bedrockagentcore_harness} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreHarnessConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreHarnessConfig);
    private _allowedTools?;
    get allowedTools(): string[];
    set allowedTools(value: string[]);
    resetAllowedTools(): void;
    get allowedToolsInput(): string[] | undefined;
    get arn(): string;
    private _environmentActual;
    get environmentActual(): BedrockagentcoreHarnessEnvironmentActualList;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    get harnessId(): string;
    private _harnessName?;
    get harnessName(): string;
    set harnessName(value: string);
    get harnessNameInput(): string | undefined;
    private _maxIterations?;
    get maxIterations(): number;
    set maxIterations(value: number);
    resetMaxIterations(): void;
    get maxIterationsInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _memoryActual;
    get memoryActual(): BedrockagentcoreHarnessMemoryActualList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _truncation;
    get truncation(): BedrockagentcoreHarnessTruncationList;
    putTruncation(value: BedrockagentcoreHarnessTruncation[] | cdktn.IResolvable): void;
    resetTruncation(): void;
    get truncationInput(): cdktn.IResolvable | BedrockagentcoreHarnessTruncation[] | undefined;
    private _authorizerConfiguration;
    get authorizerConfiguration(): BedrockagentcoreHarnessAuthorizerConfigurationList;
    putAuthorizerConfiguration(value: BedrockagentcoreHarnessAuthorizerConfiguration[] | cdktn.IResolvable): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | BedrockagentcoreHarnessAuthorizerConfiguration[] | undefined;
    private _environment;
    get environment(): BedrockagentcoreHarnessEnvironmentList;
    putEnvironment(value: BedrockagentcoreHarnessEnvironment[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironment[] | undefined;
    private _environmentArtifact;
    get environmentArtifact(): BedrockagentcoreHarnessEnvironmentArtifactList;
    putEnvironmentArtifact(value: BedrockagentcoreHarnessEnvironmentArtifact[] | cdktn.IResolvable): void;
    resetEnvironmentArtifact(): void;
    get environmentArtifactInput(): cdktn.IResolvable | BedrockagentcoreHarnessEnvironmentArtifact[] | undefined;
    private _memory;
    get memory(): BedrockagentcoreHarnessMemoryList;
    putMemory(value: BedrockagentcoreHarnessMemory[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | BedrockagentcoreHarnessMemory[] | undefined;
    private _model;
    get model(): BedrockagentcoreHarnessModelList;
    putModel(value: BedrockagentcoreHarnessModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | BedrockagentcoreHarnessModel[] | undefined;
    private _skill;
    get skill(): BedrockagentcoreHarnessSkillList;
    putSkill(value: BedrockagentcoreHarnessSkill[] | cdktn.IResolvable): void;
    resetSkill(): void;
    get skillInput(): cdktn.IResolvable | BedrockagentcoreHarnessSkill[] | undefined;
    private _systemPrompt;
    get systemPrompt(): BedrockagentcoreHarnessSystemPromptList;
    putSystemPrompt(value: BedrockagentcoreHarnessSystemPrompt[] | cdktn.IResolvable): void;
    resetSystemPrompt(): void;
    get systemPromptInput(): cdktn.IResolvable | BedrockagentcoreHarnessSystemPrompt[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreHarnessTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreHarnessTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreHarnessTimeouts | undefined;
    private _tool;
    get tool(): BedrockagentcoreHarnessToolList;
    putTool(value: BedrockagentcoreHarnessTool[] | cdktn.IResolvable): void;
    resetTool(): void;
    get toolInput(): cdktn.IResolvable | BedrockagentcoreHarnessTool[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
