/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontTrustStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#name CloudfrontTrustStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#tags CloudfrontTrustStore#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * ca_certificates_bundle_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#ca_certificates_bundle_source CloudfrontTrustStore#ca_certificates_bundle_source}
    */
    readonly caCertificatesBundleSource?: CloudfrontTrustStoreCaCertificatesBundleSource[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#timeouts CloudfrontTrustStore#timeouts}
    */
    readonly timeouts?: CloudfrontTrustStoreTimeouts;
}
export interface CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#bucket CloudfrontTrustStore#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#key CloudfrontTrustStore#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#region CloudfrontTrustStore#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#version CloudfrontTrustStore#version}
    */
    readonly version?: string;
}
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationToTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable): any;
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationToHclTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable): any;
export declare class CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationList extends cdktn.ComplexList {
    internalValue?: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationOutputReference;
}
export interface CloudfrontTrustStoreCaCertificatesBundleSource {
    /**
    * ca_certificates_bundle_s3_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#ca_certificates_bundle_s3_location CloudfrontTrustStore#ca_certificates_bundle_s3_location}
    */
    readonly caCertificatesBundleS3Location?: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location[] | cdktn.IResolvable;
}
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceToTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable): any;
export declare function cloudfrontTrustStoreCaCertificatesBundleSourceToHclTerraform(struct?: CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable): any;
export declare class CloudfrontTrustStoreCaCertificatesBundleSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontTrustStoreCaCertificatesBundleSource | cdktn.IResolvable | undefined);
    private _caCertificatesBundleS3Location;
    get caCertificatesBundleS3Location(): CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3LocationList;
    putCaCertificatesBundleS3Location(value: CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location[] | cdktn.IResolvable): void;
    resetCaCertificatesBundleS3Location(): void;
    get caCertificatesBundleS3LocationInput(): cdktn.IResolvable | CloudfrontTrustStoreCaCertificatesBundleSourceCaCertificatesBundleS3Location[] | undefined;
}
export declare class CloudfrontTrustStoreCaCertificatesBundleSourceList extends cdktn.ComplexList {
    internalValue?: CloudfrontTrustStoreCaCertificatesBundleSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontTrustStoreCaCertificatesBundleSourceOutputReference;
}
export interface CloudfrontTrustStoreTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#create CloudfrontTrustStore#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#delete CloudfrontTrustStore#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#update CloudfrontTrustStore#update}
    */
    readonly update?: string;
}
export declare function cloudfrontTrustStoreTimeoutsToTerraform(struct?: CloudfrontTrustStoreTimeouts | cdktn.IResolvable): any;
export declare function cloudfrontTrustStoreTimeoutsToHclTerraform(struct?: CloudfrontTrustStoreTimeouts | cdktn.IResolvable): any;
export declare class CloudfrontTrustStoreTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontTrustStoreTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontTrustStoreTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store aws_cloudfront_trust_store}
*/
export declare class CloudfrontTrustStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_trust_store";
    /**
    * Generates CDKTN code for importing a CloudfrontTrustStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontTrustStore to import
    * @param importFromId The id of the existing CloudfrontTrustStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontTrustStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudfront_trust_store aws_cloudfront_trust_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontTrustStoreConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontTrustStoreConfig);
    get arn(): string;
    get etag(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get numberOfCaCertificates(): number;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _caCertificatesBundleSource;
    get caCertificatesBundleSource(): CloudfrontTrustStoreCaCertificatesBundleSourceList;
    putCaCertificatesBundleSource(value: CloudfrontTrustStoreCaCertificatesBundleSource[] | cdktn.IResolvable): void;
    resetCaCertificatesBundleSource(): void;
    get caCertificatesBundleSourceInput(): cdktn.IResolvable | CloudfrontTrustStoreCaCertificatesBundleSource[] | undefined;
    private _timeouts;
    get timeouts(): CloudfrontTrustStoreTimeoutsOutputReference;
    putTimeouts(value: CloudfrontTrustStoreTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudfrontTrustStoreTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
