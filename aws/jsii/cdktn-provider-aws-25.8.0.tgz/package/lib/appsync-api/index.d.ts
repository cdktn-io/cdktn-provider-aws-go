/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#name AppsyncApi#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#owner_contact AppsyncApi#owner_contact}
    */
    readonly ownerContact?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#region AppsyncApi#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#tags AppsyncApi#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * event_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#event_config AppsyncApi#event_config}
    */
    readonly eventConfig?: AppsyncApiEventConfig[] | cdktn.IResolvable;
}
export interface AppsyncApiEventConfigAuthProviderCognitoConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#app_id_client_regex AppsyncApi#app_id_client_regex}
    */
    readonly appIdClientRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#aws_region AppsyncApi#aws_region}
    */
    readonly awsRegion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#user_pool_id AppsyncApi#user_pool_id}
    */
    readonly userPoolId: string;
}
export declare function appsyncApiEventConfigAuthProviderCognitoConfigToTerraform(struct?: AppsyncApiEventConfigAuthProviderCognitoConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProviderCognitoConfigToHclTerraform(struct?: AppsyncApiEventConfigAuthProviderCognitoConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProviderCognitoConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigAuthProviderCognitoConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProviderCognitoConfig | cdktn.IResolvable | undefined);
    private _appIdClientRegex?;
    get appIdClientRegex(): string;
    set appIdClientRegex(value: string);
    resetAppIdClientRegex(): void;
    get appIdClientRegexInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    get awsRegionInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
}
export declare class AppsyncApiEventConfigAuthProviderCognitoConfigList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigAuthProviderCognitoConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigAuthProviderCognitoConfigOutputReference;
}
export interface AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#authorizer_result_ttl_in_seconds AppsyncApi#authorizer_result_ttl_in_seconds}
    */
    readonly authorizerResultTtlInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#authorizer_uri AppsyncApi#authorizer_uri}
    */
    readonly authorizerUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#identity_validation_expression AppsyncApi#identity_validation_expression}
    */
    readonly identityValidationExpression?: string;
}
export declare function appsyncApiEventConfigAuthProviderLambdaAuthorizerConfigToTerraform(struct?: AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProviderLambdaAuthorizerConfigToHclTerraform(struct?: AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig | cdktn.IResolvable | undefined);
    private _authorizerResultTtlInSeconds?;
    get authorizerResultTtlInSeconds(): number;
    set authorizerResultTtlInSeconds(value: number);
    resetAuthorizerResultTtlInSeconds(): void;
    get authorizerResultTtlInSecondsInput(): number | undefined;
    private _authorizerUri?;
    get authorizerUri(): string;
    set authorizerUri(value: string);
    get authorizerUriInput(): string | undefined;
    private _identityValidationExpression?;
    get identityValidationExpression(): string;
    set identityValidationExpression(value: string);
    resetIdentityValidationExpression(): void;
    get identityValidationExpressionInput(): string | undefined;
}
export declare class AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfigList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfigOutputReference;
}
export interface AppsyncApiEventConfigAuthProviderOpenidConnectConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#auth_ttl AppsyncApi#auth_ttl}
    */
    readonly authTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#client_id AppsyncApi#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#iat_ttl AppsyncApi#iat_ttl}
    */
    readonly iatTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#issuer AppsyncApi#issuer}
    */
    readonly issuer: string;
}
export declare function appsyncApiEventConfigAuthProviderOpenidConnectConfigToTerraform(struct?: AppsyncApiEventConfigAuthProviderOpenidConnectConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProviderOpenidConnectConfigToHclTerraform(struct?: AppsyncApiEventConfigAuthProviderOpenidConnectConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProviderOpenidConnectConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigAuthProviderOpenidConnectConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProviderOpenidConnectConfig | cdktn.IResolvable | undefined);
    private _authTtl?;
    get authTtl(): number;
    set authTtl(value: number);
    resetAuthTtl(): void;
    get authTtlInput(): number | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _iatTtl?;
    get iatTtl(): number;
    set iatTtl(value: number);
    resetIatTtl(): void;
    get iatTtlInput(): number | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    get issuerInput(): string | undefined;
}
export declare class AppsyncApiEventConfigAuthProviderOpenidConnectConfigList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigAuthProviderOpenidConnectConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigAuthProviderOpenidConnectConfigOutputReference;
}
export interface AppsyncApiEventConfigAuthProvider {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType: string;
    /**
    * cognito_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#cognito_config AppsyncApi#cognito_config}
    */
    readonly cognitoConfig?: AppsyncApiEventConfigAuthProviderCognitoConfig[] | cdktn.IResolvable;
    /**
    * lambda_authorizer_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#lambda_authorizer_config AppsyncApi#lambda_authorizer_config}
    */
    readonly lambdaAuthorizerConfig?: AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig[] | cdktn.IResolvable;
    /**
    * openid_connect_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#openid_connect_config AppsyncApi#openid_connect_config}
    */
    readonly openidConnectConfig?: AppsyncApiEventConfigAuthProviderOpenidConnectConfig[] | cdktn.IResolvable;
}
export declare function appsyncApiEventConfigAuthProviderToTerraform(struct?: AppsyncApiEventConfigAuthProvider | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigAuthProviderToHclTerraform(struct?: AppsyncApiEventConfigAuthProvider | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigAuthProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigAuthProvider | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigAuthProvider | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
    private _cognitoConfig;
    get cognitoConfig(): AppsyncApiEventConfigAuthProviderCognitoConfigList;
    putCognitoConfig(value: AppsyncApiEventConfigAuthProviderCognitoConfig[] | cdktn.IResolvable): void;
    resetCognitoConfig(): void;
    get cognitoConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProviderCognitoConfig[] | undefined;
    private _lambdaAuthorizerConfig;
    get lambdaAuthorizerConfig(): AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfigList;
    putLambdaAuthorizerConfig(value: AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig[] | cdktn.IResolvable): void;
    resetLambdaAuthorizerConfig(): void;
    get lambdaAuthorizerConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProviderLambdaAuthorizerConfig[] | undefined;
    private _openidConnectConfig;
    get openidConnectConfig(): AppsyncApiEventConfigAuthProviderOpenidConnectConfigList;
    putOpenidConnectConfig(value: AppsyncApiEventConfigAuthProviderOpenidConnectConfig[] | cdktn.IResolvable): void;
    resetOpenidConnectConfig(): void;
    get openidConnectConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProviderOpenidConnectConfig[] | undefined;
}
export declare class AppsyncApiEventConfigAuthProviderList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigAuthProvider[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigAuthProviderOutputReference;
}
export interface AppsyncApiEventConfigConnectionAuthMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType: string;
}
export declare function appsyncApiEventConfigConnectionAuthModeToTerraform(struct?: AppsyncApiEventConfigConnectionAuthMode | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigConnectionAuthModeToHclTerraform(struct?: AppsyncApiEventConfigConnectionAuthMode | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigConnectionAuthModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigConnectionAuthMode | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigConnectionAuthMode | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
}
export declare class AppsyncApiEventConfigConnectionAuthModeList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigConnectionAuthMode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigConnectionAuthModeOutputReference;
}
export interface AppsyncApiEventConfigDefaultPublishAuthMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType: string;
}
export declare function appsyncApiEventConfigDefaultPublishAuthModeToTerraform(struct?: AppsyncApiEventConfigDefaultPublishAuthMode | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigDefaultPublishAuthModeToHclTerraform(struct?: AppsyncApiEventConfigDefaultPublishAuthMode | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigDefaultPublishAuthModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigDefaultPublishAuthMode | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigDefaultPublishAuthMode | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
}
export declare class AppsyncApiEventConfigDefaultPublishAuthModeList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigDefaultPublishAuthMode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigDefaultPublishAuthModeOutputReference;
}
export interface AppsyncApiEventConfigDefaultSubscribeAuthMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#auth_type AppsyncApi#auth_type}
    */
    readonly authType: string;
}
export declare function appsyncApiEventConfigDefaultSubscribeAuthModeToTerraform(struct?: AppsyncApiEventConfigDefaultSubscribeAuthMode | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigDefaultSubscribeAuthModeToHclTerraform(struct?: AppsyncApiEventConfigDefaultSubscribeAuthMode | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigDefaultSubscribeAuthModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigDefaultSubscribeAuthMode | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigDefaultSubscribeAuthMode | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
}
export declare class AppsyncApiEventConfigDefaultSubscribeAuthModeList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigDefaultSubscribeAuthMode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigDefaultSubscribeAuthModeOutputReference;
}
export interface AppsyncApiEventConfigLogConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#cloudwatch_logs_role_arn AppsyncApi#cloudwatch_logs_role_arn}
    */
    readonly cloudwatchLogsRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#log_level AppsyncApi#log_level}
    */
    readonly logLevel: string;
}
export declare function appsyncApiEventConfigLogConfigToTerraform(struct?: AppsyncApiEventConfigLogConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigLogConfigToHclTerraform(struct?: AppsyncApiEventConfigLogConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfigLogConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfigLogConfig | cdktn.IResolvable | undefined);
    private _cloudwatchLogsRoleArn?;
    get cloudwatchLogsRoleArn(): string;
    set cloudwatchLogsRoleArn(value: string);
    get cloudwatchLogsRoleArnInput(): string | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    get logLevelInput(): string | undefined;
}
export declare class AppsyncApiEventConfigLogConfigList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfigLogConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigLogConfigOutputReference;
}
export interface AppsyncApiEventConfig {
    /**
    * auth_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#auth_provider AppsyncApi#auth_provider}
    */
    readonly authProvider?: AppsyncApiEventConfigAuthProvider[] | cdktn.IResolvable;
    /**
    * connection_auth_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#connection_auth_mode AppsyncApi#connection_auth_mode}
    */
    readonly connectionAuthMode?: AppsyncApiEventConfigConnectionAuthMode[] | cdktn.IResolvable;
    /**
    * default_publish_auth_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#default_publish_auth_mode AppsyncApi#default_publish_auth_mode}
    */
    readonly defaultPublishAuthMode?: AppsyncApiEventConfigDefaultPublishAuthMode[] | cdktn.IResolvable;
    /**
    * default_subscribe_auth_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#default_subscribe_auth_mode AppsyncApi#default_subscribe_auth_mode}
    */
    readonly defaultSubscribeAuthMode?: AppsyncApiEventConfigDefaultSubscribeAuthMode[] | cdktn.IResolvable;
    /**
    * log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#log_config AppsyncApi#log_config}
    */
    readonly logConfig?: AppsyncApiEventConfigLogConfig[] | cdktn.IResolvable;
}
export declare function appsyncApiEventConfigToTerraform(struct?: AppsyncApiEventConfig | cdktn.IResolvable): any;
export declare function appsyncApiEventConfigToHclTerraform(struct?: AppsyncApiEventConfig | cdktn.IResolvable): any;
export declare class AppsyncApiEventConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncApiEventConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncApiEventConfig | cdktn.IResolvable | undefined);
    private _authProvider;
    get authProvider(): AppsyncApiEventConfigAuthProviderList;
    putAuthProvider(value: AppsyncApiEventConfigAuthProvider[] | cdktn.IResolvable): void;
    resetAuthProvider(): void;
    get authProviderInput(): cdktn.IResolvable | AppsyncApiEventConfigAuthProvider[] | undefined;
    private _connectionAuthMode;
    get connectionAuthMode(): AppsyncApiEventConfigConnectionAuthModeList;
    putConnectionAuthMode(value: AppsyncApiEventConfigConnectionAuthMode[] | cdktn.IResolvable): void;
    resetConnectionAuthMode(): void;
    get connectionAuthModeInput(): cdktn.IResolvable | AppsyncApiEventConfigConnectionAuthMode[] | undefined;
    private _defaultPublishAuthMode;
    get defaultPublishAuthMode(): AppsyncApiEventConfigDefaultPublishAuthModeList;
    putDefaultPublishAuthMode(value: AppsyncApiEventConfigDefaultPublishAuthMode[] | cdktn.IResolvable): void;
    resetDefaultPublishAuthMode(): void;
    get defaultPublishAuthModeInput(): cdktn.IResolvable | AppsyncApiEventConfigDefaultPublishAuthMode[] | undefined;
    private _defaultSubscribeAuthMode;
    get defaultSubscribeAuthMode(): AppsyncApiEventConfigDefaultSubscribeAuthModeList;
    putDefaultSubscribeAuthMode(value: AppsyncApiEventConfigDefaultSubscribeAuthMode[] | cdktn.IResolvable): void;
    resetDefaultSubscribeAuthMode(): void;
    get defaultSubscribeAuthModeInput(): cdktn.IResolvable | AppsyncApiEventConfigDefaultSubscribeAuthMode[] | undefined;
    private _logConfig;
    get logConfig(): AppsyncApiEventConfigLogConfigList;
    putLogConfig(value: AppsyncApiEventConfigLogConfig[] | cdktn.IResolvable): void;
    resetLogConfig(): void;
    get logConfigInput(): cdktn.IResolvable | AppsyncApiEventConfigLogConfig[] | undefined;
}
export declare class AppsyncApiEventConfigList extends cdktn.ComplexList {
    internalValue?: AppsyncApiEventConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncApiEventConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api aws_appsync_api}
*/
export declare class AppsyncApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_api";
    /**
    * Generates CDKTN code for importing a AppsyncApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncApi to import
    * @param importFromId The id of the existing AppsyncApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/appsync_api aws_appsync_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncApiConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncApiConfig);
    get apiArn(): string;
    get apiId(): string;
    private _dns;
    get dns(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ownerContact?;
    get ownerContact(): string;
    set ownerContact(value: string);
    resetOwnerContact(): void;
    get ownerContactInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get wafWebAclArn(): string;
    get xrayEnabled(): cdktn.IResolvable;
    private _eventConfig;
    get eventConfig(): AppsyncApiEventConfigList;
    putEventConfig(value: AppsyncApiEventConfig[] | cdktn.IResolvable): void;
    resetEventConfig(): void;
    get eventConfigInput(): cdktn.IResolvable | AppsyncApiEventConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
