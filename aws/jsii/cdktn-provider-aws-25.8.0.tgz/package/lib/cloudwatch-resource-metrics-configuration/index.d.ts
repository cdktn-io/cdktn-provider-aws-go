/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchResourceMetricsConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatch_resource_metrics_configuration#region CloudwatchResourceMetricsConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatch_resource_metrics_configuration#resource_arn CloudwatchResourceMetricsConfiguration#resource_arn}
    */
    readonly resourceArn: string;
    /**
    * metric_selection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatch_resource_metrics_configuration#metric_selection CloudwatchResourceMetricsConfiguration#metric_selection}
    */
    readonly metricSelection?: CloudwatchResourceMetricsConfigurationMetricSelection[] | cdktn.IResolvable;
}
export interface CloudwatchResourceMetricsConfigurationMetricSelection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatch_resource_metrics_configuration#include_metrics CloudwatchResourceMetricsConfiguration#include_metrics}
    */
    readonly includeMetrics: string[];
}
export declare function cloudwatchResourceMetricsConfigurationMetricSelectionToTerraform(struct?: CloudwatchResourceMetricsConfigurationMetricSelection | cdktn.IResolvable): any;
export declare function cloudwatchResourceMetricsConfigurationMetricSelectionToHclTerraform(struct?: CloudwatchResourceMetricsConfigurationMetricSelection | cdktn.IResolvable): any;
export declare class CloudwatchResourceMetricsConfigurationMetricSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchResourceMetricsConfigurationMetricSelection | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchResourceMetricsConfigurationMetricSelection | cdktn.IResolvable | undefined);
    private _includeMetrics?;
    get includeMetrics(): string[];
    set includeMetrics(value: string[]);
    get includeMetricsInput(): string[] | undefined;
}
export declare class CloudwatchResourceMetricsConfigurationMetricSelectionList extends cdktn.ComplexList {
    internalValue?: CloudwatchResourceMetricsConfigurationMetricSelection[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchResourceMetricsConfigurationMetricSelectionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatch_resource_metrics_configuration aws_cloudwatch_resource_metrics_configuration}
*/
export declare class CloudwatchResourceMetricsConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_resource_metrics_configuration";
    /**
    * Generates CDKTN code for importing a CloudwatchResourceMetricsConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchResourceMetricsConfiguration to import
    * @param importFromId The id of the existing CloudwatchResourceMetricsConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatch_resource_metrics_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchResourceMetricsConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/cloudwatch_resource_metrics_configuration aws_cloudwatch_resource_metrics_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchResourceMetricsConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchResourceMetricsConfigurationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    private _metricSelection;
    get metricSelection(): CloudwatchResourceMetricsConfigurationMetricSelectionList;
    putMetricSelection(value: CloudwatchResourceMetricsConfigurationMetricSelection[] | cdktn.IResolvable): void;
    resetMetricSelection(): void;
    get metricSelectionInput(): cdktn.IResolvable | CloudwatchResourceMetricsConfigurationMetricSelection[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
