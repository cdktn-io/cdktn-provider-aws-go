/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BillingViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#description BillingView#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#name BillingView#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#source_views BillingView#source_views}
    */
    readonly sourceViews?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#tags BillingView#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * data_filter_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#data_filter_expression BillingView#data_filter_expression}
    */
    readonly dataFilterExpression?: BillingViewDataFilterExpression[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#timeouts BillingView#timeouts}
    */
    readonly timeouts?: BillingViewTimeouts;
}
export interface BillingViewDataFilterExpressionDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#key BillingView#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#values BillingView#values}
    */
    readonly values: string[];
}
export declare function billingViewDataFilterExpressionDimensionsToTerraform(struct?: BillingViewDataFilterExpressionDimensions | cdktn.IResolvable): any;
export declare function billingViewDataFilterExpressionDimensionsToHclTerraform(struct?: BillingViewDataFilterExpressionDimensions | cdktn.IResolvable): any;
export declare class BillingViewDataFilterExpressionDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingViewDataFilterExpressionDimensions | cdktn.IResolvable | undefined;
    set internalValue(value: BillingViewDataFilterExpressionDimensions | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class BillingViewDataFilterExpressionDimensionsList extends cdktn.ComplexList {
    internalValue?: BillingViewDataFilterExpressionDimensions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingViewDataFilterExpressionDimensionsOutputReference;
}
export interface BillingViewDataFilterExpressionTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#key BillingView#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#values BillingView#values}
    */
    readonly values: string[];
}
export declare function billingViewDataFilterExpressionTagsToTerraform(struct?: BillingViewDataFilterExpressionTags | cdktn.IResolvable): any;
export declare function billingViewDataFilterExpressionTagsToHclTerraform(struct?: BillingViewDataFilterExpressionTags | cdktn.IResolvable): any;
export declare class BillingViewDataFilterExpressionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingViewDataFilterExpressionTags | cdktn.IResolvable | undefined;
    set internalValue(value: BillingViewDataFilterExpressionTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class BillingViewDataFilterExpressionTagsList extends cdktn.ComplexList {
    internalValue?: BillingViewDataFilterExpressionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingViewDataFilterExpressionTagsOutputReference;
}
export interface BillingViewDataFilterExpressionTimeRange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#begin_date_inclusive BillingView#begin_date_inclusive}
    */
    readonly beginDateInclusive: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#end_date_inclusive BillingView#end_date_inclusive}
    */
    readonly endDateInclusive: string;
}
export declare function billingViewDataFilterExpressionTimeRangeToTerraform(struct?: BillingViewDataFilterExpressionTimeRange | cdktn.IResolvable): any;
export declare function billingViewDataFilterExpressionTimeRangeToHclTerraform(struct?: BillingViewDataFilterExpressionTimeRange | cdktn.IResolvable): any;
export declare class BillingViewDataFilterExpressionTimeRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingViewDataFilterExpressionTimeRange | cdktn.IResolvable | undefined;
    set internalValue(value: BillingViewDataFilterExpressionTimeRange | cdktn.IResolvable | undefined);
    private _beginDateInclusive?;
    get beginDateInclusive(): string;
    set beginDateInclusive(value: string);
    get beginDateInclusiveInput(): string | undefined;
    private _endDateInclusive?;
    get endDateInclusive(): string;
    set endDateInclusive(value: string);
    get endDateInclusiveInput(): string | undefined;
}
export declare class BillingViewDataFilterExpressionTimeRangeList extends cdktn.ComplexList {
    internalValue?: BillingViewDataFilterExpressionTimeRange[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingViewDataFilterExpressionTimeRangeOutputReference;
}
export interface BillingViewDataFilterExpression {
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#dimensions BillingView#dimensions}
    */
    readonly dimensions?: BillingViewDataFilterExpressionDimensions[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#tags BillingView#tags}
    */
    readonly tags?: BillingViewDataFilterExpressionTags[] | cdktn.IResolvable;
    /**
    * time_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#time_range BillingView#time_range}
    */
    readonly timeRange?: BillingViewDataFilterExpressionTimeRange[] | cdktn.IResolvable;
}
export declare function billingViewDataFilterExpressionToTerraform(struct?: BillingViewDataFilterExpression | cdktn.IResolvable): any;
export declare function billingViewDataFilterExpressionToHclTerraform(struct?: BillingViewDataFilterExpression | cdktn.IResolvable): any;
export declare class BillingViewDataFilterExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BillingViewDataFilterExpression | cdktn.IResolvable | undefined;
    set internalValue(value: BillingViewDataFilterExpression | cdktn.IResolvable | undefined);
    private _dimensions;
    get dimensions(): BillingViewDataFilterExpressionDimensionsList;
    putDimensions(value: BillingViewDataFilterExpressionDimensions[] | cdktn.IResolvable): void;
    resetDimensions(): void;
    get dimensionsInput(): cdktn.IResolvable | BillingViewDataFilterExpressionDimensions[] | undefined;
    private _tags;
    get tags(): BillingViewDataFilterExpressionTagsList;
    putTags(value: BillingViewDataFilterExpressionTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BillingViewDataFilterExpressionTags[] | undefined;
    private _timeRange;
    get timeRange(): BillingViewDataFilterExpressionTimeRangeList;
    putTimeRange(value: BillingViewDataFilterExpressionTimeRange[] | cdktn.IResolvable): void;
    resetTimeRange(): void;
    get timeRangeInput(): cdktn.IResolvable | BillingViewDataFilterExpressionTimeRange[] | undefined;
}
export declare class BillingViewDataFilterExpressionList extends cdktn.ComplexList {
    internalValue?: BillingViewDataFilterExpression[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BillingViewDataFilterExpressionOutputReference;
}
export interface BillingViewTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#create BillingView#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#delete BillingView#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#update BillingView#update}
    */
    readonly update?: string;
}
export declare function billingViewTimeoutsToTerraform(struct?: BillingViewTimeouts | cdktn.IResolvable): any;
export declare function billingViewTimeoutsToHclTerraform(struct?: BillingViewTimeouts | cdktn.IResolvable): any;
export declare class BillingViewTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BillingViewTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BillingViewTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view aws_billing_view}
*/
export declare class BillingView extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_billing_view";
    /**
    * Generates CDKTN code for importing a BillingView resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BillingView to import
    * @param importFromId The id of the existing BillingView that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BillingView to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.0/docs/resources/billing_view aws_billing_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BillingViewConfig
    */
    constructor(scope: Construct, id: string, config: BillingViewConfig);
    get arn(): string;
    get billingViewType(): string;
    get createdAt(): string;
    get derivedViewCount(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerAccountId(): string;
    get sourceAccountId(): string;
    get sourceViewCount(): number;
    private _sourceViews?;
    get sourceViews(): string[];
    set sourceViews(value: string[]);
    resetSourceViews(): void;
    get sourceViewsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get viewDefinitionLastUpdatedAt(): string;
    private _dataFilterExpression;
    get dataFilterExpression(): BillingViewDataFilterExpressionList;
    putDataFilterExpression(value: BillingViewDataFilterExpression[] | cdktn.IResolvable): void;
    resetDataFilterExpression(): void;
    get dataFilterExpressionInput(): cdktn.IResolvable | BillingViewDataFilterExpression[] | undefined;
    private _timeouts;
    get timeouts(): BillingViewTimeoutsOutputReference;
    putTimeouts(value: BillingViewTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BillingViewTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
