/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCloudwatchEventBusConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_event_bus#id DataAwsCloudwatchEventBus#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_event_bus#name DataAwsCloudwatchEventBus#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_event_bus#region DataAwsCloudwatchEventBus#region}
    */
    readonly region?: string;
}
export interface DataAwsCloudwatchEventBusDeadLetterConfig {
}
export declare function dataAwsCloudwatchEventBusDeadLetterConfigToTerraform(struct?: DataAwsCloudwatchEventBusDeadLetterConfig): any;
export declare function dataAwsCloudwatchEventBusDeadLetterConfigToHclTerraform(struct?: DataAwsCloudwatchEventBusDeadLetterConfig): any;
export declare class DataAwsCloudwatchEventBusDeadLetterConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudwatchEventBusDeadLetterConfig | undefined;
    set internalValue(value: DataAwsCloudwatchEventBusDeadLetterConfig | undefined);
    get arn(): string;
}
export declare class DataAwsCloudwatchEventBusDeadLetterConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudwatchEventBusDeadLetterConfigOutputReference;
}
export interface DataAwsCloudwatchEventBusLogConfig {
}
export declare function dataAwsCloudwatchEventBusLogConfigToTerraform(struct?: DataAwsCloudwatchEventBusLogConfig): any;
export declare function dataAwsCloudwatchEventBusLogConfigToHclTerraform(struct?: DataAwsCloudwatchEventBusLogConfig): any;
export declare class DataAwsCloudwatchEventBusLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudwatchEventBusLogConfig | undefined;
    set internalValue(value: DataAwsCloudwatchEventBusLogConfig | undefined);
    get includeDetail(): string;
    get level(): string;
}
export declare class DataAwsCloudwatchEventBusLogConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudwatchEventBusLogConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_event_bus aws_cloudwatch_event_bus}
*/
export declare class DataAwsCloudwatchEventBus extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudwatch_event_bus";
    /**
    * Generates CDKTN code for importing a DataAwsCloudwatchEventBus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCloudwatchEventBus to import
    * @param importFromId The id of the existing DataAwsCloudwatchEventBus that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_event_bus#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCloudwatchEventBus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_event_bus aws_cloudwatch_event_bus} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCloudwatchEventBusConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCloudwatchEventBusConfig);
    get arn(): string;
    private _deadLetterConfig;
    get deadLetterConfig(): DataAwsCloudwatchEventBusDeadLetterConfigList;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kmsKeyIdentifier(): string;
    private _logConfig;
    get logConfig(): DataAwsCloudwatchEventBusLogConfigList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
