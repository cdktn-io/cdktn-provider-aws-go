/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsyncChannelNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#api_id AppsyncChannelNamespace#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#code_handlers AppsyncChannelNamespace#code_handlers}
    */
    readonly codeHandlers?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#name AppsyncChannelNamespace#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#region AppsyncChannelNamespace#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#tags AppsyncChannelNamespace#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * handler_configs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#handler_configs AppsyncChannelNamespace#handler_configs}
    */
    readonly handlerConfigs?: AppsyncChannelNamespaceHandlerConfigs[] | cdktn.IResolvable;
    /**
    * publish_auth_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#publish_auth_mode AppsyncChannelNamespace#publish_auth_mode}
    */
    readonly publishAuthMode?: AppsyncChannelNamespacePublishAuthMode[] | cdktn.IResolvable;
    /**
    * subscribe_auth_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#subscribe_auth_mode AppsyncChannelNamespace#subscribe_auth_mode}
    */
    readonly subscribeAuthMode?: AppsyncChannelNamespaceSubscribeAuthMode[] | cdktn.IResolvable;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#invoke_type AppsyncChannelNamespace#invoke_type}
    */
    readonly invokeType?: string;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig | cdktn.IResolvable | undefined);
    private _invokeType?;
    get invokeType(): string;
    set invokeType(value: string);
    resetInvokeType(): void;
    get invokeTypeInput(): string | undefined;
}
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigOutputReference;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#data_source_name AppsyncChannelNamespace#data_source_name}
    */
    readonly dataSourceName: string;
    /**
    * lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#lambda_config AppsyncChannelNamespace#lambda_config}
    */
    readonly lambdaConfig?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig[] | cdktn.IResolvable;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishIntegrationToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration | cdktn.IResolvable | undefined);
    private _dataSourceName?;
    get dataSourceName(): string;
    set dataSourceName(value: string);
    get dataSourceNameInput(): string | undefined;
    private _lambdaConfig;
    get lambdaConfig(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfigList;
    putLambdaConfig(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig[] | cdktn.IResolvable): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationLambdaConfig[] | undefined;
}
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationOutputReference;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnPublish {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#behavior AppsyncChannelNamespace#behavior}
    */
    readonly behavior: string;
    /**
    * integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#integration AppsyncChannelNamespace#integration}
    */
    readonly integration?: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration[] | cdktn.IResolvable;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnPublishToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnPublish | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _integration;
    get integration(): AppsyncChannelNamespaceHandlerConfigsOnPublishIntegrationList;
    putIntegration(value: AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration[] | cdktn.IResolvable): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnPublishIntegration[] | undefined;
}
export declare class AppsyncChannelNamespaceHandlerConfigsOnPublishList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceHandlerConfigsOnPublish[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceHandlerConfigsOnPublishOutputReference;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#invoke_type AppsyncChannelNamespace#invoke_type}
    */
    readonly invokeType?: string;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig | cdktn.IResolvable | undefined);
    private _invokeType?;
    get invokeType(): string;
    set invokeType(value: string);
    resetInvokeType(): void;
    get invokeTypeInput(): string | undefined;
}
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigOutputReference;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#data_source_name AppsyncChannelNamespace#data_source_name}
    */
    readonly dataSourceName: string;
    /**
    * lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#lambda_config AppsyncChannelNamespace#lambda_config}
    */
    readonly lambdaConfig?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig[] | cdktn.IResolvable;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration | cdktn.IResolvable | undefined);
    private _dataSourceName?;
    get dataSourceName(): string;
    set dataSourceName(value: string);
    get dataSourceNameInput(): string | undefined;
    private _lambdaConfig;
    get lambdaConfig(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfigList;
    putLambdaConfig(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig[] | cdktn.IResolvable): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationLambdaConfig[] | undefined;
}
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationOutputReference;
}
export interface AppsyncChannelNamespaceHandlerConfigsOnSubscribe {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#behavior AppsyncChannelNamespace#behavior}
    */
    readonly behavior: string;
    /**
    * integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#integration AppsyncChannelNamespace#integration}
    */
    readonly integration?: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration[] | cdktn.IResolvable;
}
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsOnSubscribeToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribe | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _integration;
    get integration(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegrationList;
    putIntegration(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration[] | cdktn.IResolvable): void;
    resetIntegration(): void;
    get integrationInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnSubscribeIntegration[] | undefined;
}
export declare class AppsyncChannelNamespaceHandlerConfigsOnSubscribeList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceHandlerConfigsOnSubscribe[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceHandlerConfigsOnSubscribeOutputReference;
}
export interface AppsyncChannelNamespaceHandlerConfigs {
    /**
    * on_publish block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#on_publish AppsyncChannelNamespace#on_publish}
    */
    readonly onPublish?: AppsyncChannelNamespaceHandlerConfigsOnPublish[] | cdktn.IResolvable;
    /**
    * on_subscribe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#on_subscribe AppsyncChannelNamespace#on_subscribe}
    */
    readonly onSubscribe?: AppsyncChannelNamespaceHandlerConfigsOnSubscribe[] | cdktn.IResolvable;
}
export declare function appsyncChannelNamespaceHandlerConfigsToTerraform(struct?: AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceHandlerConfigsToHclTerraform(struct?: AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceHandlerConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceHandlerConfigs | cdktn.IResolvable | undefined);
    private _onPublish;
    get onPublish(): AppsyncChannelNamespaceHandlerConfigsOnPublishList;
    putOnPublish(value: AppsyncChannelNamespaceHandlerConfigsOnPublish[] | cdktn.IResolvable): void;
    resetOnPublish(): void;
    get onPublishInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnPublish[] | undefined;
    private _onSubscribe;
    get onSubscribe(): AppsyncChannelNamespaceHandlerConfigsOnSubscribeList;
    putOnSubscribe(value: AppsyncChannelNamespaceHandlerConfigsOnSubscribe[] | cdktn.IResolvable): void;
    resetOnSubscribe(): void;
    get onSubscribeInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigsOnSubscribe[] | undefined;
}
export declare class AppsyncChannelNamespaceHandlerConfigsList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceHandlerConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceHandlerConfigsOutputReference;
}
export interface AppsyncChannelNamespacePublishAuthMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#auth_type AppsyncChannelNamespace#auth_type}
    */
    readonly authType: string;
}
export declare function appsyncChannelNamespacePublishAuthModeToTerraform(struct?: AppsyncChannelNamespacePublishAuthMode | cdktn.IResolvable): any;
export declare function appsyncChannelNamespacePublishAuthModeToHclTerraform(struct?: AppsyncChannelNamespacePublishAuthMode | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespacePublishAuthModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespacePublishAuthMode | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespacePublishAuthMode | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
}
export declare class AppsyncChannelNamespacePublishAuthModeList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespacePublishAuthMode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespacePublishAuthModeOutputReference;
}
export interface AppsyncChannelNamespaceSubscribeAuthMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#auth_type AppsyncChannelNamespace#auth_type}
    */
    readonly authType: string;
}
export declare function appsyncChannelNamespaceSubscribeAuthModeToTerraform(struct?: AppsyncChannelNamespaceSubscribeAuthMode | cdktn.IResolvable): any;
export declare function appsyncChannelNamespaceSubscribeAuthModeToHclTerraform(struct?: AppsyncChannelNamespaceSubscribeAuthMode | cdktn.IResolvable): any;
export declare class AppsyncChannelNamespaceSubscribeAuthModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsyncChannelNamespaceSubscribeAuthMode | cdktn.IResolvable | undefined;
    set internalValue(value: AppsyncChannelNamespaceSubscribeAuthMode | cdktn.IResolvable | undefined);
    private _authType?;
    get authType(): string;
    set authType(value: string);
    get authTypeInput(): string | undefined;
}
export declare class AppsyncChannelNamespaceSubscribeAuthModeList extends cdktn.ComplexList {
    internalValue?: AppsyncChannelNamespaceSubscribeAuthMode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsyncChannelNamespaceSubscribeAuthModeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace aws_appsync_channel_namespace}
*/
export declare class AppsyncChannelNamespace extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_channel_namespace";
    /**
    * Generates CDKTN code for importing a AppsyncChannelNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsyncChannelNamespace to import
    * @param importFromId The id of the existing AppsyncChannelNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsyncChannelNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/appsync_channel_namespace aws_appsync_channel_namespace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsyncChannelNamespaceConfig
    */
    constructor(scope: Construct, id: string, config: AppsyncChannelNamespaceConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get channelNamespaceArn(): string;
    private _codeHandlers?;
    get codeHandlers(): string;
    set codeHandlers(value: string);
    resetCodeHandlers(): void;
    get codeHandlersInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _handlerConfigs;
    get handlerConfigs(): AppsyncChannelNamespaceHandlerConfigsList;
    putHandlerConfigs(value: AppsyncChannelNamespaceHandlerConfigs[] | cdktn.IResolvable): void;
    resetHandlerConfigs(): void;
    get handlerConfigsInput(): cdktn.IResolvable | AppsyncChannelNamespaceHandlerConfigs[] | undefined;
    private _publishAuthMode;
    get publishAuthMode(): AppsyncChannelNamespacePublishAuthModeList;
    putPublishAuthMode(value: AppsyncChannelNamespacePublishAuthMode[] | cdktn.IResolvable): void;
    resetPublishAuthMode(): void;
    get publishAuthModeInput(): cdktn.IResolvable | AppsyncChannelNamespacePublishAuthMode[] | undefined;
    private _subscribeAuthMode;
    get subscribeAuthMode(): AppsyncChannelNamespaceSubscribeAuthModeList;
    putSubscribeAuthMode(value: AppsyncChannelNamespaceSubscribeAuthMode[] | cdktn.IResolvable): void;
    resetSubscribeAuthMode(): void;
    get subscribeAuthModeInput(): cdktn.IResolvable | AppsyncChannelNamespaceSubscribeAuthMode[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
