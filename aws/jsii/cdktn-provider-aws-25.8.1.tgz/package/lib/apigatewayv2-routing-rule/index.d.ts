/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface Apigatewayv2RoutingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#domain_name Apigatewayv2RoutingRule#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#priority Apigatewayv2RoutingRule#priority}
    */
    readonly priority: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#region Apigatewayv2RoutingRule#region}
    */
    readonly region?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#action Apigatewayv2RoutingRule#action}
    */
    readonly action?: Apigatewayv2RoutingRuleAction[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#condition Apigatewayv2RoutingRule#condition}
    */
    readonly condition?: Apigatewayv2RoutingRuleCondition[] | cdktn.IResolvable;
}
export interface Apigatewayv2RoutingRuleActionInvokeApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#api_id Apigatewayv2RoutingRule#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#stage Apigatewayv2RoutingRule#stage}
    */
    readonly stage: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#strip_base_path Apigatewayv2RoutingRule#strip_base_path}
    */
    readonly stripBasePath?: boolean | cdktn.IResolvable;
}
export declare function apigatewayv2RoutingRuleActionInvokeApiToTerraform(struct?: Apigatewayv2RoutingRuleActionInvokeApi | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleActionInvokeApiToHclTerraform(struct?: Apigatewayv2RoutingRuleActionInvokeApi | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleActionInvokeApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleActionInvokeApi | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleActionInvokeApi | cdktn.IResolvable | undefined);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    get stageInput(): string | undefined;
    private _stripBasePath?;
    get stripBasePath(): boolean | cdktn.IResolvable;
    set stripBasePath(value: boolean | cdktn.IResolvable);
    resetStripBasePath(): void;
    get stripBasePathInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class Apigatewayv2RoutingRuleActionInvokeApiList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleActionInvokeApi[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleActionInvokeApiOutputReference;
}
export interface Apigatewayv2RoutingRuleAction {
    /**
    * invoke_api block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#invoke_api Apigatewayv2RoutingRule#invoke_api}
    */
    readonly invokeApi?: Apigatewayv2RoutingRuleActionInvokeApi[] | cdktn.IResolvable;
}
export declare function apigatewayv2RoutingRuleActionToTerraform(struct?: Apigatewayv2RoutingRuleAction | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleActionToHclTerraform(struct?: Apigatewayv2RoutingRuleAction | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleAction | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleAction | cdktn.IResolvable | undefined);
    private _invokeApi;
    get invokeApi(): Apigatewayv2RoutingRuleActionInvokeApiList;
    putInvokeApi(value: Apigatewayv2RoutingRuleActionInvokeApi[] | cdktn.IResolvable): void;
    resetInvokeApi(): void;
    get invokeApiInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleActionInvokeApi[] | undefined;
}
export declare class Apigatewayv2RoutingRuleActionList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleActionOutputReference;
}
export interface Apigatewayv2RoutingRuleConditionMatchBasePaths {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#any_of Apigatewayv2RoutingRule#any_of}
    */
    readonly anyOf: string[];
}
export declare function apigatewayv2RoutingRuleConditionMatchBasePathsToTerraform(struct?: Apigatewayv2RoutingRuleConditionMatchBasePaths | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionMatchBasePathsToHclTerraform(struct?: Apigatewayv2RoutingRuleConditionMatchBasePaths | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionMatchBasePathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleConditionMatchBasePaths | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleConditionMatchBasePaths | cdktn.IResolvable | undefined);
    private _anyOf?;
    get anyOf(): string[];
    set anyOf(value: string[]);
    get anyOfInput(): string[] | undefined;
}
export declare class Apigatewayv2RoutingRuleConditionMatchBasePathsList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleConditionMatchBasePaths[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleConditionMatchBasePathsOutputReference;
}
export interface Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#header Apigatewayv2RoutingRule#header}
    */
    readonly header: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#value_glob Apigatewayv2RoutingRule#value_glob}
    */
    readonly valueGlob: string;
}
export declare function apigatewayv2RoutingRuleConditionMatchHeadersAnyOfToTerraform(struct?: Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionMatchHeadersAnyOfToHclTerraform(struct?: Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionMatchHeadersAnyOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf | cdktn.IResolvable | undefined);
    private _header?;
    get header(): string;
    set header(value: string);
    get headerInput(): string | undefined;
    private _valueGlob?;
    get valueGlob(): string;
    set valueGlob(value: string);
    get valueGlobInput(): string | undefined;
}
export declare class Apigatewayv2RoutingRuleConditionMatchHeadersAnyOfList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleConditionMatchHeadersAnyOfOutputReference;
}
export interface Apigatewayv2RoutingRuleConditionMatchHeaders {
    /**
    * any_of block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#any_of Apigatewayv2RoutingRule#any_of}
    */
    readonly anyOf?: Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf[] | cdktn.IResolvable;
}
export declare function apigatewayv2RoutingRuleConditionMatchHeadersToTerraform(struct?: Apigatewayv2RoutingRuleConditionMatchHeaders | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionMatchHeadersToHclTerraform(struct?: Apigatewayv2RoutingRuleConditionMatchHeaders | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionMatchHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleConditionMatchHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleConditionMatchHeaders | cdktn.IResolvable | undefined);
    private _anyOf;
    get anyOf(): Apigatewayv2RoutingRuleConditionMatchHeadersAnyOfList;
    putAnyOf(value: Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf[] | cdktn.IResolvable): void;
    resetAnyOf(): void;
    get anyOfInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleConditionMatchHeadersAnyOf[] | undefined;
}
export declare class Apigatewayv2RoutingRuleConditionMatchHeadersList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleConditionMatchHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleConditionMatchHeadersOutputReference;
}
export interface Apigatewayv2RoutingRuleCondition {
    /**
    * match_base_paths block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#match_base_paths Apigatewayv2RoutingRule#match_base_paths}
    */
    readonly matchBasePaths?: Apigatewayv2RoutingRuleConditionMatchBasePaths[] | cdktn.IResolvable;
    /**
    * match_headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#match_headers Apigatewayv2RoutingRule#match_headers}
    */
    readonly matchHeaders?: Apigatewayv2RoutingRuleConditionMatchHeaders[] | cdktn.IResolvable;
}
export declare function apigatewayv2RoutingRuleConditionToTerraform(struct?: Apigatewayv2RoutingRuleCondition | cdktn.IResolvable): any;
export declare function apigatewayv2RoutingRuleConditionToHclTerraform(struct?: Apigatewayv2RoutingRuleCondition | cdktn.IResolvable): any;
export declare class Apigatewayv2RoutingRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): Apigatewayv2RoutingRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: Apigatewayv2RoutingRuleCondition | cdktn.IResolvable | undefined);
    private _matchBasePaths;
    get matchBasePaths(): Apigatewayv2RoutingRuleConditionMatchBasePathsList;
    putMatchBasePaths(value: Apigatewayv2RoutingRuleConditionMatchBasePaths[] | cdktn.IResolvable): void;
    resetMatchBasePaths(): void;
    get matchBasePathsInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleConditionMatchBasePaths[] | undefined;
    private _matchHeaders;
    get matchHeaders(): Apigatewayv2RoutingRuleConditionMatchHeadersList;
    putMatchHeaders(value: Apigatewayv2RoutingRuleConditionMatchHeaders[] | cdktn.IResolvable): void;
    resetMatchHeaders(): void;
    get matchHeadersInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleConditionMatchHeaders[] | undefined;
}
export declare class Apigatewayv2RoutingRuleConditionList extends cdktn.ComplexList {
    internalValue?: Apigatewayv2RoutingRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): Apigatewayv2RoutingRuleConditionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule aws_apigatewayv2_routing_rule}
*/
export declare class Apigatewayv2RoutingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apigatewayv2_routing_rule";
    /**
    * Generates CDKTN code for importing a Apigatewayv2RoutingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Apigatewayv2RoutingRule to import
    * @param importFromId The id of the existing Apigatewayv2RoutingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Apigatewayv2RoutingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apigatewayv2_routing_rule aws_apigatewayv2_routing_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options Apigatewayv2RoutingRuleConfig
    */
    constructor(scope: Construct, id: string, config: Apigatewayv2RoutingRuleConfig);
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routingRuleArn(): string;
    get routingRuleId(): string;
    private _action;
    get action(): Apigatewayv2RoutingRuleActionList;
    putAction(value: Apigatewayv2RoutingRuleAction[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleAction[] | undefined;
    private _condition;
    get condition(): Apigatewayv2RoutingRuleConditionList;
    putCondition(value: Apigatewayv2RoutingRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | Apigatewayv2RoutingRuleCondition[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
