/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentPromptConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#customer_encryption_key_arn BedrockagentPrompt#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#default_variant BedrockagentPrompt#default_variant}
    */
    readonly defaultVariant?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#description BedrockagentPrompt#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#name BedrockagentPrompt#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#region BedrockagentPrompt#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#tags BedrockagentPrompt#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * variant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#variant BedrockagentPrompt#variant}
    */
    readonly variant?: BedrockagentPromptVariant[] | cdktn.IResolvable;
}
export interface BedrockagentPromptVariantGenAiResourceAgent {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#agent_identifier BedrockagentPrompt#agent_identifier}
    */
    readonly agentIdentifier: string;
}
export declare function bedrockagentPromptVariantGenAiResourceAgentToTerraform(struct?: BedrockagentPromptVariantGenAiResourceAgent | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantGenAiResourceAgentToHclTerraform(struct?: BedrockagentPromptVariantGenAiResourceAgent | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantGenAiResourceAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantGenAiResourceAgent | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantGenAiResourceAgent | cdktn.IResolvable | undefined);
    private _agentIdentifier?;
    get agentIdentifier(): string;
    set agentIdentifier(value: string);
    get agentIdentifierInput(): string | undefined;
}
export declare class BedrockagentPromptVariantGenAiResourceAgentList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantGenAiResourceAgent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantGenAiResourceAgentOutputReference;
}
export interface BedrockagentPromptVariantGenAiResource {
    /**
    * agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#agent BedrockagentPrompt#agent}
    */
    readonly agent?: BedrockagentPromptVariantGenAiResourceAgent[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantGenAiResourceToTerraform(struct?: BedrockagentPromptVariantGenAiResource | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantGenAiResourceToHclTerraform(struct?: BedrockagentPromptVariantGenAiResource | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantGenAiResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantGenAiResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantGenAiResource | cdktn.IResolvable | undefined);
    private _agent;
    get agent(): BedrockagentPromptVariantGenAiResourceAgentList;
    putAgent(value: BedrockagentPromptVariantGenAiResourceAgent[] | cdktn.IResolvable): void;
    resetAgent(): void;
    get agentInput(): cdktn.IResolvable | BedrockagentPromptVariantGenAiResourceAgent[] | undefined;
}
export declare class BedrockagentPromptVariantGenAiResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantGenAiResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantGenAiResourceOutputReference;
}
export interface BedrockagentPromptVariantInferenceConfigurationText {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#max_tokens BedrockagentPrompt#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#stop_sequences BedrockagentPrompt#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#temperature BedrockagentPrompt#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#top_p BedrockagentPrompt#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentPromptVariantInferenceConfigurationTextToTerraform(struct?: BedrockagentPromptVariantInferenceConfigurationText | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantInferenceConfigurationTextToHclTerraform(struct?: BedrockagentPromptVariantInferenceConfigurationText | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantInferenceConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantInferenceConfigurationText | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantInferenceConfigurationText | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentPromptVariantInferenceConfigurationTextList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantInferenceConfigurationText[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantInferenceConfigurationTextOutputReference;
}
export interface BedrockagentPromptVariantInferenceConfiguration {
    /**
    * text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#text BedrockagentPrompt#text}
    */
    readonly text?: BedrockagentPromptVariantInferenceConfigurationText[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantInferenceConfigurationToTerraform(struct?: BedrockagentPromptVariantInferenceConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantInferenceConfigurationToHclTerraform(struct?: BedrockagentPromptVariantInferenceConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantInferenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantInferenceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantInferenceConfiguration | cdktn.IResolvable | undefined);
    private _text;
    get text(): BedrockagentPromptVariantInferenceConfigurationTextList;
    putText(value: BedrockagentPromptVariantInferenceConfigurationText[] | cdktn.IResolvable): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | BedrockagentPromptVariantInferenceConfigurationText[] | undefined;
}
export declare class BedrockagentPromptVariantInferenceConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantInferenceConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantInferenceConfigurationOutputReference;
}
export interface BedrockagentPromptVariantMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#key BedrockagentPrompt#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#value BedrockagentPrompt#value}
    */
    readonly value: string;
}
export declare function bedrockagentPromptVariantMetadataToTerraform(struct?: BedrockagentPromptVariantMetadata | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantMetadataToHclTerraform(struct?: BedrockagentPromptVariantMetadata | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantMetadata | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class BedrockagentPromptVariantMetadataList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantMetadataOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatInputVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#name BedrockagentPrompt#name}
    */
    readonly name: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatInputVariableToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatInputVariable | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatInputVariableToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatInputVariable | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatInputVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatInputVariable | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatInputVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatInputVariableList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatInputVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatInputVariableOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#type BedrockagentPrompt#type}
    */
    readonly type: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePointToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePointToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePointOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatMessageContent {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#text BedrockagentPrompt#text}
    */
    readonly text?: string;
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#cache_point BedrockagentPrompt#cache_point}
    */
    readonly cachePoint?: BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatMessageContentToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatMessageContent | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatMessageContentToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatMessageContent | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatMessageContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatMessageContent | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatMessageContent | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _cachePoint;
    get cachePoint(): BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePointList;
    putCachePoint(value: BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatMessageContentCachePoint[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatMessageContentList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatMessageContent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatMessageContentOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatMessage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#role BedrockagentPrompt#role}
    */
    readonly role: string;
    /**
    * content block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#content BedrockagentPrompt#content}
    */
    readonly content?: BedrockagentPromptVariantTemplateConfigurationChatMessageContent[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatMessageToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatMessage | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatMessageToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatMessage | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatMessage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatMessage | cdktn.IResolvable | undefined);
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _content;
    get content(): BedrockagentPromptVariantTemplateConfigurationChatMessageContentList;
    putContent(value: BedrockagentPromptVariantTemplateConfigurationChatMessageContent[] | cdktn.IResolvable): void;
    resetContent(): void;
    get contentInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatMessageContent[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatMessageList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatMessage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatMessageOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#type BedrockagentPrompt#type}
    */
    readonly type: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatSystemCachePointToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatSystemCachePointToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatSystemCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatSystemCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatSystemCachePointOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatSystem {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#text BedrockagentPrompt#text}
    */
    readonly text?: string;
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#cache_point BedrockagentPrompt#cache_point}
    */
    readonly cachePoint?: BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatSystemToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatSystem | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatSystemToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatSystem | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatSystemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatSystem | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatSystem | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _cachePoint;
    get cachePoint(): BedrockagentPromptVariantTemplateConfigurationChatSystemCachePointList;
    putCachePoint(value: BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatSystemCachePoint[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatSystemList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatSystem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatSystemOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#type BedrockagentPrompt#type}
    */
    readonly type: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#json BedrockagentPrompt#json}
    */
    readonly json?: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable | undefined);
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#description BedrockagentPrompt#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#name BedrockagentPrompt#name}
    */
    readonly name: string;
    /**
    * input_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#input_schema BedrockagentPrompt#input_schema}
    */
    readonly inputSchema?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _inputSchema;
    get inputSchema(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaList;
    putInputSchema(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | cdktn.IResolvable): void;
    resetInputSchema(): void;
    get inputSchemaInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool {
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#cache_point BedrockagentPrompt#cache_point}
    */
    readonly cachePoint?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint[] | cdktn.IResolvable;
    /**
    * tool_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#tool_spec BedrockagentPrompt#tool_spec}
    */
    readonly toolSpec?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable | undefined);
    private _cachePoint;
    get cachePoint(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointList;
    putCachePoint(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolCachePoint[] | undefined;
    private _toolSpec;
    get toolSpec(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpecList;
    putToolSpec(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec[] | cdktn.IResolvable): void;
    resetToolSpec(): void;
    get toolSpecInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolToolSpec[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny {
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAnyToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAnyToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAnyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable | undefined);
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAnyList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAnyOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto {
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAutoToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAutoToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAutoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable | undefined);
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAutoList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAutoOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#name BedrockagentPrompt#name}
    */
    readonly name: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice {
    /**
    * any block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#any BedrockagentPrompt#any}
    */
    readonly any?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny[] | cdktn.IResolvable;
    /**
    * auto block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#auto BedrockagentPrompt#auto}
    */
    readonly auto?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | cdktn.IResolvable;
    /**
    * tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#tool BedrockagentPrompt#tool}
    */
    readonly tool?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable | undefined);
    private _any;
    get any(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAnyList;
    putAny(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny[] | cdktn.IResolvable): void;
    resetAny(): void;
    get anyInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAny[] | undefined;
    private _auto;
    get auto(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAutoList;
    putAuto(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | cdktn.IResolvable): void;
    resetAuto(): void;
    get autoInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | undefined;
    private _tool;
    get tool(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolList;
    putTool(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool[] | cdktn.IResolvable): void;
    resetTool(): void;
    get toolInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceTool[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration {
    /**
    * tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#tool BedrockagentPrompt#tool}
    */
    readonly tool?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool[] | cdktn.IResolvable;
    /**
    * tool_choice block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#tool_choice BedrockagentPrompt#tool_choice}
    */
    readonly toolChoice?: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration | cdktn.IResolvable | undefined);
    private _tool;
    get tool(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolList;
    putTool(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool[] | cdktn.IResolvable): void;
    resetTool(): void;
    get toolInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationTool[] | undefined;
    private _toolChoice;
    get toolChoice(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceList;
    putToolChoice(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice[] | cdktn.IResolvable): void;
    resetToolChoice(): void;
    get toolChoiceInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationToolChoice[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationChat {
    /**
    * input_variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#input_variable BedrockagentPrompt#input_variable}
    */
    readonly inputVariable?: BedrockagentPromptVariantTemplateConfigurationChatInputVariable[] | cdktn.IResolvable;
    /**
    * message block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#message BedrockagentPrompt#message}
    */
    readonly message?: BedrockagentPromptVariantTemplateConfigurationChatMessage[] | cdktn.IResolvable;
    /**
    * system block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#system BedrockagentPrompt#system}
    */
    readonly systemAttribute?: BedrockagentPromptVariantTemplateConfigurationChatSystem[] | cdktn.IResolvable;
    /**
    * tool_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#tool_configuration BedrockagentPrompt#tool_configuration}
    */
    readonly toolConfiguration?: BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationChatToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChat | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationChatToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationChat | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationChatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationChat | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationChat | cdktn.IResolvable | undefined);
    private _inputVariable;
    get inputVariable(): BedrockagentPromptVariantTemplateConfigurationChatInputVariableList;
    putInputVariable(value: BedrockagentPromptVariantTemplateConfigurationChatInputVariable[] | cdktn.IResolvable): void;
    resetInputVariable(): void;
    get inputVariableInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatInputVariable[] | undefined;
    private _message;
    get message(): BedrockagentPromptVariantTemplateConfigurationChatMessageList;
    putMessage(value: BedrockagentPromptVariantTemplateConfigurationChatMessage[] | cdktn.IResolvable): void;
    resetMessage(): void;
    get messageInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatMessage[] | undefined;
    private _system;
    get systemAttribute(): BedrockagentPromptVariantTemplateConfigurationChatSystemList;
    putSystemAttribute(value: BedrockagentPromptVariantTemplateConfigurationChatSystem[] | cdktn.IResolvable): void;
    resetSystemAttribute(): void;
    get systemAttributeInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatSystem[] | undefined;
    private _toolConfiguration;
    get toolConfiguration(): BedrockagentPromptVariantTemplateConfigurationChatToolConfigurationList;
    putToolConfiguration(value: BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration[] | cdktn.IResolvable): void;
    resetToolConfiguration(): void;
    get toolConfigurationInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChatToolConfiguration[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationChatList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationChat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationChatOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationTextCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#type BedrockagentPrompt#type}
    */
    readonly type: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationTextCachePointToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationTextCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationTextCachePointToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationTextCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationTextCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationTextCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationTextCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationTextCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationTextCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationTextCachePointOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationTextInputVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#name BedrockagentPrompt#name}
    */
    readonly name: string;
}
export declare function bedrockagentPromptVariantTemplateConfigurationTextInputVariableToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationTextInputVariable | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationTextInputVariableToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationTextInputVariable | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationTextInputVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationTextInputVariable | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationTextInputVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationTextInputVariableList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationTextInputVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationTextInputVariableOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfigurationText {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#text BedrockagentPrompt#text}
    */
    readonly text: string;
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#cache_point BedrockagentPrompt#cache_point}
    */
    readonly cachePoint?: BedrockagentPromptVariantTemplateConfigurationTextCachePoint[] | cdktn.IResolvable;
    /**
    * input_variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#input_variable BedrockagentPrompt#input_variable}
    */
    readonly inputVariable?: BedrockagentPromptVariantTemplateConfigurationTextInputVariable[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationTextToTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationText | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationTextToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfigurationText | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfigurationText | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfigurationText | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
    private _cachePoint;
    get cachePoint(): BedrockagentPromptVariantTemplateConfigurationTextCachePointList;
    putCachePoint(value: BedrockagentPromptVariantTemplateConfigurationTextCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationTextCachePoint[] | undefined;
    private _inputVariable;
    get inputVariable(): BedrockagentPromptVariantTemplateConfigurationTextInputVariableList;
    putInputVariable(value: BedrockagentPromptVariantTemplateConfigurationTextInputVariable[] | cdktn.IResolvable): void;
    resetInputVariable(): void;
    get inputVariableInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationTextInputVariable[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationTextList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfigurationText[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationTextOutputReference;
}
export interface BedrockagentPromptVariantTemplateConfiguration {
    /**
    * chat block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#chat BedrockagentPrompt#chat}
    */
    readonly chat?: BedrockagentPromptVariantTemplateConfigurationChat[] | cdktn.IResolvable;
    /**
    * text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#text BedrockagentPrompt#text}
    */
    readonly text?: BedrockagentPromptVariantTemplateConfigurationText[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantTemplateConfigurationToTerraform(struct?: BedrockagentPromptVariantTemplateConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantTemplateConfigurationToHclTerraform(struct?: BedrockagentPromptVariantTemplateConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantTemplateConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariantTemplateConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariantTemplateConfiguration | cdktn.IResolvable | undefined);
    private _chat;
    get chat(): BedrockagentPromptVariantTemplateConfigurationChatList;
    putChat(value: BedrockagentPromptVariantTemplateConfigurationChat[] | cdktn.IResolvable): void;
    resetChat(): void;
    get chatInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationChat[] | undefined;
    private _text;
    get text(): BedrockagentPromptVariantTemplateConfigurationTextList;
    putText(value: BedrockagentPromptVariantTemplateConfigurationText[] | cdktn.IResolvable): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfigurationText[] | undefined;
}
export declare class BedrockagentPromptVariantTemplateConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariantTemplateConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantTemplateConfigurationOutputReference;
}
export interface BedrockagentPromptVariant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#additional_model_request_fields BedrockagentPrompt#additional_model_request_fields}
    */
    readonly additionalModelRequestFields?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#model_id BedrockagentPrompt#model_id}
    */
    readonly modelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#name BedrockagentPrompt#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#template_type BedrockagentPrompt#template_type}
    */
    readonly templateType: string;
    /**
    * gen_ai_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#gen_ai_resource BedrockagentPrompt#gen_ai_resource}
    */
    readonly genAiResource?: BedrockagentPromptVariantGenAiResource[] | cdktn.IResolvable;
    /**
    * inference_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#inference_configuration BedrockagentPrompt#inference_configuration}
    */
    readonly inferenceConfiguration?: BedrockagentPromptVariantInferenceConfiguration[] | cdktn.IResolvable;
    /**
    * metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#metadata BedrockagentPrompt#metadata}
    */
    readonly metadata?: BedrockagentPromptVariantMetadata[] | cdktn.IResolvable;
    /**
    * template_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#template_configuration BedrockagentPrompt#template_configuration}
    */
    readonly templateConfiguration?: BedrockagentPromptVariantTemplateConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentPromptVariantToTerraform(struct?: BedrockagentPromptVariant | cdktn.IResolvable): any;
export declare function bedrockagentPromptVariantToHclTerraform(struct?: BedrockagentPromptVariant | cdktn.IResolvable): any;
export declare class BedrockagentPromptVariantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentPromptVariant | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentPromptVariant | cdktn.IResolvable | undefined);
    private _additionalModelRequestFields?;
    get additionalModelRequestFields(): string;
    set additionalModelRequestFields(value: string);
    resetAdditionalModelRequestFields(): void;
    get additionalModelRequestFieldsInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    resetModelId(): void;
    get modelIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _templateType?;
    get templateType(): string;
    set templateType(value: string);
    get templateTypeInput(): string | undefined;
    private _genAiResource;
    get genAiResource(): BedrockagentPromptVariantGenAiResourceList;
    putGenAiResource(value: BedrockagentPromptVariantGenAiResource[] | cdktn.IResolvable): void;
    resetGenAiResource(): void;
    get genAiResourceInput(): cdktn.IResolvable | BedrockagentPromptVariantGenAiResource[] | undefined;
    private _inferenceConfiguration;
    get inferenceConfiguration(): BedrockagentPromptVariantInferenceConfigurationList;
    putInferenceConfiguration(value: BedrockagentPromptVariantInferenceConfiguration[] | cdktn.IResolvable): void;
    resetInferenceConfiguration(): void;
    get inferenceConfigurationInput(): cdktn.IResolvable | BedrockagentPromptVariantInferenceConfiguration[] | undefined;
    private _metadata;
    get metadata(): BedrockagentPromptVariantMetadataList;
    putMetadata(value: BedrockagentPromptVariantMetadata[] | cdktn.IResolvable): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | BedrockagentPromptVariantMetadata[] | undefined;
    private _templateConfiguration;
    get templateConfiguration(): BedrockagentPromptVariantTemplateConfigurationList;
    putTemplateConfiguration(value: BedrockagentPromptVariantTemplateConfiguration[] | cdktn.IResolvable): void;
    resetTemplateConfiguration(): void;
    get templateConfigurationInput(): cdktn.IResolvable | BedrockagentPromptVariantTemplateConfiguration[] | undefined;
}
export declare class BedrockagentPromptVariantList extends cdktn.ComplexList {
    internalValue?: BedrockagentPromptVariant[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentPromptVariantOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt aws_bedrockagent_prompt}
*/
export declare class BedrockagentPrompt extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_prompt";
    /**
    * Generates CDKTN code for importing a BedrockagentPrompt resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentPrompt to import
    * @param importFromId The id of the existing BedrockagentPrompt that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentPrompt to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_prompt aws_bedrockagent_prompt} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentPromptConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentPromptConfig);
    get arn(): string;
    get createdAt(): string;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _defaultVariant?;
    get defaultVariant(): string;
    set defaultVariant(value: string);
    resetDefaultVariant(): void;
    get defaultVariantInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get version(): string;
    private _variant;
    get variant(): BedrockagentPromptVariantList;
    putVariant(value: BedrockagentPromptVariant[] | cdktn.IResolvable): void;
    resetVariant(): void;
    get variantInput(): cdktn.IResolvable | BedrockagentPromptVariant[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
