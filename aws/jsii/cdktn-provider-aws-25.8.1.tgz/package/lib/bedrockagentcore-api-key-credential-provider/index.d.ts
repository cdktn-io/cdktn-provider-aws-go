/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreApiKeyCredentialProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#api_key BedrockagentcoreApiKeyCredentialProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_secret_source BedrockagentcoreApiKeyCredentialProvider#api_key_secret_source}
    */
    readonly apiKeySecretSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_wo BedrockagentcoreApiKeyCredentialProvider#api_key_wo}
    */
    readonly apiKeyWo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_wo_version BedrockagentcoreApiKeyCredentialProvider#api_key_wo_version}
    */
    readonly apiKeyWoVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#name BedrockagentcoreApiKeyCredentialProvider#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#region BedrockagentcoreApiKeyCredentialProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#tags BedrockagentcoreApiKeyCredentialProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * api_key_secret_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_secret_config BedrockagentcoreApiKeyCredentialProvider#api_key_secret_config}
    */
    readonly apiKeySecretConfig?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig[] | cdktn.IResolvable;
}
export interface BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn {
}
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretArnToTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn): any;
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretArnToHclTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn): any;
export declare class BedrockagentcoreApiKeyCredentialProviderApiKeySecretArnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn | undefined;
    set internalValue(value: BedrockagentcoreApiKeyCredentialProviderApiKeySecretArn | undefined);
    get secretArn(): string;
}
export declare class BedrockagentcoreApiKeyCredentialProviderApiKeySecretArnList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreApiKeyCredentialProviderApiKeySecretArnOutputReference;
}
export interface BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#json_key BedrockagentcoreApiKeyCredentialProvider#json_key}
    */
    readonly jsonKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#secret_id BedrockagentcoreApiKeyCredentialProvider#secret_id}
    */
    readonly secretId: string;
}
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigToTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigToHclTerraform(struct?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig | cdktn.IResolvable | undefined);
    private _jsonKey?;
    get jsonKey(): string;
    set jsonKey(value: string);
    get jsonKeyInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    get secretIdInput(): string | undefined;
}
export declare class BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider aws_bedrockagentcore_api_key_credential_provider}
*/
export declare class BedrockagentcoreApiKeyCredentialProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_api_key_credential_provider";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreApiKeyCredentialProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreApiKeyCredentialProvider to import
    * @param importFromId The id of the existing BedrockagentcoreApiKeyCredentialProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreApiKeyCredentialProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_api_key_credential_provider aws_bedrockagentcore_api_key_credential_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreApiKeyCredentialProviderConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreApiKeyCredentialProviderConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiKeySecretArn;
    get apiKeySecretArn(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretArnList;
    private _apiKeySecretSource?;
    get apiKeySecretSource(): string;
    set apiKeySecretSource(value: string);
    resetApiKeySecretSource(): void;
    get apiKeySecretSourceInput(): string | undefined;
    private _apiKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get apiKeyWo(): string;
    set apiKeyWo(value: string);
    resetApiKeyWo(): void;
    get apiKeyWoInput(): string | undefined;
    private _apiKeyWoVersion?;
    get apiKeyWoVersion(): number;
    set apiKeyWoVersion(value: number);
    resetApiKeyWoVersion(): void;
    get apiKeyWoVersionInput(): number | undefined;
    get credentialProviderArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _apiKeySecretConfig;
    get apiKeySecretConfig(): BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfigList;
    putApiKeySecretConfig(value: BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig[] | cdktn.IResolvable): void;
    resetApiKeySecretConfig(): void;
    get apiKeySecretConfigInput(): cdktn.IResolvable | BedrockagentcoreApiKeyCredentialProviderApiKeySecretConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
