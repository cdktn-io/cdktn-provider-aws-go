/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCloudwatchContributorManagedInsightRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_contributor_managed_insight_rules#region DataAwsCloudwatchContributorManagedInsightRules#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_contributor_managed_insight_rules#resource_arn DataAwsCloudwatchContributorManagedInsightRules#resource_arn}
    */
    readonly resourceArn: string;
}
export interface DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleState {
}
export declare function dataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleStateToTerraform(struct?: DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleState): any;
export declare function dataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleStateToHclTerraform(struct?: DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleState): any;
export declare class DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleState | undefined;
    set internalValue(value: DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleState | undefined);
    get ruleName(): string;
    get state(): string;
}
export declare class DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleStateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleStateOutputReference;
}
export interface DataAwsCloudwatchContributorManagedInsightRulesManagedRules {
}
export declare function dataAwsCloudwatchContributorManagedInsightRulesManagedRulesToTerraform(struct?: DataAwsCloudwatchContributorManagedInsightRulesManagedRules): any;
export declare function dataAwsCloudwatchContributorManagedInsightRulesManagedRulesToHclTerraform(struct?: DataAwsCloudwatchContributorManagedInsightRulesManagedRules): any;
export declare class DataAwsCloudwatchContributorManagedInsightRulesManagedRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudwatchContributorManagedInsightRulesManagedRules | undefined;
    set internalValue(value: DataAwsCloudwatchContributorManagedInsightRulesManagedRules | undefined);
    get resourceArn(): string;
    private _ruleState;
    get ruleState(): DataAwsCloudwatchContributorManagedInsightRulesManagedRulesRuleStateList;
    get templateName(): string;
}
export declare class DataAwsCloudwatchContributorManagedInsightRulesManagedRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudwatchContributorManagedInsightRulesManagedRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_contributor_managed_insight_rules aws_cloudwatch_contributor_managed_insight_rules}
*/
export declare class DataAwsCloudwatchContributorManagedInsightRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudwatch_contributor_managed_insight_rules";
    /**
    * Generates CDKTN code for importing a DataAwsCloudwatchContributorManagedInsightRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCloudwatchContributorManagedInsightRules to import
    * @param importFromId The id of the existing DataAwsCloudwatchContributorManagedInsightRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_contributor_managed_insight_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCloudwatchContributorManagedInsightRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudwatch_contributor_managed_insight_rules aws_cloudwatch_contributor_managed_insight_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCloudwatchContributorManagedInsightRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCloudwatchContributorManagedInsightRulesConfig);
    private _managedRules;
    get managedRules(): DataAwsCloudwatchContributorManagedInsightRulesManagedRulesList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
