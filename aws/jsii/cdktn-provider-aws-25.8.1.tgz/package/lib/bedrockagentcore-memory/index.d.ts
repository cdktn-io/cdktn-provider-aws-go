/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreMemoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#description BedrockagentcoreMemory#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#encryption_key_arn BedrockagentcoreMemory#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#event_expiry_duration BedrockagentcoreMemory#event_expiry_duration}
    */
    readonly eventExpiryDuration: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#memory_execution_role_arn BedrockagentcoreMemory#memory_execution_role_arn}
    */
    readonly memoryExecutionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#name BedrockagentcoreMemory#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#region BedrockagentcoreMemory#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#tags BedrockagentcoreMemory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * indexed_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#indexed_key BedrockagentcoreMemory#indexed_key}
    */
    readonly indexedKey?: BedrockagentcoreMemoryIndexedKey[] | cdktn.IResolvable;
    /**
    * stream_delivery_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#stream_delivery_resources BedrockagentcoreMemory#stream_delivery_resources}
    */
    readonly streamDeliveryResources?: BedrockagentcoreMemoryStreamDeliveryResources[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#timeouts BedrockagentcoreMemory#timeouts}
    */
    readonly timeouts?: BedrockagentcoreMemoryTimeouts;
}
export interface BedrockagentcoreMemoryIndexedKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#key BedrockagentcoreMemory#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#type BedrockagentcoreMemory#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreMemoryIndexedKeyToTerraform(struct?: BedrockagentcoreMemoryIndexedKey | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryIndexedKeyToHclTerraform(struct?: BedrockagentcoreMemoryIndexedKey | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryIndexedKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryIndexedKey | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryIndexedKey | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreMemoryIndexedKeyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryIndexedKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryIndexedKeyOutputReference;
}
export interface BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#level BedrockagentcoreMemory#level}
    */
    readonly level?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#type BedrockagentcoreMemory#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfigurationToTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfigurationToHclTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration | cdktn.IResolvable | undefined);
    private _level?;
    get level(): string;
    set level(value: string);
    resetLevel(): void;
    get levelInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfigurationOutputReference;
}
export interface BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#data_stream_arn BedrockagentcoreMemory#data_stream_arn}
    */
    readonly dataStreamArn: string;
    /**
    * content_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#content_configuration BedrockagentcoreMemory#content_configuration}
    */
    readonly contentConfiguration?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisToTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisToHclTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis | cdktn.IResolvable | undefined);
    private _dataStreamArn?;
    get dataStreamArn(): string;
    set dataStreamArn(value: string);
    get dataStreamArnInput(): string | undefined;
    private _contentConfiguration;
    get contentConfiguration(): BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfigurationList;
    putContentConfiguration(value: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration[] | cdktn.IResolvable): void;
    resetContentConfiguration(): void;
    get contentConfigurationInput(): cdktn.IResolvable | BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisContentConfiguration[] | undefined;
}
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisOutputReference;
}
export interface BedrockagentcoreMemoryStreamDeliveryResourcesResource {
    /**
    * kinesis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#kinesis BedrockagentcoreMemory#kinesis}
    */
    readonly kinesis?: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesResourceToTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResourcesResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesResourceToHclTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResourcesResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStreamDeliveryResourcesResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStreamDeliveryResourcesResource | cdktn.IResolvable | undefined);
    private _kinesis;
    get kinesis(): BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesisList;
    putKinesis(value: BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis[] | cdktn.IResolvable): void;
    resetKinesis(): void;
    get kinesisInput(): cdktn.IResolvable | BedrockagentcoreMemoryStreamDeliveryResourcesResourceKinesis[] | undefined;
}
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStreamDeliveryResourcesResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStreamDeliveryResourcesResourceOutputReference;
}
export interface BedrockagentcoreMemoryStreamDeliveryResources {
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#resource BedrockagentcoreMemory#resource}
    */
    readonly resource?: BedrockagentcoreMemoryStreamDeliveryResourcesResource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesToTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResources | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryStreamDeliveryResourcesToHclTerraform(struct?: BedrockagentcoreMemoryStreamDeliveryResources | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreMemoryStreamDeliveryResources | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryStreamDeliveryResources | cdktn.IResolvable | undefined);
    private _resource;
    get resource(): BedrockagentcoreMemoryStreamDeliveryResourcesResourceList;
    putResource(value: BedrockagentcoreMemoryStreamDeliveryResourcesResource[] | cdktn.IResolvable): void;
    resetResource(): void;
    get resourceInput(): cdktn.IResolvable | BedrockagentcoreMemoryStreamDeliveryResourcesResource[] | undefined;
}
export declare class BedrockagentcoreMemoryStreamDeliveryResourcesList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreMemoryStreamDeliveryResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreMemoryStreamDeliveryResourcesOutputReference;
}
export interface BedrockagentcoreMemoryTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#create BedrockagentcoreMemory#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#delete BedrockagentcoreMemory#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#update BedrockagentcoreMemory#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcoreMemoryTimeoutsToTerraform(struct?: BedrockagentcoreMemoryTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreMemoryTimeoutsToHclTerraform(struct?: BedrockagentcoreMemoryTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreMemoryTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreMemoryTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreMemoryTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory aws_bedrockagentcore_memory}
*/
export declare class BedrockagentcoreMemory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_memory";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreMemory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreMemory to import
    * @param importFromId The id of the existing BedrockagentcoreMemory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreMemory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_memory aws_bedrockagentcore_memory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreMemoryConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreMemoryConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    private _eventExpiryDuration?;
    get eventExpiryDuration(): number;
    set eventExpiryDuration(value: number);
    get eventExpiryDurationInput(): number | undefined;
    get id(): string;
    private _memoryExecutionRoleArn?;
    get memoryExecutionRoleArn(): string;
    set memoryExecutionRoleArn(value: string);
    resetMemoryExecutionRoleArn(): void;
    get memoryExecutionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _indexedKey;
    get indexedKey(): BedrockagentcoreMemoryIndexedKeyList;
    putIndexedKey(value: BedrockagentcoreMemoryIndexedKey[] | cdktn.IResolvable): void;
    resetIndexedKey(): void;
    get indexedKeyInput(): cdktn.IResolvable | BedrockagentcoreMemoryIndexedKey[] | undefined;
    private _streamDeliveryResources;
    get streamDeliveryResources(): BedrockagentcoreMemoryStreamDeliveryResourcesList;
    putStreamDeliveryResources(value: BedrockagentcoreMemoryStreamDeliveryResources[] | cdktn.IResolvable): void;
    resetStreamDeliveryResources(): void;
    get streamDeliveryResourcesInput(): cdktn.IResolvable | BedrockagentcoreMemoryStreamDeliveryResources[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreMemoryTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreMemoryTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreMemoryTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
