/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreGatewayTargetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#gateway_identifier BedrockagentcoreGatewayTarget#gateway_identifier}
    */
    readonly gatewayIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#region BedrockagentcoreGatewayTarget#region}
    */
    readonly region?: string;
    /**
    * credential_provider_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#credential_provider_configuration BedrockagentcoreGatewayTarget#credential_provider_configuration}
    */
    readonly credentialProviderConfiguration?: BedrockagentcoreGatewayTargetCredentialProviderConfiguration[] | cdktn.IResolvable;
    /**
    * metadata_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#metadata_configuration BedrockagentcoreGatewayTarget#metadata_configuration}
    */
    readonly metadataConfiguration?: BedrockagentcoreGatewayTargetMetadataConfiguration[] | cdktn.IResolvable;
    /**
    * private_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#private_endpoint BedrockagentcoreGatewayTarget#private_endpoint}
    */
    readonly privateEndpoint?: BedrockagentcoreGatewayTargetPrivateEndpoint[] | cdktn.IResolvable;
    /**
    * target_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#target_configuration BedrockagentcoreGatewayTarget#target_configuration}
    */
    readonly targetConfiguration?: BedrockagentcoreGatewayTargetTargetConfiguration[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#timeouts BedrockagentcoreGatewayTarget#timeouts}
    */
    readonly timeouts?: BedrockagentcoreGatewayTargetTimeouts;
}
export interface BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#credential_location BedrockagentcoreGatewayTarget#credential_location}
    */
    readonly credentialLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#credential_parameter_name BedrockagentcoreGatewayTarget#credential_parameter_name}
    */
    readonly credentialParameterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#credential_prefix BedrockagentcoreGatewayTarget#credential_prefix}
    */
    readonly credentialPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#provider_arn BedrockagentcoreGatewayTarget#provider_arn}
    */
    readonly providerArn: string;
}
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKeyToTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKeyToHclTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey | cdktn.IResolvable | undefined);
    private _credentialLocation?;
    get credentialLocation(): string;
    set credentialLocation(value: string);
    resetCredentialLocation(): void;
    get credentialLocationInput(): string | undefined;
    private _credentialParameterName?;
    get credentialParameterName(): string;
    set credentialParameterName(value: string);
    resetCredentialParameterName(): void;
    get credentialParameterNameInput(): string | undefined;
    private _credentialPrefix?;
    get credentialPrefix(): string;
    set credentialPrefix(value: string);
    resetCredentialPrefix(): void;
    get credentialPrefixInput(): string | undefined;
    private _providerArn?;
    get providerArn(): string;
    set providerArn(value: string);
    get providerArnInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKeyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKeyOutputReference;
}
export interface BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#region BedrockagentcoreGatewayTarget#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#service BedrockagentcoreGatewayTarget#service}
    */
    readonly service: string;
}
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentialsToTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentialsToHclTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentialsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentialsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentialsOutputReference;
}
export interface BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole {
    /**
    * AWS Region used for SigV4 signing of upstream requests. Defaults to the gateway's Region when omitted. Only meaningful when `service` is set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#region BedrockagentcoreGatewayTarget#region}
    */
    readonly region?: string;
    /**
    * The target AWS service name used for SigV4 signing of upstream requests. Required when calling SigV4-protected endpoints such as another Bedrock AgentCore Runtime (use `bedrock-agentcore`). Omit for non-SigV4 IAM-role-based authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#service BedrockagentcoreGatewayTarget#service}
    */
    readonly service?: string;
}
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRoleToTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRoleToHclTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    resetService(): void;
    get serviceInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRoleList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRoleOutputReference;
}
export interface BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough {
}
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthroughToTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthroughToHclTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthroughOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough | cdktn.IResolvable | undefined);
}
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthroughList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthroughOutputReference;
}
export interface BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#custom_parameters BedrockagentcoreGatewayTarget#custom_parameters}
    */
    readonly customParameters?: {
        [key: string]: string;
    };
    /**
    * The URL where the end user's browser is redirected after obtaining the authorization code. Required when grant_type is AUTHORIZATION_CODE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#default_return_url BedrockagentcoreGatewayTarget#default_return_url}
    */
    readonly defaultReturnUrl?: string;
    /**
    * The OAuth grant type. Valid values are AUTHORIZATION_CODE and CLIENT_CREDENTIALS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#grant_type BedrockagentcoreGatewayTarget#grant_type}
    */
    readonly grantType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#provider_arn BedrockagentcoreGatewayTarget#provider_arn}
    */
    readonly providerArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#scopes BedrockagentcoreGatewayTarget#scopes}
    */
    readonly scopes: string[];
}
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationOauthToTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationOauthToHclTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth | cdktn.IResolvable | undefined);
    private _customParameters?;
    get customParameters(): {
        [key: string]: string;
    };
    set customParameters(value: {
        [key: string]: string;
    });
    resetCustomParameters(): void;
    get customParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultReturnUrl?;
    get defaultReturnUrl(): string;
    set defaultReturnUrl(value: string);
    resetDefaultReturnUrl(): void;
    get defaultReturnUrlInput(): string | undefined;
    private _grantType?;
    get grantType(): string;
    set grantType(value: string);
    resetGrantType(): void;
    get grantTypeInput(): string | undefined;
    private _providerArn?;
    get providerArn(): string;
    set providerArn(value: string);
    get providerArnInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauthList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauthOutputReference;
}
export interface BedrockagentcoreGatewayTargetCredentialProviderConfiguration {
    /**
    * api_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#api_key BedrockagentcoreGatewayTarget#api_key}
    */
    readonly apiKey?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey[] | cdktn.IResolvable;
    /**
    * caller_iam_credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#caller_iam_credentials BedrockagentcoreGatewayTarget#caller_iam_credentials}
    */
    readonly callerIamCredentials?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials[] | cdktn.IResolvable;
    /**
    * gateway_iam_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#gateway_iam_role BedrockagentcoreGatewayTarget#gateway_iam_role}
    */
    readonly gatewayIamRole?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole[] | cdktn.IResolvable;
    /**
    * jwt_passthrough block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#jwt_passthrough BedrockagentcoreGatewayTarget#jwt_passthrough}
    */
    readonly jwtPassthrough?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough[] | cdktn.IResolvable;
    /**
    * oauth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#oauth BedrockagentcoreGatewayTarget#oauth}
    */
    readonly oauth?: BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationToTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetCredentialProviderConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayTargetCredentialProviderConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetCredentialProviderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetCredentialProviderConfiguration | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKeyList;
    putApiKey(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey[] | cdktn.IResolvable): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetCredentialProviderConfigurationApiKey[] | undefined;
    private _callerIamCredentials;
    get callerIamCredentials(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentialsList;
    putCallerIamCredentials(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials[] | cdktn.IResolvable): void;
    resetCallerIamCredentials(): void;
    get callerIamCredentialsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetCredentialProviderConfigurationCallerIamCredentials[] | undefined;
    private _gatewayIamRole;
    get gatewayIamRole(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRoleList;
    putGatewayIamRole(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole[] | cdktn.IResolvable): void;
    resetGatewayIamRole(): void;
    get gatewayIamRoleInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetCredentialProviderConfigurationGatewayIamRole[] | undefined;
    private _jwtPassthrough;
    get jwtPassthrough(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthroughList;
    putJwtPassthrough(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough[] | cdktn.IResolvable): void;
    resetJwtPassthrough(): void;
    get jwtPassthroughInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetCredentialProviderConfigurationJwtPassthrough[] | undefined;
    private _oauth;
    get oauth(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauthList;
    putOauth(value: BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth[] | cdktn.IResolvable): void;
    resetOauth(): void;
    get oauthInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetCredentialProviderConfigurationOauth[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetCredentialProviderConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetCredentialProviderConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetCredentialProviderConfigurationOutputReference;
}
export interface BedrockagentcoreGatewayTargetMetadataConfiguration {
    /**
    * A list of URL query parameters that are allowed to be propagated from incoming gateway URL to the target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#allowed_query_parameters BedrockagentcoreGatewayTarget#allowed_query_parameters}
    */
    readonly allowedQueryParameters?: string[];
    /**
    * A list of HTTP headers that are allowed to be propagated from incoming client requests to the target.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#allowed_request_headers BedrockagentcoreGatewayTarget#allowed_request_headers}
    */
    readonly allowedRequestHeaders?: string[];
    /**
    * A list of HTTP headers that are allowed to be propagated from the target response back to the client.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#allowed_response_headers BedrockagentcoreGatewayTarget#allowed_response_headers}
    */
    readonly allowedResponseHeaders?: string[];
}
export declare function bedrockagentcoreGatewayTargetMetadataConfigurationToTerraform(struct?: BedrockagentcoreGatewayTargetMetadataConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetMetadataConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayTargetMetadataConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetMetadataConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetMetadataConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetMetadataConfiguration | cdktn.IResolvable | undefined);
    private _allowedQueryParameters?;
    get allowedQueryParameters(): string[];
    set allowedQueryParameters(value: string[]);
    resetAllowedQueryParameters(): void;
    get allowedQueryParametersInput(): string[] | undefined;
    private _allowedRequestHeaders?;
    get allowedRequestHeaders(): string[];
    set allowedRequestHeaders(value: string[]);
    resetAllowedRequestHeaders(): void;
    get allowedRequestHeadersInput(): string[] | undefined;
    private _allowedResponseHeaders?;
    get allowedResponseHeaders(): string[];
    set allowedResponseHeaders(value: string[]);
    resetAllowedResponseHeaders(): void;
    get allowedResponseHeadersInput(): string[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetMetadataConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetMetadataConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetMetadataConfigurationOutputReference;
}
export interface BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#endpoint_ip_address_type BedrockagentcoreGatewayTarget#endpoint_ip_address_type}
    */
    readonly endpointIpAddressType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#routing_domain BedrockagentcoreGatewayTarget#routing_domain}
    */
    readonly routingDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#security_group_ids BedrockagentcoreGatewayTarget#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#subnet_ids BedrockagentcoreGatewayTarget#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#tags BedrockagentcoreGatewayTarget#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#vpc_identifier BedrockagentcoreGatewayTarget#vpc_identifier}
    */
    readonly vpcIdentifier: string;
}
export declare function bedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResourceToTerraform(struct?: BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResourceToHclTerraform(struct?: BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource | cdktn.IResolvable | undefined);
    private _endpointIpAddressType?;
    get endpointIpAddressType(): string;
    set endpointIpAddressType(value: string);
    get endpointIpAddressTypeInput(): string | undefined;
    private _routingDomain?;
    get routingDomain(): string;
    set routingDomain(value: string);
    resetRoutingDomain(): void;
    get routingDomainInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    get vpcIdentifierInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResourceOutputReference;
}
export interface BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#resource_configuration_identifier BedrockagentcoreGatewayTarget#resource_configuration_identifier}
    */
    readonly resourceConfigurationIdentifier?: string;
}
export declare function bedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResourceToTerraform(struct?: BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResourceToHclTerraform(struct?: BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource | cdktn.IResolvable | undefined);
    private _resourceConfigurationIdentifier?;
    get resourceConfigurationIdentifier(): string;
    set resourceConfigurationIdentifier(value: string);
    resetResourceConfigurationIdentifier(): void;
    get resourceConfigurationIdentifierInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResourceOutputReference;
}
export interface BedrockagentcoreGatewayTargetPrivateEndpoint {
    /**
    * managed_vpc_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#managed_vpc_resource BedrockagentcoreGatewayTarget#managed_vpc_resource}
    */
    readonly managedVpcResource?: BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource[] | cdktn.IResolvable;
    /**
    * self_managed_lattice_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#self_managed_lattice_resource BedrockagentcoreGatewayTarget#self_managed_lattice_resource}
    */
    readonly selfManagedLatticeResource?: BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetPrivateEndpointToTerraform(struct?: BedrockagentcoreGatewayTargetPrivateEndpoint | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetPrivateEndpointToHclTerraform(struct?: BedrockagentcoreGatewayTargetPrivateEndpoint | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetPrivateEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetPrivateEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetPrivateEndpoint | cdktn.IResolvable | undefined);
    private _managedVpcResource;
    get managedVpcResource(): BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResourceList;
    putManagedVpcResource(value: BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource[] | cdktn.IResolvable): void;
    resetManagedVpcResource(): void;
    get managedVpcResourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetPrivateEndpointManagedVpcResource[] | undefined;
    private _selfManagedLatticeResource;
    get selfManagedLatticeResource(): BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResourceList;
    putSelfManagedLatticeResource(value: BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource[] | cdktn.IResolvable): void;
    resetSelfManagedLatticeResource(): void;
    get selfManagedLatticeResourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetPrivateEndpointSelfManagedLatticeResource[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetPrivateEndpointList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetPrivateEndpoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetPrivateEndpointOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#payload BedrockagentcoreGatewayTarget#payload}
    */
    readonly payload: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayloadToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayloadToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayloadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    get payloadInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayloadList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayloadOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id BedrockagentcoreGatewayTarget#bucket_owner_account_id}
    */
    readonly bucketOwnerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#uri BedrockagentcoreGatewayTarget#uri}
    */
    readonly uri?: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3ToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3ToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3 | cdktn.IResolvable | undefined);
    private _bucketOwnerAccountId?;
    get bucketOwnerAccountId(): string;
    set bucketOwnerAccountId(value: string);
    resetBucketOwnerAccountId(): void;
    get bucketOwnerAccountIdInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3OutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource {
    /**
    * inline_payload block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#inline_payload BedrockagentcoreGatewayTarget#inline_payload}
    */
    readonly inlinePayload?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#s3 BedrockagentcoreGatewayTarget#s3}
    */
    readonly s3?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource | cdktn.IResolvable | undefined);
    private _inlinePayload;
    get inlinePayload(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayloadList;
    putInlinePayload(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload[] | cdktn.IResolvable): void;
    resetInlinePayload(): void;
    get inlinePayloadInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceInlinePayload[] | undefined;
    private _s3;
    get s3(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3List;
    putS3(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceS3[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema {
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#source BedrockagentcoreGatewayTarget#source}
    */
    readonly source?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema | cdktn.IResolvable | undefined);
    private _source;
    get source(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSourceList;
    putSource(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaSource[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#arn BedrockagentcoreGatewayTarget#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#qualifier BedrockagentcoreGatewayTarget#qualifier}
    */
    readonly qualifier?: string;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#schema BedrockagentcoreGatewayTarget#schema}
    */
    readonly schema?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    resetQualifier(): void;
    get qualifierInput(): string | undefined;
    private _schema;
    get schema(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchemaList;
    putSchema(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema[] | cdktn.IResolvable): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeSchema[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#payload BedrockagentcoreGatewayTarget#payload}
    */
    readonly payload: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayloadToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayloadToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayloadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    get payloadInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayloadList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayloadOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id BedrockagentcoreGatewayTarget#bucket_owner_account_id}
    */
    readonly bucketOwnerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#uri BedrockagentcoreGatewayTarget#uri}
    */
    readonly uri?: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3ToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3ToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3 | cdktn.IResolvable | undefined);
    private _bucketOwnerAccountId?;
    get bucketOwnerAccountId(): string;
    set bucketOwnerAccountId(value: string);
    resetBucketOwnerAccountId(): void;
    get bucketOwnerAccountIdInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3OutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource {
    /**
    * inline_payload block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#inline_payload BedrockagentcoreGatewayTarget#inline_payload}
    */
    readonly inlinePayload?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#s3 BedrockagentcoreGatewayTarget#s3}
    */
    readonly s3?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource | cdktn.IResolvable | undefined);
    private _inlinePayload;
    get inlinePayload(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayloadList;
    putInlinePayload(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload[] | cdktn.IResolvable): void;
    resetInlinePayload(): void;
    get inlinePayloadInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceInlinePayload[] | undefined;
    private _s3;
    get s3(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3List;
    putS3(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceS3[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema {
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#source BedrockagentcoreGatewayTarget#source}
    */
    readonly source?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema | cdktn.IResolvable | undefined);
    private _source;
    get source(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSourceList;
    putSource(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaSource[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#composite_identifier BedrockagentcoreGatewayTarget#composite_identifier}
    */
    readonly compositeIdentifier?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#identifier BedrockagentcoreGatewayTarget#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#timeout BedrockagentcoreGatewayTarget#timeout}
    */
    readonly timeout?: number;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfigurationToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration | cdktn.IResolvable | undefined);
    private _compositeIdentifier?;
    get compositeIdentifier(): string[];
    set compositeIdentifier(value: string[]);
    resetCompositeIdentifier(): void;
    get compositeIdentifierInput(): string[] | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfigurationOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#endpoint BedrockagentcoreGatewayTarget#endpoint}
    */
    readonly endpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#protocol_type BedrockagentcoreGatewayTarget#protocol_type}
    */
    readonly protocolType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#static_query_parameter_conflict_resolution BedrockagentcoreGatewayTarget#static_query_parameter_conflict_resolution}
    */
    readonly staticQueryParameterConflictResolution?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#static_query_parameters BedrockagentcoreGatewayTarget#static_query_parameters}
    */
    readonly staticQueryParameters?: {
        [key: string]: string;
    };
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#schema BedrockagentcoreGatewayTarget#schema}
    */
    readonly schema?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema[] | cdktn.IResolvable;
    /**
    * stickiness_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#stickiness_configuration BedrockagentcoreGatewayTarget#stickiness_configuration}
    */
    readonly stickinessConfiguration?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _protocolType?;
    get protocolType(): string;
    set protocolType(value: string);
    get protocolTypeInput(): string | undefined;
    private _staticQueryParameterConflictResolution?;
    get staticQueryParameterConflictResolution(): string;
    set staticQueryParameterConflictResolution(value: string);
    resetStaticQueryParameterConflictResolution(): void;
    get staticQueryParameterConflictResolutionInput(): string | undefined;
    private _staticQueryParameters?;
    get staticQueryParameters(): {
        [key: string]: string;
    };
    set staticQueryParameters(value: {
        [key: string]: string;
    });
    resetStaticQueryParameters(): void;
    get staticQueryParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _schema;
    get schema(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchemaList;
    putSchema(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema[] | cdktn.IResolvable): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughSchema[] | undefined;
    private _stickinessConfiguration;
    get stickinessConfiguration(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfigurationList;
    putStickinessConfiguration(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration[] | cdktn.IResolvable): void;
    resetStickinessConfiguration(): void;
    get stickinessConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughStickinessConfiguration[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationHttp {
    /**
    * agentcore_runtime block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#agentcore_runtime BedrockagentcoreGatewayTarget#agentcore_runtime}
    */
    readonly agentcoreRuntime?: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime[] | cdktn.IResolvable;
    /**
    * passthrough block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#passthrough BedrockagentcoreGatewayTarget#passthrough}
    */
    readonly passthrough?: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttp | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationHttpToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationHttp | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationHttp | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationHttp | cdktn.IResolvable | undefined);
    private _agentcoreRuntime;
    get agentcoreRuntime(): BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntimeList;
    putAgentcoreRuntime(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime[] | cdktn.IResolvable): void;
    resetAgentcoreRuntime(): void;
    get agentcoreRuntimeInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpAgentcoreRuntime[] | undefined;
    private _passthrough;
    get passthrough(): BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthroughList;
    putPassthrough(value: BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough[] | cdktn.IResolvable): void;
    resetPassthrough(): void;
    get passthroughInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttpPassthrough[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationHttpList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationHttp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationHttpOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#connector_id BedrockagentcoreGatewayTarget#connector_id}
    */
    readonly connectorId: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSourceToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSourceToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource | cdktn.IResolvable | undefined);
    private _connectorId?;
    get connectorId(): string;
    set connectorId(value: string);
    get connectorIdInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSourceOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector {
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#source BedrockagentcoreGatewayTarget#source}
    */
    readonly source?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector | cdktn.IResolvable | undefined);
    private _source;
    get source(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSourceList;
    putSource(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorSource[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#separator BedrockagentcoreGatewayTarget#separator}
    */
    readonly separator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#strip BedrockagentcoreGatewayTarget#strip}
    */
    readonly strip?: boolean | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefixToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefixToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefixOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix | cdktn.IResolvable | undefined);
    private _separator?;
    get separator(): string;
    set separator(value: string);
    resetSeparator(): void;
    get separatorInput(): string | undefined;
    private _strip?;
    get strip(): boolean | cdktn.IResolvable;
    set strip(value: boolean | cdktn.IResolvable);
    resetStrip(): void;
    get stripInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefixList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefixOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping {
    /**
    * provider_prefix block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#provider_prefix BedrockagentcoreGatewayTarget#provider_prefix}
    */
    readonly providerPrefix?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping | cdktn.IResolvable | undefined);
    private _providerPrefix;
    get providerPrefix(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefixList;
    putProviderPrefix(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix[] | cdktn.IResolvable): void;
    resetProviderPrefix(): void;
    get providerPrefixInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingProviderPrefix[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#model BedrockagentcoreGatewayTarget#model}
    */
    readonly model: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModelToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModelToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModelList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModelOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#path BedrockagentcoreGatewayTarget#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#provider_path BedrockagentcoreGatewayTarget#provider_path}
    */
    readonly providerPath?: string;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#model BedrockagentcoreGatewayTarget#model}
    */
    readonly model?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _providerPath?;
    get providerPath(): string;
    set providerPath(value: string);
    resetProviderPath(): void;
    get providerPathInput(): string | undefined;
    private _model;
    get model(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModelList;
    putModel(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationModel[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#endpoint BedrockagentcoreGatewayTarget#endpoint}
    */
    readonly endpoint: string;
    /**
    * model_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#model_mapping BedrockagentcoreGatewayTarget#model_mapping}
    */
    readonly modelMapping?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping[] | cdktn.IResolvable;
    /**
    * operation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#operation BedrockagentcoreGatewayTarget#operation}
    */
    readonly operation?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _modelMapping;
    get modelMapping(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMappingList;
    putModelMapping(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping[] | cdktn.IResolvable): void;
    resetModelMapping(): void;
    get modelMappingInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderModelMapping[] | undefined;
    private _operation;
    get operation(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperationList;
    putOperation(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation[] | cdktn.IResolvable): void;
    resetOperation(): void;
    get operationInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOperation[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationInference {
    /**
    * connector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#connector BedrockagentcoreGatewayTarget#connector}
    */
    readonly connector?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector[] | cdktn.IResolvable;
    /**
    * provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#provider BedrockagentcoreGatewayTarget#provider}
    */
    readonly provider?: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInference | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationInferenceToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationInference | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationInference | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationInference | cdktn.IResolvable | undefined);
    private _connector;
    get connector(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnectorList;
    putConnector(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector[] | cdktn.IResolvable): void;
    resetConnector(): void;
    get connectorInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInferenceConnector[] | undefined;
    private _provider;
    get provider(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceProviderList;
    putProvider(value: BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider[] | cdktn.IResolvable): void;
    resetProvider(): void;
    get providerInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInferenceProvider[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationInferenceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationInference[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationInferenceOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#filter_path BedrockagentcoreGatewayTarget#filter_path}
    */
    readonly filterPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#methods BedrockagentcoreGatewayTarget#methods}
    */
    readonly methods: string[];
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilterToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilterToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter | cdktn.IResolvable | undefined);
    private _filterPath?;
    get filterPath(): string;
    set filterPath(value: string);
    get filterPathInput(): string | undefined;
    private _methods?;
    get methods(): string[];
    set methods(value: string[]);
    get methodsInput(): string[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilterList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilterOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#method BedrockagentcoreGatewayTarget#method}
    */
    readonly method: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#path BedrockagentcoreGatewayTarget#path}
    */
    readonly path: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverrideToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverrideToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    get methodInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverrideList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverrideOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration {
    /**
    * tool_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#tool_filter BedrockagentcoreGatewayTarget#tool_filter}
    */
    readonly toolFilter?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter[] | cdktn.IResolvable;
    /**
    * tool_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#tool_override BedrockagentcoreGatewayTarget#tool_override}
    */
    readonly toolOverride?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration | cdktn.IResolvable | undefined);
    private _toolFilter;
    get toolFilter(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilterList;
    putToolFilter(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter[] | cdktn.IResolvable): void;
    resetToolFilter(): void;
    get toolFilterInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolFilter[] | undefined;
    private _toolOverride;
    get toolOverride(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverrideList;
    putToolOverride(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride[] | cdktn.IResolvable): void;
    resetToolOverride(): void;
    get toolOverrideInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationToolOverride[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#rest_api_id BedrockagentcoreGatewayTarget#rest_api_id}
    */
    readonly restApiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#stage BedrockagentcoreGatewayTarget#stage}
    */
    readonly stage: string;
    /**
    * api_gateway_tool_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#api_gateway_tool_configuration BedrockagentcoreGatewayTarget#api_gateway_tool_configuration}
    */
    readonly apiGatewayToolConfiguration?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway | cdktn.IResolvable | undefined);
    private _restApiId?;
    get restApiId(): string;
    set restApiId(value: string);
    get restApiIdInput(): string | undefined;
    private _stage?;
    get stage(): string;
    set stage(value: string);
    get stageInput(): string | undefined;
    private _apiGatewayToolConfiguration;
    get apiGatewayToolConfiguration(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfigurationList;
    putApiGatewayToolConfiguration(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration[] | cdktn.IResolvable): void;
    resetApiGatewayToolConfiguration(): void;
    get apiGatewayToolConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayApiGatewayToolConfiguration[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#path BedrockagentcoreGatewayTarget#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#visible BedrockagentcoreGatewayTarget#visible}
    */
    readonly visible?: boolean | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverrideToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverrideToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _visible?;
    get visible(): boolean | cdktn.IResolvable;
    set visible(value: boolean | cdktn.IResolvable);
    resetVisible(): void;
    get visibleInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverrideList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverrideOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#parameter_values BedrockagentcoreGatewayTarget#parameter_values}
    */
    readonly parameterValues?: string;
    /**
    * parameter_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#parameter_override BedrockagentcoreGatewayTarget#parameter_override}
    */
    readonly parameterOverride?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameterValues?;
    get parameterValues(): string;
    set parameterValues(value: string);
    resetParameterValues(): void;
    get parameterValuesInput(): string | undefined;
    private _parameterOverride;
    get parameterOverride(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverrideList;
    putParameterOverride(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride[] | cdktn.IResolvable): void;
    resetParameterOverride(): void;
    get parameterOverrideInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationParameterOverride[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#connector_id BedrockagentcoreGatewayTarget#connector_id}
    */
    readonly connectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#version BedrockagentcoreGatewayTarget#version}
    */
    readonly version?: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSourceToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSourceToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource | cdktn.IResolvable | undefined);
    private _connectorId?;
    get connectorId(): string;
    set connectorId(value: string);
    get connectorIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSourceOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#enabled BedrockagentcoreGatewayTarget#enabled}
    */
    readonly enabled?: string[];
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#configuration BedrockagentcoreGatewayTarget#configuration}
    */
    readonly configuration?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#source BedrockagentcoreGatewayTarget#source}
    */
    readonly source?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): string[];
    set enabled(value: string[]);
    resetEnabled(): void;
    get enabledInput(): string[] | undefined;
    private _configuration;
    get configuration(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfigurationList;
    putConfiguration(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorConfiguration[] | undefined;
    private _source;
    get source(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSourceList;
    putSource(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorSource[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items_json BedrockagentcoreGatewayTarget#items_json}
    */
    readonly itemsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#properties_json BedrockagentcoreGatewayTarget#properties_json}
    */
    readonly propertiesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _itemsJson?;
    get itemsJson(): string;
    set itemsJson(value: string);
    resetItemsJson(): void;
    get itemsJsonInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _propertiesJson?;
    get propertiesJson(): string;
    set propertiesJson(value: string);
    resetPropertiesJson(): void;
    get propertiesJsonInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#required BedrockagentcoreGatewayTarget#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#type BedrockagentcoreGatewayTarget#type}
    */
    readonly type: string;
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#items BedrockagentcoreGatewayTarget#items}
    */
    readonly items?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems[] | cdktn.IResolvable;
    /**
    * property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#property BedrockagentcoreGatewayTarget#property}
    */
    readonly property?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _items;
    get items(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsList;
    putItems(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItems[] | undefined;
    private _property;
    get property(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyList;
    putProperty(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty[] | cdktn.IResolvable): void;
    resetProperty(): void;
    get propertyInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaProperty[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#description BedrockagentcoreGatewayTarget#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#name BedrockagentcoreGatewayTarget#name}
    */
    readonly name: string;
    /**
    * input_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#input_schema BedrockagentcoreGatewayTarget#input_schema}
    */
    readonly inputSchema?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema[] | cdktn.IResolvable;
    /**
    * output_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#output_schema BedrockagentcoreGatewayTarget#output_schema}
    */
    readonly outputSchema?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _inputSchema;
    get inputSchema(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaList;
    putInputSchema(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema[] | cdktn.IResolvable): void;
    resetInputSchema(): void;
    get inputSchemaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchema[] | undefined;
    private _outputSchema;
    get outputSchema(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaList;
    putOutputSchema(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema[] | cdktn.IResolvable): void;
    resetOutputSchema(): void;
    get outputSchemaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchema[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id BedrockagentcoreGatewayTarget#bucket_owner_account_id}
    */
    readonly bucketOwnerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#uri BedrockagentcoreGatewayTarget#uri}
    */
    readonly uri?: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3ToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3ToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3 | cdktn.IResolvable | undefined);
    private _bucketOwnerAccountId?;
    get bucketOwnerAccountId(): string;
    set bucketOwnerAccountId(value: string);
    resetBucketOwnerAccountId(): void;
    get bucketOwnerAccountIdInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3OutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema {
    /**
    * inline_payload block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#inline_payload BedrockagentcoreGatewayTarget#inline_payload}
    */
    readonly inlinePayload?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#s3 BedrockagentcoreGatewayTarget#s3}
    */
    readonly s3?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema | cdktn.IResolvable | undefined);
    private _inlinePayload;
    get inlinePayload(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadList;
    putInlinePayload(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload[] | cdktn.IResolvable): void;
    resetInlinePayload(): void;
    get inlinePayloadInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayload[] | undefined;
    private _s3;
    get s3(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3List;
    putS3(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#lambda_arn BedrockagentcoreGatewayTarget#lambda_arn}
    */
    readonly lambdaArn: string;
    /**
    * tool_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#tool_schema BedrockagentcoreGatewayTarget#tool_schema}
    */
    readonly toolSchema?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    get lambdaArnInput(): string | undefined;
    private _toolSchema;
    get toolSchema(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchemaList;
    putToolSchema(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema[] | cdktn.IResolvable): void;
    resetToolSchema(): void;
    get toolSchemaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaToolSchema[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#payload BedrockagentcoreGatewayTarget#payload}
    */
    readonly payload: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    get payloadInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id BedrockagentcoreGatewayTarget#bucket_owner_account_id}
    */
    readonly bucketOwnerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#uri BedrockagentcoreGatewayTarget#uri}
    */
    readonly uri: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3ToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3ToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3 | cdktn.IResolvable | undefined);
    private _bucketOwnerAccountId?;
    get bucketOwnerAccountId(): string;
    set bucketOwnerAccountId(value: string);
    resetBucketOwnerAccountId(): void;
    get bucketOwnerAccountIdInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3OutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema {
    /**
    * inline_payload block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#inline_payload BedrockagentcoreGatewayTarget#inline_payload}
    */
    readonly inlinePayload?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#s3 BedrockagentcoreGatewayTarget#s3}
    */
    readonly s3?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema | cdktn.IResolvable | undefined);
    private _inlinePayload;
    get inlinePayload(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadList;
    putInlinePayload(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload[] | cdktn.IResolvable): void;
    resetInlinePayload(): void;
    get inlinePayloadInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayload[] | undefined;
    private _s3;
    get s3(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3List;
    putS3(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#endpoint BedrockagentcoreGatewayTarget#endpoint}
    */
    readonly endpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#listing_mode BedrockagentcoreGatewayTarget#listing_mode}
    */
    readonly listingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#resource_priority BedrockagentcoreGatewayTarget#resource_priority}
    */
    readonly resourcePriority?: number;
    /**
    * mcp_tool_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#mcp_tool_schema BedrockagentcoreGatewayTarget#mcp_tool_schema}
    */
    readonly mcpToolSchema?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _listingMode?;
    get listingMode(): string;
    set listingMode(value: string);
    resetListingMode(): void;
    get listingModeInput(): string | undefined;
    private _resourcePriority?;
    get resourcePriority(): number;
    set resourcePriority(value: number);
    resetResourcePriority(): void;
    get resourcePriorityInput(): number | undefined;
    private _mcpToolSchema;
    get mcpToolSchema(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaList;
    putMcpToolSchema(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema[] | cdktn.IResolvable): void;
    resetMcpToolSchema(): void;
    get mcpToolSchemaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchema[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#payload BedrockagentcoreGatewayTarget#payload}
    */
    readonly payload: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    get payloadInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id BedrockagentcoreGatewayTarget#bucket_owner_account_id}
    */
    readonly bucketOwnerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#uri BedrockagentcoreGatewayTarget#uri}
    */
    readonly uri?: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3ToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3ToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3 | cdktn.IResolvable | undefined);
    private _bucketOwnerAccountId?;
    get bucketOwnerAccountId(): string;
    set bucketOwnerAccountId(value: string);
    resetBucketOwnerAccountId(): void;
    get bucketOwnerAccountIdInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3OutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema {
    /**
    * inline_payload block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#inline_payload BedrockagentcoreGatewayTarget#inline_payload}
    */
    readonly inlinePayload?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#s3 BedrockagentcoreGatewayTarget#s3}
    */
    readonly s3?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema | cdktn.IResolvable | undefined);
    private _inlinePayload;
    get inlinePayload(): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadList;
    putInlinePayload(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload[] | cdktn.IResolvable): void;
    resetInlinePayload(): void;
    get inlinePayloadInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayload[] | undefined;
    private _s3;
    get s3(): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3List;
    putS3(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaS3[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#payload BedrockagentcoreGatewayTarget#payload}
    */
    readonly payload: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload | cdktn.IResolvable | undefined);
    private _payload?;
    get payload(): string;
    set payload(value: string);
    get payloadInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id BedrockagentcoreGatewayTarget#bucket_owner_account_id}
    */
    readonly bucketOwnerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#uri BedrockagentcoreGatewayTarget#uri}
    */
    readonly uri?: string;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3ToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3ToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3 | cdktn.IResolvable | undefined);
    private _bucketOwnerAccountId?;
    get bucketOwnerAccountId(): string;
    set bucketOwnerAccountId(value: string);
    resetBucketOwnerAccountId(): void;
    get bucketOwnerAccountIdInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    resetUri(): void;
    get uriInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3OutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel {
    /**
    * inline_payload block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#inline_payload BedrockagentcoreGatewayTarget#inline_payload}
    */
    readonly inlinePayload?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#s3 BedrockagentcoreGatewayTarget#s3}
    */
    readonly s3?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel | cdktn.IResolvable | undefined);
    private _inlinePayload;
    get inlinePayload(): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadList;
    putInlinePayload(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload[] | cdktn.IResolvable): void;
    resetInlinePayload(): void;
    get inlinePayloadInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelInlinePayload[] | undefined;
    private _s3;
    get s3(): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3List;
    putS3(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelS3[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfigurationMcp {
    /**
    * api_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#api_gateway BedrockagentcoreGatewayTarget#api_gateway}
    */
    readonly apiGateway?: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway[] | cdktn.IResolvable;
    /**
    * connector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#connector BedrockagentcoreGatewayTarget#connector}
    */
    readonly connector?: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector[] | cdktn.IResolvable;
    /**
    * lambda block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#lambda BedrockagentcoreGatewayTarget#lambda}
    */
    readonly lambda?: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda[] | cdktn.IResolvable;
    /**
    * mcp_server block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#mcp_server BedrockagentcoreGatewayTarget#mcp_server}
    */
    readonly mcpServer?: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer[] | cdktn.IResolvable;
    /**
    * open_api_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#open_api_schema BedrockagentcoreGatewayTarget#open_api_schema}
    */
    readonly openApiSchema?: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema[] | cdktn.IResolvable;
    /**
    * smithy_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#smithy_model BedrockagentcoreGatewayTarget#smithy_model}
    */
    readonly smithyModel?: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcp | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationMcpToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfigurationMcp | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfigurationMcp | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfigurationMcp | cdktn.IResolvable | undefined);
    private _apiGateway;
    get apiGateway(): BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGatewayList;
    putApiGateway(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway[] | cdktn.IResolvable): void;
    resetApiGateway(): void;
    get apiGatewayInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpApiGateway[] | undefined;
    private _connector;
    get connector(): BedrockagentcoreGatewayTargetTargetConfigurationMcpConnectorList;
    putConnector(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector[] | cdktn.IResolvable): void;
    resetConnector(): void;
    get connectorInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpConnector[] | undefined;
    private _lambda;
    get lambda(): BedrockagentcoreGatewayTargetTargetConfigurationMcpLambdaList;
    putLambda(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda[] | cdktn.IResolvable): void;
    resetLambda(): void;
    get lambdaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpLambda[] | undefined;
    private _mcpServer;
    get mcpServer(): BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServerList;
    putMcpServer(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer[] | cdktn.IResolvable): void;
    resetMcpServer(): void;
    get mcpServerInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpMcpServer[] | undefined;
    private _openApiSchema;
    get openApiSchema(): BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchemaList;
    putOpenApiSchema(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema[] | cdktn.IResolvable): void;
    resetOpenApiSchema(): void;
    get openApiSchemaInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpOpenApiSchema[] | undefined;
    private _smithyModel;
    get smithyModel(): BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModelList;
    putSmithyModel(value: BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel[] | cdktn.IResolvable): void;
    resetSmithyModel(): void;
    get smithyModelInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcpSmithyModel[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationMcpList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfigurationMcp[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationMcpOutputReference;
}
export interface BedrockagentcoreGatewayTargetTargetConfiguration {
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#http BedrockagentcoreGatewayTarget#http}
    */
    readonly http?: BedrockagentcoreGatewayTargetTargetConfigurationHttp[] | cdktn.IResolvable;
    /**
    * inference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#inference BedrockagentcoreGatewayTarget#inference}
    */
    readonly inference?: BedrockagentcoreGatewayTargetTargetConfigurationInference[] | cdktn.IResolvable;
    /**
    * mcp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#mcp BedrockagentcoreGatewayTarget#mcp}
    */
    readonly mcp?: BedrockagentcoreGatewayTargetTargetConfigurationMcp[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayTargetTargetConfigurationToTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTargetConfigurationToHclTerraform(struct?: BedrockagentcoreGatewayTargetTargetConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTargetConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayTargetTargetConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTargetConfiguration | cdktn.IResolvable | undefined);
    private _http;
    get http(): BedrockagentcoreGatewayTargetTargetConfigurationHttpList;
    putHttp(value: BedrockagentcoreGatewayTargetTargetConfigurationHttp[] | cdktn.IResolvable): void;
    resetHttp(): void;
    get httpInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationHttp[] | undefined;
    private _inference;
    get inference(): BedrockagentcoreGatewayTargetTargetConfigurationInferenceList;
    putInference(value: BedrockagentcoreGatewayTargetTargetConfigurationInference[] | cdktn.IResolvable): void;
    resetInference(): void;
    get inferenceInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationInference[] | undefined;
    private _mcp;
    get mcp(): BedrockagentcoreGatewayTargetTargetConfigurationMcpList;
    putMcp(value: BedrockagentcoreGatewayTargetTargetConfigurationMcp[] | cdktn.IResolvable): void;
    resetMcp(): void;
    get mcpInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfigurationMcp[] | undefined;
}
export declare class BedrockagentcoreGatewayTargetTargetConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayTargetTargetConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayTargetTargetConfigurationOutputReference;
}
export interface BedrockagentcoreGatewayTargetTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#create BedrockagentcoreGatewayTarget#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#delete BedrockagentcoreGatewayTarget#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#update BedrockagentcoreGatewayTarget#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcoreGatewayTargetTimeoutsToTerraform(struct?: BedrockagentcoreGatewayTargetTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayTargetTimeoutsToHclTerraform(struct?: BedrockagentcoreGatewayTargetTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayTargetTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayTargetTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayTargetTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target aws_bedrockagentcore_gateway_target}
*/
export declare class BedrockagentcoreGatewayTarget extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_gateway_target";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreGatewayTarget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreGatewayTarget to import
    * @param importFromId The id of the existing BedrockagentcoreGatewayTarget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreGatewayTarget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagentcore_gateway_target aws_bedrockagentcore_gateway_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreGatewayTargetConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreGatewayTargetConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _gatewayIdentifier?;
    get gatewayIdentifier(): string;
    set gatewayIdentifier(value: string);
    get gatewayIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get targetId(): string;
    private _credentialProviderConfiguration;
    get credentialProviderConfiguration(): BedrockagentcoreGatewayTargetCredentialProviderConfigurationList;
    putCredentialProviderConfiguration(value: BedrockagentcoreGatewayTargetCredentialProviderConfiguration[] | cdktn.IResolvable): void;
    resetCredentialProviderConfiguration(): void;
    get credentialProviderConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetCredentialProviderConfiguration[] | undefined;
    private _metadataConfiguration;
    get metadataConfiguration(): BedrockagentcoreGatewayTargetMetadataConfigurationList;
    putMetadataConfiguration(value: BedrockagentcoreGatewayTargetMetadataConfiguration[] | cdktn.IResolvable): void;
    resetMetadataConfiguration(): void;
    get metadataConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetMetadataConfiguration[] | undefined;
    private _privateEndpoint;
    get privateEndpoint(): BedrockagentcoreGatewayTargetPrivateEndpointList;
    putPrivateEndpoint(value: BedrockagentcoreGatewayTargetPrivateEndpoint[] | cdktn.IResolvable): void;
    resetPrivateEndpoint(): void;
    get privateEndpointInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetPrivateEndpoint[] | undefined;
    private _targetConfiguration;
    get targetConfiguration(): BedrockagentcoreGatewayTargetTargetConfigurationList;
    putTargetConfiguration(value: BedrockagentcoreGatewayTargetTargetConfiguration[] | cdktn.IResolvable): void;
    resetTargetConfiguration(): void;
    get targetConfigurationInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTargetConfiguration[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreGatewayTargetTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreGatewayTargetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreGatewayTargetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
