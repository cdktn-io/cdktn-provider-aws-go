/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupSelectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#iam_role_arn BackupSelection#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#id BackupSelection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#name BackupSelection#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#not_resources BackupSelection#not_resources}
    */
    readonly notResources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#plan_id BackupSelection#plan_id}
    */
    readonly planId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#region BackupSelection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#resources BackupSelection#resources}
    */
    readonly resources?: string[];
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#condition BackupSelection#condition}
    */
    readonly condition?: BackupSelectionCondition[] | cdktn.IResolvable;
    /**
    * selection_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#selection_tag BackupSelection#selection_tag}
    */
    readonly selectionTag?: BackupSelectionSelectionTag[] | cdktn.IResolvable;
}
export interface BackupSelectionConditionStringEquals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#key BackupSelection#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#value BackupSelection#value}
    */
    readonly value: string;
}
export declare function backupSelectionConditionStringEqualsToTerraform(struct?: BackupSelectionConditionStringEquals | cdktn.IResolvable): any;
export declare function backupSelectionConditionStringEqualsToHclTerraform(struct?: BackupSelectionConditionStringEquals | cdktn.IResolvable): any;
export declare class BackupSelectionConditionStringEqualsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupSelectionConditionStringEquals | cdktn.IResolvable | undefined;
    set internalValue(value: BackupSelectionConditionStringEquals | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class BackupSelectionConditionStringEqualsList extends cdktn.ComplexList {
    internalValue?: BackupSelectionConditionStringEquals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupSelectionConditionStringEqualsOutputReference;
}
export interface BackupSelectionConditionStringLike {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#key BackupSelection#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#value BackupSelection#value}
    */
    readonly value: string;
}
export declare function backupSelectionConditionStringLikeToTerraform(struct?: BackupSelectionConditionStringLike | cdktn.IResolvable): any;
export declare function backupSelectionConditionStringLikeToHclTerraform(struct?: BackupSelectionConditionStringLike | cdktn.IResolvable): any;
export declare class BackupSelectionConditionStringLikeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupSelectionConditionStringLike | cdktn.IResolvable | undefined;
    set internalValue(value: BackupSelectionConditionStringLike | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class BackupSelectionConditionStringLikeList extends cdktn.ComplexList {
    internalValue?: BackupSelectionConditionStringLike[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupSelectionConditionStringLikeOutputReference;
}
export interface BackupSelectionConditionStringNotEquals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#key BackupSelection#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#value BackupSelection#value}
    */
    readonly value: string;
}
export declare function backupSelectionConditionStringNotEqualsToTerraform(struct?: BackupSelectionConditionStringNotEquals | cdktn.IResolvable): any;
export declare function backupSelectionConditionStringNotEqualsToHclTerraform(struct?: BackupSelectionConditionStringNotEquals | cdktn.IResolvable): any;
export declare class BackupSelectionConditionStringNotEqualsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupSelectionConditionStringNotEquals | cdktn.IResolvable | undefined;
    set internalValue(value: BackupSelectionConditionStringNotEquals | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class BackupSelectionConditionStringNotEqualsList extends cdktn.ComplexList {
    internalValue?: BackupSelectionConditionStringNotEquals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupSelectionConditionStringNotEqualsOutputReference;
}
export interface BackupSelectionConditionStringNotLike {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#key BackupSelection#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#value BackupSelection#value}
    */
    readonly value: string;
}
export declare function backupSelectionConditionStringNotLikeToTerraform(struct?: BackupSelectionConditionStringNotLike | cdktn.IResolvable): any;
export declare function backupSelectionConditionStringNotLikeToHclTerraform(struct?: BackupSelectionConditionStringNotLike | cdktn.IResolvable): any;
export declare class BackupSelectionConditionStringNotLikeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupSelectionConditionStringNotLike | cdktn.IResolvable | undefined;
    set internalValue(value: BackupSelectionConditionStringNotLike | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class BackupSelectionConditionStringNotLikeList extends cdktn.ComplexList {
    internalValue?: BackupSelectionConditionStringNotLike[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupSelectionConditionStringNotLikeOutputReference;
}
export interface BackupSelectionCondition {
    /**
    * string_equals block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#string_equals BackupSelection#string_equals}
    */
    readonly stringEquals?: BackupSelectionConditionStringEquals[] | cdktn.IResolvable;
    /**
    * string_like block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#string_like BackupSelection#string_like}
    */
    readonly stringLike?: BackupSelectionConditionStringLike[] | cdktn.IResolvable;
    /**
    * string_not_equals block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#string_not_equals BackupSelection#string_not_equals}
    */
    readonly stringNotEquals?: BackupSelectionConditionStringNotEquals[] | cdktn.IResolvable;
    /**
    * string_not_like block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#string_not_like BackupSelection#string_not_like}
    */
    readonly stringNotLike?: BackupSelectionConditionStringNotLike[] | cdktn.IResolvable;
}
export declare function backupSelectionConditionToTerraform(struct?: BackupSelectionCondition | cdktn.IResolvable): any;
export declare function backupSelectionConditionToHclTerraform(struct?: BackupSelectionCondition | cdktn.IResolvable): any;
export declare class BackupSelectionConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupSelectionCondition | cdktn.IResolvable | undefined;
    set internalValue(value: BackupSelectionCondition | cdktn.IResolvable | undefined);
    private _stringEquals;
    get stringEquals(): BackupSelectionConditionStringEqualsList;
    putStringEquals(value: BackupSelectionConditionStringEquals[] | cdktn.IResolvable): void;
    resetStringEquals(): void;
    get stringEqualsInput(): cdktn.IResolvable | BackupSelectionConditionStringEquals[] | undefined;
    private _stringLike;
    get stringLike(): BackupSelectionConditionStringLikeList;
    putStringLike(value: BackupSelectionConditionStringLike[] | cdktn.IResolvable): void;
    resetStringLike(): void;
    get stringLikeInput(): cdktn.IResolvable | BackupSelectionConditionStringLike[] | undefined;
    private _stringNotEquals;
    get stringNotEquals(): BackupSelectionConditionStringNotEqualsList;
    putStringNotEquals(value: BackupSelectionConditionStringNotEquals[] | cdktn.IResolvable): void;
    resetStringNotEquals(): void;
    get stringNotEqualsInput(): cdktn.IResolvable | BackupSelectionConditionStringNotEquals[] | undefined;
    private _stringNotLike;
    get stringNotLike(): BackupSelectionConditionStringNotLikeList;
    putStringNotLike(value: BackupSelectionConditionStringNotLike[] | cdktn.IResolvable): void;
    resetStringNotLike(): void;
    get stringNotLikeInput(): cdktn.IResolvable | BackupSelectionConditionStringNotLike[] | undefined;
}
export declare class BackupSelectionConditionList extends cdktn.ComplexList {
    internalValue?: BackupSelectionCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupSelectionConditionOutputReference;
}
export interface BackupSelectionSelectionTag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#key BackupSelection#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#type BackupSelection#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#value BackupSelection#value}
    */
    readonly value: string;
}
export declare function backupSelectionSelectionTagToTerraform(struct?: BackupSelectionSelectionTag | cdktn.IResolvable): any;
export declare function backupSelectionSelectionTagToHclTerraform(struct?: BackupSelectionSelectionTag | cdktn.IResolvable): any;
export declare class BackupSelectionSelectionTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupSelectionSelectionTag | cdktn.IResolvable | undefined;
    set internalValue(value: BackupSelectionSelectionTag | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class BackupSelectionSelectionTagList extends cdktn.ComplexList {
    internalValue?: BackupSelectionSelectionTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupSelectionSelectionTagOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection aws_backup_selection}
*/
export declare class BackupSelection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_selection";
    /**
    * Generates CDKTN code for importing a BackupSelection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupSelection to import
    * @param importFromId The id of the existing BackupSelection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupSelection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/backup_selection aws_backup_selection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupSelectionConfig
    */
    constructor(scope: Construct, id: string, config: BackupSelectionConfig);
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notResources?;
    get notResources(): string[];
    set notResources(value: string[]);
    resetNotResources(): void;
    get notResourcesInput(): string[] | undefined;
    private _planId?;
    get planId(): string;
    set planId(value: string);
    get planIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _condition;
    get condition(): BackupSelectionConditionList;
    putCondition(value: BackupSelectionCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | BackupSelectionCondition[] | undefined;
    private _selectionTag;
    get selectionTag(): BackupSelectionSelectionTagList;
    putSelectionTag(value: BackupSelectionSelectionTag[] | cdktn.IResolvable): void;
    resetSelectionTag(): void;
    get selectionTagInput(): cdktn.IResolvable | BackupSelectionSelectionTag[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
