/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCloudfrontDistributionTenantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudfront_distribution_tenant#arn DataAwsCloudfrontDistributionTenant#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudfront_distribution_tenant#domain DataAwsCloudfrontDistributionTenant#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudfront_distribution_tenant#id DataAwsCloudfrontDistributionTenant#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudfront_distribution_tenant#name DataAwsCloudfrontDistributionTenant#name}
    */
    readonly name?: string;
}
export interface DataAwsCloudfrontDistributionTenantCustomizationsCertificate {
}
export declare function dataAwsCloudfrontDistributionTenantCustomizationsCertificateToTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizationsCertificate): any;
export declare function dataAwsCloudfrontDistributionTenantCustomizationsCertificateToHclTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizationsCertificate): any;
export declare class DataAwsCloudfrontDistributionTenantCustomizationsCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudfrontDistributionTenantCustomizationsCertificate | undefined;
    set internalValue(value: DataAwsCloudfrontDistributionTenantCustomizationsCertificate | undefined);
    get arn(): string;
}
export declare class DataAwsCloudfrontDistributionTenantCustomizationsCertificateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudfrontDistributionTenantCustomizationsCertificateOutputReference;
}
export interface DataAwsCloudfrontDistributionTenantCustomizationsGeoRestriction {
}
export declare function dataAwsCloudfrontDistributionTenantCustomizationsGeoRestrictionToTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizationsGeoRestriction): any;
export declare function dataAwsCloudfrontDistributionTenantCustomizationsGeoRestrictionToHclTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizationsGeoRestriction): any;
export declare class DataAwsCloudfrontDistributionTenantCustomizationsGeoRestrictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudfrontDistributionTenantCustomizationsGeoRestriction | undefined;
    set internalValue(value: DataAwsCloudfrontDistributionTenantCustomizationsGeoRestriction | undefined);
    get locations(): string[];
    get restrictionType(): string;
}
export declare class DataAwsCloudfrontDistributionTenantCustomizationsGeoRestrictionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudfrontDistributionTenantCustomizationsGeoRestrictionOutputReference;
}
export interface DataAwsCloudfrontDistributionTenantCustomizationsWebAcl {
}
export declare function dataAwsCloudfrontDistributionTenantCustomizationsWebAclToTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizationsWebAcl): any;
export declare function dataAwsCloudfrontDistributionTenantCustomizationsWebAclToHclTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizationsWebAcl): any;
export declare class DataAwsCloudfrontDistributionTenantCustomizationsWebAclOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudfrontDistributionTenantCustomizationsWebAcl | undefined;
    set internalValue(value: DataAwsCloudfrontDistributionTenantCustomizationsWebAcl | undefined);
    get action(): string;
    get arn(): string;
}
export declare class DataAwsCloudfrontDistributionTenantCustomizationsWebAclList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudfrontDistributionTenantCustomizationsWebAclOutputReference;
}
export interface DataAwsCloudfrontDistributionTenantCustomizations {
}
export declare function dataAwsCloudfrontDistributionTenantCustomizationsToTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizations): any;
export declare function dataAwsCloudfrontDistributionTenantCustomizationsToHclTerraform(struct?: DataAwsCloudfrontDistributionTenantCustomizations): any;
export declare class DataAwsCloudfrontDistributionTenantCustomizationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudfrontDistributionTenantCustomizations | undefined;
    set internalValue(value: DataAwsCloudfrontDistributionTenantCustomizations | undefined);
    private _certificate;
    get certificate(): DataAwsCloudfrontDistributionTenantCustomizationsCertificateList;
    private _geoRestriction;
    get geoRestriction(): DataAwsCloudfrontDistributionTenantCustomizationsGeoRestrictionList;
    private _webAcl;
    get webAcl(): DataAwsCloudfrontDistributionTenantCustomizationsWebAclList;
}
export declare class DataAwsCloudfrontDistributionTenantCustomizationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudfrontDistributionTenantCustomizationsOutputReference;
}
export interface DataAwsCloudfrontDistributionTenantDomains {
}
export declare function dataAwsCloudfrontDistributionTenantDomainsToTerraform(struct?: DataAwsCloudfrontDistributionTenantDomains): any;
export declare function dataAwsCloudfrontDistributionTenantDomainsToHclTerraform(struct?: DataAwsCloudfrontDistributionTenantDomains): any;
export declare class DataAwsCloudfrontDistributionTenantDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudfrontDistributionTenantDomains | undefined;
    set internalValue(value: DataAwsCloudfrontDistributionTenantDomains | undefined);
    get domain(): string;
    get status(): string;
}
export declare class DataAwsCloudfrontDistributionTenantDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudfrontDistributionTenantDomainsOutputReference;
}
export interface DataAwsCloudfrontDistributionTenantManagedCertificateRequest {
}
export declare function dataAwsCloudfrontDistributionTenantManagedCertificateRequestToTerraform(struct?: DataAwsCloudfrontDistributionTenantManagedCertificateRequest): any;
export declare function dataAwsCloudfrontDistributionTenantManagedCertificateRequestToHclTerraform(struct?: DataAwsCloudfrontDistributionTenantManagedCertificateRequest): any;
export declare class DataAwsCloudfrontDistributionTenantManagedCertificateRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudfrontDistributionTenantManagedCertificateRequest | undefined;
    set internalValue(value: DataAwsCloudfrontDistributionTenantManagedCertificateRequest | undefined);
    get certificateTransparencyLoggingPreference(): string;
    get primaryDomainName(): string;
    get validationTokenHost(): string;
}
export declare class DataAwsCloudfrontDistributionTenantManagedCertificateRequestList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudfrontDistributionTenantManagedCertificateRequestOutputReference;
}
export interface DataAwsCloudfrontDistributionTenantParameters {
}
export declare function dataAwsCloudfrontDistributionTenantParametersToTerraform(struct?: DataAwsCloudfrontDistributionTenantParameters): any;
export declare function dataAwsCloudfrontDistributionTenantParametersToHclTerraform(struct?: DataAwsCloudfrontDistributionTenantParameters): any;
export declare class DataAwsCloudfrontDistributionTenantParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsCloudfrontDistributionTenantParameters | undefined;
    set internalValue(value: DataAwsCloudfrontDistributionTenantParameters | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataAwsCloudfrontDistributionTenantParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsCloudfrontDistributionTenantParametersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant}
*/
export declare class DataAwsCloudfrontDistributionTenant extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_distribution_tenant";
    /**
    * Generates CDKTN code for importing a DataAwsCloudfrontDistributionTenant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCloudfrontDistributionTenant to import
    * @param importFromId The id of the existing DataAwsCloudfrontDistributionTenant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudfront_distribution_tenant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCloudfrontDistributionTenant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCloudfrontDistributionTenantConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsCloudfrontDistributionTenantConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get connectionGroupId(): string;
    private _customizations;
    get customizations(): DataAwsCloudfrontDistributionTenantCustomizationsList;
    get distributionId(): string;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _domains;
    get domains(): DataAwsCloudfrontDistributionTenantDomainsList;
    get enabled(): cdktn.IResolvable;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _managedCertificateRequest;
    get managedCertificateRequest(): DataAwsCloudfrontDistributionTenantManagedCertificateRequestList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): DataAwsCloudfrontDistributionTenantParametersList;
    get status(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
