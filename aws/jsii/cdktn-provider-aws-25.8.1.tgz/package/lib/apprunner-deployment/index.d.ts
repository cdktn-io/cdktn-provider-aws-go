/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApprunnerDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apprunner_deployment#region ApprunnerDeployment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apprunner_deployment#service_arn ApprunnerDeployment#service_arn}
    */
    readonly serviceArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apprunner_deployment#timeouts ApprunnerDeployment#timeouts}
    */
    readonly timeouts?: ApprunnerDeploymentTimeouts;
}
export interface ApprunnerDeploymentTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apprunner_deployment#create ApprunnerDeployment#create}
    */
    readonly create?: string;
}
export declare function apprunnerDeploymentTimeoutsToTerraform(struct?: ApprunnerDeploymentTimeouts | cdktn.IResolvable): any;
export declare function apprunnerDeploymentTimeoutsToHclTerraform(struct?: ApprunnerDeploymentTimeouts | cdktn.IResolvable): any;
export declare class ApprunnerDeploymentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApprunnerDeploymentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApprunnerDeploymentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apprunner_deployment aws_apprunner_deployment}
*/
export declare class ApprunnerDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_deployment";
    /**
    * Generates CDKTN code for importing a ApprunnerDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApprunnerDeployment to import
    * @param importFromId The id of the existing ApprunnerDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apprunner_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApprunnerDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/apprunner_deployment aws_apprunner_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApprunnerDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: ApprunnerDeploymentConfig);
    get id(): string;
    get operationId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
    get status(): string;
    private _timeouts;
    get timeouts(): ApprunnerDeploymentTimeoutsOutputReference;
    putTimeouts(value: ApprunnerDeploymentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApprunnerDeploymentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
