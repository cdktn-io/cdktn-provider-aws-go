/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentFlowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#customer_encryption_key_arn BedrockagentFlow#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#description BedrockagentFlow#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#execution_role_arn BedrockagentFlow#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#region BedrockagentFlow#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#tags BedrockagentFlow#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#definition BedrockagentFlow#definition}
    */
    readonly definition?: BedrockagentFlowDefinition[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#timeouts BedrockagentFlow#timeouts}
    */
    readonly timeouts?: BedrockagentFlowTimeouts;
}
export interface BedrockagentFlowDefinitionConnectionConfigurationConditional {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#condition BedrockagentFlow#condition}
    */
    readonly condition: string;
}
export declare function bedrockagentFlowDefinitionConnectionConfigurationConditionalToTerraform(struct?: BedrockagentFlowDefinitionConnectionConfigurationConditional | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionConnectionConfigurationConditionalToHclTerraform(struct?: BedrockagentFlowDefinitionConnectionConfigurationConditional | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionConnectionConfigurationConditionalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionConnectionConfigurationConditional | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionConnectionConfigurationConditional | cdktn.IResolvable | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionConnectionConfigurationConditionalList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionConnectionConfigurationConditional[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionConnectionConfigurationConditionalOutputReference;
}
export interface BedrockagentFlowDefinitionConnectionConfigurationData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#source_output BedrockagentFlow#source_output}
    */
    readonly sourceOutput: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#target_input BedrockagentFlow#target_input}
    */
    readonly targetInput: string;
}
export declare function bedrockagentFlowDefinitionConnectionConfigurationDataToTerraform(struct?: BedrockagentFlowDefinitionConnectionConfigurationData | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionConnectionConfigurationDataToHclTerraform(struct?: BedrockagentFlowDefinitionConnectionConfigurationData | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionConnectionConfigurationDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionConnectionConfigurationData | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionConnectionConfigurationData | cdktn.IResolvable | undefined);
    private _sourceOutput?;
    get sourceOutput(): string;
    set sourceOutput(value: string);
    get sourceOutputInput(): string | undefined;
    private _targetInput?;
    get targetInput(): string;
    set targetInput(value: string);
    get targetInputInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionConnectionConfigurationDataList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionConnectionConfigurationData[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionConnectionConfigurationDataOutputReference;
}
export interface BedrockagentFlowDefinitionConnectionConfiguration {
    /**
    * conditional block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#conditional BedrockagentFlow#conditional}
    */
    readonly conditional?: BedrockagentFlowDefinitionConnectionConfigurationConditional[] | cdktn.IResolvable;
    /**
    * data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#data BedrockagentFlow#data}
    */
    readonly data?: BedrockagentFlowDefinitionConnectionConfigurationData[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionConnectionConfigurationToTerraform(struct?: BedrockagentFlowDefinitionConnectionConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionConnectionConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionConnectionConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionConnectionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionConnectionConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionConnectionConfiguration | cdktn.IResolvable | undefined);
    private _conditional;
    get conditional(): BedrockagentFlowDefinitionConnectionConfigurationConditionalList;
    putConditional(value: BedrockagentFlowDefinitionConnectionConfigurationConditional[] | cdktn.IResolvable): void;
    resetConditional(): void;
    get conditionalInput(): cdktn.IResolvable | BedrockagentFlowDefinitionConnectionConfigurationConditional[] | undefined;
    private _data;
    get data(): BedrockagentFlowDefinitionConnectionConfigurationDataList;
    putData(value: BedrockagentFlowDefinitionConnectionConfigurationData[] | cdktn.IResolvable): void;
    resetData(): void;
    get dataInput(): cdktn.IResolvable | BedrockagentFlowDefinitionConnectionConfigurationData[] | undefined;
}
export declare class BedrockagentFlowDefinitionConnectionConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionConnectionConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionConnectionConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#source BedrockagentFlow#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#target BedrockagentFlow#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#configuration BedrockagentFlow#configuration}
    */
    readonly configuration?: BedrockagentFlowDefinitionConnectionConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionConnectionToTerraform(struct?: BedrockagentFlowDefinitionConnection | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionConnectionToHclTerraform(struct?: BedrockagentFlowDefinitionConnection | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionConnection | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionConnection | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): BedrockagentFlowDefinitionConnectionConfigurationList;
    putConfiguration(value: BedrockagentFlowDefinitionConnectionConfiguration[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionConnectionConfiguration[] | undefined;
}
export declare class BedrockagentFlowDefinitionConnectionList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionConnection[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionConnectionOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationAgent {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#agent_alias_arn BedrockagentFlow#agent_alias_arn}
    */
    readonly agentAliasArn: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationAgentToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationAgent | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationAgentToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationAgent | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationAgent | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationAgent | cdktn.IResolvable | undefined);
    private _agentAliasArn?;
    get agentAliasArn(): string;
    set agentAliasArn(value: string);
    get agentAliasArnInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationAgentList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationAgent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationAgentOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationCollector {
}
export declare function bedrockagentFlowDefinitionNodeConfigurationCollectorToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationCollector | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationCollectorToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationCollector | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationCollectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationCollector | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationCollector | cdktn.IResolvable | undefined);
}
export declare class BedrockagentFlowDefinitionNodeConfigurationCollectorList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationCollector[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationCollectorOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationConditionCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#expression BedrockagentFlow#expression}
    */
    readonly expression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationConditionConditionToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationConditionCondition | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationConditionConditionToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationConditionCondition | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationConditionConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationConditionCondition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationConditionCondition | cdktn.IResolvable | undefined);
    private _expression?;
    get expression(): string;
    set expression(value: string);
    resetExpression(): void;
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationConditionConditionList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationConditionCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationConditionConditionOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationCondition {
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#condition BedrockagentFlow#condition}
    */
    readonly condition?: BedrockagentFlowDefinitionNodeConfigurationConditionCondition[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationConditionToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationCondition | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationConditionToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationCondition | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationCondition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationCondition | cdktn.IResolvable | undefined);
    private _condition;
    get condition(): BedrockagentFlowDefinitionNodeConfigurationConditionConditionList;
    putCondition(value: BedrockagentFlowDefinitionNodeConfigurationConditionCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationConditionCondition[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationConditionList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationConditionOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationInlineCode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#code BedrockagentFlow#code}
    */
    readonly code: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#language BedrockagentFlow#language}
    */
    readonly language: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationInlineCodeToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationInlineCode | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationInlineCodeToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationInlineCode | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationInlineCodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationInlineCode | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationInlineCode | cdktn.IResolvable | undefined);
    private _code?;
    get code(): string;
    set code(value: string);
    get codeInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    get languageInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationInlineCodeList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationInlineCode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationInlineCodeOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationInput {
}
export declare function bedrockagentFlowDefinitionNodeConfigurationInputToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationInput | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationInputToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationInput | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationInput | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationInput | cdktn.IResolvable | undefined);
}
export declare class BedrockagentFlowDefinitionNodeConfigurationInputList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationInputOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationIterator {
}
export declare function bedrockagentFlowDefinitionNodeConfigurationIteratorToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationIterator | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationIteratorToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationIterator | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationIteratorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationIterator | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationIterator | cdktn.IResolvable | undefined);
}
export declare class BedrockagentFlowDefinitionNodeConfigurationIteratorList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationIterator[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationIteratorOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#guardrail_identifier BedrockagentFlow#guardrail_identifier}
    */
    readonly guardrailIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#guardrail_version BedrockagentFlow#guardrail_version}
    */
    readonly guardrailVersion: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration | cdktn.IResolvable | undefined);
    private _guardrailIdentifier?;
    get guardrailIdentifier(): string;
    set guardrailIdentifier(value: string);
    get guardrailIdentifierInput(): string | undefined;
    private _guardrailVersion?;
    get guardrailVersion(): string;
    set guardrailVersion(value: string);
    get guardrailVersionInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#max_tokens BedrockagentFlow#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#stop_sequences BedrockagentFlow#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#temperature BedrockagentFlow#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#top_p BedrockagentFlow#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration {
    /**
    * text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#text BedrockagentFlow#text}
    */
    readonly text?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration | cdktn.IResolvable | undefined);
    private _text;
    get text(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextList;
    putText(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText[] | cdktn.IResolvable): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationText[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#knowledge_base_id BedrockagentFlow#knowledge_base_id}
    */
    readonly knowledgeBaseId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#model_id BedrockagentFlow#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#number_of_results BedrockagentFlow#number_of_results}
    */
    readonly numberOfResults?: number;
    /**
    * guardrail_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#guardrail_configuration BedrockagentFlow#guardrail_configuration}
    */
    readonly guardrailConfiguration?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration[] | cdktn.IResolvable;
    /**
    * inference_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#inference_configuration BedrockagentFlow#inference_configuration}
    */
    readonly inferenceConfiguration?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase | cdktn.IResolvable | undefined);
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    get knowledgeBaseIdInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _numberOfResults?;
    get numberOfResults(): number;
    set numberOfResults(value: number);
    resetNumberOfResults(): void;
    get numberOfResultsInput(): number | undefined;
    private _guardrailConfiguration;
    get guardrailConfiguration(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationList;
    putGuardrailConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration[] | cdktn.IResolvable): void;
    resetGuardrailConfiguration(): void;
    get guardrailConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfiguration[] | undefined;
    private _inferenceConfiguration;
    get inferenceConfiguration(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationList;
    putInferenceConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration[] | cdktn.IResolvable): void;
    resetInferenceConfiguration(): void;
    get inferenceConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfiguration[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationLambdaFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#lambda_arn BedrockagentFlow#lambda_arn}
    */
    readonly lambdaArn: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationLambdaFunctionToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationLambdaFunction | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationLambdaFunctionToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationLambdaFunction | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationLambdaFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationLambdaFunction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationLambdaFunction | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    get lambdaArnInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationLambdaFunctionList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationLambdaFunction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationLambdaFunctionOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationLex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#bot_alias_arn BedrockagentFlow#bot_alias_arn}
    */
    readonly botAliasArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#locale_id BedrockagentFlow#locale_id}
    */
    readonly localeId: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationLexToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationLex | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationLexToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationLex | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationLexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationLex | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationLex | cdktn.IResolvable | undefined);
    private _botAliasArn?;
    get botAliasArn(): string;
    set botAliasArn(value: string);
    get botAliasArnInput(): string | undefined;
    private _localeId?;
    get localeId(): string;
    set localeId(value: string);
    get localeIdInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationLexList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationLex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationLexOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationOutput {
}
export declare function bedrockagentFlowDefinitionNodeConfigurationOutputToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationOutput | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationOutputToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationOutput | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationOutput | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationOutput | cdktn.IResolvable | undefined);
}
export declare class BedrockagentFlowDefinitionNodeConfigurationOutputList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationOutput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationOutputOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#guardrail_identifier BedrockagentFlow#guardrail_identifier}
    */
    readonly guardrailIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#guardrail_version BedrockagentFlow#guardrail_version}
    */
    readonly guardrailVersion: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration | cdktn.IResolvable | undefined);
    private _guardrailIdentifier?;
    get guardrailIdentifier(): string;
    set guardrailIdentifier(value: string);
    get guardrailIdentifierInput(): string | undefined;
    private _guardrailVersion?;
    get guardrailVersion(): string;
    set guardrailVersion(value: string);
    get guardrailVersionInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#max_tokens BedrockagentFlow#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#stop_sequences BedrockagentFlow#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#temperature BedrockagentFlow#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#top_p BedrockagentFlow#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration {
    /**
    * text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#text BedrockagentFlow#text}
    */
    readonly text?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration | cdktn.IResolvable | undefined);
    private _text;
    get text(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextList;
    putText(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText[] | cdktn.IResolvable): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationText[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#text BedrockagentFlow#text}
    */
    readonly text?: string;
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#cache_point BedrockagentFlow#cache_point}
    */
    readonly cachePoint?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _cachePoint;
    get cachePoint(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointList;
    putCachePoint(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePoint[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#role BedrockagentFlow#role}
    */
    readonly role: string;
    /**
    * content block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#content BedrockagentFlow#content}
    */
    readonly content?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage | cdktn.IResolvable | undefined);
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _content;
    get content(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentList;
    putContent(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent[] | cdktn.IResolvable): void;
    resetContent(): void;
    get contentInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContent[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#text BedrockagentFlow#text}
    */
    readonly text?: string;
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#cache_point BedrockagentFlow#cache_point}
    */
    readonly cachePoint?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    resetText(): void;
    get textInput(): string | undefined;
    private _cachePoint;
    get cachePoint(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointList;
    putCachePoint(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePoint[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#json BedrockagentFlow#json}
    */
    readonly json?: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema | cdktn.IResolvable | undefined);
    private _json?;
    get json(): string;
    set json(value: string);
    resetJson(): void;
    get jsonInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#description BedrockagentFlow#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
    /**
    * input_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#input_schema BedrockagentFlow#input_schema}
    */
    readonly inputSchema?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _inputSchema;
    get inputSchema(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchemaList;
    putInputSchema(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | cdktn.IResolvable): void;
    resetInputSchema(): void;
    get inputSchemaInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecInputSchema[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool {
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#cache_point BedrockagentFlow#cache_point}
    */
    readonly cachePoint?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint[] | cdktn.IResolvable;
    /**
    * tool_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#tool_spec BedrockagentFlow#tool_spec}
    */
    readonly toolSpec?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool | cdktn.IResolvable | undefined);
    private _cachePoint;
    get cachePoint(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointList;
    putCachePoint(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePoint[] | undefined;
    private _toolSpec;
    get toolSpec(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpecList;
    putToolSpec(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec[] | cdktn.IResolvable): void;
    resetToolSpec(): void;
    get toolSpecInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolToolSpec[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny {
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAnyToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAnyToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAnyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny | cdktn.IResolvable | undefined);
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAnyList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAnyOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto {
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAutoToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAutoToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAutoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto | cdktn.IResolvable | undefined);
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAutoList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAutoOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice {
    /**
    * any block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#any BedrockagentFlow#any}
    */
    readonly any?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny[] | cdktn.IResolvable;
    /**
    * auto block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#auto BedrockagentFlow#auto}
    */
    readonly auto?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | cdktn.IResolvable;
    /**
    * tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#tool BedrockagentFlow#tool}
    */
    readonly tool?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice | cdktn.IResolvable | undefined);
    private _any;
    get any(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAnyList;
    putAny(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny[] | cdktn.IResolvable): void;
    resetAny(): void;
    get anyInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAny[] | undefined;
    private _auto;
    get auto(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAutoList;
    putAuto(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | cdktn.IResolvable): void;
    resetAuto(): void;
    get autoInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceAuto[] | undefined;
    private _tool;
    get tool(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolList;
    putTool(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool[] | cdktn.IResolvable): void;
    resetTool(): void;
    get toolInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceTool[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration {
    /**
    * tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#tool BedrockagentFlow#tool}
    */
    readonly tool?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool[] | cdktn.IResolvable;
    /**
    * tool_choice block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#tool_choice BedrockagentFlow#tool_choice}
    */
    readonly toolChoice?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration | cdktn.IResolvable | undefined);
    private _tool;
    get tool(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolList;
    putTool(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool[] | cdktn.IResolvable): void;
    resetTool(): void;
    get toolInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationTool[] | undefined;
    private _toolChoice;
    get toolChoice(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceList;
    putToolChoice(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice[] | cdktn.IResolvable): void;
    resetToolChoice(): void;
    get toolChoiceInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoice[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat {
    /**
    * input_variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#input_variable BedrockagentFlow#input_variable}
    */
    readonly inputVariable?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable[] | cdktn.IResolvable;
    /**
    * message block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#message BedrockagentFlow#message}
    */
    readonly message?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage[] | cdktn.IResolvable;
    /**
    * system block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#system BedrockagentFlow#system}
    */
    readonly systemAttribute?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem[] | cdktn.IResolvable;
    /**
    * tool_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#tool_configuration BedrockagentFlow#tool_configuration}
    */
    readonly toolConfiguration?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat | cdktn.IResolvable | undefined);
    private _inputVariable;
    get inputVariable(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableList;
    putInputVariable(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable[] | cdktn.IResolvable): void;
    resetInputVariable(): void;
    get inputVariableInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariable[] | undefined;
    private _message;
    get message(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageList;
    putMessage(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage[] | cdktn.IResolvable): void;
    resetMessage(): void;
    get messageInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessage[] | undefined;
    private _system;
    get systemAttribute(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemList;
    putSystemAttribute(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem[] | cdktn.IResolvable): void;
    resetSystemAttribute(): void;
    get systemAttributeInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystem[] | undefined;
    private _toolConfiguration;
    get toolConfiguration(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationList;
    putToolConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration[] | cdktn.IResolvable): void;
    resetToolConfiguration(): void;
    get toolConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfiguration[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#text BedrockagentFlow#text}
    */
    readonly text: string;
    /**
    * cache_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#cache_point BedrockagentFlow#cache_point}
    */
    readonly cachePoint?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint[] | cdktn.IResolvable;
    /**
    * input_variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#input_variable BedrockagentFlow#input_variable}
    */
    readonly inputVariable?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText | cdktn.IResolvable | undefined);
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
    private _cachePoint;
    get cachePoint(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointList;
    putCachePoint(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint[] | cdktn.IResolvable): void;
    resetCachePoint(): void;
    get cachePointInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePoint[] | undefined;
    private _inputVariable;
    get inputVariable(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableList;
    putInputVariable(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable[] | cdktn.IResolvable): void;
    resetInputVariable(): void;
    get inputVariableInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariable[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration {
    /**
    * chat block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#chat BedrockagentFlow#chat}
    */
    readonly chat?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat[] | cdktn.IResolvable;
    /**
    * text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#text BedrockagentFlow#text}
    */
    readonly text?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration | cdktn.IResolvable | undefined);
    private _chat;
    get chat(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatList;
    putChat(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat[] | cdktn.IResolvable): void;
    resetChat(): void;
    get chatInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChat[] | undefined;
    private _text;
    get text(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextList;
    putText(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText[] | cdktn.IResolvable): void;
    resetText(): void;
    get textInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationText[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#additional_model_request_fields BedrockagentFlow#additional_model_request_fields}
    */
    readonly additionalModelRequestFields?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#model_id BedrockagentFlow#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#template_type BedrockagentFlow#template_type}
    */
    readonly templateType: string;
    /**
    * inference_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#inference_configuration BedrockagentFlow#inference_configuration}
    */
    readonly inferenceConfiguration?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration[] | cdktn.IResolvable;
    /**
    * template_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#template_configuration BedrockagentFlow#template_configuration}
    */
    readonly templateConfiguration?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline | cdktn.IResolvable | undefined);
    private _additionalModelRequestFields?;
    get additionalModelRequestFields(): string;
    set additionalModelRequestFields(value: string);
    resetAdditionalModelRequestFields(): void;
    get additionalModelRequestFieldsInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _templateType?;
    get templateType(): string;
    set templateType(value: string);
    get templateTypeInput(): string | undefined;
    private _inferenceConfiguration;
    get inferenceConfiguration(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationList;
    putInferenceConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration[] | cdktn.IResolvable): void;
    resetInferenceConfiguration(): void;
    get inferenceConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfiguration[] | undefined;
    private _templateConfiguration;
    get templateConfiguration(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationList;
    putTemplateConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration[] | cdktn.IResolvable): void;
    resetTemplateConfiguration(): void;
    get templateConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfiguration[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#prompt_arn BedrockagentFlow#prompt_arn}
    */
    readonly promptArn: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResourceToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResourceToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource | cdktn.IResolvable | undefined);
    private _promptArn?;
    get promptArn(): string;
    set promptArn(value: string);
    get promptArnInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResourceList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResourceOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration {
    /**
    * inline block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#inline BedrockagentFlow#inline}
    */
    readonly inline?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline[] | cdktn.IResolvable;
    /**
    * resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#resource BedrockagentFlow#resource}
    */
    readonly resource?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration | cdktn.IResolvable | undefined);
    private _inline;
    get inline(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineList;
    putInline(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline[] | cdktn.IResolvable): void;
    resetInline(): void;
    get inlineInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationInline[] | undefined;
    private _resource;
    get resource(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResourceList;
    putResource(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource[] | cdktn.IResolvable): void;
    resetResource(): void;
    get resourceInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationResource[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationPrompt {
    /**
    * guardrail_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#guardrail_configuration BedrockagentFlow#guardrail_configuration}
    */
    readonly guardrailConfiguration?: BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration[] | cdktn.IResolvable;
    /**
    * source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#source_configuration BedrockagentFlow#source_configuration}
    */
    readonly sourceConfiguration?: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPrompt | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationPromptToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationPrompt | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationPrompt | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationPrompt | cdktn.IResolvable | undefined);
    private _guardrailConfiguration;
    get guardrailConfiguration(): BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfigurationList;
    putGuardrailConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration[] | cdktn.IResolvable): void;
    resetGuardrailConfiguration(): void;
    get guardrailConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptGuardrailConfiguration[] | undefined;
    private _sourceConfiguration;
    get sourceConfiguration(): BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfigurationList;
    putSourceConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration[] | cdktn.IResolvable): void;
    resetSourceConfiguration(): void;
    get sourceConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPromptSourceConfiguration[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationPromptList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationPrompt[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationPromptOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#bucket_name BedrockagentFlow#bucket_name}
    */
    readonly bucketName: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3ToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3 | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3ToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3 | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3 | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3OutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration {
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#s3 BedrockagentFlow#s3}
    */
    readonly s3?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration | cdktn.IResolvable | undefined);
    private _s3;
    get s3(): BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3List;
    putS3(value: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationRetrieval {
    /**
    * service_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#service_configuration BedrockagentFlow#service_configuration}
    */
    readonly serviceConfiguration?: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationRetrievalToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationRetrieval | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationRetrievalToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationRetrieval | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationRetrievalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationRetrieval | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationRetrieval | cdktn.IResolvable | undefined);
    private _serviceConfiguration;
    get serviceConfiguration(): BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfigurationList;
    putServiceConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration[] | cdktn.IResolvable): void;
    resetServiceConfiguration(): void;
    get serviceConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationRetrievalServiceConfiguration[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationRetrievalList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationRetrieval[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationRetrievalOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#bucket_name BedrockagentFlow#bucket_name}
    */
    readonly bucketName: string;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3ToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3 | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3ToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3 | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3 | cdktn.IResolvable | undefined);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3OutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration {
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#s3 BedrockagentFlow#s3}
    */
    readonly s3?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration | cdktn.IResolvable | undefined);
    private _s3;
    get s3(): BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3List;
    putS3(value: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationS3[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfigurationStorage {
    /**
    * service_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#service_configuration BedrockagentFlow#service_configuration}
    */
    readonly serviceConfiguration?: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationStorageToTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationStorage | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationStorageToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfigurationStorage | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfigurationStorage | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfigurationStorage | cdktn.IResolvable | undefined);
    private _serviceConfiguration;
    get serviceConfiguration(): BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfigurationList;
    putServiceConfiguration(value: BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration[] | cdktn.IResolvable): void;
    resetServiceConfiguration(): void;
    get serviceConfigurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationStorageServiceConfiguration[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationStorageList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfigurationStorage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationStorageOutputReference;
}
export interface BedrockagentFlowDefinitionNodeConfiguration {
    /**
    * agent block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#agent BedrockagentFlow#agent}
    */
    readonly agent?: BedrockagentFlowDefinitionNodeConfigurationAgent[] | cdktn.IResolvable;
    /**
    * collector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#collector BedrockagentFlow#collector}
    */
    readonly collector?: BedrockagentFlowDefinitionNodeConfigurationCollector[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#condition BedrockagentFlow#condition}
    */
    readonly condition?: BedrockagentFlowDefinitionNodeConfigurationCondition[] | cdktn.IResolvable;
    /**
    * inline_code block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#inline_code BedrockagentFlow#inline_code}
    */
    readonly inlineCode?: BedrockagentFlowDefinitionNodeConfigurationInlineCode[] | cdktn.IResolvable;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#input BedrockagentFlow#input}
    */
    readonly input?: BedrockagentFlowDefinitionNodeConfigurationInput[] | cdktn.IResolvable;
    /**
    * iterator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#iterator BedrockagentFlow#iterator}
    */
    readonly iterator?: BedrockagentFlowDefinitionNodeConfigurationIterator[] | cdktn.IResolvable;
    /**
    * knowledge_base block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#knowledge_base BedrockagentFlow#knowledge_base}
    */
    readonly knowledgeBase?: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase[] | cdktn.IResolvable;
    /**
    * lambda_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#lambda_function BedrockagentFlow#lambda_function}
    */
    readonly lambdaFunction?: BedrockagentFlowDefinitionNodeConfigurationLambdaFunction[] | cdktn.IResolvable;
    /**
    * lex block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#lex BedrockagentFlow#lex}
    */
    readonly lex?: BedrockagentFlowDefinitionNodeConfigurationLex[] | cdktn.IResolvable;
    /**
    * output block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#output BedrockagentFlow#output}
    */
    readonly output?: BedrockagentFlowDefinitionNodeConfigurationOutput[] | cdktn.IResolvable;
    /**
    * prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#prompt BedrockagentFlow#prompt}
    */
    readonly prompt?: BedrockagentFlowDefinitionNodeConfigurationPrompt[] | cdktn.IResolvable;
    /**
    * retrieval block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#retrieval BedrockagentFlow#retrieval}
    */
    readonly retrieval?: BedrockagentFlowDefinitionNodeConfigurationRetrieval[] | cdktn.IResolvable;
    /**
    * storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#storage BedrockagentFlow#storage}
    */
    readonly storage?: BedrockagentFlowDefinitionNodeConfigurationStorage[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeConfigurationToTerraform(struct?: BedrockagentFlowDefinitionNodeConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeConfigurationToHclTerraform(struct?: BedrockagentFlowDefinitionNodeConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeConfiguration | cdktn.IResolvable | undefined);
    private _agent;
    get agent(): BedrockagentFlowDefinitionNodeConfigurationAgentList;
    putAgent(value: BedrockagentFlowDefinitionNodeConfigurationAgent[] | cdktn.IResolvable): void;
    resetAgent(): void;
    get agentInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationAgent[] | undefined;
    private _collector;
    get collector(): BedrockagentFlowDefinitionNodeConfigurationCollectorList;
    putCollector(value: BedrockagentFlowDefinitionNodeConfigurationCollector[] | cdktn.IResolvable): void;
    resetCollector(): void;
    get collectorInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationCollector[] | undefined;
    private _condition;
    get condition(): BedrockagentFlowDefinitionNodeConfigurationConditionList;
    putCondition(value: BedrockagentFlowDefinitionNodeConfigurationCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationCondition[] | undefined;
    private _inlineCode;
    get inlineCode(): BedrockagentFlowDefinitionNodeConfigurationInlineCodeList;
    putInlineCode(value: BedrockagentFlowDefinitionNodeConfigurationInlineCode[] | cdktn.IResolvable): void;
    resetInlineCode(): void;
    get inlineCodeInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationInlineCode[] | undefined;
    private _input;
    get input(): BedrockagentFlowDefinitionNodeConfigurationInputList;
    putInput(value: BedrockagentFlowDefinitionNodeConfigurationInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationInput[] | undefined;
    private _iterator;
    get iterator(): BedrockagentFlowDefinitionNodeConfigurationIteratorList;
    putIterator(value: BedrockagentFlowDefinitionNodeConfigurationIterator[] | cdktn.IResolvable): void;
    resetIterator(): void;
    get iteratorInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationIterator[] | undefined;
    private _knowledgeBase;
    get knowledgeBase(): BedrockagentFlowDefinitionNodeConfigurationKnowledgeBaseList;
    putKnowledgeBase(value: BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase[] | cdktn.IResolvable): void;
    resetKnowledgeBase(): void;
    get knowledgeBaseInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationKnowledgeBase[] | undefined;
    private _lambdaFunction;
    get lambdaFunction(): BedrockagentFlowDefinitionNodeConfigurationLambdaFunctionList;
    putLambdaFunction(value: BedrockagentFlowDefinitionNodeConfigurationLambdaFunction[] | cdktn.IResolvable): void;
    resetLambdaFunction(): void;
    get lambdaFunctionInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationLambdaFunction[] | undefined;
    private _lex;
    get lex(): BedrockagentFlowDefinitionNodeConfigurationLexList;
    putLex(value: BedrockagentFlowDefinitionNodeConfigurationLex[] | cdktn.IResolvable): void;
    resetLex(): void;
    get lexInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationLex[] | undefined;
    private _output;
    get output(): BedrockagentFlowDefinitionNodeConfigurationOutputList;
    putOutput(value: BedrockagentFlowDefinitionNodeConfigurationOutput[] | cdktn.IResolvable): void;
    resetOutput(): void;
    get outputInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationOutput[] | undefined;
    private _prompt;
    get prompt(): BedrockagentFlowDefinitionNodeConfigurationPromptList;
    putPrompt(value: BedrockagentFlowDefinitionNodeConfigurationPrompt[] | cdktn.IResolvable): void;
    resetPrompt(): void;
    get promptInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationPrompt[] | undefined;
    private _retrieval;
    get retrieval(): BedrockagentFlowDefinitionNodeConfigurationRetrievalList;
    putRetrieval(value: BedrockagentFlowDefinitionNodeConfigurationRetrieval[] | cdktn.IResolvable): void;
    resetRetrieval(): void;
    get retrievalInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationRetrieval[] | undefined;
    private _storage;
    get storage(): BedrockagentFlowDefinitionNodeConfigurationStorageList;
    putStorage(value: BedrockagentFlowDefinitionNodeConfigurationStorage[] | cdktn.IResolvable): void;
    resetStorage(): void;
    get storageInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfigurationStorage[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeConfigurationOutputReference;
}
export interface BedrockagentFlowDefinitionNodeInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#category BedrockagentFlow#category}
    */
    readonly category?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#expression BedrockagentFlow#expression}
    */
    readonly expression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
}
export declare function bedrockagentFlowDefinitionNodeInputToTerraform(struct?: BedrockagentFlowDefinitionNodeInput | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeInputToHclTerraform(struct?: BedrockagentFlowDefinitionNodeInput | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeInput | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeInput | cdktn.IResolvable | undefined);
    private _category?;
    get category(): string;
    set category(value: string);
    resetCategory(): void;
    get categoryInput(): string | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeInputList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeInputOutputReference;
}
export interface BedrockagentFlowDefinitionNodeOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
}
export declare function bedrockagentFlowDefinitionNodeOutputToTerraform(struct?: BedrockagentFlowDefinitionNodeOutput | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeOutputToHclTerraform(struct?: BedrockagentFlowDefinitionNodeOutput | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNodeOutput | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNodeOutput | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockagentFlowDefinitionNodeOutputList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNodeOutput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeOutputOutputReference;
}
export interface BedrockagentFlowDefinitionNode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#name BedrockagentFlow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#type BedrockagentFlow#type}
    */
    readonly type: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#configuration BedrockagentFlow#configuration}
    */
    readonly configuration?: BedrockagentFlowDefinitionNodeConfiguration[] | cdktn.IResolvable;
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#input BedrockagentFlow#input}
    */
    readonly input?: BedrockagentFlowDefinitionNodeInput[] | cdktn.IResolvable;
    /**
    * output block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#output BedrockagentFlow#output}
    */
    readonly output?: BedrockagentFlowDefinitionNodeOutput[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionNodeToTerraform(struct?: BedrockagentFlowDefinitionNode | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionNodeToHclTerraform(struct?: BedrockagentFlowDefinitionNode | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionNodeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinitionNode | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinitionNode | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): BedrockagentFlowDefinitionNodeConfigurationList;
    putConfiguration(value: BedrockagentFlowDefinitionNodeConfiguration[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeConfiguration[] | undefined;
    private _input;
    get input(): BedrockagentFlowDefinitionNodeInputList;
    putInput(value: BedrockagentFlowDefinitionNodeInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeInput[] | undefined;
    private _output;
    get output(): BedrockagentFlowDefinitionNodeOutputList;
    putOutput(value: BedrockagentFlowDefinitionNodeOutput[] | cdktn.IResolvable): void;
    resetOutput(): void;
    get outputInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNodeOutput[] | undefined;
}
export declare class BedrockagentFlowDefinitionNodeList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinitionNode[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionNodeOutputReference;
}
export interface BedrockagentFlowDefinition {
    /**
    * connection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#connection BedrockagentFlow#connection}
    */
    readonly connection?: BedrockagentFlowDefinitionConnection[] | cdktn.IResolvable;
    /**
    * node block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#node BedrockagentFlow#node}
    */
    readonly nodeAttribute?: BedrockagentFlowDefinitionNode[] | cdktn.IResolvable;
}
export declare function bedrockagentFlowDefinitionToTerraform(struct?: BedrockagentFlowDefinition | cdktn.IResolvable): any;
export declare function bedrockagentFlowDefinitionToHclTerraform(struct?: BedrockagentFlowDefinition | cdktn.IResolvable): any;
export declare class BedrockagentFlowDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentFlowDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowDefinition | cdktn.IResolvable | undefined);
    private _connection;
    get connection(): BedrockagentFlowDefinitionConnectionList;
    putConnection(value: BedrockagentFlowDefinitionConnection[] | cdktn.IResolvable): void;
    resetConnection(): void;
    get connectionInput(): cdktn.IResolvable | BedrockagentFlowDefinitionConnection[] | undefined;
    private _node;
    get nodeAttribute(): BedrockagentFlowDefinitionNodeList;
    putNodeAttribute(value: BedrockagentFlowDefinitionNode[] | cdktn.IResolvable): void;
    resetNodeAttribute(): void;
    get nodeAttributeInput(): cdktn.IResolvable | BedrockagentFlowDefinitionNode[] | undefined;
}
export declare class BedrockagentFlowDefinitionList extends cdktn.ComplexList {
    internalValue?: BedrockagentFlowDefinition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentFlowDefinitionOutputReference;
}
export interface BedrockagentFlowTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#create BedrockagentFlow#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#delete BedrockagentFlow#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#update BedrockagentFlow#update}
    */
    readonly update?: string;
}
export declare function bedrockagentFlowTimeoutsToTerraform(struct?: BedrockagentFlowTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentFlowTimeoutsToHclTerraform(struct?: BedrockagentFlowTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentFlowTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentFlowTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentFlowTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow aws_bedrockagent_flow}
*/
export declare class BedrockagentFlow extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_flow";
    /**
    * Generates CDKTN code for importing a BedrockagentFlow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentFlow to import
    * @param importFromId The id of the existing BedrockagentFlow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentFlow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrockagent_flow aws_bedrockagent_flow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentFlowConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentFlowConfig);
    get arn(): string;
    get createdAt(): string;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get version(): string;
    private _definition;
    get definition(): BedrockagentFlowDefinitionList;
    putDefinition(value: BedrockagentFlowDefinition[] | cdktn.IResolvable): void;
    resetDefinition(): void;
    get definitionInput(): cdktn.IResolvable | BedrockagentFlowDefinition[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentFlowTimeoutsOutputReference;
    putTimeouts(value: BedrockagentFlowTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentFlowTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
