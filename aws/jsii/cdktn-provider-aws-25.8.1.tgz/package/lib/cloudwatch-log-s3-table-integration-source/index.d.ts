/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchLogS3TableIntegrationSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#integration_arn CloudwatchLogS3TableIntegrationSource#integration_arn}
    */
    readonly integrationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#region CloudwatchLogS3TableIntegrationSource#region}
    */
    readonly region?: string;
    /**
    * data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#data_source CloudwatchLogS3TableIntegrationSource#data_source}
    */
    readonly dataSource?: CloudwatchLogS3TableIntegrationSourceDataSource[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#timeouts CloudwatchLogS3TableIntegrationSource#timeouts}
    */
    readonly timeouts?: CloudwatchLogS3TableIntegrationSourceTimeouts;
}
export interface CloudwatchLogS3TableIntegrationSourceDataSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#name CloudwatchLogS3TableIntegrationSource#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#type CloudwatchLogS3TableIntegrationSource#type}
    */
    readonly type: string;
}
export declare function cloudwatchLogS3TableIntegrationSourceDataSourceToTerraform(struct?: CloudwatchLogS3TableIntegrationSourceDataSource | cdktn.IResolvable): any;
export declare function cloudwatchLogS3TableIntegrationSourceDataSourceToHclTerraform(struct?: CloudwatchLogS3TableIntegrationSourceDataSource | cdktn.IResolvable): any;
export declare class CloudwatchLogS3TableIntegrationSourceDataSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogS3TableIntegrationSourceDataSource | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogS3TableIntegrationSourceDataSource | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class CloudwatchLogS3TableIntegrationSourceDataSourceList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogS3TableIntegrationSourceDataSource[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogS3TableIntegrationSourceDataSourceOutputReference;
}
export interface CloudwatchLogS3TableIntegrationSourceTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#delete CloudwatchLogS3TableIntegrationSource#delete}
    */
    readonly delete?: string;
}
export declare function cloudwatchLogS3TableIntegrationSourceTimeoutsToTerraform(struct?: CloudwatchLogS3TableIntegrationSourceTimeouts | cdktn.IResolvable): any;
export declare function cloudwatchLogS3TableIntegrationSourceTimeoutsToHclTerraform(struct?: CloudwatchLogS3TableIntegrationSourceTimeouts | cdktn.IResolvable): any;
export declare class CloudwatchLogS3TableIntegrationSourceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchLogS3TableIntegrationSourceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogS3TableIntegrationSourceTimeouts | cdktn.IResolvable | undefined);
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source aws_cloudwatch_log_s3_table_integration_source}
*/
export declare class CloudwatchLogS3TableIntegrationSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_s3_table_integration_source";
    /**
    * Generates CDKTN code for importing a CloudwatchLogS3TableIntegrationSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchLogS3TableIntegrationSource to import
    * @param importFromId The id of the existing CloudwatchLogS3TableIntegrationSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchLogS3TableIntegrationSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_s3_table_integration_source aws_cloudwatch_log_s3_table_integration_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchLogS3TableIntegrationSourceConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchLogS3TableIntegrationSourceConfig);
    get id(): string;
    private _integrationArn?;
    get integrationArn(): string;
    set integrationArn(value: string);
    get integrationArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _dataSource;
    get dataSource(): CloudwatchLogS3TableIntegrationSourceDataSourceList;
    putDataSource(value: CloudwatchLogS3TableIntegrationSourceDataSource[] | cdktn.IResolvable): void;
    resetDataSource(): void;
    get dataSourceInput(): cdktn.IResolvable | CloudwatchLogS3TableIntegrationSourceDataSource[] | undefined;
    private _timeouts;
    get timeouts(): CloudwatchLogS3TableIntegrationSourceTimeoutsOutputReference;
    putTimeouts(value: CloudwatchLogS3TableIntegrationSourceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudwatchLogS3TableIntegrationSourceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
