/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockModelInvocationJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#job_name BedrockModelInvocationJob#job_name}
    */
    readonly jobName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#model_id BedrockModelInvocationJob#model_id}
    */
    readonly modelId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#region BedrockModelInvocationJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#role_arn BedrockModelInvocationJob#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#skip_destroy BedrockModelInvocationJob#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#timeout_duration_in_hours BedrockModelInvocationJob#timeout_duration_in_hours}
    */
    readonly timeoutDurationInHours?: number;
    /**
    * input_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#input_data_config BedrockModelInvocationJob#input_data_config}
    */
    readonly inputDataConfig?: BedrockModelInvocationJobInputDataConfig[] | cdktn.IResolvable;
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#output_data_config BedrockModelInvocationJob#output_data_config}
    */
    readonly outputDataConfig?: BedrockModelInvocationJobOutputDataConfig[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#timeouts BedrockModelInvocationJob#timeouts}
    */
    readonly timeouts?: BedrockModelInvocationJobTimeouts;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#vpc_config BedrockModelInvocationJob#vpc_config}
    */
    readonly vpcConfig?: BedrockModelInvocationJobVpcConfig[] | cdktn.IResolvable;
}
export interface BedrockModelInvocationJobInputDataConfigS3InputDataConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_bucket_owner BedrockModelInvocationJob#s3_bucket_owner}
    */
    readonly s3BucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_input_format BedrockModelInvocationJob#s3_input_format}
    */
    readonly s3InputFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_uri BedrockModelInvocationJob#s3_uri}
    */
    readonly s3Uri: string;
}
export declare function bedrockModelInvocationJobInputDataConfigS3InputDataConfigToTerraform(struct?: BedrockModelInvocationJobInputDataConfigS3InputDataConfig | cdktn.IResolvable): any;
export declare function bedrockModelInvocationJobInputDataConfigS3InputDataConfigToHclTerraform(struct?: BedrockModelInvocationJobInputDataConfigS3InputDataConfig | cdktn.IResolvable): any;
export declare class BedrockModelInvocationJobInputDataConfigS3InputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationJobInputDataConfigS3InputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationJobInputDataConfigS3InputDataConfig | cdktn.IResolvable | undefined);
    private _s3BucketOwner?;
    get s3BucketOwner(): string;
    set s3BucketOwner(value: string);
    resetS3BucketOwner(): void;
    get s3BucketOwnerInput(): string | undefined;
    private _s3InputFormat?;
    get s3InputFormat(): string;
    set s3InputFormat(value: string);
    resetS3InputFormat(): void;
    get s3InputFormatInput(): string | undefined;
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    get s3UriInput(): string | undefined;
}
export declare class BedrockModelInvocationJobInputDataConfigS3InputDataConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationJobInputDataConfigS3InputDataConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationJobInputDataConfigS3InputDataConfigOutputReference;
}
export interface BedrockModelInvocationJobInputDataConfig {
    /**
    * s3_input_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_input_data_config BedrockModelInvocationJob#s3_input_data_config}
    */
    readonly s3InputDataConfig?: BedrockModelInvocationJobInputDataConfigS3InputDataConfig[] | cdktn.IResolvable;
}
export declare function bedrockModelInvocationJobInputDataConfigToTerraform(struct?: BedrockModelInvocationJobInputDataConfig | cdktn.IResolvable): any;
export declare function bedrockModelInvocationJobInputDataConfigToHclTerraform(struct?: BedrockModelInvocationJobInputDataConfig | cdktn.IResolvable): any;
export declare class BedrockModelInvocationJobInputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationJobInputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationJobInputDataConfig | cdktn.IResolvable | undefined);
    private _s3InputDataConfig;
    get s3InputDataConfig(): BedrockModelInvocationJobInputDataConfigS3InputDataConfigList;
    putS3InputDataConfig(value: BedrockModelInvocationJobInputDataConfigS3InputDataConfig[] | cdktn.IResolvable): void;
    resetS3InputDataConfig(): void;
    get s3InputDataConfigInput(): cdktn.IResolvable | BedrockModelInvocationJobInputDataConfigS3InputDataConfig[] | undefined;
}
export declare class BedrockModelInvocationJobInputDataConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationJobInputDataConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationJobInputDataConfigOutputReference;
}
export interface BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_bucket_owner BedrockModelInvocationJob#s3_bucket_owner}
    */
    readonly s3BucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_encryption_key_id BedrockModelInvocationJob#s3_encryption_key_id}
    */
    readonly s3EncryptionKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_uri BedrockModelInvocationJob#s3_uri}
    */
    readonly s3Uri: string;
}
export declare function bedrockModelInvocationJobOutputDataConfigS3OutputDataConfigToTerraform(struct?: BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig | cdktn.IResolvable): any;
export declare function bedrockModelInvocationJobOutputDataConfigS3OutputDataConfigToHclTerraform(struct?: BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig | cdktn.IResolvable): any;
export declare class BedrockModelInvocationJobOutputDataConfigS3OutputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig | cdktn.IResolvable | undefined);
    private _s3BucketOwner?;
    get s3BucketOwner(): string;
    set s3BucketOwner(value: string);
    resetS3BucketOwner(): void;
    get s3BucketOwnerInput(): string | undefined;
    private _s3EncryptionKeyId?;
    get s3EncryptionKeyId(): string;
    set s3EncryptionKeyId(value: string);
    resetS3EncryptionKeyId(): void;
    get s3EncryptionKeyIdInput(): string | undefined;
    private _s3Uri?;
    get s3Uri(): string;
    set s3Uri(value: string);
    get s3UriInput(): string | undefined;
}
export declare class BedrockModelInvocationJobOutputDataConfigS3OutputDataConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationJobOutputDataConfigS3OutputDataConfigOutputReference;
}
export interface BedrockModelInvocationJobOutputDataConfig {
    /**
    * s3_output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#s3_output_data_config BedrockModelInvocationJob#s3_output_data_config}
    */
    readonly s3OutputDataConfig?: BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig[] | cdktn.IResolvable;
}
export declare function bedrockModelInvocationJobOutputDataConfigToTerraform(struct?: BedrockModelInvocationJobOutputDataConfig | cdktn.IResolvable): any;
export declare function bedrockModelInvocationJobOutputDataConfigToHclTerraform(struct?: BedrockModelInvocationJobOutputDataConfig | cdktn.IResolvable): any;
export declare class BedrockModelInvocationJobOutputDataConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationJobOutputDataConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationJobOutputDataConfig | cdktn.IResolvable | undefined);
    private _s3OutputDataConfig;
    get s3OutputDataConfig(): BedrockModelInvocationJobOutputDataConfigS3OutputDataConfigList;
    putS3OutputDataConfig(value: BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig[] | cdktn.IResolvable): void;
    resetS3OutputDataConfig(): void;
    get s3OutputDataConfigInput(): cdktn.IResolvable | BedrockModelInvocationJobOutputDataConfigS3OutputDataConfig[] | undefined;
}
export declare class BedrockModelInvocationJobOutputDataConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationJobOutputDataConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationJobOutputDataConfigOutputReference;
}
export interface BedrockModelInvocationJobTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#create BedrockModelInvocationJob#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#delete BedrockModelInvocationJob#delete}
    */
    readonly delete?: string;
}
export declare function bedrockModelInvocationJobTimeoutsToTerraform(struct?: BedrockModelInvocationJobTimeouts | cdktn.IResolvable): any;
export declare function bedrockModelInvocationJobTimeoutsToHclTerraform(struct?: BedrockModelInvocationJobTimeouts | cdktn.IResolvable): any;
export declare class BedrockModelInvocationJobTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockModelInvocationJobTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationJobTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
export interface BedrockModelInvocationJobVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#security_group_ids BedrockModelInvocationJob#security_group_ids}
    */
    readonly securityGroupIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#subnet_ids BedrockModelInvocationJob#subnet_ids}
    */
    readonly subnetIds: string[];
}
export declare function bedrockModelInvocationJobVpcConfigToTerraform(struct?: BedrockModelInvocationJobVpcConfig | cdktn.IResolvable): any;
export declare function bedrockModelInvocationJobVpcConfigToHclTerraform(struct?: BedrockModelInvocationJobVpcConfig | cdktn.IResolvable): any;
export declare class BedrockModelInvocationJobVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockModelInvocationJobVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockModelInvocationJobVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
}
export declare class BedrockModelInvocationJobVpcConfigList extends cdktn.ComplexList {
    internalValue?: BedrockModelInvocationJobVpcConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockModelInvocationJobVpcConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job aws_bedrock_model_invocation_job}
*/
export declare class BedrockModelInvocationJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_model_invocation_job";
    /**
    * Generates CDKTN code for importing a BedrockModelInvocationJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockModelInvocationJob to import
    * @param importFromId The id of the existing BedrockModelInvocationJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockModelInvocationJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/bedrock_model_invocation_job aws_bedrock_model_invocation_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockModelInvocationJobConfig
    */
    constructor(scope: Construct, id: string, config: BedrockModelInvocationJobConfig);
    get endTime(): string;
    get errorRecordCount(): number;
    get jobArn(): string;
    get jobExpirationTime(): string;
    private _jobName?;
    get jobName(): string;
    set jobName(value: string);
    get jobNameInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    get modelInvocationType(): string;
    get processedRecordCount(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    get submitTime(): string;
    get successRecordCount(): number;
    private _timeoutDurationInHours?;
    get timeoutDurationInHours(): number;
    set timeoutDurationInHours(value: number);
    resetTimeoutDurationInHours(): void;
    get timeoutDurationInHoursInput(): number | undefined;
    get totalRecordCount(): number;
    private _inputDataConfig;
    get inputDataConfig(): BedrockModelInvocationJobInputDataConfigList;
    putInputDataConfig(value: BedrockModelInvocationJobInputDataConfig[] | cdktn.IResolvable): void;
    resetInputDataConfig(): void;
    get inputDataConfigInput(): cdktn.IResolvable | BedrockModelInvocationJobInputDataConfig[] | undefined;
    private _outputDataConfig;
    get outputDataConfig(): BedrockModelInvocationJobOutputDataConfigList;
    putOutputDataConfig(value: BedrockModelInvocationJobOutputDataConfig[] | cdktn.IResolvable): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | BedrockModelInvocationJobOutputDataConfig[] | undefined;
    private _timeouts;
    get timeouts(): BedrockModelInvocationJobTimeoutsOutputReference;
    putTimeouts(value: BedrockModelInvocationJobTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockModelInvocationJobTimeouts | undefined;
    private _vpcConfig;
    get vpcConfig(): BedrockModelInvocationJobVpcConfigList;
    putVpcConfig(value: BedrockModelInvocationJobVpcConfig[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | BedrockModelInvocationJobVpcConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
