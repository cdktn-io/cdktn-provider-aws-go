/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAuditmanagerControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/auditmanager_control#name DataAwsAuditmanagerControl#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/auditmanager_control#region DataAwsAuditmanagerControl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/auditmanager_control#type DataAwsAuditmanagerControl#type}
    */
    readonly type: string;
}
export interface DataAwsAuditmanagerControlControlMappingSourcesSourceKeyword {
}
export declare function dataAwsAuditmanagerControlControlMappingSourcesSourceKeywordToTerraform(struct?: DataAwsAuditmanagerControlControlMappingSourcesSourceKeyword): any;
export declare function dataAwsAuditmanagerControlControlMappingSourcesSourceKeywordToHclTerraform(struct?: DataAwsAuditmanagerControlControlMappingSourcesSourceKeyword): any;
export declare class DataAwsAuditmanagerControlControlMappingSourcesSourceKeywordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAuditmanagerControlControlMappingSourcesSourceKeyword | undefined;
    set internalValue(value: DataAwsAuditmanagerControlControlMappingSourcesSourceKeyword | undefined);
    get keywordInputType(): string;
    get keywordValue(): string;
}
export declare class DataAwsAuditmanagerControlControlMappingSourcesSourceKeywordList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAuditmanagerControlControlMappingSourcesSourceKeywordOutputReference;
}
export interface DataAwsAuditmanagerControlControlMappingSources {
}
export declare function dataAwsAuditmanagerControlControlMappingSourcesToTerraform(struct?: DataAwsAuditmanagerControlControlMappingSources): any;
export declare function dataAwsAuditmanagerControlControlMappingSourcesToHclTerraform(struct?: DataAwsAuditmanagerControlControlMappingSources): any;
export declare class DataAwsAuditmanagerControlControlMappingSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsAuditmanagerControlControlMappingSources | undefined;
    set internalValue(value: DataAwsAuditmanagerControlControlMappingSources | undefined);
    get sourceDescription(): string;
    get sourceFrequency(): string;
    get sourceId(): string;
    private _sourceKeyword;
    get sourceKeyword(): DataAwsAuditmanagerControlControlMappingSourcesSourceKeywordList;
    get sourceName(): string;
    get sourceSetUpOption(): string;
    get sourceType(): string;
    get troubleshootingText(): string;
}
export declare class DataAwsAuditmanagerControlControlMappingSourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsAuditmanagerControlControlMappingSourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/auditmanager_control aws_auditmanager_control}
*/
export declare class DataAwsAuditmanagerControl extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_auditmanager_control";
    /**
    * Generates CDKTN code for importing a DataAwsAuditmanagerControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAuditmanagerControl to import
    * @param importFromId The id of the existing DataAwsAuditmanagerControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/auditmanager_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAuditmanagerControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/data-sources/auditmanager_control aws_auditmanager_control} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAuditmanagerControlConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsAuditmanagerControlConfig);
    get actionPlanInstructions(): string;
    get actionPlanTitle(): string;
    get arn(): string;
    private _controlMappingSources;
    get controlMappingSources(): DataAwsAuditmanagerControlControlMappingSourcesList;
    get description(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    get testingInformation(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
