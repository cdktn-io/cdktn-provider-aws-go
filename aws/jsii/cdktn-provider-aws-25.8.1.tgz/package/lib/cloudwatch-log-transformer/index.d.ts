/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchLogTransformerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#log_group_arn CloudwatchLogTransformer#log_group_arn}
    */
    readonly logGroupArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#region CloudwatchLogTransformer#region}
    */
    readonly region?: string;
    /**
    * transformer_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#transformer_config CloudwatchLogTransformer#transformer_config}
    */
    readonly transformerConfig?: CloudwatchLogTransformerTransformerConfig[] | cdktn.IResolvable;
}
export interface CloudwatchLogTransformerTransformerConfigAddKeysEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#key CloudwatchLogTransformer#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#overwrite_if_exists CloudwatchLogTransformer#overwrite_if_exists}
    */
    readonly overwriteIfExists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#value CloudwatchLogTransformer#value}
    */
    readonly value: string;
}
export declare function cloudwatchLogTransformerTransformerConfigAddKeysEntryToTerraform(struct?: CloudwatchLogTransformerTransformerConfigAddKeysEntry | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigAddKeysEntryToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigAddKeysEntry | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigAddKeysEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigAddKeysEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigAddKeysEntry | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _overwriteIfExists?;
    get overwriteIfExists(): boolean | cdktn.IResolvable;
    set overwriteIfExists(value: boolean | cdktn.IResolvable);
    resetOverwriteIfExists(): void;
    get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigAddKeysEntryList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigAddKeysEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigAddKeysEntryOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigAddKeys {
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#entry CloudwatchLogTransformer#entry}
    */
    readonly entry?: CloudwatchLogTransformerTransformerConfigAddKeysEntry[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigAddKeysToTerraform(struct?: CloudwatchLogTransformerTransformerConfigAddKeys | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigAddKeysToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigAddKeys | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigAddKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigAddKeys | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigAddKeys | cdktn.IResolvable | undefined);
    private _entry;
    get entry(): CloudwatchLogTransformerTransformerConfigAddKeysEntryList;
    putEntry(value: CloudwatchLogTransformerTransformerConfigAddKeysEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigAddKeysEntry[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigAddKeysList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigAddKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigAddKeysOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigCopyValueEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#overwrite_if_exists CloudwatchLogTransformer#overwrite_if_exists}
    */
    readonly overwriteIfExists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#target CloudwatchLogTransformer#target}
    */
    readonly target: string;
}
export declare function cloudwatchLogTransformerTransformerConfigCopyValueEntryToTerraform(struct?: CloudwatchLogTransformerTransformerConfigCopyValueEntry | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigCopyValueEntryToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigCopyValueEntry | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigCopyValueEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigCopyValueEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigCopyValueEntry | cdktn.IResolvable | undefined);
    private _overwriteIfExists?;
    get overwriteIfExists(): boolean | cdktn.IResolvable;
    set overwriteIfExists(value: boolean | cdktn.IResolvable);
    resetOverwriteIfExists(): void;
    get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigCopyValueEntryList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigCopyValueEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigCopyValueEntryOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigCopyValue {
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#entry CloudwatchLogTransformer#entry}
    */
    readonly entry?: CloudwatchLogTransformerTransformerConfigCopyValueEntry[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigCopyValueToTerraform(struct?: CloudwatchLogTransformerTransformerConfigCopyValue | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigCopyValueToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigCopyValue | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigCopyValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigCopyValue | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigCopyValue | cdktn.IResolvable | undefined);
    private _entry;
    get entry(): CloudwatchLogTransformerTransformerConfigCopyValueEntryList;
    putEntry(value: CloudwatchLogTransformerTransformerConfigCopyValueEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigCopyValueEntry[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigCopyValueList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigCopyValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigCopyValueOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigCsv {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#columns CloudwatchLogTransformer#columns}
    */
    readonly columns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#delimiter CloudwatchLogTransformer#delimiter}
    */
    readonly delimiter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#quote_character CloudwatchLogTransformer#quote_character}
    */
    readonly quoteCharacter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigCsvToTerraform(struct?: CloudwatchLogTransformerTransformerConfigCsv | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigCsvToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigCsv | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigCsvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigCsv | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigCsv | cdktn.IResolvable | undefined);
    private _columns?;
    get columns(): string[];
    set columns(value: string[]);
    resetColumns(): void;
    get columnsInput(): string[] | undefined;
    private _delimiter?;
    get delimiter(): string;
    set delimiter(value: string);
    resetDelimiter(): void;
    get delimiterInput(): string | undefined;
    private _quoteCharacter?;
    get quoteCharacter(): string;
    set quoteCharacter(value: string);
    resetQuoteCharacter(): void;
    get quoteCharacterInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigCsvList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigCsv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigCsvOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigDateTimeConverter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#locale CloudwatchLogTransformer#locale}
    */
    readonly locale?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#match_patterns CloudwatchLogTransformer#match_patterns}
    */
    readonly matchPatterns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source_timezone CloudwatchLogTransformer#source_timezone}
    */
    readonly sourceTimezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#target CloudwatchLogTransformer#target}
    */
    readonly target: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#target_format CloudwatchLogTransformer#target_format}
    */
    readonly targetFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#target_timezone CloudwatchLogTransformer#target_timezone}
    */
    readonly targetTimezone?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigDateTimeConverterToTerraform(struct?: CloudwatchLogTransformerTransformerConfigDateTimeConverter | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigDateTimeConverterToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigDateTimeConverter | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigDateTimeConverterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigDateTimeConverter | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigDateTimeConverter | cdktn.IResolvable | undefined);
    private _locale?;
    get locale(): string;
    set locale(value: string);
    resetLocale(): void;
    get localeInput(): string | undefined;
    private _matchPatterns?;
    get matchPatterns(): string[];
    set matchPatterns(value: string[]);
    get matchPatternsInput(): string[] | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _sourceTimezone?;
    get sourceTimezone(): string;
    set sourceTimezone(value: string);
    resetSourceTimezone(): void;
    get sourceTimezoneInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _targetFormat?;
    get targetFormat(): string;
    set targetFormat(value: string);
    resetTargetFormat(): void;
    get targetFormatInput(): string | undefined;
    private _targetTimezone?;
    get targetTimezone(): string;
    set targetTimezone(value: string);
    resetTargetTimezone(): void;
    get targetTimezoneInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigDateTimeConverterList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigDateTimeConverter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigDateTimeConverterOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigDeleteKeys {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#with_keys CloudwatchLogTransformer#with_keys}
    */
    readonly withKeys: string[];
}
export declare function cloudwatchLogTransformerTransformerConfigDeleteKeysToTerraform(struct?: CloudwatchLogTransformerTransformerConfigDeleteKeys | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigDeleteKeysToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigDeleteKeys | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigDeleteKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigDeleteKeys | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigDeleteKeys | cdktn.IResolvable | undefined);
    private _withKeys?;
    get withKeys(): string[];
    set withKeys(value: string[]);
    get withKeysInput(): string[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigDeleteKeysList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigDeleteKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigDeleteKeysOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigGrok {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#match CloudwatchLogTransformer#match}
    */
    readonly match: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigGrokToTerraform(struct?: CloudwatchLogTransformerTransformerConfigGrok | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigGrokToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigGrok | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigGrokOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigGrok | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigGrok | cdktn.IResolvable | undefined);
    private _match?;
    get match(): string;
    set match(value: string);
    get matchInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigGrokList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigGrok[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigGrokOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigListToMap {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#flatten CloudwatchLogTransformer#flatten}
    */
    readonly flatten?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#flattened_element CloudwatchLogTransformer#flattened_element}
    */
    readonly flattenedElement?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#key CloudwatchLogTransformer#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#target CloudwatchLogTransformer#target}
    */
    readonly target?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#value_key CloudwatchLogTransformer#value_key}
    */
    readonly valueKey?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigListToMapToTerraform(struct?: CloudwatchLogTransformerTransformerConfigListToMap | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigListToMapToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigListToMap | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigListToMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigListToMap | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigListToMap | cdktn.IResolvable | undefined);
    private _flatten?;
    get flatten(): boolean | cdktn.IResolvable;
    set flatten(value: boolean | cdktn.IResolvable);
    resetFlatten(): void;
    get flattenInput(): boolean | cdktn.IResolvable | undefined;
    private _flattenedElement?;
    get flattenedElement(): string;
    set flattenedElement(value: string);
    resetFlattenedElement(): void;
    get flattenedElementInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _valueKey?;
    get valueKey(): string;
    set valueKey(value: string);
    resetValueKey(): void;
    get valueKeyInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigListToMapList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigListToMap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigListToMapOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigLowerCaseString {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#with_keys CloudwatchLogTransformer#with_keys}
    */
    readonly withKeys: string[];
}
export declare function cloudwatchLogTransformerTransformerConfigLowerCaseStringToTerraform(struct?: CloudwatchLogTransformerTransformerConfigLowerCaseString | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigLowerCaseStringToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigLowerCaseString | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigLowerCaseStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigLowerCaseString | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigLowerCaseString | cdktn.IResolvable | undefined);
    private _withKeys?;
    get withKeys(): string[];
    set withKeys(value: string[]);
    get withKeysInput(): string[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigLowerCaseStringList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigLowerCaseString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigLowerCaseStringOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigMoveKeysEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#overwrite_if_exists CloudwatchLogTransformer#overwrite_if_exists}
    */
    readonly overwriteIfExists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#target CloudwatchLogTransformer#target}
    */
    readonly target: string;
}
export declare function cloudwatchLogTransformerTransformerConfigMoveKeysEntryToTerraform(struct?: CloudwatchLogTransformerTransformerConfigMoveKeysEntry | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigMoveKeysEntryToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigMoveKeysEntry | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigMoveKeysEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigMoveKeysEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigMoveKeysEntry | cdktn.IResolvable | undefined);
    private _overwriteIfExists?;
    get overwriteIfExists(): boolean | cdktn.IResolvable;
    set overwriteIfExists(value: boolean | cdktn.IResolvable);
    resetOverwriteIfExists(): void;
    get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigMoveKeysEntryList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigMoveKeysEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigMoveKeysEntryOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigMoveKeys {
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#entry CloudwatchLogTransformer#entry}
    */
    readonly entry?: CloudwatchLogTransformerTransformerConfigMoveKeysEntry[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigMoveKeysToTerraform(struct?: CloudwatchLogTransformerTransformerConfigMoveKeys | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigMoveKeysToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigMoveKeys | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigMoveKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigMoveKeys | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigMoveKeys | cdktn.IResolvable | undefined);
    private _entry;
    get entry(): CloudwatchLogTransformerTransformerConfigMoveKeysEntryList;
    putEntry(value: CloudwatchLogTransformerTransformerConfigMoveKeysEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigMoveKeysEntry[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigMoveKeysList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigMoveKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigMoveKeysOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParseCloudfront {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParseCloudfrontToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseCloudfront | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParseCloudfrontToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseCloudfront | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParseCloudfrontOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParseCloudfront | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParseCloudfront | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParseCloudfrontList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParseCloudfront[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParseCloudfrontOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParseJson {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#destination CloudwatchLogTransformer#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParseJsonToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseJson | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParseJsonToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseJson | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParseJsonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParseJson | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParseJson | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParseJsonList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParseJson[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParseJsonOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParseKeyValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#destination CloudwatchLogTransformer#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#field_delimiter CloudwatchLogTransformer#field_delimiter}
    */
    readonly fieldDelimiter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#key_prefix CloudwatchLogTransformer#key_prefix}
    */
    readonly keyPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#key_value_delimiter CloudwatchLogTransformer#key_value_delimiter}
    */
    readonly keyValueDelimiter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#non_match_value CloudwatchLogTransformer#non_match_value}
    */
    readonly nonMatchValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#overwrite_if_exists CloudwatchLogTransformer#overwrite_if_exists}
    */
    readonly overwriteIfExists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParseKeyValueToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseKeyValue | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParseKeyValueToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseKeyValue | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParseKeyValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParseKeyValue | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParseKeyValue | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _fieldDelimiter?;
    get fieldDelimiter(): string;
    set fieldDelimiter(value: string);
    resetFieldDelimiter(): void;
    get fieldDelimiterInput(): string | undefined;
    private _keyPrefix?;
    get keyPrefix(): string;
    set keyPrefix(value: string);
    resetKeyPrefix(): void;
    get keyPrefixInput(): string | undefined;
    private _keyValueDelimiter?;
    get keyValueDelimiter(): string;
    set keyValueDelimiter(value: string);
    resetKeyValueDelimiter(): void;
    get keyValueDelimiterInput(): string | undefined;
    private _nonMatchValue?;
    get nonMatchValue(): string;
    set nonMatchValue(value: string);
    resetNonMatchValue(): void;
    get nonMatchValueInput(): string | undefined;
    private _overwriteIfExists?;
    get overwriteIfExists(): boolean | cdktn.IResolvable;
    set overwriteIfExists(value: boolean | cdktn.IResolvable);
    resetOverwriteIfExists(): void;
    get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParseKeyValueList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParseKeyValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParseKeyValueOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParsePostgres {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParsePostgresToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParsePostgres | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParsePostgresToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParsePostgres | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParsePostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParsePostgres | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParsePostgres | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParsePostgresList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParsePostgres[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParsePostgresOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParseRoute53 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParseRoute53ToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseRoute53 | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParseRoute53ToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseRoute53 | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParseRoute53OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParseRoute53 | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParseRoute53 | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParseRoute53List extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParseRoute53[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParseRoute53OutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParseToOcsf {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#event_source CloudwatchLogTransformer#event_source}
    */
    readonly eventSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#ocsf_version CloudwatchLogTransformer#ocsf_version}
    */
    readonly ocsfVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParseToOcsfToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseToOcsf | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParseToOcsfToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseToOcsf | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParseToOcsfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParseToOcsf | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParseToOcsf | cdktn.IResolvable | undefined);
    private _eventSource?;
    get eventSource(): string;
    set eventSource(value: string);
    get eventSourceInput(): string | undefined;
    private _ocsfVersion?;
    get ocsfVersion(): string;
    set ocsfVersion(value: string);
    get ocsfVersionInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParseToOcsfList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParseToOcsf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParseToOcsfOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParseVpc {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParseVpcToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseVpc | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParseVpcToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseVpc | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParseVpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParseVpc | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParseVpc | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParseVpcList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParseVpc[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParseVpcOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigParseWaf {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source?: string;
}
export declare function cloudwatchLogTransformerTransformerConfigParseWafToTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseWaf | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigParseWafToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigParseWaf | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigParseWafOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigParseWaf | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigParseWaf | cdktn.IResolvable | undefined);
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigParseWafList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigParseWaf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigParseWafOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigRenameKeysEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#key CloudwatchLogTransformer#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#overwrite_if_exists CloudwatchLogTransformer#overwrite_if_exists}
    */
    readonly overwriteIfExists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#rename_to CloudwatchLogTransformer#rename_to}
    */
    readonly renameTo: string;
}
export declare function cloudwatchLogTransformerTransformerConfigRenameKeysEntryToTerraform(struct?: CloudwatchLogTransformerTransformerConfigRenameKeysEntry | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigRenameKeysEntryToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigRenameKeysEntry | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigRenameKeysEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigRenameKeysEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigRenameKeysEntry | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _overwriteIfExists?;
    get overwriteIfExists(): boolean | cdktn.IResolvable;
    set overwriteIfExists(value: boolean | cdktn.IResolvable);
    resetOverwriteIfExists(): void;
    get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _renameTo?;
    get renameTo(): string;
    set renameTo(value: string);
    get renameToInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigRenameKeysEntryList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigRenameKeysEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigRenameKeysEntryOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigRenameKeys {
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#entry CloudwatchLogTransformer#entry}
    */
    readonly entry?: CloudwatchLogTransformerTransformerConfigRenameKeysEntry[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigRenameKeysToTerraform(struct?: CloudwatchLogTransformerTransformerConfigRenameKeys | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigRenameKeysToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigRenameKeys | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigRenameKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigRenameKeys | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigRenameKeys | cdktn.IResolvable | undefined);
    private _entry;
    get entry(): CloudwatchLogTransformerTransformerConfigRenameKeysEntryList;
    putEntry(value: CloudwatchLogTransformerTransformerConfigRenameKeysEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigRenameKeysEntry[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigRenameKeysList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigRenameKeys[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigRenameKeysOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigSplitStringEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#delimiter CloudwatchLogTransformer#delimiter}
    */
    readonly delimiter: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source: string;
}
export declare function cloudwatchLogTransformerTransformerConfigSplitStringEntryToTerraform(struct?: CloudwatchLogTransformerTransformerConfigSplitStringEntry | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigSplitStringEntryToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigSplitStringEntry | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigSplitStringEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigSplitStringEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigSplitStringEntry | cdktn.IResolvable | undefined);
    private _delimiter?;
    get delimiter(): string;
    set delimiter(value: string);
    get delimiterInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigSplitStringEntryList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigSplitStringEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigSplitStringEntryOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigSplitString {
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#entry CloudwatchLogTransformer#entry}
    */
    readonly entry?: CloudwatchLogTransformerTransformerConfigSplitStringEntry[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigSplitStringToTerraform(struct?: CloudwatchLogTransformerTransformerConfigSplitString | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigSplitStringToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigSplitString | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigSplitStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigSplitString | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigSplitString | cdktn.IResolvable | undefined);
    private _entry;
    get entry(): CloudwatchLogTransformerTransformerConfigSplitStringEntryList;
    putEntry(value: CloudwatchLogTransformerTransformerConfigSplitStringEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigSplitStringEntry[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigSplitStringList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigSplitString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigSplitStringOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigSubstituteStringEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#from CloudwatchLogTransformer#from}
    */
    readonly from: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#source CloudwatchLogTransformer#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#to CloudwatchLogTransformer#to}
    */
    readonly to: string;
}
export declare function cloudwatchLogTransformerTransformerConfigSubstituteStringEntryToTerraform(struct?: CloudwatchLogTransformerTransformerConfigSubstituteStringEntry | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigSubstituteStringEntryToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigSubstituteStringEntry | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigSubstituteStringEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigSubstituteStringEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigSubstituteStringEntry | cdktn.IResolvable | undefined);
    private _from?;
    get from(): string;
    set from(value: string);
    get fromInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _to?;
    get to(): string;
    set to(value: string);
    get toInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigSubstituteStringEntryList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigSubstituteStringEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigSubstituteStringEntryOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigSubstituteString {
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#entry CloudwatchLogTransformer#entry}
    */
    readonly entry?: CloudwatchLogTransformerTransformerConfigSubstituteStringEntry[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigSubstituteStringToTerraform(struct?: CloudwatchLogTransformerTransformerConfigSubstituteString | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigSubstituteStringToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigSubstituteString | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigSubstituteStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigSubstituteString | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigSubstituteString | cdktn.IResolvable | undefined);
    private _entry;
    get entry(): CloudwatchLogTransformerTransformerConfigSubstituteStringEntryList;
    putEntry(value: CloudwatchLogTransformerTransformerConfigSubstituteStringEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigSubstituteStringEntry[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigSubstituteStringList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigSubstituteString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigSubstituteStringOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigTrimString {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#with_keys CloudwatchLogTransformer#with_keys}
    */
    readonly withKeys: string[];
}
export declare function cloudwatchLogTransformerTransformerConfigTrimStringToTerraform(struct?: CloudwatchLogTransformerTransformerConfigTrimString | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigTrimStringToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigTrimString | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigTrimStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigTrimString | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigTrimString | cdktn.IResolvable | undefined);
    private _withKeys?;
    get withKeys(): string[];
    set withKeys(value: string[]);
    get withKeysInput(): string[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigTrimStringList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigTrimString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigTrimStringOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigTypeConverterEntry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#key CloudwatchLogTransformer#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#type CloudwatchLogTransformer#type}
    */
    readonly type: string;
}
export declare function cloudwatchLogTransformerTransformerConfigTypeConverterEntryToTerraform(struct?: CloudwatchLogTransformerTransformerConfigTypeConverterEntry | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigTypeConverterEntryToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigTypeConverterEntry | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigTypeConverterEntryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigTypeConverterEntry | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigTypeConverterEntry | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigTypeConverterEntryList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigTypeConverterEntry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigTypeConverterEntryOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigTypeConverter {
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#entry CloudwatchLogTransformer#entry}
    */
    readonly entry?: CloudwatchLogTransformerTransformerConfigTypeConverterEntry[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigTypeConverterToTerraform(struct?: CloudwatchLogTransformerTransformerConfigTypeConverter | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigTypeConverterToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigTypeConverter | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigTypeConverterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigTypeConverter | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigTypeConverter | cdktn.IResolvable | undefined);
    private _entry;
    get entry(): CloudwatchLogTransformerTransformerConfigTypeConverterEntryList;
    putEntry(value: CloudwatchLogTransformerTransformerConfigTypeConverterEntry[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigTypeConverterEntry[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigTypeConverterList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigTypeConverter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigTypeConverterOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfigUpperCaseString {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#with_keys CloudwatchLogTransformer#with_keys}
    */
    readonly withKeys: string[];
}
export declare function cloudwatchLogTransformerTransformerConfigUpperCaseStringToTerraform(struct?: CloudwatchLogTransformerTransformerConfigUpperCaseString | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigUpperCaseStringToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfigUpperCaseString | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigUpperCaseStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfigUpperCaseString | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfigUpperCaseString | cdktn.IResolvable | undefined);
    private _withKeys?;
    get withKeys(): string[];
    set withKeys(value: string[]);
    get withKeysInput(): string[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigUpperCaseStringList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfigUpperCaseString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigUpperCaseStringOutputReference;
}
export interface CloudwatchLogTransformerTransformerConfig {
    /**
    * add_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#add_keys CloudwatchLogTransformer#add_keys}
    */
    readonly addKeys?: CloudwatchLogTransformerTransformerConfigAddKeys[] | cdktn.IResolvable;
    /**
    * copy_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#copy_value CloudwatchLogTransformer#copy_value}
    */
    readonly copyValue?: CloudwatchLogTransformerTransformerConfigCopyValue[] | cdktn.IResolvable;
    /**
    * csv block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#csv CloudwatchLogTransformer#csv}
    */
    readonly csv?: CloudwatchLogTransformerTransformerConfigCsv[] | cdktn.IResolvable;
    /**
    * date_time_converter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#date_time_converter CloudwatchLogTransformer#date_time_converter}
    */
    readonly dateTimeConverter?: CloudwatchLogTransformerTransformerConfigDateTimeConverter[] | cdktn.IResolvable;
    /**
    * delete_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#delete_keys CloudwatchLogTransformer#delete_keys}
    */
    readonly deleteKeys?: CloudwatchLogTransformerTransformerConfigDeleteKeys[] | cdktn.IResolvable;
    /**
    * grok block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#grok CloudwatchLogTransformer#grok}
    */
    readonly grok?: CloudwatchLogTransformerTransformerConfigGrok[] | cdktn.IResolvable;
    /**
    * list_to_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#list_to_map CloudwatchLogTransformer#list_to_map}
    */
    readonly listToMap?: CloudwatchLogTransformerTransformerConfigListToMap[] | cdktn.IResolvable;
    /**
    * lower_case_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#lower_case_string CloudwatchLogTransformer#lower_case_string}
    */
    readonly lowerCaseString?: CloudwatchLogTransformerTransformerConfigLowerCaseString[] | cdktn.IResolvable;
    /**
    * move_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#move_keys CloudwatchLogTransformer#move_keys}
    */
    readonly moveKeys?: CloudwatchLogTransformerTransformerConfigMoveKeys[] | cdktn.IResolvable;
    /**
    * parse_cloudfront block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_cloudfront CloudwatchLogTransformer#parse_cloudfront}
    */
    readonly parseCloudfront?: CloudwatchLogTransformerTransformerConfigParseCloudfront[] | cdktn.IResolvable;
    /**
    * parse_json block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_json CloudwatchLogTransformer#parse_json}
    */
    readonly parseJson?: CloudwatchLogTransformerTransformerConfigParseJson[] | cdktn.IResolvable;
    /**
    * parse_key_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_key_value CloudwatchLogTransformer#parse_key_value}
    */
    readonly parseKeyValue?: CloudwatchLogTransformerTransformerConfigParseKeyValue[] | cdktn.IResolvable;
    /**
    * parse_postgres block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_postgres CloudwatchLogTransformer#parse_postgres}
    */
    readonly parsePostgres?: CloudwatchLogTransformerTransformerConfigParsePostgres[] | cdktn.IResolvable;
    /**
    * parse_route53 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_route53 CloudwatchLogTransformer#parse_route53}
    */
    readonly parseRoute53?: CloudwatchLogTransformerTransformerConfigParseRoute53[] | cdktn.IResolvable;
    /**
    * parse_to_ocsf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_to_ocsf CloudwatchLogTransformer#parse_to_ocsf}
    */
    readonly parseToOcsf?: CloudwatchLogTransformerTransformerConfigParseToOcsf[] | cdktn.IResolvable;
    /**
    * parse_vpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_vpc CloudwatchLogTransformer#parse_vpc}
    */
    readonly parseVpc?: CloudwatchLogTransformerTransformerConfigParseVpc[] | cdktn.IResolvable;
    /**
    * parse_waf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#parse_waf CloudwatchLogTransformer#parse_waf}
    */
    readonly parseWaf?: CloudwatchLogTransformerTransformerConfigParseWaf[] | cdktn.IResolvable;
    /**
    * rename_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#rename_keys CloudwatchLogTransformer#rename_keys}
    */
    readonly renameKeys?: CloudwatchLogTransformerTransformerConfigRenameKeys[] | cdktn.IResolvable;
    /**
    * split_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#split_string CloudwatchLogTransformer#split_string}
    */
    readonly splitString?: CloudwatchLogTransformerTransformerConfigSplitString[] | cdktn.IResolvable;
    /**
    * substitute_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#substitute_string CloudwatchLogTransformer#substitute_string}
    */
    readonly substituteString?: CloudwatchLogTransformerTransformerConfigSubstituteString[] | cdktn.IResolvable;
    /**
    * trim_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#trim_string CloudwatchLogTransformer#trim_string}
    */
    readonly trimString?: CloudwatchLogTransformerTransformerConfigTrimString[] | cdktn.IResolvable;
    /**
    * type_converter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#type_converter CloudwatchLogTransformer#type_converter}
    */
    readonly typeConverter?: CloudwatchLogTransformerTransformerConfigTypeConverter[] | cdktn.IResolvable;
    /**
    * upper_case_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#upper_case_string CloudwatchLogTransformer#upper_case_string}
    */
    readonly upperCaseString?: CloudwatchLogTransformerTransformerConfigUpperCaseString[] | cdktn.IResolvable;
}
export declare function cloudwatchLogTransformerTransformerConfigToTerraform(struct?: CloudwatchLogTransformerTransformerConfig | cdktn.IResolvable): any;
export declare function cloudwatchLogTransformerTransformerConfigToHclTerraform(struct?: CloudwatchLogTransformerTransformerConfig | cdktn.IResolvable): any;
export declare class CloudwatchLogTransformerTransformerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchLogTransformerTransformerConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchLogTransformerTransformerConfig | cdktn.IResolvable | undefined);
    private _addKeys;
    get addKeys(): CloudwatchLogTransformerTransformerConfigAddKeysList;
    putAddKeys(value: CloudwatchLogTransformerTransformerConfigAddKeys[] | cdktn.IResolvable): void;
    resetAddKeys(): void;
    get addKeysInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigAddKeys[] | undefined;
    private _copyValue;
    get copyValue(): CloudwatchLogTransformerTransformerConfigCopyValueList;
    putCopyValue(value: CloudwatchLogTransformerTransformerConfigCopyValue[] | cdktn.IResolvable): void;
    resetCopyValue(): void;
    get copyValueInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigCopyValue[] | undefined;
    private _csv;
    get csv(): CloudwatchLogTransformerTransformerConfigCsvList;
    putCsv(value: CloudwatchLogTransformerTransformerConfigCsv[] | cdktn.IResolvable): void;
    resetCsv(): void;
    get csvInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigCsv[] | undefined;
    private _dateTimeConverter;
    get dateTimeConverter(): CloudwatchLogTransformerTransformerConfigDateTimeConverterList;
    putDateTimeConverter(value: CloudwatchLogTransformerTransformerConfigDateTimeConverter[] | cdktn.IResolvable): void;
    resetDateTimeConverter(): void;
    get dateTimeConverterInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigDateTimeConverter[] | undefined;
    private _deleteKeys;
    get deleteKeys(): CloudwatchLogTransformerTransformerConfigDeleteKeysList;
    putDeleteKeys(value: CloudwatchLogTransformerTransformerConfigDeleteKeys[] | cdktn.IResolvable): void;
    resetDeleteKeys(): void;
    get deleteKeysInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigDeleteKeys[] | undefined;
    private _grok;
    get grok(): CloudwatchLogTransformerTransformerConfigGrokList;
    putGrok(value: CloudwatchLogTransformerTransformerConfigGrok[] | cdktn.IResolvable): void;
    resetGrok(): void;
    get grokInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigGrok[] | undefined;
    private _listToMap;
    get listToMap(): CloudwatchLogTransformerTransformerConfigListToMapList;
    putListToMap(value: CloudwatchLogTransformerTransformerConfigListToMap[] | cdktn.IResolvable): void;
    resetListToMap(): void;
    get listToMapInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigListToMap[] | undefined;
    private _lowerCaseString;
    get lowerCaseString(): CloudwatchLogTransformerTransformerConfigLowerCaseStringList;
    putLowerCaseString(value: CloudwatchLogTransformerTransformerConfigLowerCaseString[] | cdktn.IResolvable): void;
    resetLowerCaseString(): void;
    get lowerCaseStringInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigLowerCaseString[] | undefined;
    private _moveKeys;
    get moveKeys(): CloudwatchLogTransformerTransformerConfigMoveKeysList;
    putMoveKeys(value: CloudwatchLogTransformerTransformerConfigMoveKeys[] | cdktn.IResolvable): void;
    resetMoveKeys(): void;
    get moveKeysInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigMoveKeys[] | undefined;
    private _parseCloudfront;
    get parseCloudfront(): CloudwatchLogTransformerTransformerConfigParseCloudfrontList;
    putParseCloudfront(value: CloudwatchLogTransformerTransformerConfigParseCloudfront[] | cdktn.IResolvable): void;
    resetParseCloudfront(): void;
    get parseCloudfrontInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParseCloudfront[] | undefined;
    private _parseJson;
    get parseJson(): CloudwatchLogTransformerTransformerConfigParseJsonList;
    putParseJson(value: CloudwatchLogTransformerTransformerConfigParseJson[] | cdktn.IResolvable): void;
    resetParseJson(): void;
    get parseJsonInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParseJson[] | undefined;
    private _parseKeyValue;
    get parseKeyValue(): CloudwatchLogTransformerTransformerConfigParseKeyValueList;
    putParseKeyValue(value: CloudwatchLogTransformerTransformerConfigParseKeyValue[] | cdktn.IResolvable): void;
    resetParseKeyValue(): void;
    get parseKeyValueInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParseKeyValue[] | undefined;
    private _parsePostgres;
    get parsePostgres(): CloudwatchLogTransformerTransformerConfigParsePostgresList;
    putParsePostgres(value: CloudwatchLogTransformerTransformerConfigParsePostgres[] | cdktn.IResolvable): void;
    resetParsePostgres(): void;
    get parsePostgresInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParsePostgres[] | undefined;
    private _parseRoute53;
    get parseRoute53(): CloudwatchLogTransformerTransformerConfigParseRoute53List;
    putParseRoute53(value: CloudwatchLogTransformerTransformerConfigParseRoute53[] | cdktn.IResolvable): void;
    resetParseRoute53(): void;
    get parseRoute53Input(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParseRoute53[] | undefined;
    private _parseToOcsf;
    get parseToOcsf(): CloudwatchLogTransformerTransformerConfigParseToOcsfList;
    putParseToOcsf(value: CloudwatchLogTransformerTransformerConfigParseToOcsf[] | cdktn.IResolvable): void;
    resetParseToOcsf(): void;
    get parseToOcsfInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParseToOcsf[] | undefined;
    private _parseVpc;
    get parseVpc(): CloudwatchLogTransformerTransformerConfigParseVpcList;
    putParseVpc(value: CloudwatchLogTransformerTransformerConfigParseVpc[] | cdktn.IResolvable): void;
    resetParseVpc(): void;
    get parseVpcInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParseVpc[] | undefined;
    private _parseWaf;
    get parseWaf(): CloudwatchLogTransformerTransformerConfigParseWafList;
    putParseWaf(value: CloudwatchLogTransformerTransformerConfigParseWaf[] | cdktn.IResolvable): void;
    resetParseWaf(): void;
    get parseWafInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigParseWaf[] | undefined;
    private _renameKeys;
    get renameKeys(): CloudwatchLogTransformerTransformerConfigRenameKeysList;
    putRenameKeys(value: CloudwatchLogTransformerTransformerConfigRenameKeys[] | cdktn.IResolvable): void;
    resetRenameKeys(): void;
    get renameKeysInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigRenameKeys[] | undefined;
    private _splitString;
    get splitString(): CloudwatchLogTransformerTransformerConfigSplitStringList;
    putSplitString(value: CloudwatchLogTransformerTransformerConfigSplitString[] | cdktn.IResolvable): void;
    resetSplitString(): void;
    get splitStringInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigSplitString[] | undefined;
    private _substituteString;
    get substituteString(): CloudwatchLogTransformerTransformerConfigSubstituteStringList;
    putSubstituteString(value: CloudwatchLogTransformerTransformerConfigSubstituteString[] | cdktn.IResolvable): void;
    resetSubstituteString(): void;
    get substituteStringInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigSubstituteString[] | undefined;
    private _trimString;
    get trimString(): CloudwatchLogTransformerTransformerConfigTrimStringList;
    putTrimString(value: CloudwatchLogTransformerTransformerConfigTrimString[] | cdktn.IResolvable): void;
    resetTrimString(): void;
    get trimStringInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigTrimString[] | undefined;
    private _typeConverter;
    get typeConverter(): CloudwatchLogTransformerTransformerConfigTypeConverterList;
    putTypeConverter(value: CloudwatchLogTransformerTransformerConfigTypeConverter[] | cdktn.IResolvable): void;
    resetTypeConverter(): void;
    get typeConverterInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigTypeConverter[] | undefined;
    private _upperCaseString;
    get upperCaseString(): CloudwatchLogTransformerTransformerConfigUpperCaseStringList;
    putUpperCaseString(value: CloudwatchLogTransformerTransformerConfigUpperCaseString[] | cdktn.IResolvable): void;
    resetUpperCaseString(): void;
    get upperCaseStringInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfigUpperCaseString[] | undefined;
}
export declare class CloudwatchLogTransformerTransformerConfigList extends cdktn.ComplexList {
    internalValue?: CloudwatchLogTransformerTransformerConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchLogTransformerTransformerConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer aws_cloudwatch_log_transformer}
*/
export declare class CloudwatchLogTransformer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_transformer";
    /**
    * Generates CDKTN code for importing a CloudwatchLogTransformer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchLogTransformer to import
    * @param importFromId The id of the existing CloudwatchLogTransformer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchLogTransformer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_log_transformer aws_cloudwatch_log_transformer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchLogTransformerConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchLogTransformerConfig);
    private _logGroupArn?;
    get logGroupArn(): string;
    set logGroupArn(value: string);
    get logGroupArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _transformerConfig;
    get transformerConfig(): CloudwatchLogTransformerTransformerConfigList;
    putTransformerConfig(value: CloudwatchLogTransformerTransformerConfig[] | cdktn.IResolvable): void;
    resetTransformerConfig(): void;
    get transformerConfigInput(): cdktn.IResolvable | CloudwatchLogTransformerTransformerConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
