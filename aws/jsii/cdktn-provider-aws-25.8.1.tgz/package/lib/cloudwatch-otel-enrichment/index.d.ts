/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchOtelEnrichmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#region CloudwatchOtelEnrichment#region}
    */
    readonly region?: string;
    /**
    * exclude_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#exclude_filter CloudwatchOtelEnrichment#exclude_filter}
    */
    readonly excludeFilter?: CloudwatchOtelEnrichmentExcludeFilter[] | cdktn.IResolvable;
    /**
    * include_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#include_filter CloudwatchOtelEnrichment#include_filter}
    */
    readonly includeFilter?: CloudwatchOtelEnrichmentIncludeFilter[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#timeouts CloudwatchOtelEnrichment#timeouts}
    */
    readonly timeouts?: CloudwatchOtelEnrichmentTimeouts;
}
export interface CloudwatchOtelEnrichmentExcludeFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#metric_names CloudwatchOtelEnrichment#metric_names}
    */
    readonly metricNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#namespace CloudwatchOtelEnrichment#namespace}
    */
    readonly namespace: string;
}
export declare function cloudwatchOtelEnrichmentExcludeFilterToTerraform(struct?: CloudwatchOtelEnrichmentExcludeFilter | cdktn.IResolvable): any;
export declare function cloudwatchOtelEnrichmentExcludeFilterToHclTerraform(struct?: CloudwatchOtelEnrichmentExcludeFilter | cdktn.IResolvable): any;
export declare class CloudwatchOtelEnrichmentExcludeFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchOtelEnrichmentExcludeFilter | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchOtelEnrichmentExcludeFilter | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    resetMetricNames(): void;
    get metricNamesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
}
export declare class CloudwatchOtelEnrichmentExcludeFilterList extends cdktn.ComplexList {
    internalValue?: CloudwatchOtelEnrichmentExcludeFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchOtelEnrichmentExcludeFilterOutputReference;
}
export interface CloudwatchOtelEnrichmentIncludeFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#metric_names CloudwatchOtelEnrichment#metric_names}
    */
    readonly metricNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#namespace CloudwatchOtelEnrichment#namespace}
    */
    readonly namespace: string;
}
export declare function cloudwatchOtelEnrichmentIncludeFilterToTerraform(struct?: CloudwatchOtelEnrichmentIncludeFilter | cdktn.IResolvable): any;
export declare function cloudwatchOtelEnrichmentIncludeFilterToHclTerraform(struct?: CloudwatchOtelEnrichmentIncludeFilter | cdktn.IResolvable): any;
export declare class CloudwatchOtelEnrichmentIncludeFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchOtelEnrichmentIncludeFilter | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchOtelEnrichmentIncludeFilter | cdktn.IResolvable | undefined);
    private _metricNames?;
    get metricNames(): string[];
    set metricNames(value: string[]);
    resetMetricNames(): void;
    get metricNamesInput(): string[] | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
}
export declare class CloudwatchOtelEnrichmentIncludeFilterList extends cdktn.ComplexList {
    internalValue?: CloudwatchOtelEnrichmentIncludeFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchOtelEnrichmentIncludeFilterOutputReference;
}
export interface CloudwatchOtelEnrichmentTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#create CloudwatchOtelEnrichment#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#delete CloudwatchOtelEnrichment#delete}
    */
    readonly delete?: string;
}
export declare function cloudwatchOtelEnrichmentTimeoutsToTerraform(struct?: CloudwatchOtelEnrichmentTimeouts | cdktn.IResolvable): any;
export declare function cloudwatchOtelEnrichmentTimeoutsToHclTerraform(struct?: CloudwatchOtelEnrichmentTimeouts | cdktn.IResolvable): any;
export declare class CloudwatchOtelEnrichmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudwatchOtelEnrichmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchOtelEnrichmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment aws_cloudwatch_otel_enrichment}
*/
export declare class CloudwatchOtelEnrichment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_otel_enrichment";
    /**
    * Generates CDKTN code for importing a CloudwatchOtelEnrichment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchOtelEnrichment to import
    * @param importFromId The id of the existing CloudwatchOtelEnrichment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchOtelEnrichment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.69.1/docs/resources/cloudwatch_otel_enrichment aws_cloudwatch_otel_enrichment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchOtelEnrichmentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CloudwatchOtelEnrichmentConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _excludeFilter;
    get excludeFilter(): CloudwatchOtelEnrichmentExcludeFilterList;
    putExcludeFilter(value: CloudwatchOtelEnrichmentExcludeFilter[] | cdktn.IResolvable): void;
    resetExcludeFilter(): void;
    get excludeFilterInput(): cdktn.IResolvable | CloudwatchOtelEnrichmentExcludeFilter[] | undefined;
    private _includeFilter;
    get includeFilter(): CloudwatchOtelEnrichmentIncludeFilterList;
    putIncludeFilter(value: CloudwatchOtelEnrichmentIncludeFilter[] | cdktn.IResolvable): void;
    resetIncludeFilter(): void;
    get includeFilterInput(): cdktn.IResolvable | CloudwatchOtelEnrichmentIncludeFilter[] | undefined;
    private _timeouts;
    get timeouts(): CloudwatchOtelEnrichmentTimeoutsOutputReference;
    putTimeouts(value: CloudwatchOtelEnrichmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudwatchOtelEnrichmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
