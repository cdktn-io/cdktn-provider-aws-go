/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreEvaluatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#description BedrockagentcoreEvaluator#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#evaluator_name BedrockagentcoreEvaluator#evaluator_name}
    */
    readonly evaluatorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#kms_key_arn BedrockagentcoreEvaluator#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#level BedrockagentcoreEvaluator#level}
    */
    readonly level: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#region BedrockagentcoreEvaluator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#tags BedrockagentcoreEvaluator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * evaluator_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#evaluator_config BedrockagentcoreEvaluator#evaluator_config}
    */
    readonly evaluatorConfig?: BedrockagentcoreEvaluatorEvaluatorConfig[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#timeouts BedrockagentcoreEvaluator#timeouts}
    */
    readonly timeouts?: BedrockagentcoreEvaluatorTimeouts;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#lambda_arn BedrockagentcoreEvaluator#lambda_arn}
    */
    readonly lambdaArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#lambda_timeout_in_seconds BedrockagentcoreEvaluator#lambda_timeout_in_seconds}
    */
    readonly lambdaTimeoutInSeconds?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig | cdktn.IResolvable | undefined);
    private _lambdaArn?;
    get lambdaArn(): string;
    set lambdaArn(value: string);
    get lambdaArnInput(): string | undefined;
    private _lambdaTimeoutInSeconds?;
    get lambdaTimeoutInSeconds(): number;
    set lambdaTimeoutInSeconds(value: number);
    resetLambdaTimeoutInSeconds(): void;
    get lambdaTimeoutInSecondsInput(): number | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigCodeBased {
    /**
    * lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#lambda_config BedrockagentcoreEvaluator#lambda_config}
    */
    readonly lambdaConfig?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigCodeBasedToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased | cdktn.IResolvable | undefined);
    private _lambdaConfig;
    get lambdaConfig(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfigList;
    putLambdaConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig[] | cdktn.IResolvable): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedLambdaConfig[] | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#max_tokens BedrockagentcoreEvaluator#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#stop_sequences BedrockagentcoreEvaluator#stop_sequences}
    */
    readonly stopSequences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#temperature BedrockagentcoreEvaluator#temperature}
    */
    readonly temperature?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#top_p BedrockagentcoreEvaluator#top_p}
    */
    readonly topP?: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig | cdktn.IResolvable | undefined);
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _stopSequences?;
    get stopSequences(): string[];
    set stopSequences(value: string[]);
    resetStopSequences(): void;
    get stopSequencesInput(): string[] | undefined;
    private _temperature?;
    get temperature(): number;
    set temperature(value: number);
    resetTemperature(): void;
    get temperatureInput(): number | undefined;
    private _topP?;
    get topP(): number;
    set topP(value: number);
    resetTopP(): void;
    get topPInput(): number | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#additional_model_request_fields BedrockagentcoreEvaluator#additional_model_request_fields}
    */
    readonly additionalModelRequestFields?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#model_id BedrockagentcoreEvaluator#model_id}
    */
    readonly modelId: string;
    /**
    * inference_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#inference_config BedrockagentcoreEvaluator#inference_config}
    */
    readonly inferenceConfig?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig | cdktn.IResolvable | undefined);
    private _additionalModelRequestFields?;
    get additionalModelRequestFields(): string;
    set additionalModelRequestFields(value: string);
    resetAdditionalModelRequestFields(): void;
    get additionalModelRequestFieldsInput(): string | undefined;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _inferenceConfig;
    get inferenceConfig(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfigList;
    putInferenceConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig[] | cdktn.IResolvable): void;
    resetInferenceConfig(): void;
    get inferenceConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigInferenceConfig[] | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig {
    /**
    * bedrock_evaluator_model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#bedrock_evaluator_model_config BedrockagentcoreEvaluator#bedrock_evaluator_model_config}
    */
    readonly bedrockEvaluatorModelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig | cdktn.IResolvable | undefined);
    private _bedrockEvaluatorModelConfig;
    get bedrockEvaluatorModelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfigList;
    putBedrockEvaluatorModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig[] | cdktn.IResolvable): void;
    resetBedrockEvaluatorModelConfig(): void;
    get bedrockEvaluatorModelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigBedrockEvaluatorModelConfig[] | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#definition BedrockagentcoreEvaluator#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#label BedrockagentcoreEvaluator#label}
    */
    readonly label: string;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#definition BedrockagentcoreEvaluator#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#label BedrockagentcoreEvaluator#label}
    */
    readonly label: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#value BedrockagentcoreEvaluator#value}
    */
    readonly value: number;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale {
    /**
    * categorical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#categorical BedrockagentcoreEvaluator#categorical}
    */
    readonly categorical?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | cdktn.IResolvable;
    /**
    * numerical block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#numerical BedrockagentcoreEvaluator#numerical}
    */
    readonly numerical?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale | cdktn.IResolvable | undefined);
    private _categorical;
    get categorical(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategoricalList;
    putCategorical(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | cdktn.IResolvable): void;
    resetCategorical(): void;
    get categoricalInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleCategorical[] | undefined;
    private _numerical;
    get numerical(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumericalList;
    putNumerical(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | cdktn.IResolvable): void;
    resetNumerical(): void;
    get numericalInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleNumerical[] | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#instructions BedrockagentcoreEvaluator#instructions}
    */
    readonly instructions: string;
    /**
    * model_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#model_config BedrockagentcoreEvaluator#model_config}
    */
    readonly modelConfig?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig[] | cdktn.IResolvable;
    /**
    * rating_scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#rating_scale BedrockagentcoreEvaluator#rating_scale}
    */
    readonly ratingScale?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge | cdktn.IResolvable | undefined);
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    get instructionsInput(): string | undefined;
    private _modelConfig;
    get modelConfig(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfigList;
    putModelConfig(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig[] | cdktn.IResolvable): void;
    resetModelConfig(): void;
    get modelConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeModelConfig[] | undefined;
    private _ratingScale;
    get ratingScale(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScaleList;
    putRatingScale(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale[] | cdktn.IResolvable): void;
    resetRatingScale(): void;
    get ratingScaleInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeRatingScale[] | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeOutputReference;
}
export interface BedrockagentcoreEvaluatorEvaluatorConfig {
    /**
    * code_based block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#code_based BedrockagentcoreEvaluator#code_based}
    */
    readonly codeBased?: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased[] | cdktn.IResolvable;
    /**
    * llm_as_a_judge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#llm_as_a_judge BedrockagentcoreEvaluator#llm_as_a_judge}
    */
    readonly llmAsAJudge?: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreEvaluatorEvaluatorConfigToTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorEvaluatorConfigToHclTerraform(struct?: BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorEvaluatorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorEvaluatorConfig | cdktn.IResolvable | undefined);
    private _codeBased;
    get codeBased(): BedrockagentcoreEvaluatorEvaluatorConfigCodeBasedList;
    putCodeBased(value: BedrockagentcoreEvaluatorEvaluatorConfigCodeBased[] | cdktn.IResolvable): void;
    resetCodeBased(): void;
    get codeBasedInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigCodeBased[] | undefined;
    private _llmAsAJudge;
    get llmAsAJudge(): BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudgeList;
    putLlmAsAJudge(value: BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge[] | cdktn.IResolvable): void;
    resetLlmAsAJudge(): void;
    get llmAsAJudgeInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfigLlmAsAJudge[] | undefined;
}
export declare class BedrockagentcoreEvaluatorEvaluatorConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreEvaluatorEvaluatorConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreEvaluatorEvaluatorConfigOutputReference;
}
export interface BedrockagentcoreEvaluatorTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#create BedrockagentcoreEvaluator#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#delete BedrockagentcoreEvaluator#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#update BedrockagentcoreEvaluator#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcoreEvaluatorTimeoutsToTerraform(struct?: BedrockagentcoreEvaluatorTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreEvaluatorTimeoutsToHclTerraform(struct?: BedrockagentcoreEvaluatorTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreEvaluatorTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreEvaluatorTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreEvaluatorTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator aws_bedrockagentcore_evaluator}
*/
export declare class BedrockagentcoreEvaluator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_evaluator";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreEvaluator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreEvaluator to import
    * @param importFromId The id of the existing BedrockagentcoreEvaluator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreEvaluator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_evaluator aws_bedrockagentcore_evaluator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreEvaluatorConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreEvaluatorConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get evaluatorArn(): string;
    get evaluatorId(): string;
    private _evaluatorName?;
    get evaluatorName(): string;
    set evaluatorName(value: string);
    get evaluatorNameInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    get levelInput(): string | undefined;
    get lockedForModification(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _evaluatorConfig;
    get evaluatorConfig(): BedrockagentcoreEvaluatorEvaluatorConfigList;
    putEvaluatorConfig(value: BedrockagentcoreEvaluatorEvaluatorConfig[] | cdktn.IResolvable): void;
    resetEvaluatorConfig(): void;
    get evaluatorConfigInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorEvaluatorConfig[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreEvaluatorTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreEvaluatorTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreEvaluatorTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
