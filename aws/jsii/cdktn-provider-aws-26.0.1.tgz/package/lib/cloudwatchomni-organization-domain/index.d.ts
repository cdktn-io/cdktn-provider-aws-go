/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudwatchomniOrganizationDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#domain_access_role_arn CloudwatchomniOrganizationDomain#domain_access_role_arn}
    */
    readonly domainAccessRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#identity_providers CloudwatchomniOrganizationDomain#identity_providers}
    */
    readonly identityProviders: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#name CloudwatchomniOrganizationDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#region CloudwatchomniOrganizationDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#tags CloudwatchomniOrganizationDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * identity_provider_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#identity_provider_configuration CloudwatchomniOrganizationDomain#identity_provider_configuration}
    */
    readonly identityProviderConfiguration?: CloudwatchomniOrganizationDomainIdentityProviderConfiguration[] | cdktn.IResolvable;
}
export interface CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#identity_center_instance_arn CloudwatchomniOrganizationDomain#identity_center_instance_arn}
    */
    readonly identityCenterInstanceArn: string;
}
export declare function cloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfigurationToTerraform(struct?: CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfigurationToHclTerraform(struct?: CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterInstanceArn?;
    get identityCenterInstanceArn(): string;
    set identityCenterInstanceArn(value: string);
    get identityCenterInstanceArnInput(): string | undefined;
}
export declare class CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfigurationList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfigurationOutputReference;
}
export interface CloudwatchomniOrganizationDomainIdentityProviderConfiguration {
    /**
    * identity_center_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#identity_center_configuration CloudwatchomniOrganizationDomain#identity_center_configuration}
    */
    readonly identityCenterConfiguration?: CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | cdktn.IResolvable;
}
export declare function cloudwatchomniOrganizationDomainIdentityProviderConfigurationToTerraform(struct?: CloudwatchomniOrganizationDomainIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare function cloudwatchomniOrganizationDomainIdentityProviderConfigurationToHclTerraform(struct?: CloudwatchomniOrganizationDomainIdentityProviderConfiguration | cdktn.IResolvable): any;
export declare class CloudwatchomniOrganizationDomainIdentityProviderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudwatchomniOrganizationDomainIdentityProviderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CloudwatchomniOrganizationDomainIdentityProviderConfiguration | cdktn.IResolvable | undefined);
    private _identityCenterConfiguration;
    get identityCenterConfiguration(): CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfigurationList;
    putIdentityCenterConfiguration(value: CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | cdktn.IResolvable): void;
    resetIdentityCenterConfiguration(): void;
    get identityCenterConfigurationInput(): cdktn.IResolvable | CloudwatchomniOrganizationDomainIdentityProviderConfigurationIdentityCenterConfiguration[] | undefined;
}
export declare class CloudwatchomniOrganizationDomainIdentityProviderConfigurationList extends cdktn.ComplexList {
    internalValue?: CloudwatchomniOrganizationDomainIdentityProviderConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudwatchomniOrganizationDomainIdentityProviderConfigurationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain aws_cloudwatchomni_organization_domain}
*/
export declare class CloudwatchomniOrganizationDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatchomni_organization_domain";
    /**
    * Generates CDKTN code for importing a CloudwatchomniOrganizationDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudwatchomniOrganizationDomain to import
    * @param importFromId The id of the existing CloudwatchomniOrganizationDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudwatchomniOrganizationDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudwatchomni_organization_domain aws_cloudwatchomni_organization_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudwatchomniOrganizationDomainConfig
    */
    constructor(scope: Construct, id: string, config: CloudwatchomniOrganizationDomainConfig);
    get arn(): string;
    get customEndpointUrls(): string[];
    private _domainAccessRoleArn?;
    get domainAccessRoleArn(): string;
    set domainAccessRoleArn(value: string);
    get domainAccessRoleArnInput(): string | undefined;
    get domainEndpointUrl(): string;
    get domainId(): string;
    get identityCenterApplicationArn(): string;
    private _identityProviders?;
    get identityProviders(): string[];
    set identityProviders(value: string[]);
    get identityProvidersInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get organizationId(): string;
    get ownerAccountId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _identityProviderConfiguration;
    get identityProviderConfiguration(): CloudwatchomniOrganizationDomainIdentityProviderConfigurationList;
    putIdentityProviderConfiguration(value: CloudwatchomniOrganizationDomainIdentityProviderConfiguration[] | cdktn.IResolvable): void;
    resetIdentityProviderConfiguration(): void;
    get identityProviderConfigurationInput(): cdktn.IResolvable | CloudwatchomniOrganizationDomainIdentityProviderConfiguration[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
