/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BudgetsBudgetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#account_id BudgetsBudget#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#billing_view_arn BudgetsBudget#billing_view_arn}
    */
    readonly billingViewArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#budget_type BudgetsBudget#budget_type}
    */
    readonly budgetType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#id BudgetsBudget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#limit_amount BudgetsBudget#limit_amount}
    */
    readonly limitAmount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#limit_unit BudgetsBudget#limit_unit}
    */
    readonly limitUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#metrics BudgetsBudget#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#name BudgetsBudget#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#name_prefix BudgetsBudget#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags_all BudgetsBudget#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#time_period_end BudgetsBudget#time_period_end}
    */
    readonly timePeriodEnd?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#time_period_start BudgetsBudget#time_period_start}
    */
    readonly timePeriodStart?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#time_unit BudgetsBudget#time_unit}
    */
    readonly timeUnit: string;
    /**
    * auto_adjust_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#auto_adjust_data BudgetsBudget#auto_adjust_data}
    */
    readonly autoAdjustData?: BudgetsBudgetAutoAdjustData;
    /**
    * cost_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_filter BudgetsBudget#cost_filter}
    */
    readonly costFilter?: BudgetsBudgetCostFilter[] | cdktn.IResolvable;
    /**
    * cost_types block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_types BudgetsBudget#cost_types}
    */
    readonly costTypes?: BudgetsBudgetCostTypes;
    /**
    * filter_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#filter_expression BudgetsBudget#filter_expression}
    */
    readonly filterExpression?: BudgetsBudgetFilterExpression;
    /**
    * notification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#notification BudgetsBudget#notification}
    */
    readonly notification?: BudgetsBudgetNotification[] | cdktn.IResolvable;
    /**
    * planned_limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#planned_limit BudgetsBudget#planned_limit}
    */
    readonly plannedLimit?: BudgetsBudgetPlannedLimit[] | cdktn.IResolvable;
}
export interface BudgetsBudgetAutoAdjustDataHistoricalOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#budget_adjustment_period BudgetsBudget#budget_adjustment_period}
    */
    readonly budgetAdjustmentPeriod: number;
}
export declare function budgetsBudgetAutoAdjustDataHistoricalOptionsToTerraform(struct?: BudgetsBudgetAutoAdjustDataHistoricalOptionsOutputReference | BudgetsBudgetAutoAdjustDataHistoricalOptions): any;
export declare function budgetsBudgetAutoAdjustDataHistoricalOptionsToHclTerraform(struct?: BudgetsBudgetAutoAdjustDataHistoricalOptionsOutputReference | BudgetsBudgetAutoAdjustDataHistoricalOptions): any;
export declare class BudgetsBudgetAutoAdjustDataHistoricalOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetAutoAdjustDataHistoricalOptions | undefined;
    set internalValue(value: BudgetsBudgetAutoAdjustDataHistoricalOptions | undefined);
    private _budgetAdjustmentPeriod?;
    get budgetAdjustmentPeriod(): number;
    set budgetAdjustmentPeriod(value: number);
    get budgetAdjustmentPeriodInput(): number | undefined;
    get lookbackAvailablePeriods(): number;
}
export interface BudgetsBudgetAutoAdjustData {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#auto_adjust_type BudgetsBudget#auto_adjust_type}
    */
    readonly autoAdjustType: string;
    /**
    * historical_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#historical_options BudgetsBudget#historical_options}
    */
    readonly historicalOptions?: BudgetsBudgetAutoAdjustDataHistoricalOptions;
}
export declare function budgetsBudgetAutoAdjustDataToTerraform(struct?: BudgetsBudgetAutoAdjustDataOutputReference | BudgetsBudgetAutoAdjustData): any;
export declare function budgetsBudgetAutoAdjustDataToHclTerraform(struct?: BudgetsBudgetAutoAdjustDataOutputReference | BudgetsBudgetAutoAdjustData): any;
export declare class BudgetsBudgetAutoAdjustDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetAutoAdjustData | undefined;
    set internalValue(value: BudgetsBudgetAutoAdjustData | undefined);
    private _autoAdjustType?;
    get autoAdjustType(): string;
    set autoAdjustType(value: string);
    get autoAdjustTypeInput(): string | undefined;
    get lastAutoAdjustTime(): string;
    private _historicalOptions;
    get historicalOptions(): BudgetsBudgetAutoAdjustDataHistoricalOptionsOutputReference;
    putHistoricalOptions(value: BudgetsBudgetAutoAdjustDataHistoricalOptions): void;
    resetHistoricalOptions(): void;
    get historicalOptionsInput(): BudgetsBudgetAutoAdjustDataHistoricalOptions | undefined;
}
export interface BudgetsBudgetCostFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#name BudgetsBudget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetCostFilterToTerraform(struct?: BudgetsBudgetCostFilter | cdktn.IResolvable): any;
export declare function budgetsBudgetCostFilterToHclTerraform(struct?: BudgetsBudgetCostFilter | cdktn.IResolvable): any;
export declare class BudgetsBudgetCostFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetCostFilter | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetCostFilter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class BudgetsBudgetCostFilterList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetCostFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetCostFilterOutputReference;
}
export interface BudgetsBudgetCostTypes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_credit BudgetsBudget#include_credit}
    */
    readonly includeCredit?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_discount BudgetsBudget#include_discount}
    */
    readonly includeDiscount?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_other_subscription BudgetsBudget#include_other_subscription}
    */
    readonly includeOtherSubscription?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_recurring BudgetsBudget#include_recurring}
    */
    readonly includeRecurring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_refund BudgetsBudget#include_refund}
    */
    readonly includeRefund?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_subscription BudgetsBudget#include_subscription}
    */
    readonly includeSubscription?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_support BudgetsBudget#include_support}
    */
    readonly includeSupport?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_tax BudgetsBudget#include_tax}
    */
    readonly includeTax?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#include_upfront BudgetsBudget#include_upfront}
    */
    readonly includeUpfront?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#use_amortized BudgetsBudget#use_amortized}
    */
    readonly useAmortized?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#use_blended BudgetsBudget#use_blended}
    */
    readonly useBlended?: boolean | cdktn.IResolvable;
}
export declare function budgetsBudgetCostTypesToTerraform(struct?: BudgetsBudgetCostTypesOutputReference | BudgetsBudgetCostTypes): any;
export declare function budgetsBudgetCostTypesToHclTerraform(struct?: BudgetsBudgetCostTypesOutputReference | BudgetsBudgetCostTypes): any;
export declare class BudgetsBudgetCostTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetCostTypes | undefined;
    set internalValue(value: BudgetsBudgetCostTypes | undefined);
    private _includeCredit?;
    get includeCredit(): boolean | cdktn.IResolvable;
    set includeCredit(value: boolean | cdktn.IResolvable);
    resetIncludeCredit(): void;
    get includeCreditInput(): boolean | cdktn.IResolvable | undefined;
    private _includeDiscount?;
    get includeDiscount(): boolean | cdktn.IResolvable;
    set includeDiscount(value: boolean | cdktn.IResolvable);
    resetIncludeDiscount(): void;
    get includeDiscountInput(): boolean | cdktn.IResolvable | undefined;
    private _includeOtherSubscription?;
    get includeOtherSubscription(): boolean | cdktn.IResolvable;
    set includeOtherSubscription(value: boolean | cdktn.IResolvable);
    resetIncludeOtherSubscription(): void;
    get includeOtherSubscriptionInput(): boolean | cdktn.IResolvable | undefined;
    private _includeRecurring?;
    get includeRecurring(): boolean | cdktn.IResolvable;
    set includeRecurring(value: boolean | cdktn.IResolvable);
    resetIncludeRecurring(): void;
    get includeRecurringInput(): boolean | cdktn.IResolvable | undefined;
    private _includeRefund?;
    get includeRefund(): boolean | cdktn.IResolvable;
    set includeRefund(value: boolean | cdktn.IResolvable);
    resetIncludeRefund(): void;
    get includeRefundInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSubscription?;
    get includeSubscription(): boolean | cdktn.IResolvable;
    set includeSubscription(value: boolean | cdktn.IResolvable);
    resetIncludeSubscription(): void;
    get includeSubscriptionInput(): boolean | cdktn.IResolvable | undefined;
    private _includeSupport?;
    get includeSupport(): boolean | cdktn.IResolvable;
    set includeSupport(value: boolean | cdktn.IResolvable);
    resetIncludeSupport(): void;
    get includeSupportInput(): boolean | cdktn.IResolvable | undefined;
    private _includeTax?;
    get includeTax(): boolean | cdktn.IResolvable;
    set includeTax(value: boolean | cdktn.IResolvable);
    resetIncludeTax(): void;
    get includeTaxInput(): boolean | cdktn.IResolvable | undefined;
    private _includeUpfront?;
    get includeUpfront(): boolean | cdktn.IResolvable;
    set includeUpfront(value: boolean | cdktn.IResolvable);
    resetIncludeUpfront(): void;
    get includeUpfrontInput(): boolean | cdktn.IResolvable | undefined;
    private _useAmortized?;
    get useAmortized(): boolean | cdktn.IResolvable;
    set useAmortized(value: boolean | cdktn.IResolvable);
    resetUseAmortized(): void;
    get useAmortizedInput(): boolean | cdktn.IResolvable | undefined;
    private _useBlended?;
    get useBlended(): boolean | cdktn.IResolvable;
    set useBlended(value: boolean | cdktn.IResolvable);
    resetUseBlended(): void;
    get useBlendedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BudgetsBudgetFilterExpressionAndAndCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndAndCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionAndAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndAndCostCategories): any;
export declare function budgetsBudgetFilterExpressionAndAndCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndAndCostCategories): any;
export declare class BudgetsBudgetFilterExpressionAndAndCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndAndCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndAndCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndAndDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionAndAndDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionAndAndDimensionsOutputReference | BudgetsBudgetFilterExpressionAndAndDimensions): any;
export declare function budgetsBudgetFilterExpressionAndAndDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndAndDimensionsOutputReference | BudgetsBudgetFilterExpressionAndAndDimensions): any;
export declare class BudgetsBudgetFilterExpressionAndAndDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndAndDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndAndDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndAndTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndAndTagsToTerraform(struct?: BudgetsBudgetFilterExpressionAndAndTagsOutputReference | BudgetsBudgetFilterExpressionAndAndTags): any;
export declare function budgetsBudgetFilterExpressionAndAndTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndAndTagsOutputReference | BudgetsBudgetFilterExpressionAndAndTags): any;
export declare class BudgetsBudgetFilterExpressionAndAndTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndAndTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndAndTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndAnd {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionAndAndCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionAndAndDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionAndAndTags;
}
export declare function budgetsBudgetFilterExpressionAndAndToTerraform(struct?: BudgetsBudgetFilterExpressionAndAnd | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionAndAndToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndAnd | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionAndAndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionAndAnd | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndAnd | cdktn.IResolvable | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionAndAndCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionAndAndCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionAndAndCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionAndAndDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionAndAndDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionAndAndDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionAndAndTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionAndAndTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionAndAndTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionAndAndList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionAndAnd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionAndAndOutputReference;
}
export interface BudgetsBudgetFilterExpressionAndCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndCostCategories): any;
export declare function budgetsBudgetFilterExpressionAndCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndCostCategories): any;
export declare class BudgetsBudgetFilterExpressionAndCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionAndDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionAndDimensionsOutputReference | BudgetsBudgetFilterExpressionAndDimensions): any;
export declare function budgetsBudgetFilterExpressionAndDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndDimensionsOutputReference | BudgetsBudgetFilterExpressionAndDimensions): any;
export declare class BudgetsBudgetFilterExpressionAndDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndNotCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndNotCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionAndNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndNotCostCategories): any;
export declare function budgetsBudgetFilterExpressionAndNotCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndNotCostCategories): any;
export declare class BudgetsBudgetFilterExpressionAndNotCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndNotCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndNotCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndNotDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionAndNotDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionAndNotDimensionsOutputReference | BudgetsBudgetFilterExpressionAndNotDimensions): any;
export declare function budgetsBudgetFilterExpressionAndNotDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndNotDimensionsOutputReference | BudgetsBudgetFilterExpressionAndNotDimensions): any;
export declare class BudgetsBudgetFilterExpressionAndNotDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndNotDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndNotDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndNotTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndNotTagsToTerraform(struct?: BudgetsBudgetFilterExpressionAndNotTagsOutputReference | BudgetsBudgetFilterExpressionAndNotTags): any;
export declare function budgetsBudgetFilterExpressionAndNotTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndNotTagsOutputReference | BudgetsBudgetFilterExpressionAndNotTags): any;
export declare class BudgetsBudgetFilterExpressionAndNotTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndNotTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndNotTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndNot {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionAndNotCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionAndNotDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionAndNotTags;
}
export declare function budgetsBudgetFilterExpressionAndNotToTerraform(struct?: BudgetsBudgetFilterExpressionAndNotOutputReference | BudgetsBudgetFilterExpressionAndNot): any;
export declare function budgetsBudgetFilterExpressionAndNotToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndNotOutputReference | BudgetsBudgetFilterExpressionAndNot): any;
export declare class BudgetsBudgetFilterExpressionAndNotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndNot | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndNot | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionAndNotCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionAndNotCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionAndNotCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionAndNotDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionAndNotDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionAndNotDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionAndNotTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionAndNotTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionAndNotTags | undefined;
}
export interface BudgetsBudgetFilterExpressionAndOrCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndOrCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionAndOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndOrCostCategories): any;
export declare function budgetsBudgetFilterExpressionAndOrCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionAndOrCostCategories): any;
export declare class BudgetsBudgetFilterExpressionAndOrCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndOrCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndOrCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndOrDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionAndOrDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionAndOrDimensionsOutputReference | BudgetsBudgetFilterExpressionAndOrDimensions): any;
export declare function budgetsBudgetFilterExpressionAndOrDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndOrDimensionsOutputReference | BudgetsBudgetFilterExpressionAndOrDimensions): any;
export declare class BudgetsBudgetFilterExpressionAndOrDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndOrDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndOrDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndOrTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndOrTagsToTerraform(struct?: BudgetsBudgetFilterExpressionAndOrTagsOutputReference | BudgetsBudgetFilterExpressionAndOrTags): any;
export declare function budgetsBudgetFilterExpressionAndOrTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndOrTagsOutputReference | BudgetsBudgetFilterExpressionAndOrTags): any;
export declare class BudgetsBudgetFilterExpressionAndOrTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndOrTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndOrTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAndOr {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionAndOrCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionAndOrDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionAndOrTags;
}
export declare function budgetsBudgetFilterExpressionAndOrToTerraform(struct?: BudgetsBudgetFilterExpressionAndOr | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionAndOrToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndOr | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionAndOrOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionAndOr | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndOr | cdktn.IResolvable | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionAndOrCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionAndOrCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionAndOrCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionAndOrDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionAndOrDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionAndOrDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionAndOrTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionAndOrTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionAndOrTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionAndOrList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionAndOr[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionAndOrOutputReference;
}
export interface BudgetsBudgetFilterExpressionAndTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionAndTagsToTerraform(struct?: BudgetsBudgetFilterExpressionAndTagsOutputReference | BudgetsBudgetFilterExpressionAndTags): any;
export declare function budgetsBudgetFilterExpressionAndTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionAndTagsOutputReference | BudgetsBudgetFilterExpressionAndTags): any;
export declare class BudgetsBudgetFilterExpressionAndTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionAndTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAndTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionAnd {
    /**
    * and block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#and BudgetsBudget#and}
    */
    readonly and?: BudgetsBudgetFilterExpressionAndAnd[] | cdktn.IResolvable;
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionAndCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionAndDimensions;
    /**
    * not block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#not BudgetsBudget#not}
    */
    readonly not?: BudgetsBudgetFilterExpressionAndNot;
    /**
    * or block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#or BudgetsBudget#or}
    */
    readonly or?: BudgetsBudgetFilterExpressionAndOr[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionAndTags;
}
export declare function budgetsBudgetFilterExpressionAndToTerraform(struct?: BudgetsBudgetFilterExpressionAnd | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionAndToHclTerraform(struct?: BudgetsBudgetFilterExpressionAnd | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionAndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionAnd | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionAnd | cdktn.IResolvable | undefined);
    private _and;
    get and(): BudgetsBudgetFilterExpressionAndAndList;
    putAnd(value: BudgetsBudgetFilterExpressionAndAnd[] | cdktn.IResolvable): void;
    resetAnd(): void;
    get andInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionAndAnd[] | undefined;
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionAndCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionAndCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionAndCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionAndDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionAndDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionAndDimensions | undefined;
    private _not;
    get not(): BudgetsBudgetFilterExpressionAndNotOutputReference;
    putNot(value: BudgetsBudgetFilterExpressionAndNot): void;
    resetNot(): void;
    get notInput(): BudgetsBudgetFilterExpressionAndNot | undefined;
    private _or;
    get or(): BudgetsBudgetFilterExpressionAndOrList;
    putOr(value: BudgetsBudgetFilterExpressionAndOr[] | cdktn.IResolvable): void;
    resetOr(): void;
    get orInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionAndOr[] | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionAndTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionAndTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionAndTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionAndList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionAnd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionAndOutputReference;
}
export interface BudgetsBudgetFilterExpressionCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionCostCategoriesOutputReference | BudgetsBudgetFilterExpressionCostCategories): any;
export declare function budgetsBudgetFilterExpressionCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionCostCategoriesOutputReference | BudgetsBudgetFilterExpressionCostCategories): any;
export declare class BudgetsBudgetFilterExpressionCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionDimensionsOutputReference | BudgetsBudgetFilterExpressionDimensions): any;
export declare function budgetsBudgetFilterExpressionDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionDimensionsOutputReference | BudgetsBudgetFilterExpressionDimensions): any;
export declare class BudgetsBudgetFilterExpressionDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotAndCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotAndCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionNotAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotAndCostCategories): any;
export declare function budgetsBudgetFilterExpressionNotAndCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotAndCostCategories): any;
export declare class BudgetsBudgetFilterExpressionNotAndCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotAndCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotAndCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotAndDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionNotAndDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionNotAndDimensionsOutputReference | BudgetsBudgetFilterExpressionNotAndDimensions): any;
export declare function budgetsBudgetFilterExpressionNotAndDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotAndDimensionsOutputReference | BudgetsBudgetFilterExpressionNotAndDimensions): any;
export declare class BudgetsBudgetFilterExpressionNotAndDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotAndDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotAndDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotAndTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotAndTagsToTerraform(struct?: BudgetsBudgetFilterExpressionNotAndTagsOutputReference | BudgetsBudgetFilterExpressionNotAndTags): any;
export declare function budgetsBudgetFilterExpressionNotAndTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotAndTagsOutputReference | BudgetsBudgetFilterExpressionNotAndTags): any;
export declare class BudgetsBudgetFilterExpressionNotAndTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotAndTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotAndTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotAnd {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionNotAndCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionNotAndDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionNotAndTags;
}
export declare function budgetsBudgetFilterExpressionNotAndToTerraform(struct?: BudgetsBudgetFilterExpressionNotAnd | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionNotAndToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotAnd | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionNotAndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionNotAnd | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotAnd | cdktn.IResolvable | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionNotAndCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionNotAndCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionNotAndCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionNotAndDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionNotAndDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionNotAndDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionNotAndTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionNotAndTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionNotAndTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionNotAndList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionNotAnd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionNotAndOutputReference;
}
export interface BudgetsBudgetFilterExpressionNotCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotCostCategories): any;
export declare function budgetsBudgetFilterExpressionNotCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotCostCategories): any;
export declare class BudgetsBudgetFilterExpressionNotCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionNotDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionNotDimensionsOutputReference | BudgetsBudgetFilterExpressionNotDimensions): any;
export declare function budgetsBudgetFilterExpressionNotDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotDimensionsOutputReference | BudgetsBudgetFilterExpressionNotDimensions): any;
export declare class BudgetsBudgetFilterExpressionNotDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotNotCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotNotCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionNotNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotNotCostCategories): any;
export declare function budgetsBudgetFilterExpressionNotNotCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotNotCostCategories): any;
export declare class BudgetsBudgetFilterExpressionNotNotCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotNotCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotNotCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotNotDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionNotNotDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionNotNotDimensionsOutputReference | BudgetsBudgetFilterExpressionNotNotDimensions): any;
export declare function budgetsBudgetFilterExpressionNotNotDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotNotDimensionsOutputReference | BudgetsBudgetFilterExpressionNotNotDimensions): any;
export declare class BudgetsBudgetFilterExpressionNotNotDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotNotDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotNotDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotNotTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotNotTagsToTerraform(struct?: BudgetsBudgetFilterExpressionNotNotTagsOutputReference | BudgetsBudgetFilterExpressionNotNotTags): any;
export declare function budgetsBudgetFilterExpressionNotNotTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotNotTagsOutputReference | BudgetsBudgetFilterExpressionNotNotTags): any;
export declare class BudgetsBudgetFilterExpressionNotNotTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotNotTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotNotTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotNot {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionNotNotCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionNotNotDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionNotNotTags;
}
export declare function budgetsBudgetFilterExpressionNotNotToTerraform(struct?: BudgetsBudgetFilterExpressionNotNotOutputReference | BudgetsBudgetFilterExpressionNotNot): any;
export declare function budgetsBudgetFilterExpressionNotNotToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotNotOutputReference | BudgetsBudgetFilterExpressionNotNot): any;
export declare class BudgetsBudgetFilterExpressionNotNotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotNot | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotNot | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionNotNotCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionNotNotCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionNotNotCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionNotNotDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionNotNotDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionNotNotDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionNotNotTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionNotNotTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionNotNotTags | undefined;
}
export interface BudgetsBudgetFilterExpressionNotOrCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotOrCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionNotOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotOrCostCategories): any;
export declare function budgetsBudgetFilterExpressionNotOrCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionNotOrCostCategories): any;
export declare class BudgetsBudgetFilterExpressionNotOrCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotOrCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotOrCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotOrDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionNotOrDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionNotOrDimensionsOutputReference | BudgetsBudgetFilterExpressionNotOrDimensions): any;
export declare function budgetsBudgetFilterExpressionNotOrDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotOrDimensionsOutputReference | BudgetsBudgetFilterExpressionNotOrDimensions): any;
export declare class BudgetsBudgetFilterExpressionNotOrDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotOrDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotOrDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotOrTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotOrTagsToTerraform(struct?: BudgetsBudgetFilterExpressionNotOrTagsOutputReference | BudgetsBudgetFilterExpressionNotOrTags): any;
export declare function budgetsBudgetFilterExpressionNotOrTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotOrTagsOutputReference | BudgetsBudgetFilterExpressionNotOrTags): any;
export declare class BudgetsBudgetFilterExpressionNotOrTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotOrTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotOrTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNotOr {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionNotOrCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionNotOrDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionNotOrTags;
}
export declare function budgetsBudgetFilterExpressionNotOrToTerraform(struct?: BudgetsBudgetFilterExpressionNotOr | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionNotOrToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotOr | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionNotOrOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionNotOr | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotOr | cdktn.IResolvable | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionNotOrCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionNotOrCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionNotOrCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionNotOrDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionNotOrDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionNotOrDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionNotOrTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionNotOrTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionNotOrTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionNotOrList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionNotOr[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionNotOrOutputReference;
}
export interface BudgetsBudgetFilterExpressionNotTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionNotTagsToTerraform(struct?: BudgetsBudgetFilterExpressionNotTagsOutputReference | BudgetsBudgetFilterExpressionNotTags): any;
export declare function budgetsBudgetFilterExpressionNotTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotTagsOutputReference | BudgetsBudgetFilterExpressionNotTags): any;
export declare class BudgetsBudgetFilterExpressionNotTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNotTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNotTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionNot {
    /**
    * and block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#and BudgetsBudget#and}
    */
    readonly and?: BudgetsBudgetFilterExpressionNotAnd[] | cdktn.IResolvable;
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionNotCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionNotDimensions;
    /**
    * not block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#not BudgetsBudget#not}
    */
    readonly not?: BudgetsBudgetFilterExpressionNotNot;
    /**
    * or block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#or BudgetsBudget#or}
    */
    readonly or?: BudgetsBudgetFilterExpressionNotOr[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionNotTags;
}
export declare function budgetsBudgetFilterExpressionNotToTerraform(struct?: BudgetsBudgetFilterExpressionNotOutputReference | BudgetsBudgetFilterExpressionNot): any;
export declare function budgetsBudgetFilterExpressionNotToHclTerraform(struct?: BudgetsBudgetFilterExpressionNotOutputReference | BudgetsBudgetFilterExpressionNot): any;
export declare class BudgetsBudgetFilterExpressionNotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionNot | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionNot | undefined);
    private _and;
    get and(): BudgetsBudgetFilterExpressionNotAndList;
    putAnd(value: BudgetsBudgetFilterExpressionNotAnd[] | cdktn.IResolvable): void;
    resetAnd(): void;
    get andInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionNotAnd[] | undefined;
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionNotCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionNotCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionNotCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionNotDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionNotDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionNotDimensions | undefined;
    private _not;
    get not(): BudgetsBudgetFilterExpressionNotNotOutputReference;
    putNot(value: BudgetsBudgetFilterExpressionNotNot): void;
    resetNot(): void;
    get notInput(): BudgetsBudgetFilterExpressionNotNot | undefined;
    private _or;
    get or(): BudgetsBudgetFilterExpressionNotOrList;
    putOr(value: BudgetsBudgetFilterExpressionNotOr[] | cdktn.IResolvable): void;
    resetOr(): void;
    get orInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionNotOr[] | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionNotTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionNotTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionNotTags | undefined;
}
export interface BudgetsBudgetFilterExpressionOrAndCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrAndCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionOrAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrAndCostCategories): any;
export declare function budgetsBudgetFilterExpressionOrAndCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrAndCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrAndCostCategories): any;
export declare class BudgetsBudgetFilterExpressionOrAndCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrAndCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrAndCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrAndDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionOrAndDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionOrAndDimensionsOutputReference | BudgetsBudgetFilterExpressionOrAndDimensions): any;
export declare function budgetsBudgetFilterExpressionOrAndDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrAndDimensionsOutputReference | BudgetsBudgetFilterExpressionOrAndDimensions): any;
export declare class BudgetsBudgetFilterExpressionOrAndDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrAndDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrAndDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrAndTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrAndTagsToTerraform(struct?: BudgetsBudgetFilterExpressionOrAndTagsOutputReference | BudgetsBudgetFilterExpressionOrAndTags): any;
export declare function budgetsBudgetFilterExpressionOrAndTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrAndTagsOutputReference | BudgetsBudgetFilterExpressionOrAndTags): any;
export declare class BudgetsBudgetFilterExpressionOrAndTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrAndTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrAndTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrAnd {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionOrAndCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionOrAndDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionOrAndTags;
}
export declare function budgetsBudgetFilterExpressionOrAndToTerraform(struct?: BudgetsBudgetFilterExpressionOrAnd | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionOrAndToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrAnd | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionOrAndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionOrAnd | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrAnd | cdktn.IResolvable | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionOrAndCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionOrAndCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionOrAndCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionOrAndDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionOrAndDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionOrAndDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionOrAndTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionOrAndTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionOrAndTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionOrAndList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionOrAnd[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionOrAndOutputReference;
}
export interface BudgetsBudgetFilterExpressionOrCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrCostCategories): any;
export declare function budgetsBudgetFilterExpressionOrCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrCostCategories): any;
export declare class BudgetsBudgetFilterExpressionOrCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionOrDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionOrDimensionsOutputReference | BudgetsBudgetFilterExpressionOrDimensions): any;
export declare function budgetsBudgetFilterExpressionOrDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrDimensionsOutputReference | BudgetsBudgetFilterExpressionOrDimensions): any;
export declare class BudgetsBudgetFilterExpressionOrDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrNotCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrNotCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionOrNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrNotCostCategories): any;
export declare function budgetsBudgetFilterExpressionOrNotCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrNotCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrNotCostCategories): any;
export declare class BudgetsBudgetFilterExpressionOrNotCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrNotCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrNotCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrNotDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionOrNotDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionOrNotDimensionsOutputReference | BudgetsBudgetFilterExpressionOrNotDimensions): any;
export declare function budgetsBudgetFilterExpressionOrNotDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrNotDimensionsOutputReference | BudgetsBudgetFilterExpressionOrNotDimensions): any;
export declare class BudgetsBudgetFilterExpressionOrNotDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrNotDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrNotDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrNotTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrNotTagsToTerraform(struct?: BudgetsBudgetFilterExpressionOrNotTagsOutputReference | BudgetsBudgetFilterExpressionOrNotTags): any;
export declare function budgetsBudgetFilterExpressionOrNotTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrNotTagsOutputReference | BudgetsBudgetFilterExpressionOrNotTags): any;
export declare class BudgetsBudgetFilterExpressionOrNotTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrNotTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrNotTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrNot {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionOrNotCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionOrNotDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionOrNotTags;
}
export declare function budgetsBudgetFilterExpressionOrNotToTerraform(struct?: BudgetsBudgetFilterExpressionOrNotOutputReference | BudgetsBudgetFilterExpressionOrNot): any;
export declare function budgetsBudgetFilterExpressionOrNotToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrNotOutputReference | BudgetsBudgetFilterExpressionOrNot): any;
export declare class BudgetsBudgetFilterExpressionOrNotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrNot | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrNot | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionOrNotCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionOrNotCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionOrNotCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionOrNotDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionOrNotDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionOrNotDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionOrNotTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionOrNotTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionOrNotTags | undefined;
}
export interface BudgetsBudgetFilterExpressionOrOrCostCategories {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrOrCostCategoriesToTerraform(struct?: BudgetsBudgetFilterExpressionOrOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrOrCostCategories): any;
export declare function budgetsBudgetFilterExpressionOrOrCostCategoriesToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrOrCostCategoriesOutputReference | BudgetsBudgetFilterExpressionOrOrCostCategories): any;
export declare class BudgetsBudgetFilterExpressionOrOrCostCategoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrOrCostCategories | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrOrCostCategories | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrOrDimensions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values: string[];
}
export declare function budgetsBudgetFilterExpressionOrOrDimensionsToTerraform(struct?: BudgetsBudgetFilterExpressionOrOrDimensionsOutputReference | BudgetsBudgetFilterExpressionOrOrDimensions): any;
export declare function budgetsBudgetFilterExpressionOrOrDimensionsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrOrDimensionsOutputReference | BudgetsBudgetFilterExpressionOrOrDimensions): any;
export declare class BudgetsBudgetFilterExpressionOrOrDimensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrOrDimensions | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrOrDimensions | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrOrTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrOrTagsToTerraform(struct?: BudgetsBudgetFilterExpressionOrOrTagsOutputReference | BudgetsBudgetFilterExpressionOrOrTags): any;
export declare function budgetsBudgetFilterExpressionOrOrTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrOrTagsOutputReference | BudgetsBudgetFilterExpressionOrOrTags): any;
export declare class BudgetsBudgetFilterExpressionOrOrTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrOrTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrOrTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOrOr {
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionOrOrCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionOrOrDimensions;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionOrOrTags;
}
export declare function budgetsBudgetFilterExpressionOrOrToTerraform(struct?: BudgetsBudgetFilterExpressionOrOr | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionOrOrToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrOr | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionOrOrOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionOrOr | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrOr | cdktn.IResolvable | undefined);
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionOrOrCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionOrOrCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionOrOrCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionOrOrDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionOrOrDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionOrOrDimensions | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionOrOrTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionOrOrTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionOrOrTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionOrOrList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionOrOr[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionOrOrOutputReference;
}
export interface BudgetsBudgetFilterExpressionOrTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionOrTagsToTerraform(struct?: BudgetsBudgetFilterExpressionOrTagsOutputReference | BudgetsBudgetFilterExpressionOrTags): any;
export declare function budgetsBudgetFilterExpressionOrTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionOrTagsOutputReference | BudgetsBudgetFilterExpressionOrTags): any;
export declare class BudgetsBudgetFilterExpressionOrTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionOrTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOrTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpressionOr {
    /**
    * and block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#and BudgetsBudget#and}
    */
    readonly and?: BudgetsBudgetFilterExpressionOrAnd[] | cdktn.IResolvable;
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionOrCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionOrDimensions;
    /**
    * not block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#not BudgetsBudget#not}
    */
    readonly not?: BudgetsBudgetFilterExpressionOrNot;
    /**
    * or block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#or BudgetsBudget#or}
    */
    readonly or?: BudgetsBudgetFilterExpressionOrOr[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionOrTags;
}
export declare function budgetsBudgetFilterExpressionOrToTerraform(struct?: BudgetsBudgetFilterExpressionOr | cdktn.IResolvable): any;
export declare function budgetsBudgetFilterExpressionOrToHclTerraform(struct?: BudgetsBudgetFilterExpressionOr | cdktn.IResolvable): any;
export declare class BudgetsBudgetFilterExpressionOrOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetFilterExpressionOr | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionOr | cdktn.IResolvable | undefined);
    private _and;
    get and(): BudgetsBudgetFilterExpressionOrAndList;
    putAnd(value: BudgetsBudgetFilterExpressionOrAnd[] | cdktn.IResolvable): void;
    resetAnd(): void;
    get andInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionOrAnd[] | undefined;
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionOrCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionOrCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionOrCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionOrDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionOrDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionOrDimensions | undefined;
    private _not;
    get not(): BudgetsBudgetFilterExpressionOrNotOutputReference;
    putNot(value: BudgetsBudgetFilterExpressionOrNot): void;
    resetNot(): void;
    get notInput(): BudgetsBudgetFilterExpressionOrNot | undefined;
    private _or;
    get or(): BudgetsBudgetFilterExpressionOrOrList;
    putOr(value: BudgetsBudgetFilterExpressionOrOr[] | cdktn.IResolvable): void;
    resetOr(): void;
    get orInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionOrOr[] | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionOrTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionOrTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionOrTags | undefined;
}
export declare class BudgetsBudgetFilterExpressionOrList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetFilterExpressionOr[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetFilterExpressionOrOutputReference;
}
export interface BudgetsBudgetFilterExpressionTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#key BudgetsBudget#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#match_options BudgetsBudget#match_options}
    */
    readonly matchOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#values BudgetsBudget#values}
    */
    readonly values?: string[];
}
export declare function budgetsBudgetFilterExpressionTagsToTerraform(struct?: BudgetsBudgetFilterExpressionTagsOutputReference | BudgetsBudgetFilterExpressionTags): any;
export declare function budgetsBudgetFilterExpressionTagsToHclTerraform(struct?: BudgetsBudgetFilterExpressionTagsOutputReference | BudgetsBudgetFilterExpressionTags): any;
export declare class BudgetsBudgetFilterExpressionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpressionTags | undefined;
    set internalValue(value: BudgetsBudgetFilterExpressionTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _matchOptions?;
    get matchOptions(): string[];
    set matchOptions(value: string[]);
    resetMatchOptions(): void;
    get matchOptionsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetsBudgetFilterExpression {
    /**
    * and block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#and BudgetsBudget#and}
    */
    readonly and?: BudgetsBudgetFilterExpressionAnd[] | cdktn.IResolvable;
    /**
    * cost_categories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#cost_categories BudgetsBudget#cost_categories}
    */
    readonly costCategories?: BudgetsBudgetFilterExpressionCostCategories;
    /**
    * dimensions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#dimensions BudgetsBudget#dimensions}
    */
    readonly dimensions?: BudgetsBudgetFilterExpressionDimensions;
    /**
    * not block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#not BudgetsBudget#not}
    */
    readonly not?: BudgetsBudgetFilterExpressionNot;
    /**
    * or block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#or BudgetsBudget#or}
    */
    readonly or?: BudgetsBudgetFilterExpressionOr[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#tags BudgetsBudget#tags}
    */
    readonly tags?: BudgetsBudgetFilterExpressionTags;
}
export declare function budgetsBudgetFilterExpressionToTerraform(struct?: BudgetsBudgetFilterExpressionOutputReference | BudgetsBudgetFilterExpression): any;
export declare function budgetsBudgetFilterExpressionToHclTerraform(struct?: BudgetsBudgetFilterExpressionOutputReference | BudgetsBudgetFilterExpression): any;
export declare class BudgetsBudgetFilterExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetsBudgetFilterExpression | undefined;
    set internalValue(value: BudgetsBudgetFilterExpression | undefined);
    private _and;
    get and(): BudgetsBudgetFilterExpressionAndList;
    putAnd(value: BudgetsBudgetFilterExpressionAnd[] | cdktn.IResolvable): void;
    resetAnd(): void;
    get andInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionAnd[] | undefined;
    private _costCategories;
    get costCategories(): BudgetsBudgetFilterExpressionCostCategoriesOutputReference;
    putCostCategories(value: BudgetsBudgetFilterExpressionCostCategories): void;
    resetCostCategories(): void;
    get costCategoriesInput(): BudgetsBudgetFilterExpressionCostCategories | undefined;
    private _dimensions;
    get dimensions(): BudgetsBudgetFilterExpressionDimensionsOutputReference;
    putDimensions(value: BudgetsBudgetFilterExpressionDimensions): void;
    resetDimensions(): void;
    get dimensionsInput(): BudgetsBudgetFilterExpressionDimensions | undefined;
    private _not;
    get not(): BudgetsBudgetFilterExpressionNotOutputReference;
    putNot(value: BudgetsBudgetFilterExpressionNot): void;
    resetNot(): void;
    get notInput(): BudgetsBudgetFilterExpressionNot | undefined;
    private _or;
    get or(): BudgetsBudgetFilterExpressionOrList;
    putOr(value: BudgetsBudgetFilterExpressionOr[] | cdktn.IResolvable): void;
    resetOr(): void;
    get orInput(): cdktn.IResolvable | BudgetsBudgetFilterExpressionOr[] | undefined;
    private _tags;
    get tags(): BudgetsBudgetFilterExpressionTagsOutputReference;
    putTags(value: BudgetsBudgetFilterExpressionTags): void;
    resetTags(): void;
    get tagsInput(): BudgetsBudgetFilterExpressionTags | undefined;
}
export interface BudgetsBudgetNotification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#comparison_operator BudgetsBudget#comparison_operator}
    */
    readonly comparisonOperator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#notification_type BudgetsBudget#notification_type}
    */
    readonly notificationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#subscriber_email_addresses BudgetsBudget#subscriber_email_addresses}
    */
    readonly subscriberEmailAddresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#subscriber_sns_topic_arns BudgetsBudget#subscriber_sns_topic_arns}
    */
    readonly subscriberSnsTopicArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#threshold BudgetsBudget#threshold}
    */
    readonly threshold: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#threshold_type BudgetsBudget#threshold_type}
    */
    readonly thresholdType: string;
}
export declare function budgetsBudgetNotificationToTerraform(struct?: BudgetsBudgetNotification | cdktn.IResolvable): any;
export declare function budgetsBudgetNotificationToHclTerraform(struct?: BudgetsBudgetNotification | cdktn.IResolvable): any;
export declare class BudgetsBudgetNotificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetNotification | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetNotification | cdktn.IResolvable | undefined);
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    get comparisonOperatorInput(): string | undefined;
    private _notificationType?;
    get notificationType(): string;
    set notificationType(value: string);
    get notificationTypeInput(): string | undefined;
    private _subscriberEmailAddresses?;
    get subscriberEmailAddresses(): string[];
    set subscriberEmailAddresses(value: string[]);
    resetSubscriberEmailAddresses(): void;
    get subscriberEmailAddressesInput(): string[] | undefined;
    private _subscriberSnsTopicArns?;
    get subscriberSnsTopicArns(): string[];
    set subscriberSnsTopicArns(value: string[]);
    resetSubscriberSnsTopicArns(): void;
    get subscriberSnsTopicArnsInput(): string[] | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _thresholdType?;
    get thresholdType(): string;
    set thresholdType(value: string);
    get thresholdTypeInput(): string | undefined;
}
export declare class BudgetsBudgetNotificationList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetNotification[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetNotificationOutputReference;
}
export interface BudgetsBudgetPlannedLimit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#amount BudgetsBudget#amount}
    */
    readonly amount: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#start_time BudgetsBudget#start_time}
    */
    readonly startTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#unit BudgetsBudget#unit}
    */
    readonly unit: string;
}
export declare function budgetsBudgetPlannedLimitToTerraform(struct?: BudgetsBudgetPlannedLimit | cdktn.IResolvable): any;
export declare function budgetsBudgetPlannedLimitToHclTerraform(struct?: BudgetsBudgetPlannedLimit | cdktn.IResolvable): any;
export declare class BudgetsBudgetPlannedLimitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetsBudgetPlannedLimit | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetsBudgetPlannedLimit | cdktn.IResolvable | undefined);
    private _amount?;
    get amount(): string;
    set amount(value: string);
    get amountInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    get startTimeInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export declare class BudgetsBudgetPlannedLimitList extends cdktn.ComplexList {
    internalValue?: BudgetsBudgetPlannedLimit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetsBudgetPlannedLimitOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget aws_budgets_budget}
*/
export declare class BudgetsBudget extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_budgets_budget";
    /**
    * Generates CDKTN code for importing a BudgetsBudget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BudgetsBudget to import
    * @param importFromId The id of the existing BudgetsBudget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BudgetsBudget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/budgets_budget aws_budgets_budget} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BudgetsBudgetConfig
    */
    constructor(scope: Construct, id: string, config: BudgetsBudgetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get arn(): string;
    private _billingViewArn?;
    get billingViewArn(): string;
    set billingViewArn(value: string);
    resetBillingViewArn(): void;
    get billingViewArnInput(): string | undefined;
    private _budgetType?;
    get budgetType(): string;
    set budgetType(value: string);
    get budgetTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _limitAmount?;
    get limitAmount(): string;
    set limitAmount(value: string);
    resetLimitAmount(): void;
    get limitAmountInput(): string | undefined;
    private _limitUnit?;
    get limitUnit(): string;
    set limitUnit(value: string);
    resetLimitUnit(): void;
    get limitUnitInput(): string | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timePeriodEnd?;
    get timePeriodEnd(): string;
    set timePeriodEnd(value: string);
    resetTimePeriodEnd(): void;
    get timePeriodEndInput(): string | undefined;
    private _timePeriodStart?;
    get timePeriodStart(): string;
    set timePeriodStart(value: string);
    resetTimePeriodStart(): void;
    get timePeriodStartInput(): string | undefined;
    private _timeUnit?;
    get timeUnit(): string;
    set timeUnit(value: string);
    get timeUnitInput(): string | undefined;
    private _autoAdjustData;
    get autoAdjustData(): BudgetsBudgetAutoAdjustDataOutputReference;
    putAutoAdjustData(value: BudgetsBudgetAutoAdjustData): void;
    resetAutoAdjustData(): void;
    get autoAdjustDataInput(): BudgetsBudgetAutoAdjustData | undefined;
    private _costFilter;
    get costFilter(): BudgetsBudgetCostFilterList;
    putCostFilter(value: BudgetsBudgetCostFilter[] | cdktn.IResolvable): void;
    resetCostFilter(): void;
    get costFilterInput(): cdktn.IResolvable | BudgetsBudgetCostFilter[] | undefined;
    private _costTypes;
    get costTypes(): BudgetsBudgetCostTypesOutputReference;
    putCostTypes(value: BudgetsBudgetCostTypes): void;
    resetCostTypes(): void;
    get costTypesInput(): BudgetsBudgetCostTypes | undefined;
    private _filterExpression;
    get filterExpression(): BudgetsBudgetFilterExpressionOutputReference;
    putFilterExpression(value: BudgetsBudgetFilterExpression): void;
    resetFilterExpression(): void;
    get filterExpressionInput(): BudgetsBudgetFilterExpression | undefined;
    private _notification;
    get notification(): BudgetsBudgetNotificationList;
    putNotification(value: BudgetsBudgetNotification[] | cdktn.IResolvable): void;
    resetNotification(): void;
    get notificationInput(): cdktn.IResolvable | BudgetsBudgetNotification[] | undefined;
    private _plannedLimit;
    get plannedLimit(): BudgetsBudgetPlannedLimitList;
    putPlannedLimit(value: BudgetsBudgetPlannedLimit[] | cdktn.IResolvable): void;
    resetPlannedLimit(): void;
    get plannedLimitInput(): cdktn.IResolvable | BudgetsBudgetPlannedLimit[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
