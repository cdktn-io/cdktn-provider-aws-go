/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBedrockFoundationModelAgreementOffersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/bedrock_foundation_model_agreement_offers#model_id DataAwsBedrockFoundationModelAgreementOffers#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/bedrock_foundation_model_agreement_offers#offer_type DataAwsBedrockFoundationModelAgreementOffers#offer_type}
    */
    readonly offerType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/bedrock_foundation_model_agreement_offers#region DataAwsBedrockFoundationModelAgreementOffers#region}
    */
    readonly region?: string;
}
export interface DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTerm {
}
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTermToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTerm): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTermToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTerm): any;
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTerm | undefined;
    set internalValue(value: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTerm | undefined);
    get url(): string;
}
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTermOutputReference;
}
export interface DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTerm {
}
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTermToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTerm): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTermToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTerm): any;
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTerm | undefined;
    set internalValue(value: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTerm | undefined);
    get refundPolicyDescription(): string;
}
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTermOutputReference;
}
export interface DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCard {
}
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCardToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCard): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCardToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCard): any;
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCard | undefined;
    set internalValue(value: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCard | undefined);
    get description(): string;
    get dimension(): string;
    get price(): string;
    get unit(): string;
}
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCardList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCardOutputReference;
}
export interface DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTerm {
}
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTerm): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTerm): any;
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTerm | undefined;
    set internalValue(value: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTerm | undefined);
    private _rateCard;
    get rateCard(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermRateCardList;
}
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermOutputReference;
}
export interface DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTerm {
}
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTermToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTerm): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTermToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTerm): any;
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTermOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTerm | undefined;
    set internalValue(value: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTerm | undefined);
    get agreementDuration(): string;
}
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTermList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTermOutputReference;
}
export interface DataAwsBedrockFoundationModelAgreementOffersOffersTermDetails {
}
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetails): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetails): any;
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetails | undefined;
    set internalValue(value: DataAwsBedrockFoundationModelAgreementOffersOffersTermDetails | undefined);
    private _legalTerm;
    get legalTerm(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsLegalTermList;
    private _supportTerm;
    get supportTerm(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsSupportTermList;
    private _usageBasedPricingTerm;
    get usageBasedPricingTerm(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsUsageBasedPricingTermList;
    private _validityTerm;
    get validityTerm(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsValidityTermList;
}
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsOutputReference;
}
export interface DataAwsBedrockFoundationModelAgreementOffersOffers {
}
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffers): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffersOffers): any;
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBedrockFoundationModelAgreementOffersOffers | undefined;
    set internalValue(value: DataAwsBedrockFoundationModelAgreementOffersOffers | undefined);
    get offerId(): string;
    get offerToken(): string;
    private _termDetails;
    get termDetails(): DataAwsBedrockFoundationModelAgreementOffersOffersTermDetailsList;
}
export declare class DataAwsBedrockFoundationModelAgreementOffersOffersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBedrockFoundationModelAgreementOffersOffersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/bedrock_foundation_model_agreement_offers aws_bedrock_foundation_model_agreement_offers}
*/
export declare class DataAwsBedrockFoundationModelAgreementOffers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_bedrock_foundation_model_agreement_offers";
    /**
    * Generates CDKTN code for importing a DataAwsBedrockFoundationModelAgreementOffers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBedrockFoundationModelAgreementOffers to import
    * @param importFromId The id of the existing DataAwsBedrockFoundationModelAgreementOffers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/bedrock_foundation_model_agreement_offers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBedrockFoundationModelAgreementOffers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/bedrock_foundation_model_agreement_offers aws_bedrock_foundation_model_agreement_offers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBedrockFoundationModelAgreementOffersConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsBedrockFoundationModelAgreementOffersConfig);
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _offerType?;
    get offerType(): string;
    set offerType(value: string);
    resetOfferType(): void;
    get offerTypeInput(): string | undefined;
    private _offers;
    get offers(): DataAwsBedrockFoundationModelAgreementOffersOffersList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
