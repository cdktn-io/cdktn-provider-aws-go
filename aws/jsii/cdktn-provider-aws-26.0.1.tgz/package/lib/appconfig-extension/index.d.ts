/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppconfigExtensionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#description AppconfigExtension#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#id AppconfigExtension#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#name AppconfigExtension#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#region AppconfigExtension#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#tags AppconfigExtension#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#tags_all AppconfigExtension#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#action_point AppconfigExtension#action_point}
    */
    readonly actionPoint: AppconfigExtensionActionPoint[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#parameter AppconfigExtension#parameter}
    */
    readonly parameter?: AppconfigExtensionParameter[] | cdktn.IResolvable;
}
export interface AppconfigExtensionActionPointAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#description AppconfigExtension#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#name AppconfigExtension#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#role_arn AppconfigExtension#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#uri AppconfigExtension#uri}
    */
    readonly uri: string;
}
export declare function appconfigExtensionActionPointActionToTerraform(struct?: AppconfigExtensionActionPointAction | cdktn.IResolvable): any;
export declare function appconfigExtensionActionPointActionToHclTerraform(struct?: AppconfigExtensionActionPointAction | cdktn.IResolvable): any;
export declare class AppconfigExtensionActionPointActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExtensionActionPointAction | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExtensionActionPointAction | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export declare class AppconfigExtensionActionPointActionList extends cdktn.ComplexList {
    internalValue?: AppconfigExtensionActionPointAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExtensionActionPointActionOutputReference;
}
export interface AppconfigExtensionActionPoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#point AppconfigExtension#point}
    */
    readonly point: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#action AppconfigExtension#action}
    */
    readonly action: AppconfigExtensionActionPointAction[] | cdktn.IResolvable;
}
export declare function appconfigExtensionActionPointToTerraform(struct?: AppconfigExtensionActionPoint | cdktn.IResolvable): any;
export declare function appconfigExtensionActionPointToHclTerraform(struct?: AppconfigExtensionActionPoint | cdktn.IResolvable): any;
export declare class AppconfigExtensionActionPointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExtensionActionPoint | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExtensionActionPoint | cdktn.IResolvable | undefined);
    private _point?;
    get point(): string;
    set point(value: string);
    get pointInput(): string | undefined;
    private _action;
    get action(): AppconfigExtensionActionPointActionList;
    putAction(value: AppconfigExtensionActionPointAction[] | cdktn.IResolvable): void;
    get actionInput(): cdktn.IResolvable | AppconfigExtensionActionPointAction[] | undefined;
}
export declare class AppconfigExtensionActionPointList extends cdktn.ComplexList {
    internalValue?: AppconfigExtensionActionPoint[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExtensionActionPointOutputReference;
}
export interface AppconfigExtensionParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#description AppconfigExtension#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#name AppconfigExtension#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#required AppconfigExtension#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
}
export declare function appconfigExtensionParameterToTerraform(struct?: AppconfigExtensionParameter | cdktn.IResolvable): any;
export declare function appconfigExtensionParameterToHclTerraform(struct?: AppconfigExtensionParameter | cdktn.IResolvable): any;
export declare class AppconfigExtensionParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppconfigExtensionParameter | cdktn.IResolvable | undefined;
    set internalValue(value: AppconfigExtensionParameter | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class AppconfigExtensionParameterList extends cdktn.ComplexList {
    internalValue?: AppconfigExtensionParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppconfigExtensionParameterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension aws_appconfig_extension}
*/
export declare class AppconfigExtension extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appconfig_extension";
    /**
    * Generates CDKTN code for importing a AppconfigExtension resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppconfigExtension to import
    * @param importFromId The id of the existing AppconfigExtension that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppconfigExtension to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/appconfig_extension aws_appconfig_extension} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppconfigExtensionConfig
    */
    constructor(scope: Construct, id: string, config: AppconfigExtensionConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): number;
    private _actionPoint;
    get actionPoint(): AppconfigExtensionActionPointList;
    putActionPoint(value: AppconfigExtensionActionPoint[] | cdktn.IResolvable): void;
    get actionPointInput(): cdktn.IResolvable | AppconfigExtensionActionPoint[] | undefined;
    private _parameter;
    get parameter(): AppconfigExtensionParameterList;
    putParameter(value: AppconfigExtensionParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | AppconfigExtensionParameter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
