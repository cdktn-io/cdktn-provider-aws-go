/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessanalyzerAnalyzerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#analyzer_name AccessanalyzerAnalyzer#analyzer_name}
    */
    readonly analyzerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#id AccessanalyzerAnalyzer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#region AccessanalyzerAnalyzer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#tags AccessanalyzerAnalyzer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#tags_all AccessanalyzerAnalyzer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#type AccessanalyzerAnalyzer#type}
    */
    readonly type?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#configuration AccessanalyzerAnalyzer#configuration}
    */
    readonly configuration?: AccessanalyzerAnalyzerConfiguration;
}
export interface AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#account_ids AccessanalyzerAnalyzer#account_ids}
    */
    readonly accountIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#resource_arns AccessanalyzerAnalyzer#resource_arns}
    */
    readonly resourceArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#resource_types AccessanalyzerAnalyzer#resource_types}
    */
    readonly resourceTypes?: string[];
}
export declare function accessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusionToTerraform(struct?: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusionToHclTerraform(struct?: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion | cdktn.IResolvable | undefined);
    private _accountIds?;
    get accountIds(): string[];
    set accountIds(value: string[]);
    resetAccountIds(): void;
    get accountIdsInput(): string[] | undefined;
    private _resourceArns?;
    get resourceArns(): string[];
    set resourceArns(value: string[]);
    resetResourceArns(): void;
    get resourceArnsInput(): string[] | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    resetResourceTypes(): void;
    get resourceTypesInput(): string[] | undefined;
}
export declare class AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusionList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusionOutputReference;
}
export interface AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule {
    /**
    * inclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#inclusion AccessanalyzerAnalyzer#inclusion}
    */
    readonly inclusion?: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion[] | cdktn.IResolvable;
}
export declare function accessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleToTerraform(struct?: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleOutputReference | AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule): any;
export declare function accessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleToHclTerraform(struct?: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleOutputReference | AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule): any;
export declare class AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule | undefined;
    set internalValue(value: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule | undefined);
    private _inclusion;
    get inclusion(): AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusionList;
    putInclusion(value: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion[] | cdktn.IResolvable): void;
    resetInclusion(): void;
    get inclusionInput(): cdktn.IResolvable | AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleInclusion[] | undefined;
}
export interface AccessanalyzerAnalyzerConfigurationInternalAccess {
    /**
    * analysis_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#analysis_rule AccessanalyzerAnalyzer#analysis_rule}
    */
    readonly analysisRule?: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule;
}
export declare function accessanalyzerAnalyzerConfigurationInternalAccessToTerraform(struct?: AccessanalyzerAnalyzerConfigurationInternalAccessOutputReference | AccessanalyzerAnalyzerConfigurationInternalAccess): any;
export declare function accessanalyzerAnalyzerConfigurationInternalAccessToHclTerraform(struct?: AccessanalyzerAnalyzerConfigurationInternalAccessOutputReference | AccessanalyzerAnalyzerConfigurationInternalAccess): any;
export declare class AccessanalyzerAnalyzerConfigurationInternalAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerConfigurationInternalAccess | undefined;
    set internalValue(value: AccessanalyzerAnalyzerConfigurationInternalAccess | undefined);
    private _analysisRule;
    get analysisRule(): AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRuleOutputReference;
    putAnalysisRule(value: AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule): void;
    resetAnalysisRule(): void;
    get analysisRuleInput(): AccessanalyzerAnalyzerConfigurationInternalAccessAnalysisRule | undefined;
}
export interface AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#account_ids AccessanalyzerAnalyzer#account_ids}
    */
    readonly accountIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#resource_tags AccessanalyzerAnalyzer#resource_tags}
    */
    readonly resourceTags?: {
        [key: string]: string;
    }[] | cdktn.IResolvable;
}
export declare function accessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusionToTerraform(struct?: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion | cdktn.IResolvable): any;
export declare function accessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusionToHclTerraform(struct?: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion | cdktn.IResolvable): any;
export declare class AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion | cdktn.IResolvable | undefined;
    set internalValue(value: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion | cdktn.IResolvable | undefined);
    private _accountIds?;
    get accountIds(): string[];
    set accountIds(value: string[]);
    resetAccountIds(): void;
    get accountIdsInput(): string[] | undefined;
    private _resourceTags?;
    get resourceTags(): {
        [key: string]: string;
    }[] | cdktn.IResolvable;
    set resourceTags(value: {
        [key: string]: string;
    }[] | cdktn.IResolvable);
    resetResourceTags(): void;
    get resourceTagsInput(): cdktn.IResolvable | {
        [key: string]: string;
    }[] | undefined;
}
export declare class AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusionList extends cdktn.ComplexList {
    internalValue?: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusionOutputReference;
}
export interface AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule {
    /**
    * exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#exclusion AccessanalyzerAnalyzer#exclusion}
    */
    readonly exclusion?: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion[] | cdktn.IResolvable;
}
export declare function accessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleToTerraform(struct?: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleOutputReference | AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule): any;
export declare function accessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleToHclTerraform(struct?: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleOutputReference | AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule): any;
export declare class AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule | undefined;
    set internalValue(value: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule | undefined);
    private _exclusion;
    get exclusion(): AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusionList;
    putExclusion(value: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion[] | cdktn.IResolvable): void;
    resetExclusion(): void;
    get exclusionInput(): cdktn.IResolvable | AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleExclusion[] | undefined;
}
export interface AccessanalyzerAnalyzerConfigurationUnusedAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#unused_access_age AccessanalyzerAnalyzer#unused_access_age}
    */
    readonly unusedAccessAge?: number;
    /**
    * analysis_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#analysis_rule AccessanalyzerAnalyzer#analysis_rule}
    */
    readonly analysisRule?: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule;
}
export declare function accessanalyzerAnalyzerConfigurationUnusedAccessToTerraform(struct?: AccessanalyzerAnalyzerConfigurationUnusedAccessOutputReference | AccessanalyzerAnalyzerConfigurationUnusedAccess): any;
export declare function accessanalyzerAnalyzerConfigurationUnusedAccessToHclTerraform(struct?: AccessanalyzerAnalyzerConfigurationUnusedAccessOutputReference | AccessanalyzerAnalyzerConfigurationUnusedAccess): any;
export declare class AccessanalyzerAnalyzerConfigurationUnusedAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerConfigurationUnusedAccess | undefined;
    set internalValue(value: AccessanalyzerAnalyzerConfigurationUnusedAccess | undefined);
    private _unusedAccessAge?;
    get unusedAccessAge(): number;
    set unusedAccessAge(value: number);
    resetUnusedAccessAge(): void;
    get unusedAccessAgeInput(): number | undefined;
    private _analysisRule;
    get analysisRule(): AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRuleOutputReference;
    putAnalysisRule(value: AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule): void;
    resetAnalysisRule(): void;
    get analysisRuleInput(): AccessanalyzerAnalyzerConfigurationUnusedAccessAnalysisRule | undefined;
}
export interface AccessanalyzerAnalyzerConfiguration {
    /**
    * internal_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#internal_access AccessanalyzerAnalyzer#internal_access}
    */
    readonly internalAccess?: AccessanalyzerAnalyzerConfigurationInternalAccess;
    /**
    * unused_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#unused_access AccessanalyzerAnalyzer#unused_access}
    */
    readonly unusedAccess?: AccessanalyzerAnalyzerConfigurationUnusedAccess;
}
export declare function accessanalyzerAnalyzerConfigurationToTerraform(struct?: AccessanalyzerAnalyzerConfigurationOutputReference | AccessanalyzerAnalyzerConfiguration): any;
export declare function accessanalyzerAnalyzerConfigurationToHclTerraform(struct?: AccessanalyzerAnalyzerConfigurationOutputReference | AccessanalyzerAnalyzerConfiguration): any;
export declare class AccessanalyzerAnalyzerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessanalyzerAnalyzerConfiguration | undefined;
    set internalValue(value: AccessanalyzerAnalyzerConfiguration | undefined);
    private _internalAccess;
    get internalAccess(): AccessanalyzerAnalyzerConfigurationInternalAccessOutputReference;
    putInternalAccess(value: AccessanalyzerAnalyzerConfigurationInternalAccess): void;
    resetInternalAccess(): void;
    get internalAccessInput(): AccessanalyzerAnalyzerConfigurationInternalAccess | undefined;
    private _unusedAccess;
    get unusedAccess(): AccessanalyzerAnalyzerConfigurationUnusedAccessOutputReference;
    putUnusedAccess(value: AccessanalyzerAnalyzerConfigurationUnusedAccess): void;
    resetUnusedAccess(): void;
    get unusedAccessInput(): AccessanalyzerAnalyzerConfigurationUnusedAccess | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer aws_accessanalyzer_analyzer}
*/
export declare class AccessanalyzerAnalyzer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_accessanalyzer_analyzer";
    /**
    * Generates CDKTN code for importing a AccessanalyzerAnalyzer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessanalyzerAnalyzer to import
    * @param importFromId The id of the existing AccessanalyzerAnalyzer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessanalyzerAnalyzer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accessanalyzer_analyzer aws_accessanalyzer_analyzer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessanalyzerAnalyzerConfig
    */
    constructor(scope: Construct, id: string, config: AccessanalyzerAnalyzerConfig);
    private _analyzerName?;
    get analyzerName(): string;
    set analyzerName(value: string);
    get analyzerNameInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): AccessanalyzerAnalyzerConfigurationOutputReference;
    putConfiguration(value: AccessanalyzerAnalyzerConfiguration): void;
    resetConfiguration(): void;
    get configurationInput(): AccessanalyzerAnalyzerConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
