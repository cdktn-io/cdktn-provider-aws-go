/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCloudfrontConnectionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/cloudfront_connection_group#id DataAwsCloudfrontConnectionGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/cloudfront_connection_group#routing_endpoint DataAwsCloudfrontConnectionGroup#routing_endpoint}
    */
    readonly routingEndpoint?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/cloudfront_connection_group aws_cloudfront_connection_group}
*/
export declare class DataAwsCloudfrontConnectionGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_connection_group";
    /**
    * Generates CDKTN code for importing a DataAwsCloudfrontConnectionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCloudfrontConnectionGroup to import
    * @param importFromId The id of the existing DataAwsCloudfrontConnectionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/cloudfront_connection_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCloudfrontConnectionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/cloudfront_connection_group aws_cloudfront_connection_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCloudfrontConnectionGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsCloudfrontConnectionGroupConfig);
    get anycastIpListId(): string;
    get arn(): string;
    get enabled(): cdktn.IResolvable;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipv6Enabled(): cdktn.IResolvable;
    get isDefault(): cdktn.IResolvable;
    get lastModifiedTime(): string;
    get name(): string;
    private _routingEndpoint?;
    get routingEndpoint(): string;
    set routingEndpoint(value: string);
    resetRoutingEndpoint(): void;
    get routingEndpointInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
