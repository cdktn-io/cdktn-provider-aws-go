/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontMultitenantDistributionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#comment CloudfrontMultitenantDistribution#comment}
    */
    readonly comment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#default_root_object CloudfrontMultitenantDistribution#default_root_object}
    */
    readonly defaultRootObject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#enabled CloudfrontMultitenantDistribution#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#http_version CloudfrontMultitenantDistribution#http_version}
    */
    readonly httpVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#tags CloudfrontMultitenantDistribution#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#web_acl_id CloudfrontMultitenantDistribution#web_acl_id}
    */
    readonly webAclId?: string;
    /**
    * active_trusted_key_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#active_trusted_key_groups CloudfrontMultitenantDistribution#active_trusted_key_groups}
    */
    readonly activeTrustedKeyGroups?: CloudfrontMultitenantDistributionActiveTrustedKeyGroups[] | cdktn.IResolvable;
    /**
    * cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#cache_behavior CloudfrontMultitenantDistribution#cache_behavior}
    */
    readonly cacheBehavior?: CloudfrontMultitenantDistributionCacheBehavior[] | cdktn.IResolvable;
    /**
    * custom_error_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#custom_error_response CloudfrontMultitenantDistribution#custom_error_response}
    */
    readonly customErrorResponse?: CloudfrontMultitenantDistributionCustomErrorResponse[] | cdktn.IResolvable;
    /**
    * default_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#default_cache_behavior CloudfrontMultitenantDistribution#default_cache_behavior}
    */
    readonly defaultCacheBehavior?: CloudfrontMultitenantDistributionDefaultCacheBehavior[] | cdktn.IResolvable;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin CloudfrontMultitenantDistribution#origin}
    */
    readonly origin?: CloudfrontMultitenantDistributionOrigin[] | cdktn.IResolvable;
    /**
    * origin_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_group CloudfrontMultitenantDistribution#origin_group}
    */
    readonly originGroup?: CloudfrontMultitenantDistributionOriginGroup[] | cdktn.IResolvable;
    /**
    * restrictions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#restrictions CloudfrontMultitenantDistribution#restrictions}
    */
    readonly restrictions?: CloudfrontMultitenantDistributionRestrictions[] | cdktn.IResolvable;
    /**
    * tenant_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#tenant_config CloudfrontMultitenantDistribution#tenant_config}
    */
    readonly tenantConfig?: CloudfrontMultitenantDistributionTenantConfig[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#timeouts CloudfrontMultitenantDistribution#timeouts}
    */
    readonly timeouts?: CloudfrontMultitenantDistributionTimeouts;
    /**
    * viewer_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#viewer_certificate CloudfrontMultitenantDistribution#viewer_certificate}
    */
    readonly viewerCertificate?: CloudfrontMultitenantDistributionViewerCertificate[] | cdktn.IResolvable;
}
export interface CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems {
}
export declare function cloudfrontMultitenantDistributionActiveTrustedKeyGroupsItemsToTerraform(struct?: CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionActiveTrustedKeyGroupsItemsToHclTerraform(struct?: CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems | cdktn.IResolvable | undefined);
    get keyGroupId(): string;
    get keyPairIds(): string[];
}
export declare class CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItemsList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItemsOutputReference;
}
export interface CloudfrontMultitenantDistributionActiveTrustedKeyGroups {
    /**
    * items block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#items CloudfrontMultitenantDistribution#items}
    */
    readonly items?: CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionActiveTrustedKeyGroupsToTerraform(struct?: CloudfrontMultitenantDistributionActiveTrustedKeyGroups | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionActiveTrustedKeyGroupsToHclTerraform(struct?: CloudfrontMultitenantDistributionActiveTrustedKeyGroups | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionActiveTrustedKeyGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionActiveTrustedKeyGroups | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionActiveTrustedKeyGroups | cdktn.IResolvable | undefined);
    get enabled(): cdktn.IResolvable;
    private _items;
    get items(): CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItemsList;
    putItems(value: CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems[] | cdktn.IResolvable): void;
    resetItems(): void;
    get itemsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionActiveTrustedKeyGroupsItems[] | undefined;
}
export declare class CloudfrontMultitenantDistributionActiveTrustedKeyGroupsList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionActiveTrustedKeyGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionActiveTrustedKeyGroupsOutputReference;
}
export interface CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#cached_methods CloudfrontMultitenantDistribution#cached_methods}
    */
    readonly cachedMethods: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#items CloudfrontMultitenantDistribution#items}
    */
    readonly items: string[];
}
export declare function cloudfrontMultitenantDistributionCacheBehaviorAllowedMethodsToTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionCacheBehaviorAllowedMethodsToHclTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionCacheBehaviorAllowedMethodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods | cdktn.IResolvable | undefined);
    private _cachedMethods?;
    get cachedMethods(): string[];
    set cachedMethods(value: string[]);
    get cachedMethodsInput(): string[] | undefined;
    private _items?;
    get items(): string[];
    set items(value: string[]);
    get itemsInput(): string[] | undefined;
}
export declare class CloudfrontMultitenantDistributionCacheBehaviorAllowedMethodsList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionCacheBehaviorAllowedMethodsOutputReference;
}
export interface CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#event_type CloudfrontMultitenantDistribution#event_type}
    */
    readonly eventType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#function_arn CloudfrontMultitenantDistribution#function_arn}
    */
    readonly functionArn: string;
}
export declare function cloudfrontMultitenantDistributionCacheBehaviorFunctionAssociationToTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionCacheBehaviorFunctionAssociationToHclTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation | cdktn.IResolvable | undefined);
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    private _functionArn?;
    get functionArn(): string;
    set functionArn(value: string);
    get functionArnInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociationList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociationOutputReference;
}
export interface CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#event_type CloudfrontMultitenantDistribution#event_type}
    */
    readonly eventType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#include_body CloudfrontMultitenantDistribution#include_body}
    */
    readonly includeBody?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_arn CloudfrontMultitenantDistribution#lambda_function_arn}
    */
    readonly lambdaFunctionArn: string;
}
export declare function cloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociationToTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociationToHclTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable | undefined);
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    private _includeBody?;
    get includeBody(): boolean | cdktn.IResolvable;
    set includeBody(value: boolean | cdktn.IResolvable);
    resetIncludeBody(): void;
    get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
    private _lambdaFunctionArn?;
    get lambdaFunctionArn(): string;
    set lambdaFunctionArn(value: string);
    get lambdaFunctionArnInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociationList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociationOutputReference;
}
export interface CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#enabled CloudfrontMultitenantDistribution#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#items CloudfrontMultitenantDistribution#items}
    */
    readonly items?: string[];
}
export declare function cloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroupsToTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroupsToHclTerraform(struct?: CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
}
export declare class CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroupsList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroupsOutputReference;
}
export interface CloudfrontMultitenantDistributionCacheBehavior {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#cache_policy_id CloudfrontMultitenantDistribution#cache_policy_id}
    */
    readonly cachePolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#compress CloudfrontMultitenantDistribution#compress}
    */
    readonly compress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#field_level_encryption_id CloudfrontMultitenantDistribution#field_level_encryption_id}
    */
    readonly fieldLevelEncryptionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_request_policy_id CloudfrontMultitenantDistribution#origin_request_policy_id}
    */
    readonly originRequestPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#path_pattern CloudfrontMultitenantDistribution#path_pattern}
    */
    readonly pathPattern: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#realtime_log_config_arn CloudfrontMultitenantDistribution#realtime_log_config_arn}
    */
    readonly realtimeLogConfigArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#response_headers_policy_id CloudfrontMultitenantDistribution#response_headers_policy_id}
    */
    readonly responseHeadersPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#target_origin_id CloudfrontMultitenantDistribution#target_origin_id}
    */
    readonly targetOriginId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#viewer_protocol_policy CloudfrontMultitenantDistribution#viewer_protocol_policy}
    */
    readonly viewerProtocolPolicy: string;
    /**
    * allowed_methods block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#allowed_methods CloudfrontMultitenantDistribution#allowed_methods}
    */
    readonly allowedMethods?: CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods[] | cdktn.IResolvable;
    /**
    * function_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#function_association CloudfrontMultitenantDistribution#function_association}
    */
    readonly functionAssociation?: CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation[] | cdktn.IResolvable;
    /**
    * lambda_function_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_association CloudfrontMultitenantDistribution#lambda_function_association}
    */
    readonly lambdaFunctionAssociation?: CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation[] | cdktn.IResolvable;
    /**
    * trusted_key_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#trusted_key_groups CloudfrontMultitenantDistribution#trusted_key_groups}
    */
    readonly trustedKeyGroups?: CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionCacheBehaviorToTerraform(struct?: CloudfrontMultitenantDistributionCacheBehavior | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionCacheBehaviorToHclTerraform(struct?: CloudfrontMultitenantDistributionCacheBehavior | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionCacheBehaviorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionCacheBehavior | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionCacheBehavior | cdktn.IResolvable | undefined);
    private _cachePolicyId?;
    get cachePolicyId(): string;
    set cachePolicyId(value: string);
    resetCachePolicyId(): void;
    get cachePolicyIdInput(): string | undefined;
    private _compress?;
    get compress(): boolean | cdktn.IResolvable;
    set compress(value: boolean | cdktn.IResolvable);
    resetCompress(): void;
    get compressInput(): boolean | cdktn.IResolvable | undefined;
    private _fieldLevelEncryptionId?;
    get fieldLevelEncryptionId(): string;
    set fieldLevelEncryptionId(value: string);
    resetFieldLevelEncryptionId(): void;
    get fieldLevelEncryptionIdInput(): string | undefined;
    private _originRequestPolicyId?;
    get originRequestPolicyId(): string;
    set originRequestPolicyId(value: string);
    resetOriginRequestPolicyId(): void;
    get originRequestPolicyIdInput(): string | undefined;
    private _pathPattern?;
    get pathPattern(): string;
    set pathPattern(value: string);
    get pathPatternInput(): string | undefined;
    private _realtimeLogConfigArn?;
    get realtimeLogConfigArn(): string;
    set realtimeLogConfigArn(value: string);
    resetRealtimeLogConfigArn(): void;
    get realtimeLogConfigArnInput(): string | undefined;
    private _responseHeadersPolicyId?;
    get responseHeadersPolicyId(): string;
    set responseHeadersPolicyId(value: string);
    resetResponseHeadersPolicyId(): void;
    get responseHeadersPolicyIdInput(): string | undefined;
    private _targetOriginId?;
    get targetOriginId(): string;
    set targetOriginId(value: string);
    get targetOriginIdInput(): string | undefined;
    private _viewerProtocolPolicy?;
    get viewerProtocolPolicy(): string;
    set viewerProtocolPolicy(value: string);
    get viewerProtocolPolicyInput(): string | undefined;
    private _allowedMethods;
    get allowedMethods(): CloudfrontMultitenantDistributionCacheBehaviorAllowedMethodsList;
    putAllowedMethods(value: CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods[] | cdktn.IResolvable): void;
    resetAllowedMethods(): void;
    get allowedMethodsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionCacheBehaviorAllowedMethods[] | undefined;
    private _functionAssociation;
    get functionAssociation(): CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociationList;
    putFunctionAssociation(value: CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation[] | cdktn.IResolvable): void;
    resetFunctionAssociation(): void;
    get functionAssociationInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionCacheBehaviorFunctionAssociation[] | undefined;
    private _lambdaFunctionAssociation;
    get lambdaFunctionAssociation(): CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociationList;
    putLambdaFunctionAssociation(value: CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation[] | cdktn.IResolvable): void;
    resetLambdaFunctionAssociation(): void;
    get lambdaFunctionAssociationInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionCacheBehaviorLambdaFunctionAssociation[] | undefined;
    private _trustedKeyGroups;
    get trustedKeyGroups(): CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroupsList;
    putTrustedKeyGroups(value: CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups[] | cdktn.IResolvable): void;
    resetTrustedKeyGroups(): void;
    get trustedKeyGroupsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionCacheBehaviorTrustedKeyGroups[] | undefined;
}
export declare class CloudfrontMultitenantDistributionCacheBehaviorList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionCacheBehavior[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionCacheBehaviorOutputReference;
}
export interface CloudfrontMultitenantDistributionCustomErrorResponse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#error_caching_min_ttl CloudfrontMultitenantDistribution#error_caching_min_ttl}
    */
    readonly errorCachingMinTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#error_code CloudfrontMultitenantDistribution#error_code}
    */
    readonly errorCode: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#response_code CloudfrontMultitenantDistribution#response_code}
    */
    readonly responseCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#response_page_path CloudfrontMultitenantDistribution#response_page_path}
    */
    readonly responsePagePath?: string;
}
export declare function cloudfrontMultitenantDistributionCustomErrorResponseToTerraform(struct?: CloudfrontMultitenantDistributionCustomErrorResponse | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionCustomErrorResponseToHclTerraform(struct?: CloudfrontMultitenantDistributionCustomErrorResponse | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionCustomErrorResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionCustomErrorResponse | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionCustomErrorResponse | cdktn.IResolvable | undefined);
    private _errorCachingMinTtl?;
    get errorCachingMinTtl(): number;
    set errorCachingMinTtl(value: number);
    resetErrorCachingMinTtl(): void;
    get errorCachingMinTtlInput(): number | undefined;
    private _errorCode?;
    get errorCode(): number;
    set errorCode(value: number);
    get errorCodeInput(): number | undefined;
    private _responseCode?;
    get responseCode(): string;
    set responseCode(value: string);
    resetResponseCode(): void;
    get responseCodeInput(): string | undefined;
    private _responsePagePath?;
    get responsePagePath(): string;
    set responsePagePath(value: string);
    resetResponsePagePath(): void;
    get responsePagePathInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionCustomErrorResponseList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionCustomErrorResponse[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionCustomErrorResponseOutputReference;
}
export interface CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#cached_methods CloudfrontMultitenantDistribution#cached_methods}
    */
    readonly cachedMethods: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#items CloudfrontMultitenantDistribution#items}
    */
    readonly items: string[];
}
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethodsToTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethodsToHclTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods | cdktn.IResolvable | undefined);
    private _cachedMethods?;
    get cachedMethods(): string[];
    set cachedMethods(value: string[]);
    get cachedMethodsInput(): string[] | undefined;
    private _items?;
    get items(): string[];
    set items(value: string[]);
    get itemsInput(): string[] | undefined;
}
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethodsList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethodsOutputReference;
}
export interface CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#event_type CloudfrontMultitenantDistribution#event_type}
    */
    readonly eventType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#function_arn CloudfrontMultitenantDistribution#function_arn}
    */
    readonly functionArn: string;
}
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociationToTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociationToHclTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation | cdktn.IResolvable | undefined);
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    private _functionArn?;
    get functionArn(): string;
    set functionArn(value: string);
    get functionArnInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociationList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociationOutputReference;
}
export interface CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#event_type CloudfrontMultitenantDistribution#event_type}
    */
    readonly eventType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#include_body CloudfrontMultitenantDistribution#include_body}
    */
    readonly includeBody?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_arn CloudfrontMultitenantDistribution#lambda_function_arn}
    */
    readonly lambdaFunctionArn: string;
}
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationToTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationToHclTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation | cdktn.IResolvable | undefined);
    private _eventType?;
    get eventType(): string;
    set eventType(value: string);
    get eventTypeInput(): string | undefined;
    private _includeBody?;
    get includeBody(): boolean | cdktn.IResolvable;
    set includeBody(value: boolean | cdktn.IResolvable);
    resetIncludeBody(): void;
    get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
    private _lambdaFunctionArn?;
    get lambdaFunctionArn(): string;
    set lambdaFunctionArn(value: string);
    get lambdaFunctionArnInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationOutputReference;
}
export interface CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#enabled CloudfrontMultitenantDistribution#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#items CloudfrontMultitenantDistribution#items}
    */
    readonly items?: string[];
}
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsToTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsToHclTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
}
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsOutputReference;
}
export interface CloudfrontMultitenantDistributionDefaultCacheBehavior {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#cache_policy_id CloudfrontMultitenantDistribution#cache_policy_id}
    */
    readonly cachePolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#compress CloudfrontMultitenantDistribution#compress}
    */
    readonly compress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#field_level_encryption_id CloudfrontMultitenantDistribution#field_level_encryption_id}
    */
    readonly fieldLevelEncryptionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_request_policy_id CloudfrontMultitenantDistribution#origin_request_policy_id}
    */
    readonly originRequestPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#realtime_log_config_arn CloudfrontMultitenantDistribution#realtime_log_config_arn}
    */
    readonly realtimeLogConfigArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#response_headers_policy_id CloudfrontMultitenantDistribution#response_headers_policy_id}
    */
    readonly responseHeadersPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#target_origin_id CloudfrontMultitenantDistribution#target_origin_id}
    */
    readonly targetOriginId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#viewer_protocol_policy CloudfrontMultitenantDistribution#viewer_protocol_policy}
    */
    readonly viewerProtocolPolicy: string;
    /**
    * allowed_methods block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#allowed_methods CloudfrontMultitenantDistribution#allowed_methods}
    */
    readonly allowedMethods?: CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods[] | cdktn.IResolvable;
    /**
    * function_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#function_association CloudfrontMultitenantDistribution#function_association}
    */
    readonly functionAssociation?: CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation[] | cdktn.IResolvable;
    /**
    * lambda_function_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_association CloudfrontMultitenantDistribution#lambda_function_association}
    */
    readonly lambdaFunctionAssociation?: CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation[] | cdktn.IResolvable;
    /**
    * trusted_key_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#trusted_key_groups CloudfrontMultitenantDistribution#trusted_key_groups}
    */
    readonly trustedKeyGroups?: CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorToTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehavior | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionDefaultCacheBehaviorToHclTerraform(struct?: CloudfrontMultitenantDistributionDefaultCacheBehavior | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionDefaultCacheBehavior | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionDefaultCacheBehavior | cdktn.IResolvable | undefined);
    private _cachePolicyId?;
    get cachePolicyId(): string;
    set cachePolicyId(value: string);
    resetCachePolicyId(): void;
    get cachePolicyIdInput(): string | undefined;
    private _compress?;
    get compress(): boolean | cdktn.IResolvable;
    set compress(value: boolean | cdktn.IResolvable);
    resetCompress(): void;
    get compressInput(): boolean | cdktn.IResolvable | undefined;
    private _fieldLevelEncryptionId?;
    get fieldLevelEncryptionId(): string;
    set fieldLevelEncryptionId(value: string);
    resetFieldLevelEncryptionId(): void;
    get fieldLevelEncryptionIdInput(): string | undefined;
    private _originRequestPolicyId?;
    get originRequestPolicyId(): string;
    set originRequestPolicyId(value: string);
    resetOriginRequestPolicyId(): void;
    get originRequestPolicyIdInput(): string | undefined;
    private _realtimeLogConfigArn?;
    get realtimeLogConfigArn(): string;
    set realtimeLogConfigArn(value: string);
    resetRealtimeLogConfigArn(): void;
    get realtimeLogConfigArnInput(): string | undefined;
    private _responseHeadersPolicyId?;
    get responseHeadersPolicyId(): string;
    set responseHeadersPolicyId(value: string);
    resetResponseHeadersPolicyId(): void;
    get responseHeadersPolicyIdInput(): string | undefined;
    private _targetOriginId?;
    get targetOriginId(): string;
    set targetOriginId(value: string);
    get targetOriginIdInput(): string | undefined;
    private _viewerProtocolPolicy?;
    get viewerProtocolPolicy(): string;
    set viewerProtocolPolicy(value: string);
    get viewerProtocolPolicyInput(): string | undefined;
    private _allowedMethods;
    get allowedMethods(): CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethodsList;
    putAllowedMethods(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods[] | cdktn.IResolvable): void;
    resetAllowedMethods(): void;
    get allowedMethodsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionDefaultCacheBehaviorAllowedMethods[] | undefined;
    private _functionAssociation;
    get functionAssociation(): CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociationList;
    putFunctionAssociation(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation[] | cdktn.IResolvable): void;
    resetFunctionAssociation(): void;
    get functionAssociationInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionDefaultCacheBehaviorFunctionAssociation[] | undefined;
    private _lambdaFunctionAssociation;
    get lambdaFunctionAssociation(): CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationList;
    putLambdaFunctionAssociation(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation[] | cdktn.IResolvable): void;
    resetLambdaFunctionAssociation(): void;
    get lambdaFunctionAssociationInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociation[] | undefined;
    private _trustedKeyGroups;
    get trustedKeyGroups(): CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsList;
    putTrustedKeyGroups(value: CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups[] | cdktn.IResolvable): void;
    resetTrustedKeyGroups(): void;
    get trustedKeyGroupsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroups[] | undefined;
}
export declare class CloudfrontMultitenantDistributionDefaultCacheBehaviorList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionDefaultCacheBehavior[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionDefaultCacheBehaviorOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginCustomHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#header_name CloudfrontMultitenantDistribution#header_name}
    */
    readonly headerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#header_value CloudfrontMultitenantDistribution#header_value}
    */
    readonly headerValue: string;
}
export declare function cloudfrontMultitenantDistributionOriginCustomHeaderToTerraform(struct?: CloudfrontMultitenantDistributionOriginCustomHeader | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginCustomHeaderToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginCustomHeader | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginCustomHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginCustomHeader | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginCustomHeader | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginCustomHeaderList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginCustomHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginCustomHeaderOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#client_certificate_arn CloudfrontMultitenantDistribution#client_certificate_arn}
    */
    readonly clientCertificateArn: string;
}
export declare function cloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfigToTerraform(struct?: CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfigToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig | cdktn.IResolvable | undefined);
    private _clientCertificateArn?;
    get clientCertificateArn(): string;
    set clientCertificateArn(value: string);
    get clientCertificateArnInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfigList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfigOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginCustomOriginConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#http_port CloudfrontMultitenantDistribution#http_port}
    */
    readonly httpPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#https_port CloudfrontMultitenantDistribution#https_port}
    */
    readonly httpsPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#ip_address_type CloudfrontMultitenantDistribution#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_keepalive_timeout CloudfrontMultitenantDistribution#origin_keepalive_timeout}
    */
    readonly originKeepaliveTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_protocol_policy CloudfrontMultitenantDistribution#origin_protocol_policy}
    */
    readonly originProtocolPolicy: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_read_timeout CloudfrontMultitenantDistribution#origin_read_timeout}
    */
    readonly originReadTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_ssl_protocols CloudfrontMultitenantDistribution#origin_ssl_protocols}
    */
    readonly originSslProtocols: string[];
    /**
    * origin_mtls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_mtls_config CloudfrontMultitenantDistribution#origin_mtls_config}
    */
    readonly originMtlsConfig?: CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionOriginCustomOriginConfigToTerraform(struct?: CloudfrontMultitenantDistributionOriginCustomOriginConfig | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginCustomOriginConfigToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginCustomOriginConfig | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginCustomOriginConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginCustomOriginConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginCustomOriginConfig | cdktn.IResolvable | undefined);
    private _httpPort?;
    get httpPort(): number;
    set httpPort(value: number);
    get httpPortInput(): number | undefined;
    private _httpsPort?;
    get httpsPort(): number;
    set httpsPort(value: number);
    get httpsPortInput(): number | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _originKeepaliveTimeout?;
    get originKeepaliveTimeout(): number;
    set originKeepaliveTimeout(value: number);
    resetOriginKeepaliveTimeout(): void;
    get originKeepaliveTimeoutInput(): number | undefined;
    private _originProtocolPolicy?;
    get originProtocolPolicy(): string;
    set originProtocolPolicy(value: string);
    get originProtocolPolicyInput(): string | undefined;
    private _originReadTimeout?;
    get originReadTimeout(): number;
    set originReadTimeout(value: number);
    resetOriginReadTimeout(): void;
    get originReadTimeoutInput(): number | undefined;
    private _originSslProtocols?;
    get originSslProtocols(): string[];
    set originSslProtocols(value: string[]);
    get originSslProtocolsInput(): string[] | undefined;
    private _originMtlsConfig;
    get originMtlsConfig(): CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfigList;
    putOriginMtlsConfig(value: CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig[] | cdktn.IResolvable): void;
    resetOriginMtlsConfig(): void;
    get originMtlsConfigInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginCustomOriginConfigOriginMtlsConfig[] | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginCustomOriginConfigList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginCustomOriginConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginCustomOriginConfigOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginOriginShield {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#enabled CloudfrontMultitenantDistribution#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_shield_region CloudfrontMultitenantDistribution#origin_shield_region}
    */
    readonly originShieldRegion?: string;
}
export declare function cloudfrontMultitenantDistributionOriginOriginShieldToTerraform(struct?: CloudfrontMultitenantDistributionOriginOriginShield | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginOriginShieldToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginOriginShield | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginOriginShieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginOriginShield | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginOriginShield | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _originShieldRegion?;
    get originShieldRegion(): string;
    set originShieldRegion(value: string);
    resetOriginShieldRegion(): void;
    get originShieldRegionInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginOriginShieldList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginOriginShield[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginOriginShieldOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginVpcOriginConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_keepalive_timeout CloudfrontMultitenantDistribution#origin_keepalive_timeout}
    */
    readonly originKeepaliveTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_read_timeout CloudfrontMultitenantDistribution#origin_read_timeout}
    */
    readonly originReadTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#vpc_origin_id CloudfrontMultitenantDistribution#vpc_origin_id}
    */
    readonly vpcOriginId: string;
}
export declare function cloudfrontMultitenantDistributionOriginVpcOriginConfigToTerraform(struct?: CloudfrontMultitenantDistributionOriginVpcOriginConfig | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginVpcOriginConfigToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginVpcOriginConfig | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginVpcOriginConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginVpcOriginConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginVpcOriginConfig | cdktn.IResolvable | undefined);
    private _originKeepaliveTimeout?;
    get originKeepaliveTimeout(): number;
    set originKeepaliveTimeout(value: number);
    resetOriginKeepaliveTimeout(): void;
    get originKeepaliveTimeoutInput(): number | undefined;
    private _originReadTimeout?;
    get originReadTimeout(): number;
    set originReadTimeout(value: number);
    resetOriginReadTimeout(): void;
    get originReadTimeoutInput(): number | undefined;
    private _vpcOriginId?;
    get vpcOriginId(): string;
    set vpcOriginId(value: string);
    get vpcOriginIdInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginVpcOriginConfigList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginVpcOriginConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginVpcOriginConfigOutputReference;
}
export interface CloudfrontMultitenantDistributionOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#connection_attempts CloudfrontMultitenantDistribution#connection_attempts}
    */
    readonly connectionAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#connection_timeout CloudfrontMultitenantDistribution#connection_timeout}
    */
    readonly connectionTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#domain_name CloudfrontMultitenantDistribution#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#id CloudfrontMultitenantDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_access_control_id CloudfrontMultitenantDistribution#origin_access_control_id}
    */
    readonly originAccessControlId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_path CloudfrontMultitenantDistribution#origin_path}
    */
    readonly originPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#response_completion_timeout CloudfrontMultitenantDistribution#response_completion_timeout}
    */
    readonly responseCompletionTimeout?: number;
    /**
    * custom_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#custom_header CloudfrontMultitenantDistribution#custom_header}
    */
    readonly customHeader?: CloudfrontMultitenantDistributionOriginCustomHeader[] | cdktn.IResolvable;
    /**
    * custom_origin_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#custom_origin_config CloudfrontMultitenantDistribution#custom_origin_config}
    */
    readonly customOriginConfig?: CloudfrontMultitenantDistributionOriginCustomOriginConfig[] | cdktn.IResolvable;
    /**
    * origin_shield block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_shield CloudfrontMultitenantDistribution#origin_shield}
    */
    readonly originShield?: CloudfrontMultitenantDistributionOriginOriginShield[] | cdktn.IResolvable;
    /**
    * vpc_origin_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#vpc_origin_config CloudfrontMultitenantDistribution#vpc_origin_config}
    */
    readonly vpcOriginConfig?: CloudfrontMultitenantDistributionOriginVpcOriginConfig[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionOriginToTerraform(struct?: CloudfrontMultitenantDistributionOrigin | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginToHclTerraform(struct?: CloudfrontMultitenantDistributionOrigin | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOrigin | cdktn.IResolvable | undefined);
    private _connectionAttempts?;
    get connectionAttempts(): number;
    set connectionAttempts(value: number);
    resetConnectionAttempts(): void;
    get connectionAttemptsInput(): number | undefined;
    private _connectionTimeout?;
    get connectionTimeout(): number;
    set connectionTimeout(value: number);
    resetConnectionTimeout(): void;
    get connectionTimeoutInput(): number | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _originAccessControlId?;
    get originAccessControlId(): string;
    set originAccessControlId(value: string);
    resetOriginAccessControlId(): void;
    get originAccessControlIdInput(): string | undefined;
    private _originPath?;
    get originPath(): string;
    set originPath(value: string);
    resetOriginPath(): void;
    get originPathInput(): string | undefined;
    private _responseCompletionTimeout?;
    get responseCompletionTimeout(): number;
    set responseCompletionTimeout(value: number);
    resetResponseCompletionTimeout(): void;
    get responseCompletionTimeoutInput(): number | undefined;
    private _customHeader;
    get customHeader(): CloudfrontMultitenantDistributionOriginCustomHeaderList;
    putCustomHeader(value: CloudfrontMultitenantDistributionOriginCustomHeader[] | cdktn.IResolvable): void;
    resetCustomHeader(): void;
    get customHeaderInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginCustomHeader[] | undefined;
    private _customOriginConfig;
    get customOriginConfig(): CloudfrontMultitenantDistributionOriginCustomOriginConfigList;
    putCustomOriginConfig(value: CloudfrontMultitenantDistributionOriginCustomOriginConfig[] | cdktn.IResolvable): void;
    resetCustomOriginConfig(): void;
    get customOriginConfigInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginCustomOriginConfig[] | undefined;
    private _originShield;
    get originShield(): CloudfrontMultitenantDistributionOriginOriginShieldList;
    putOriginShield(value: CloudfrontMultitenantDistributionOriginOriginShield[] | cdktn.IResolvable): void;
    resetOriginShield(): void;
    get originShieldInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginOriginShield[] | undefined;
    private _vpcOriginConfig;
    get vpcOriginConfig(): CloudfrontMultitenantDistributionOriginVpcOriginConfigList;
    putVpcOriginConfig(value: CloudfrontMultitenantDistributionOriginVpcOriginConfig[] | cdktn.IResolvable): void;
    resetVpcOriginConfig(): void;
    get vpcOriginConfigInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginVpcOriginConfig[] | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOrigin[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginGroupFailoverCriteria {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#status_codes CloudfrontMultitenantDistribution#status_codes}
    */
    readonly statusCodes: number[];
}
export declare function cloudfrontMultitenantDistributionOriginGroupFailoverCriteriaToTerraform(struct?: CloudfrontMultitenantDistributionOriginGroupFailoverCriteria | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginGroupFailoverCriteriaToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginGroupFailoverCriteria | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginGroupFailoverCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginGroupFailoverCriteria | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginGroupFailoverCriteria | cdktn.IResolvable | undefined);
    private _statusCodes?;
    get statusCodes(): number[];
    set statusCodes(value: number[]);
    get statusCodesInput(): number[] | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginGroupFailoverCriteriaList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginGroupFailoverCriteria[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginGroupFailoverCriteriaOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginGroupMember {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#origin_id CloudfrontMultitenantDistribution#origin_id}
    */
    readonly originId: string;
}
export declare function cloudfrontMultitenantDistributionOriginGroupMemberToTerraform(struct?: CloudfrontMultitenantDistributionOriginGroupMember | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginGroupMemberToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginGroupMember | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginGroupMemberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginGroupMember | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginGroupMember | cdktn.IResolvable | undefined);
    private _originId?;
    get originId(): string;
    set originId(value: string);
    get originIdInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginGroupMemberList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginGroupMember[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginGroupMemberOutputReference;
}
export interface CloudfrontMultitenantDistributionOriginGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#id CloudfrontMultitenantDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * failover_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#failover_criteria CloudfrontMultitenantDistribution#failover_criteria}
    */
    readonly failoverCriteria?: CloudfrontMultitenantDistributionOriginGroupFailoverCriteria[] | cdktn.IResolvable;
    /**
    * member block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#member CloudfrontMultitenantDistribution#member}
    */
    readonly member?: CloudfrontMultitenantDistributionOriginGroupMember[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionOriginGroupToTerraform(struct?: CloudfrontMultitenantDistributionOriginGroup | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionOriginGroupToHclTerraform(struct?: CloudfrontMultitenantDistributionOriginGroup | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionOriginGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionOriginGroup | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionOriginGroup | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _failoverCriteria;
    get failoverCriteria(): CloudfrontMultitenantDistributionOriginGroupFailoverCriteriaList;
    putFailoverCriteria(value: CloudfrontMultitenantDistributionOriginGroupFailoverCriteria[] | cdktn.IResolvable): void;
    resetFailoverCriteria(): void;
    get failoverCriteriaInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginGroupFailoverCriteria[] | undefined;
    private _member;
    get member(): CloudfrontMultitenantDistributionOriginGroupMemberList;
    putMember(value: CloudfrontMultitenantDistributionOriginGroupMember[] | cdktn.IResolvable): void;
    resetMember(): void;
    get memberInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginGroupMember[] | undefined;
}
export declare class CloudfrontMultitenantDistributionOriginGroupList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionOriginGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionOriginGroupOutputReference;
}
export interface CloudfrontMultitenantDistributionRestrictionsGeoRestriction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#items CloudfrontMultitenantDistribution#items}
    */
    readonly items?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#restriction_type CloudfrontMultitenantDistribution#restriction_type}
    */
    readonly restrictionType: string;
}
export declare function cloudfrontMultitenantDistributionRestrictionsGeoRestrictionToTerraform(struct?: CloudfrontMultitenantDistributionRestrictionsGeoRestriction | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionRestrictionsGeoRestrictionToHclTerraform(struct?: CloudfrontMultitenantDistributionRestrictionsGeoRestriction | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionRestrictionsGeoRestrictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionRestrictionsGeoRestriction | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionRestrictionsGeoRestriction | cdktn.IResolvable | undefined);
    private _items?;
    get items(): string[];
    set items(value: string[]);
    resetItems(): void;
    get itemsInput(): string[] | undefined;
    private _restrictionType?;
    get restrictionType(): string;
    set restrictionType(value: string);
    get restrictionTypeInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionRestrictionsGeoRestrictionList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionRestrictionsGeoRestriction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionRestrictionsGeoRestrictionOutputReference;
}
export interface CloudfrontMultitenantDistributionRestrictions {
    /**
    * geo_restriction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#geo_restriction CloudfrontMultitenantDistribution#geo_restriction}
    */
    readonly geoRestriction?: CloudfrontMultitenantDistributionRestrictionsGeoRestriction[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionRestrictionsToTerraform(struct?: CloudfrontMultitenantDistributionRestrictions | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionRestrictionsToHclTerraform(struct?: CloudfrontMultitenantDistributionRestrictions | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionRestrictionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionRestrictions | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionRestrictions | cdktn.IResolvable | undefined);
    private _geoRestriction;
    get geoRestriction(): CloudfrontMultitenantDistributionRestrictionsGeoRestrictionList;
    putGeoRestriction(value: CloudfrontMultitenantDistributionRestrictionsGeoRestriction[] | cdktn.IResolvable): void;
    resetGeoRestriction(): void;
    get geoRestrictionInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionRestrictionsGeoRestriction[] | undefined;
}
export declare class CloudfrontMultitenantDistributionRestrictionsList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionRestrictions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionRestrictionsOutputReference;
}
export interface CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#comment CloudfrontMultitenantDistribution#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#default_value CloudfrontMultitenantDistribution#default_value}
    */
    readonly defaultValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#required CloudfrontMultitenantDistribution#required}
    */
    readonly required: boolean | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchemaToTerraform(struct?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchemaToHclTerraform(struct?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchemaList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchemaOutputReference;
}
export interface CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition {
    /**
    * string_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#string_schema CloudfrontMultitenantDistribution#string_schema}
    */
    readonly stringSchema?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionToTerraform(struct?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionToHclTerraform(struct?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition | cdktn.IResolvable | undefined);
    private _stringSchema;
    get stringSchema(): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchemaList;
    putStringSchema(value: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema[] | cdktn.IResolvable): void;
    resetStringSchema(): void;
    get stringSchemaInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionStringSchema[] | undefined;
}
export declare class CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionOutputReference;
}
export interface CloudfrontMultitenantDistributionTenantConfigParameterDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#name CloudfrontMultitenantDistribution#name}
    */
    readonly name: string;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#definition CloudfrontMultitenantDistribution#definition}
    */
    readonly definition?: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionTenantConfigParameterDefinitionToTerraform(struct?: CloudfrontMultitenantDistributionTenantConfigParameterDefinition | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionTenantConfigParameterDefinitionToHclTerraform(struct?: CloudfrontMultitenantDistributionTenantConfigParameterDefinition | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionTenantConfigParameterDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionTenantConfigParameterDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionTenantConfigParameterDefinition | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _definition;
    get definition(): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinitionList;
    putDefinition(value: CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition[] | cdktn.IResolvable): void;
    resetDefinition(): void;
    get definitionInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionTenantConfigParameterDefinitionDefinition[] | undefined;
}
export declare class CloudfrontMultitenantDistributionTenantConfigParameterDefinitionList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionTenantConfigParameterDefinition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionOutputReference;
}
export interface CloudfrontMultitenantDistributionTenantConfig {
    /**
    * parameter_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#parameter_definition CloudfrontMultitenantDistribution#parameter_definition}
    */
    readonly parameterDefinition?: CloudfrontMultitenantDistributionTenantConfigParameterDefinition[] | cdktn.IResolvable;
}
export declare function cloudfrontMultitenantDistributionTenantConfigToTerraform(struct?: CloudfrontMultitenantDistributionTenantConfig | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionTenantConfigToHclTerraform(struct?: CloudfrontMultitenantDistributionTenantConfig | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionTenantConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionTenantConfig | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionTenantConfig | cdktn.IResolvable | undefined);
    private _parameterDefinition;
    get parameterDefinition(): CloudfrontMultitenantDistributionTenantConfigParameterDefinitionList;
    putParameterDefinition(value: CloudfrontMultitenantDistributionTenantConfigParameterDefinition[] | cdktn.IResolvable): void;
    resetParameterDefinition(): void;
    get parameterDefinitionInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionTenantConfigParameterDefinition[] | undefined;
}
export declare class CloudfrontMultitenantDistributionTenantConfigList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionTenantConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionTenantConfigOutputReference;
}
export interface CloudfrontMultitenantDistributionTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#create CloudfrontMultitenantDistribution#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#delete CloudfrontMultitenantDistribution#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#update CloudfrontMultitenantDistribution#update}
    */
    readonly update?: string;
}
export declare function cloudfrontMultitenantDistributionTimeoutsToTerraform(struct?: CloudfrontMultitenantDistributionTimeouts | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionTimeoutsToHclTerraform(struct?: CloudfrontMultitenantDistributionTimeouts | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontMultitenantDistributionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CloudfrontMultitenantDistributionViewerCertificate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#acm_certificate_arn CloudfrontMultitenantDistribution#acm_certificate_arn}
    */
    readonly acmCertificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#cloudfront_default_certificate CloudfrontMultitenantDistribution#cloudfront_default_certificate}
    */
    readonly cloudfrontDefaultCertificate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#minimum_protocol_version CloudfrontMultitenantDistribution#minimum_protocol_version}
    */
    readonly minimumProtocolVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#ssl_support_method CloudfrontMultitenantDistribution#ssl_support_method}
    */
    readonly sslSupportMethod?: string;
}
export declare function cloudfrontMultitenantDistributionViewerCertificateToTerraform(struct?: CloudfrontMultitenantDistributionViewerCertificate | cdktn.IResolvable): any;
export declare function cloudfrontMultitenantDistributionViewerCertificateToHclTerraform(struct?: CloudfrontMultitenantDistributionViewerCertificate | cdktn.IResolvable): any;
export declare class CloudfrontMultitenantDistributionViewerCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudfrontMultitenantDistributionViewerCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontMultitenantDistributionViewerCertificate | cdktn.IResolvable | undefined);
    private _acmCertificateArn?;
    get acmCertificateArn(): string;
    set acmCertificateArn(value: string);
    resetAcmCertificateArn(): void;
    get acmCertificateArnInput(): string | undefined;
    private _cloudfrontDefaultCertificate?;
    get cloudfrontDefaultCertificate(): boolean | cdktn.IResolvable;
    set cloudfrontDefaultCertificate(value: boolean | cdktn.IResolvable);
    resetCloudfrontDefaultCertificate(): void;
    get cloudfrontDefaultCertificateInput(): boolean | cdktn.IResolvable | undefined;
    private _minimumProtocolVersion?;
    get minimumProtocolVersion(): string;
    set minimumProtocolVersion(value: string);
    resetMinimumProtocolVersion(): void;
    get minimumProtocolVersionInput(): string | undefined;
    private _sslSupportMethod?;
    get sslSupportMethod(): string;
    set sslSupportMethod(value: string);
    resetSslSupportMethod(): void;
    get sslSupportMethodInput(): string | undefined;
}
export declare class CloudfrontMultitenantDistributionViewerCertificateList extends cdktn.ComplexList {
    internalValue?: CloudfrontMultitenantDistributionViewerCertificate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudfrontMultitenantDistributionViewerCertificateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution aws_cloudfront_multitenant_distribution}
*/
export declare class CloudfrontMultitenantDistribution extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_multitenant_distribution";
    /**
    * Generates CDKTN code for importing a CloudfrontMultitenantDistribution resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontMultitenantDistribution to import
    * @param importFromId The id of the existing CloudfrontMultitenantDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontMultitenantDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_multitenant_distribution aws_cloudfront_multitenant_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontMultitenantDistributionConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontMultitenantDistributionConfig);
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    get commentInput(): string | undefined;
    get connectionMode(): string;
    private _defaultRootObject?;
    get defaultRootObject(): string;
    set defaultRootObject(value: string);
    resetDefaultRootObject(): void;
    get defaultRootObjectInput(): string | undefined;
    get domainName(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    get id(): string;
    get inProgressInvalidationBatches(): number;
    get lastModifiedTime(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _webAclId?;
    get webAclId(): string;
    set webAclId(value: string);
    resetWebAclId(): void;
    get webAclIdInput(): string | undefined;
    private _activeTrustedKeyGroups;
    get activeTrustedKeyGroups(): CloudfrontMultitenantDistributionActiveTrustedKeyGroupsList;
    putActiveTrustedKeyGroups(value: CloudfrontMultitenantDistributionActiveTrustedKeyGroups[] | cdktn.IResolvable): void;
    resetActiveTrustedKeyGroups(): void;
    get activeTrustedKeyGroupsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionActiveTrustedKeyGroups[] | undefined;
    private _cacheBehavior;
    get cacheBehavior(): CloudfrontMultitenantDistributionCacheBehaviorList;
    putCacheBehavior(value: CloudfrontMultitenantDistributionCacheBehavior[] | cdktn.IResolvable): void;
    resetCacheBehavior(): void;
    get cacheBehaviorInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionCacheBehavior[] | undefined;
    private _customErrorResponse;
    get customErrorResponse(): CloudfrontMultitenantDistributionCustomErrorResponseList;
    putCustomErrorResponse(value: CloudfrontMultitenantDistributionCustomErrorResponse[] | cdktn.IResolvable): void;
    resetCustomErrorResponse(): void;
    get customErrorResponseInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionCustomErrorResponse[] | undefined;
    private _defaultCacheBehavior;
    get defaultCacheBehavior(): CloudfrontMultitenantDistributionDefaultCacheBehaviorList;
    putDefaultCacheBehavior(value: CloudfrontMultitenantDistributionDefaultCacheBehavior[] | cdktn.IResolvable): void;
    resetDefaultCacheBehavior(): void;
    get defaultCacheBehaviorInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionDefaultCacheBehavior[] | undefined;
    private _origin;
    get origin(): CloudfrontMultitenantDistributionOriginList;
    putOrigin(value: CloudfrontMultitenantDistributionOrigin[] | cdktn.IResolvable): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOrigin[] | undefined;
    private _originGroup;
    get originGroup(): CloudfrontMultitenantDistributionOriginGroupList;
    putOriginGroup(value: CloudfrontMultitenantDistributionOriginGroup[] | cdktn.IResolvable): void;
    resetOriginGroup(): void;
    get originGroupInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionOriginGroup[] | undefined;
    private _restrictions;
    get restrictions(): CloudfrontMultitenantDistributionRestrictionsList;
    putRestrictions(value: CloudfrontMultitenantDistributionRestrictions[] | cdktn.IResolvable): void;
    resetRestrictions(): void;
    get restrictionsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionRestrictions[] | undefined;
    private _tenantConfig;
    get tenantConfig(): CloudfrontMultitenantDistributionTenantConfigList;
    putTenantConfig(value: CloudfrontMultitenantDistributionTenantConfig[] | cdktn.IResolvable): void;
    resetTenantConfig(): void;
    get tenantConfigInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionTenantConfig[] | undefined;
    private _timeouts;
    get timeouts(): CloudfrontMultitenantDistributionTimeoutsOutputReference;
    putTimeouts(value: CloudfrontMultitenantDistributionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionTimeouts | undefined;
    private _viewerCertificate;
    get viewerCertificate(): CloudfrontMultitenantDistributionViewerCertificateList;
    putViewerCertificate(value: CloudfrontMultitenantDistributionViewerCertificate[] | cdktn.IResolvable): void;
    resetViewerCertificate(): void;
    get viewerCertificateInput(): cdktn.IResolvable | CloudfrontMultitenantDistributionViewerCertificate[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
