/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreBrowserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#description BedrockagentcoreBrowser#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#execution_role_arn BedrockagentcoreBrowser#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#name BedrockagentcoreBrowser#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#region BedrockagentcoreBrowser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#tags BedrockagentcoreBrowser#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * browser_signing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#browser_signing BedrockagentcoreBrowser#browser_signing}
    */
    readonly browserSigning?: BedrockagentcoreBrowserBrowserSigning[] | cdktn.IResolvable;
    /**
    * certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#certificate BedrockagentcoreBrowser#certificate}
    */
    readonly certificate?: BedrockagentcoreBrowserCertificate[] | cdktn.IResolvable;
    /**
    * enterprise_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#enterprise_policy BedrockagentcoreBrowser#enterprise_policy}
    */
    readonly enterprisePolicy?: BedrockagentcoreBrowserEnterprisePolicy[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#network_configuration BedrockagentcoreBrowser#network_configuration}
    */
    readonly networkConfiguration?: BedrockagentcoreBrowserNetworkConfiguration[] | cdktn.IResolvable;
    /**
    * recording block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#recording BedrockagentcoreBrowser#recording}
    */
    readonly recording?: BedrockagentcoreBrowserRecording[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#timeouts BedrockagentcoreBrowser#timeouts}
    */
    readonly timeouts?: BedrockagentcoreBrowserTimeouts;
}
export interface BedrockagentcoreBrowserBrowserSigning {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#enabled BedrockagentcoreBrowser#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserBrowserSigningToTerraform(struct?: BedrockagentcoreBrowserBrowserSigning | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserBrowserSigningToHclTerraform(struct?: BedrockagentcoreBrowserBrowserSigning | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserBrowserSigningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserBrowserSigning | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserBrowserSigning | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class BedrockagentcoreBrowserBrowserSigningList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserBrowserSigning[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserBrowserSigningOutputReference;
}
export interface BedrockagentcoreBrowserCertificateLocationSecretsManager {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#secret_arn BedrockagentcoreBrowser#secret_arn}
    */
    readonly secretArn: string;
}
export declare function bedrockagentcoreBrowserCertificateLocationSecretsManagerToTerraform(struct?: BedrockagentcoreBrowserCertificateLocationSecretsManager | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCertificateLocationSecretsManagerToHclTerraform(struct?: BedrockagentcoreBrowserCertificateLocationSecretsManager | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCertificateLocationSecretsManagerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserCertificateLocationSecretsManager | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCertificateLocationSecretsManager | cdktn.IResolvable | undefined);
    private _secretArn?;
    get secretArn(): string;
    set secretArn(value: string);
    get secretArnInput(): string | undefined;
}
export declare class BedrockagentcoreBrowserCertificateLocationSecretsManagerList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserCertificateLocationSecretsManager[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserCertificateLocationSecretsManagerOutputReference;
}
export interface BedrockagentcoreBrowserCertificateLocation {
    /**
    * secrets_manager block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#secrets_manager BedrockagentcoreBrowser#secrets_manager}
    */
    readonly secretsManager?: BedrockagentcoreBrowserCertificateLocationSecretsManager[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserCertificateLocationToTerraform(struct?: BedrockagentcoreBrowserCertificateLocation | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCertificateLocationToHclTerraform(struct?: BedrockagentcoreBrowserCertificateLocation | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCertificateLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserCertificateLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCertificateLocation | cdktn.IResolvable | undefined);
    private _secretsManager;
    get secretsManager(): BedrockagentcoreBrowserCertificateLocationSecretsManagerList;
    putSecretsManager(value: BedrockagentcoreBrowserCertificateLocationSecretsManager[] | cdktn.IResolvable): void;
    resetSecretsManager(): void;
    get secretsManagerInput(): cdktn.IResolvable | BedrockagentcoreBrowserCertificateLocationSecretsManager[] | undefined;
}
export declare class BedrockagentcoreBrowserCertificateLocationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserCertificateLocation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserCertificateLocationOutputReference;
}
export interface BedrockagentcoreBrowserCertificate {
    /**
    * location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#location BedrockagentcoreBrowser#location}
    */
    readonly location?: BedrockagentcoreBrowserCertificateLocation[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserCertificateToTerraform(struct?: BedrockagentcoreBrowserCertificate | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserCertificateToHclTerraform(struct?: BedrockagentcoreBrowserCertificate | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserCertificate | cdktn.IResolvable | undefined);
    private _location;
    get location(): BedrockagentcoreBrowserCertificateLocationList;
    putLocation(value: BedrockagentcoreBrowserCertificateLocation[] | cdktn.IResolvable): void;
    resetLocation(): void;
    get locationInput(): cdktn.IResolvable | BedrockagentcoreBrowserCertificateLocation[] | undefined;
}
export declare class BedrockagentcoreBrowserCertificateList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserCertificate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserCertificateOutputReference;
}
export interface BedrockagentcoreBrowserEnterprisePolicyLocationS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#bucket BedrockagentcoreBrowser#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#prefix BedrockagentcoreBrowser#prefix}
    */
    readonly prefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#version_id BedrockagentcoreBrowser#version_id}
    */
    readonly versionId?: string;
}
export declare function bedrockagentcoreBrowserEnterprisePolicyLocationS3ToTerraform(struct?: BedrockagentcoreBrowserEnterprisePolicyLocationS3 | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserEnterprisePolicyLocationS3ToHclTerraform(struct?: BedrockagentcoreBrowserEnterprisePolicyLocationS3 | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserEnterprisePolicyLocationS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserEnterprisePolicyLocationS3 | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserEnterprisePolicyLocationS3 | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
}
export declare class BedrockagentcoreBrowserEnterprisePolicyLocationS3List extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserEnterprisePolicyLocationS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserEnterprisePolicyLocationS3OutputReference;
}
export interface BedrockagentcoreBrowserEnterprisePolicyLocation {
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#s3 BedrockagentcoreBrowser#s3}
    */
    readonly s3?: BedrockagentcoreBrowserEnterprisePolicyLocationS3[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserEnterprisePolicyLocationToTerraform(struct?: BedrockagentcoreBrowserEnterprisePolicyLocation | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserEnterprisePolicyLocationToHclTerraform(struct?: BedrockagentcoreBrowserEnterprisePolicyLocation | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserEnterprisePolicyLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserEnterprisePolicyLocation | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserEnterprisePolicyLocation | cdktn.IResolvable | undefined);
    private _s3;
    get s3(): BedrockagentcoreBrowserEnterprisePolicyLocationS3List;
    putS3(value: BedrockagentcoreBrowserEnterprisePolicyLocationS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | BedrockagentcoreBrowserEnterprisePolicyLocationS3[] | undefined;
}
export declare class BedrockagentcoreBrowserEnterprisePolicyLocationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserEnterprisePolicyLocation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserEnterprisePolicyLocationOutputReference;
}
export interface BedrockagentcoreBrowserEnterprisePolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#type BedrockagentcoreBrowser#type}
    */
    readonly type?: string;
    /**
    * location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#location BedrockagentcoreBrowser#location}
    */
    readonly location?: BedrockagentcoreBrowserEnterprisePolicyLocation[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserEnterprisePolicyToTerraform(struct?: BedrockagentcoreBrowserEnterprisePolicy | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserEnterprisePolicyToHclTerraform(struct?: BedrockagentcoreBrowserEnterprisePolicy | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserEnterprisePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserEnterprisePolicy | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserEnterprisePolicy | cdktn.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _location;
    get location(): BedrockagentcoreBrowserEnterprisePolicyLocationList;
    putLocation(value: BedrockagentcoreBrowserEnterprisePolicyLocation[] | cdktn.IResolvable): void;
    resetLocation(): void;
    get locationInput(): cdktn.IResolvable | BedrockagentcoreBrowserEnterprisePolicyLocation[] | undefined;
}
export declare class BedrockagentcoreBrowserEnterprisePolicyList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserEnterprisePolicy[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserEnterprisePolicyOutputReference;
}
export interface BedrockagentcoreBrowserNetworkConfigurationVpcConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#security_groups BedrockagentcoreBrowser#security_groups}
    */
    readonly securityGroups: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#subnets BedrockagentcoreBrowser#subnets}
    */
    readonly subnets: string[];
}
export declare function bedrockagentcoreBrowserNetworkConfigurationVpcConfigToTerraform(struct?: BedrockagentcoreBrowserNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserNetworkConfigurationVpcConfigToHclTerraform(struct?: BedrockagentcoreBrowserNetworkConfigurationVpcConfig | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserNetworkConfigurationVpcConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserNetworkConfigurationVpcConfig | cdktn.IResolvable | undefined);
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    get subnetsInput(): string[] | undefined;
}
export declare class BedrockagentcoreBrowserNetworkConfigurationVpcConfigList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserNetworkConfigurationVpcConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserNetworkConfigurationVpcConfigOutputReference;
}
export interface BedrockagentcoreBrowserNetworkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#network_mode BedrockagentcoreBrowser#network_mode}
    */
    readonly networkMode: string;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#vpc_config BedrockagentcoreBrowser#vpc_config}
    */
    readonly vpcConfig?: BedrockagentcoreBrowserNetworkConfigurationVpcConfig[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserNetworkConfigurationToTerraform(struct?: BedrockagentcoreBrowserNetworkConfiguration | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserNetworkConfigurationToHclTerraform(struct?: BedrockagentcoreBrowserNetworkConfiguration | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserNetworkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserNetworkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserNetworkConfiguration | cdktn.IResolvable | undefined);
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    get networkModeInput(): string | undefined;
    private _vpcConfig;
    get vpcConfig(): BedrockagentcoreBrowserNetworkConfigurationVpcConfigList;
    putVpcConfig(value: BedrockagentcoreBrowserNetworkConfigurationVpcConfig[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | BedrockagentcoreBrowserNetworkConfigurationVpcConfig[] | undefined;
}
export declare class BedrockagentcoreBrowserNetworkConfigurationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserNetworkConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserNetworkConfigurationOutputReference;
}
export interface BedrockagentcoreBrowserRecordingS3Location {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#bucket BedrockagentcoreBrowser#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#prefix BedrockagentcoreBrowser#prefix}
    */
    readonly prefix: string;
}
export declare function bedrockagentcoreBrowserRecordingS3LocationToTerraform(struct?: BedrockagentcoreBrowserRecordingS3Location | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserRecordingS3LocationToHclTerraform(struct?: BedrockagentcoreBrowserRecordingS3Location | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserRecordingS3LocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserRecordingS3Location | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserRecordingS3Location | cdktn.IResolvable | undefined);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
}
export declare class BedrockagentcoreBrowserRecordingS3LocationList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserRecordingS3Location[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserRecordingS3LocationOutputReference;
}
export interface BedrockagentcoreBrowserRecording {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#enabled BedrockagentcoreBrowser#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * s3_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#s3_location BedrockagentcoreBrowser#s3_location}
    */
    readonly s3Location?: BedrockagentcoreBrowserRecordingS3Location[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreBrowserRecordingToTerraform(struct?: BedrockagentcoreBrowserRecording | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserRecordingToHclTerraform(struct?: BedrockagentcoreBrowserRecording | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserRecordingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreBrowserRecording | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserRecording | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _s3Location;
    get s3Location(): BedrockagentcoreBrowserRecordingS3LocationList;
    putS3Location(value: BedrockagentcoreBrowserRecordingS3Location[] | cdktn.IResolvable): void;
    resetS3Location(): void;
    get s3LocationInput(): cdktn.IResolvable | BedrockagentcoreBrowserRecordingS3Location[] | undefined;
}
export declare class BedrockagentcoreBrowserRecordingList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreBrowserRecording[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreBrowserRecordingOutputReference;
}
export interface BedrockagentcoreBrowserTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#create BedrockagentcoreBrowser#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#delete BedrockagentcoreBrowser#delete}
    */
    readonly delete?: string;
}
export declare function bedrockagentcoreBrowserTimeoutsToTerraform(struct?: BedrockagentcoreBrowserTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreBrowserTimeoutsToHclTerraform(struct?: BedrockagentcoreBrowserTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreBrowserTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreBrowserTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreBrowserTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser aws_bedrockagentcore_browser}
*/
export declare class BedrockagentcoreBrowser extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_browser";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreBrowser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreBrowser to import
    * @param importFromId The id of the existing BedrockagentcoreBrowser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreBrowser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_browser aws_bedrockagentcore_browser} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreBrowserConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreBrowserConfig);
    get browserArn(): string;
    get browserId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _browserSigning;
    get browserSigning(): BedrockagentcoreBrowserBrowserSigningList;
    putBrowserSigning(value: BedrockagentcoreBrowserBrowserSigning[] | cdktn.IResolvable): void;
    resetBrowserSigning(): void;
    get browserSigningInput(): cdktn.IResolvable | BedrockagentcoreBrowserBrowserSigning[] | undefined;
    private _certificate;
    get certificate(): BedrockagentcoreBrowserCertificateList;
    putCertificate(value: BedrockagentcoreBrowserCertificate[] | cdktn.IResolvable): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | BedrockagentcoreBrowserCertificate[] | undefined;
    private _enterprisePolicy;
    get enterprisePolicy(): BedrockagentcoreBrowserEnterprisePolicyList;
    putEnterprisePolicy(value: BedrockagentcoreBrowserEnterprisePolicy[] | cdktn.IResolvable): void;
    resetEnterprisePolicy(): void;
    get enterprisePolicyInput(): cdktn.IResolvable | BedrockagentcoreBrowserEnterprisePolicy[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): BedrockagentcoreBrowserNetworkConfigurationList;
    putNetworkConfiguration(value: BedrockagentcoreBrowserNetworkConfiguration[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | BedrockagentcoreBrowserNetworkConfiguration[] | undefined;
    private _recording;
    get recording(): BedrockagentcoreBrowserRecordingList;
    putRecording(value: BedrockagentcoreBrowserRecording[] | cdktn.IResolvable): void;
    resetRecording(): void;
    get recordingInput(): cdktn.IResolvable | BedrockagentcoreBrowserRecording[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreBrowserTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreBrowserTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreBrowserTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
