/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBackupPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/backup_plan#id DataAwsBackupPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/backup_plan#plan_id DataAwsBackupPlan#plan_id}
    */
    readonly planId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/backup_plan#region DataAwsBackupPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/backup_plan#tags DataAwsBackupPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export interface DataAwsBackupPlanRuleCopyActionLifecycle {
}
export declare function dataAwsBackupPlanRuleCopyActionLifecycleToTerraform(struct?: DataAwsBackupPlanRuleCopyActionLifecycle): any;
export declare function dataAwsBackupPlanRuleCopyActionLifecycleToHclTerraform(struct?: DataAwsBackupPlanRuleCopyActionLifecycle): any;
export declare class DataAwsBackupPlanRuleCopyActionLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBackupPlanRuleCopyActionLifecycle | undefined;
    set internalValue(value: DataAwsBackupPlanRuleCopyActionLifecycle | undefined);
    get coldStorageAfter(): number;
    get deleteAfter(): number;
    get optInToArchiveForSupportedResources(): cdktn.IResolvable;
}
export declare class DataAwsBackupPlanRuleCopyActionLifecycleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBackupPlanRuleCopyActionLifecycleOutputReference;
}
export interface DataAwsBackupPlanRuleCopyAction {
}
export declare function dataAwsBackupPlanRuleCopyActionToTerraform(struct?: DataAwsBackupPlanRuleCopyAction): any;
export declare function dataAwsBackupPlanRuleCopyActionToHclTerraform(struct?: DataAwsBackupPlanRuleCopyAction): any;
export declare class DataAwsBackupPlanRuleCopyActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBackupPlanRuleCopyAction | undefined;
    set internalValue(value: DataAwsBackupPlanRuleCopyAction | undefined);
    get destinationVaultArn(): string;
    private _lifecycle;
    get lifecycle(): DataAwsBackupPlanRuleCopyActionLifecycleList;
}
export declare class DataAwsBackupPlanRuleCopyActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBackupPlanRuleCopyActionOutputReference;
}
export interface DataAwsBackupPlanRuleLifecycle {
}
export declare function dataAwsBackupPlanRuleLifecycleToTerraform(struct?: DataAwsBackupPlanRuleLifecycle): any;
export declare function dataAwsBackupPlanRuleLifecycleToHclTerraform(struct?: DataAwsBackupPlanRuleLifecycle): any;
export declare class DataAwsBackupPlanRuleLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBackupPlanRuleLifecycle | undefined;
    set internalValue(value: DataAwsBackupPlanRuleLifecycle | undefined);
    get coldStorageAfter(): number;
    get deleteAfter(): number;
    get optInToArchiveForSupportedResources(): cdktn.IResolvable;
}
export declare class DataAwsBackupPlanRuleLifecycleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBackupPlanRuleLifecycleOutputReference;
}
export interface DataAwsBackupPlanRuleScanAction {
}
export declare function dataAwsBackupPlanRuleScanActionToTerraform(struct?: DataAwsBackupPlanRuleScanAction): any;
export declare function dataAwsBackupPlanRuleScanActionToHclTerraform(struct?: DataAwsBackupPlanRuleScanAction): any;
export declare class DataAwsBackupPlanRuleScanActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBackupPlanRuleScanAction | undefined;
    set internalValue(value: DataAwsBackupPlanRuleScanAction | undefined);
    get malwareScanner(): string;
    get scanMode(): string;
}
export declare class DataAwsBackupPlanRuleScanActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBackupPlanRuleScanActionOutputReference;
}
export interface DataAwsBackupPlanRule {
}
export declare function dataAwsBackupPlanRuleToTerraform(struct?: DataAwsBackupPlanRule): any;
export declare function dataAwsBackupPlanRuleToHclTerraform(struct?: DataAwsBackupPlanRule): any;
export declare class DataAwsBackupPlanRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBackupPlanRule | undefined;
    set internalValue(value: DataAwsBackupPlanRule | undefined);
    get completionWindow(): number;
    private _copyAction;
    get copyAction(): DataAwsBackupPlanRuleCopyActionList;
    get enableContinuousBackup(): cdktn.IResolvable;
    private _lifecycle;
    get lifecycle(): DataAwsBackupPlanRuleLifecycleList;
    private _recoveryPointTags;
    get recoveryPointTags(): cdktn.StringMap;
    get ruleId(): string;
    get ruleName(): string;
    private _scanAction;
    get scanAction(): DataAwsBackupPlanRuleScanActionList;
    get schedule(): string;
    get scheduleExpressionTimezone(): string;
    get startWindow(): number;
    get targetLogicallyAirGappedBackupVaultArn(): string;
    get targetVaultName(): string;
}
export declare class DataAwsBackupPlanRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBackupPlanRuleOutputReference;
}
export interface DataAwsBackupPlanScanSetting {
}
export declare function dataAwsBackupPlanScanSettingToTerraform(struct?: DataAwsBackupPlanScanSetting): any;
export declare function dataAwsBackupPlanScanSettingToHclTerraform(struct?: DataAwsBackupPlanScanSetting): any;
export declare class DataAwsBackupPlanScanSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAwsBackupPlanScanSetting | undefined;
    set internalValue(value: DataAwsBackupPlanScanSetting | undefined);
    get malwareScanner(): string;
    get resourceTypes(): string[];
    get scannerRoleArn(): string;
}
export declare class DataAwsBackupPlanScanSettingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAwsBackupPlanScanSettingOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/backup_plan aws_backup_plan}
*/
export declare class DataAwsBackupPlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_backup_plan";
    /**
    * Generates CDKTN code for importing a DataAwsBackupPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBackupPlan to import
    * @param importFromId The id of the existing DataAwsBackupPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/backup_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBackupPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/data-sources/backup_plan aws_backup_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBackupPlanConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsBackupPlanConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _planId?;
    get planId(): string;
    set planId(value: string);
    get planIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rule;
    get rule(): DataAwsBackupPlanRuleList;
    private _scanSetting;
    get scanSetting(): DataAwsBackupPlanScanSettingList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
