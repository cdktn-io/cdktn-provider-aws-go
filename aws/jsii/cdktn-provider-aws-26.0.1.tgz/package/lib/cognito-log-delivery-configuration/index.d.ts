/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CognitoLogDeliveryConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#region CognitoLogDeliveryConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#user_pool_id CognitoLogDeliveryConfiguration#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * log_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#log_configurations CognitoLogDeliveryConfiguration#log_configurations}
    */
    readonly logConfigurations?: CognitoLogDeliveryConfigurationLogConfigurations[] | cdktn.IResolvable;
}
export interface CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#log_group_arn CognitoLogDeliveryConfiguration#log_group_arn}
    */
    readonly logGroupArn?: string;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfigurationToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfigurationToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration | cdktn.IResolvable | undefined);
    private _logGroupArn?;
    get logGroupArn(): string;
    set logGroupArn(value: string);
    resetLogGroupArn(): void;
    get logGroupArnInput(): string | undefined;
}
export declare class CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfigurationList extends cdktn.ComplexList {
    internalValue?: CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfigurationOutputReference;
}
export interface CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#stream_arn CognitoLogDeliveryConfiguration#stream_arn}
    */
    readonly streamArn?: string;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration | cdktn.IResolvable | undefined);
    private _streamArn?;
    get streamArn(): string;
    set streamArn(value: string);
    resetStreamArn(): void;
    get streamArnInput(): string | undefined;
}
export declare class CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationList extends cdktn.ComplexList {
    internalValue?: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationOutputReference;
}
export interface CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#bucket_arn CognitoLogDeliveryConfiguration#bucket_arn}
    */
    readonly bucketArn?: string;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration | cdktn.IResolvable | undefined);
    private _bucketArn?;
    get bucketArn(): string;
    set bucketArn(value: string);
    resetBucketArn(): void;
    get bucketArnInput(): string | undefined;
}
export declare class CognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationList extends cdktn.ComplexList {
    internalValue?: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationOutputReference;
}
export interface CognitoLogDeliveryConfigurationLogConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#event_source CognitoLogDeliveryConfiguration#event_source}
    */
    readonly eventSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#log_level CognitoLogDeliveryConfiguration#log_level}
    */
    readonly logLevel: string;
    /**
    * cloud_watch_logs_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#cloud_watch_logs_configuration CognitoLogDeliveryConfiguration#cloud_watch_logs_configuration}
    */
    readonly cloudWatchLogsConfiguration?: CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration[] | cdktn.IResolvable;
    /**
    * firehose_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#firehose_configuration CognitoLogDeliveryConfiguration#firehose_configuration}
    */
    readonly firehoseConfiguration?: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration[] | cdktn.IResolvable;
    /**
    * s3_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#s3_configuration CognitoLogDeliveryConfiguration#s3_configuration}
    */
    readonly s3Configuration?: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration[] | cdktn.IResolvable;
}
export declare function cognitoLogDeliveryConfigurationLogConfigurationsToTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable): any;
export declare function cognitoLogDeliveryConfigurationLogConfigurationsToHclTerraform(struct?: CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable): any;
export declare class CognitoLogDeliveryConfigurationLogConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: CognitoLogDeliveryConfigurationLogConfigurations | cdktn.IResolvable | undefined);
    private _eventSource?;
    get eventSource(): string;
    set eventSource(value: string);
    get eventSourceInput(): string | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    get logLevelInput(): string | undefined;
    private _cloudWatchLogsConfiguration;
    get cloudWatchLogsConfiguration(): CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfigurationList;
    putCloudWatchLogsConfiguration(value: CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration[] | cdktn.IResolvable): void;
    resetCloudWatchLogsConfiguration(): void;
    get cloudWatchLogsConfigurationInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurationsCloudWatchLogsConfiguration[] | undefined;
    private _firehoseConfiguration;
    get firehoseConfiguration(): CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfigurationList;
    putFirehoseConfiguration(value: CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration[] | cdktn.IResolvable): void;
    resetFirehoseConfiguration(): void;
    get firehoseConfigurationInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurationsFirehoseConfiguration[] | undefined;
    private _s3Configuration;
    get s3Configuration(): CognitoLogDeliveryConfigurationLogConfigurationsS3ConfigurationList;
    putS3Configuration(value: CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration[] | cdktn.IResolvable): void;
    resetS3Configuration(): void;
    get s3ConfigurationInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurationsS3Configuration[] | undefined;
}
export declare class CognitoLogDeliveryConfigurationLogConfigurationsList extends cdktn.ComplexList {
    internalValue?: CognitoLogDeliveryConfigurationLogConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CognitoLogDeliveryConfigurationLogConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration aws_cognito_log_delivery_configuration}
*/
export declare class CognitoLogDeliveryConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_log_delivery_configuration";
    /**
    * Generates CDKTN code for importing a CognitoLogDeliveryConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CognitoLogDeliveryConfiguration to import
    * @param importFromId The id of the existing CognitoLogDeliveryConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CognitoLogDeliveryConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cognito_log_delivery_configuration aws_cognito_log_delivery_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CognitoLogDeliveryConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: CognitoLogDeliveryConfigurationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _logConfigurations;
    get logConfigurations(): CognitoLogDeliveryConfigurationLogConfigurationsList;
    putLogConfigurations(value: CognitoLogDeliveryConfigurationLogConfigurations[] | cdktn.IResolvable): void;
    resetLogConfigurations(): void;
    get logConfigurationsInput(): cdktn.IResolvable | CognitoLogDeliveryConfigurationLogConfigurations[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
