/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockGuardrailConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#blocked_input_messaging BedrockGuardrail#blocked_input_messaging}
    */
    readonly blockedInputMessaging: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#blocked_outputs_messaging BedrockGuardrail#blocked_outputs_messaging}
    */
    readonly blockedOutputsMessaging: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#description BedrockGuardrail#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#kms_key_arn BedrockGuardrail#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#name BedrockGuardrail#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#region BedrockGuardrail#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#tags BedrockGuardrail#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * content_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#content_policy_config BedrockGuardrail#content_policy_config}
    */
    readonly contentPolicyConfig?: BedrockGuardrailContentPolicyConfig[] | cdktn.IResolvable;
    /**
    * contextual_grounding_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#contextual_grounding_policy_config BedrockGuardrail#contextual_grounding_policy_config}
    */
    readonly contextualGroundingPolicyConfig?: BedrockGuardrailContextualGroundingPolicyConfig[] | cdktn.IResolvable;
    /**
    * cross_region_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#cross_region_config BedrockGuardrail#cross_region_config}
    */
    readonly crossRegionConfig?: BedrockGuardrailCrossRegionConfig[] | cdktn.IResolvable;
    /**
    * sensitive_information_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#sensitive_information_policy_config BedrockGuardrail#sensitive_information_policy_config}
    */
    readonly sensitiveInformationPolicyConfig?: BedrockGuardrailSensitiveInformationPolicyConfig[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#timeouts BedrockGuardrail#timeouts}
    */
    readonly timeouts?: BedrockGuardrailTimeouts;
    /**
    * topic_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#topic_policy_config BedrockGuardrail#topic_policy_config}
    */
    readonly topicPolicyConfig?: BedrockGuardrailTopicPolicyConfig[] | cdktn.IResolvable;
    /**
    * word_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#word_policy_config BedrockGuardrail#word_policy_config}
    */
    readonly wordPolicyConfig?: BedrockGuardrailWordPolicyConfig[] | cdktn.IResolvable;
}
export interface BedrockGuardrailContentPolicyConfigTierConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#tier_name BedrockGuardrail#tier_name}
    */
    readonly tierName?: string;
}
export declare function bedrockGuardrailContentPolicyConfigTierConfigToTerraform(struct?: BedrockGuardrailContentPolicyConfigTierConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContentPolicyConfigTierConfigToHclTerraform(struct?: BedrockGuardrailContentPolicyConfigTierConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContentPolicyConfigTierConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailContentPolicyConfigTierConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContentPolicyConfigTierConfig | cdktn.IResolvable | undefined);
    private _tierName?;
    get tierName(): string;
    set tierName(value: string);
    resetTierName(): void;
    get tierNameInput(): string | undefined;
}
export declare class BedrockGuardrailContentPolicyConfigTierConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailContentPolicyConfigTierConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailContentPolicyConfigTierConfigOutputReference;
}
export interface BedrockGuardrailContentPolicyConfigFiltersConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_modalities BedrockGuardrail#input_modalities}
    */
    readonly inputModalities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_strength BedrockGuardrail#input_strength}
    */
    readonly inputStrength: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_modalities BedrockGuardrail#output_modalities}
    */
    readonly outputModalities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_strength BedrockGuardrail#output_strength}
    */
    readonly outputStrength: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type: string;
}
export declare function bedrockGuardrailContentPolicyConfigFiltersConfigToTerraform(struct?: BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContentPolicyConfigFiltersConfigToHclTerraform(struct?: BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContentPolicyConfigFiltersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContentPolicyConfigFiltersConfig | cdktn.IResolvable | undefined);
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _inputModalities?;
    get inputModalities(): string[];
    set inputModalities(value: string[]);
    resetInputModalities(): void;
    get inputModalitiesInput(): string[] | undefined;
    private _inputStrength?;
    get inputStrength(): string;
    set inputStrength(value: string);
    get inputStrengthInput(): string | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputModalities?;
    get outputModalities(): string[];
    set outputModalities(value: string[]);
    resetOutputModalities(): void;
    get outputModalitiesInput(): string[] | undefined;
    private _outputStrength?;
    get outputStrength(): string;
    set outputStrength(value: string);
    get outputStrengthInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailContentPolicyConfigFiltersConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailContentPolicyConfigFiltersConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailContentPolicyConfigFiltersConfigOutputReference;
}
export interface BedrockGuardrailContentPolicyConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#tier_config BedrockGuardrail#tier_config}
    */
    readonly tierConfig?: BedrockGuardrailContentPolicyConfigTierConfig[] | cdktn.IResolvable;
    /**
    * filters_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#filters_config BedrockGuardrail#filters_config}
    */
    readonly filtersConfig?: BedrockGuardrailContentPolicyConfigFiltersConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailContentPolicyConfigToTerraform(struct?: BedrockGuardrailContentPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContentPolicyConfigToHclTerraform(struct?: BedrockGuardrailContentPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContentPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailContentPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContentPolicyConfig | cdktn.IResolvable | undefined);
    private _tierConfig;
    get tierConfig(): BedrockGuardrailContentPolicyConfigTierConfigList;
    putTierConfig(value: BedrockGuardrailContentPolicyConfigTierConfig[] | cdktn.IResolvable): void;
    resetTierConfig(): void;
    get tierConfigInput(): cdktn.IResolvable | BedrockGuardrailContentPolicyConfigTierConfig[] | undefined;
    private _filtersConfig;
    get filtersConfig(): BedrockGuardrailContentPolicyConfigFiltersConfigList;
    putFiltersConfig(value: BedrockGuardrailContentPolicyConfigFiltersConfig[] | cdktn.IResolvable): void;
    resetFiltersConfig(): void;
    get filtersConfigInput(): cdktn.IResolvable | BedrockGuardrailContentPolicyConfigFiltersConfig[] | undefined;
}
export declare class BedrockGuardrailContentPolicyConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailContentPolicyConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailContentPolicyConfigOutputReference;
}
export interface BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#threshold BedrockGuardrail#threshold}
    */
    readonly threshold: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type: string;
}
export declare function bedrockGuardrailContextualGroundingPolicyConfigFiltersConfigToTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContextualGroundingPolicyConfigFiltersConfigToHclTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig | cdktn.IResolvable | undefined);
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigOutputReference;
}
export interface BedrockGuardrailContextualGroundingPolicyConfig {
    /**
    * filters_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#filters_config BedrockGuardrail#filters_config}
    */
    readonly filtersConfig?: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailContextualGroundingPolicyConfigToTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailContextualGroundingPolicyConfigToHclTerraform(struct?: BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailContextualGroundingPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailContextualGroundingPolicyConfig | cdktn.IResolvable | undefined);
    private _filtersConfig;
    get filtersConfig(): BedrockGuardrailContextualGroundingPolicyConfigFiltersConfigList;
    putFiltersConfig(value: BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | cdktn.IResolvable): void;
    resetFiltersConfig(): void;
    get filtersConfigInput(): cdktn.IResolvable | BedrockGuardrailContextualGroundingPolicyConfigFiltersConfig[] | undefined;
}
export declare class BedrockGuardrailContextualGroundingPolicyConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailContextualGroundingPolicyConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailContextualGroundingPolicyConfigOutputReference;
}
export interface BedrockGuardrailCrossRegionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#guardrail_profile_identifier BedrockGuardrail#guardrail_profile_identifier}
    */
    readonly guardrailProfileIdentifier: string;
}
export declare function bedrockGuardrailCrossRegionConfigToTerraform(struct?: BedrockGuardrailCrossRegionConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailCrossRegionConfigToHclTerraform(struct?: BedrockGuardrailCrossRegionConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailCrossRegionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailCrossRegionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailCrossRegionConfig | cdktn.IResolvable | undefined);
    private _guardrailProfileIdentifier?;
    get guardrailProfileIdentifier(): string;
    set guardrailProfileIdentifier(value: string);
    get guardrailProfileIdentifierInput(): string | undefined;
}
export declare class BedrockGuardrailCrossRegionConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailCrossRegionConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailCrossRegionConfigOutputReference;
}
export interface BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#action BedrockGuardrail#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type: string;
}
export declare function bedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigToTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigToHclTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigOutputReference;
}
export interface BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#action BedrockGuardrail#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#description BedrockGuardrail#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#name BedrockGuardrail#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#pattern BedrockGuardrail#pattern}
    */
    readonly pattern: string;
}
export declare function bedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigToTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigToHclTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    get patternInput(): string | undefined;
}
export declare class BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigOutputReference;
}
export interface BedrockGuardrailSensitiveInformationPolicyConfig {
    /**
    * pii_entities_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#pii_entities_config BedrockGuardrail#pii_entities_config}
    */
    readonly piiEntitiesConfig?: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | cdktn.IResolvable;
    /**
    * regexes_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#regexes_config BedrockGuardrail#regexes_config}
    */
    readonly regexesConfig?: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailSensitiveInformationPolicyConfigToTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailSensitiveInformationPolicyConfigToHclTerraform(struct?: BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailSensitiveInformationPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailSensitiveInformationPolicyConfig | cdktn.IResolvable | undefined);
    private _piiEntitiesConfig;
    get piiEntitiesConfig(): BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfigList;
    putPiiEntitiesConfig(value: BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | cdktn.IResolvable): void;
    resetPiiEntitiesConfig(): void;
    get piiEntitiesConfigInput(): cdktn.IResolvable | BedrockGuardrailSensitiveInformationPolicyConfigPiiEntitiesConfig[] | undefined;
    private _regexesConfig;
    get regexesConfig(): BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfigList;
    putRegexesConfig(value: BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | cdktn.IResolvable): void;
    resetRegexesConfig(): void;
    get regexesConfigInput(): cdktn.IResolvable | BedrockGuardrailSensitiveInformationPolicyConfigRegexesConfig[] | undefined;
}
export declare class BedrockGuardrailSensitiveInformationPolicyConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailSensitiveInformationPolicyConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailSensitiveInformationPolicyConfigOutputReference;
}
export interface BedrockGuardrailTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#create BedrockGuardrail#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#delete BedrockGuardrail#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#update BedrockGuardrail#update}
    */
    readonly update?: string;
}
export declare function bedrockGuardrailTimeoutsToTerraform(struct?: BedrockGuardrailTimeouts | cdktn.IResolvable): any;
export declare function bedrockGuardrailTimeoutsToHclTerraform(struct?: BedrockGuardrailTimeouts | cdktn.IResolvable): any;
export declare class BedrockGuardrailTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockGuardrailTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface BedrockGuardrailTopicPolicyConfigTierConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#tier_name BedrockGuardrail#tier_name}
    */
    readonly tierName?: string;
}
export declare function bedrockGuardrailTopicPolicyConfigTierConfigToTerraform(struct?: BedrockGuardrailTopicPolicyConfigTierConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailTopicPolicyConfigTierConfigToHclTerraform(struct?: BedrockGuardrailTopicPolicyConfigTierConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailTopicPolicyConfigTierConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailTopicPolicyConfigTierConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTopicPolicyConfigTierConfig | cdktn.IResolvable | undefined);
    private _tierName?;
    get tierName(): string;
    set tierName(value: string);
    resetTierName(): void;
    get tierNameInput(): string | undefined;
}
export declare class BedrockGuardrailTopicPolicyConfigTierConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailTopicPolicyConfigTierConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailTopicPolicyConfigTierConfigOutputReference;
}
export interface BedrockGuardrailTopicPolicyConfigTopicsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#definition BedrockGuardrail#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#examples BedrockGuardrail#examples}
    */
    readonly examples?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#name BedrockGuardrail#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type: string;
}
export declare function bedrockGuardrailTopicPolicyConfigTopicsConfigToTerraform(struct?: BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailTopicPolicyConfigTopicsConfigToHclTerraform(struct?: BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailTopicPolicyConfigTopicsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTopicPolicyConfigTopicsConfig | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _examples?;
    get examples(): string[];
    set examples(value: string[]);
    resetExamples(): void;
    get examplesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailTopicPolicyConfigTopicsConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailTopicPolicyConfigTopicsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailTopicPolicyConfigTopicsConfigOutputReference;
}
export interface BedrockGuardrailTopicPolicyConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#tier_config BedrockGuardrail#tier_config}
    */
    readonly tierConfig?: BedrockGuardrailTopicPolicyConfigTierConfig[] | cdktn.IResolvable;
    /**
    * topics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#topics_config BedrockGuardrail#topics_config}
    */
    readonly topicsConfig?: BedrockGuardrailTopicPolicyConfigTopicsConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailTopicPolicyConfigToTerraform(struct?: BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailTopicPolicyConfigToHclTerraform(struct?: BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailTopicPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailTopicPolicyConfig | cdktn.IResolvable | undefined);
    private _tierConfig;
    get tierConfig(): BedrockGuardrailTopicPolicyConfigTierConfigList;
    putTierConfig(value: BedrockGuardrailTopicPolicyConfigTierConfig[] | cdktn.IResolvable): void;
    resetTierConfig(): void;
    get tierConfigInput(): cdktn.IResolvable | BedrockGuardrailTopicPolicyConfigTierConfig[] | undefined;
    private _topicsConfig;
    get topicsConfig(): BedrockGuardrailTopicPolicyConfigTopicsConfigList;
    putTopicsConfig(value: BedrockGuardrailTopicPolicyConfigTopicsConfig[] | cdktn.IResolvable): void;
    resetTopicsConfig(): void;
    get topicsConfigInput(): cdktn.IResolvable | BedrockGuardrailTopicPolicyConfigTopicsConfig[] | undefined;
}
export declare class BedrockGuardrailTopicPolicyConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailTopicPolicyConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailTopicPolicyConfigOutputReference;
}
export interface BedrockGuardrailWordPolicyConfigManagedWordListsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#type BedrockGuardrail#type}
    */
    readonly type: string;
}
export declare function bedrockGuardrailWordPolicyConfigManagedWordListsConfigToTerraform(struct?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailWordPolicyConfigManagedWordListsConfigToHclTerraform(struct?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailWordPolicyConfigManagedWordListsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailWordPolicyConfigManagedWordListsConfig | cdktn.IResolvable | undefined);
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class BedrockGuardrailWordPolicyConfigManagedWordListsConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailWordPolicyConfigManagedWordListsConfigOutputReference;
}
export interface BedrockGuardrailWordPolicyConfigWordsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_action BedrockGuardrail#input_action}
    */
    readonly inputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#input_enabled BedrockGuardrail#input_enabled}
    */
    readonly inputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_action BedrockGuardrail#output_action}
    */
    readonly outputAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#output_enabled BedrockGuardrail#output_enabled}
    */
    readonly outputEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#text BedrockGuardrail#text}
    */
    readonly text: string;
}
export declare function bedrockGuardrailWordPolicyConfigWordsConfigToTerraform(struct?: BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailWordPolicyConfigWordsConfigToHclTerraform(struct?: BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailWordPolicyConfigWordsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailWordPolicyConfigWordsConfig | cdktn.IResolvable | undefined);
    private _inputAction?;
    get inputAction(): string;
    set inputAction(value: string);
    resetInputAction(): void;
    get inputActionInput(): string | undefined;
    private _inputEnabled?;
    get inputEnabled(): boolean | cdktn.IResolvable;
    set inputEnabled(value: boolean | cdktn.IResolvable);
    resetInputEnabled(): void;
    get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outputAction?;
    get outputAction(): string;
    set outputAction(value: string);
    resetOutputAction(): void;
    get outputActionInput(): string | undefined;
    private _outputEnabled?;
    get outputEnabled(): boolean | cdktn.IResolvable;
    set outputEnabled(value: boolean | cdktn.IResolvable);
    resetOutputEnabled(): void;
    get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _text?;
    get text(): string;
    set text(value: string);
    get textInput(): string | undefined;
}
export declare class BedrockGuardrailWordPolicyConfigWordsConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailWordPolicyConfigWordsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailWordPolicyConfigWordsConfigOutputReference;
}
export interface BedrockGuardrailWordPolicyConfig {
    /**
    * managed_word_lists_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#managed_word_lists_config BedrockGuardrail#managed_word_lists_config}
    */
    readonly managedWordListsConfig?: BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | cdktn.IResolvable;
    /**
    * words_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#words_config BedrockGuardrail#words_config}
    */
    readonly wordsConfig?: BedrockGuardrailWordPolicyConfigWordsConfig[] | cdktn.IResolvable;
}
export declare function bedrockGuardrailWordPolicyConfigToTerraform(struct?: BedrockGuardrailWordPolicyConfig | cdktn.IResolvable): any;
export declare function bedrockGuardrailWordPolicyConfigToHclTerraform(struct?: BedrockGuardrailWordPolicyConfig | cdktn.IResolvable): any;
export declare class BedrockGuardrailWordPolicyConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockGuardrailWordPolicyConfig | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockGuardrailWordPolicyConfig | cdktn.IResolvable | undefined);
    private _managedWordListsConfig;
    get managedWordListsConfig(): BedrockGuardrailWordPolicyConfigManagedWordListsConfigList;
    putManagedWordListsConfig(value: BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | cdktn.IResolvable): void;
    resetManagedWordListsConfig(): void;
    get managedWordListsConfigInput(): cdktn.IResolvable | BedrockGuardrailWordPolicyConfigManagedWordListsConfig[] | undefined;
    private _wordsConfig;
    get wordsConfig(): BedrockGuardrailWordPolicyConfigWordsConfigList;
    putWordsConfig(value: BedrockGuardrailWordPolicyConfigWordsConfig[] | cdktn.IResolvable): void;
    resetWordsConfig(): void;
    get wordsConfigInput(): cdktn.IResolvable | BedrockGuardrailWordPolicyConfigWordsConfig[] | undefined;
}
export declare class BedrockGuardrailWordPolicyConfigList extends cdktn.ComplexList {
    internalValue?: BedrockGuardrailWordPolicyConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockGuardrailWordPolicyConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail aws_bedrock_guardrail}
*/
export declare class BedrockGuardrail extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_guardrail";
    /**
    * Generates CDKTN code for importing a BedrockGuardrail resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockGuardrail to import
    * @param importFromId The id of the existing BedrockGuardrail that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockGuardrail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrock_guardrail aws_bedrock_guardrail} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockGuardrailConfig
    */
    constructor(scope: Construct, id: string, config: BedrockGuardrailConfig);
    private _blockedInputMessaging?;
    get blockedInputMessaging(): string;
    set blockedInputMessaging(value: string);
    get blockedInputMessagingInput(): string | undefined;
    private _blockedOutputsMessaging?;
    get blockedOutputsMessaging(): string;
    set blockedOutputsMessaging(value: string);
    get blockedOutputsMessagingInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guardrailArn(): string;
    get guardrailId(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get version(): string;
    private _contentPolicyConfig;
    get contentPolicyConfig(): BedrockGuardrailContentPolicyConfigList;
    putContentPolicyConfig(value: BedrockGuardrailContentPolicyConfig[] | cdktn.IResolvable): void;
    resetContentPolicyConfig(): void;
    get contentPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailContentPolicyConfig[] | undefined;
    private _contextualGroundingPolicyConfig;
    get contextualGroundingPolicyConfig(): BedrockGuardrailContextualGroundingPolicyConfigList;
    putContextualGroundingPolicyConfig(value: BedrockGuardrailContextualGroundingPolicyConfig[] | cdktn.IResolvable): void;
    resetContextualGroundingPolicyConfig(): void;
    get contextualGroundingPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailContextualGroundingPolicyConfig[] | undefined;
    private _crossRegionConfig;
    get crossRegionConfig(): BedrockGuardrailCrossRegionConfigList;
    putCrossRegionConfig(value: BedrockGuardrailCrossRegionConfig[] | cdktn.IResolvable): void;
    resetCrossRegionConfig(): void;
    get crossRegionConfigInput(): cdktn.IResolvable | BedrockGuardrailCrossRegionConfig[] | undefined;
    private _sensitiveInformationPolicyConfig;
    get sensitiveInformationPolicyConfig(): BedrockGuardrailSensitiveInformationPolicyConfigList;
    putSensitiveInformationPolicyConfig(value: BedrockGuardrailSensitiveInformationPolicyConfig[] | cdktn.IResolvable): void;
    resetSensitiveInformationPolicyConfig(): void;
    get sensitiveInformationPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailSensitiveInformationPolicyConfig[] | undefined;
    private _timeouts;
    get timeouts(): BedrockGuardrailTimeoutsOutputReference;
    putTimeouts(value: BedrockGuardrailTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockGuardrailTimeouts | undefined;
    private _topicPolicyConfig;
    get topicPolicyConfig(): BedrockGuardrailTopicPolicyConfigList;
    putTopicPolicyConfig(value: BedrockGuardrailTopicPolicyConfig[] | cdktn.IResolvable): void;
    resetTopicPolicyConfig(): void;
    get topicPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailTopicPolicyConfig[] | undefined;
    private _wordPolicyConfig;
    get wordPolicyConfig(): BedrockGuardrailWordPolicyConfigList;
    putWordPolicyConfig(value: BedrockGuardrailWordPolicyConfig[] | cdktn.IResolvable): void;
    resetWordPolicyConfig(): void;
    get wordPolicyConfigInput(): cdktn.IResolvable | BedrockGuardrailWordPolicyConfig[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
