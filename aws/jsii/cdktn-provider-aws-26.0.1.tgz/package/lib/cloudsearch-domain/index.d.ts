/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudsearchDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#id CloudsearchDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#multi_az CloudsearchDomain#multi_az}
    */
    readonly multiAz?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#name CloudsearchDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#region CloudsearchDomain#region}
    */
    readonly region?: string;
    /**
    * endpoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#endpoint_options CloudsearchDomain#endpoint_options}
    */
    readonly endpointOptions?: CloudsearchDomainEndpointOptions;
    /**
    * index_field block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#index_field CloudsearchDomain#index_field}
    */
    readonly indexField?: CloudsearchDomainIndexField[] | cdktn.IResolvable;
    /**
    * scaling_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#scaling_parameters CloudsearchDomain#scaling_parameters}
    */
    readonly scalingParameters?: CloudsearchDomainScalingParameters;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#timeouts CloudsearchDomain#timeouts}
    */
    readonly timeouts?: CloudsearchDomainTimeouts;
}
export interface CloudsearchDomainEndpointOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#enforce_https CloudsearchDomain#enforce_https}
    */
    readonly enforceHttps?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#tls_security_policy CloudsearchDomain#tls_security_policy}
    */
    readonly tlsSecurityPolicy?: string;
}
export declare function cloudsearchDomainEndpointOptionsToTerraform(struct?: CloudsearchDomainEndpointOptionsOutputReference | CloudsearchDomainEndpointOptions): any;
export declare function cloudsearchDomainEndpointOptionsToHclTerraform(struct?: CloudsearchDomainEndpointOptionsOutputReference | CloudsearchDomainEndpointOptions): any;
export declare class CloudsearchDomainEndpointOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudsearchDomainEndpointOptions | undefined;
    set internalValue(value: CloudsearchDomainEndpointOptions | undefined);
    private _enforceHttps?;
    get enforceHttps(): boolean | cdktn.IResolvable;
    set enforceHttps(value: boolean | cdktn.IResolvable);
    resetEnforceHttps(): void;
    get enforceHttpsInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsSecurityPolicy?;
    get tlsSecurityPolicy(): string;
    set tlsSecurityPolicy(value: string);
    resetTlsSecurityPolicy(): void;
    get tlsSecurityPolicyInput(): string | undefined;
}
export interface CloudsearchDomainIndexField {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#analysis_scheme CloudsearchDomain#analysis_scheme}
    */
    readonly analysisScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#default_value CloudsearchDomain#default_value}
    */
    readonly defaultValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#facet CloudsearchDomain#facet}
    */
    readonly facet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#highlight CloudsearchDomain#highlight}
    */
    readonly highlight?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#name CloudsearchDomain#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#return CloudsearchDomain#return}
    */
    readonly return?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#search CloudsearchDomain#search}
    */
    readonly search?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#sort CloudsearchDomain#sort}
    */
    readonly sort?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#source_fields CloudsearchDomain#source_fields}
    */
    readonly sourceFields?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#type CloudsearchDomain#type}
    */
    readonly type: string;
}
export declare function cloudsearchDomainIndexFieldToTerraform(struct?: CloudsearchDomainIndexField | cdktn.IResolvable): any;
export declare function cloudsearchDomainIndexFieldToHclTerraform(struct?: CloudsearchDomainIndexField | cdktn.IResolvable): any;
export declare class CloudsearchDomainIndexFieldOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CloudsearchDomainIndexField | cdktn.IResolvable | undefined;
    set internalValue(value: CloudsearchDomainIndexField | cdktn.IResolvable | undefined);
    private _analysisScheme?;
    get analysisScheme(): string;
    set analysisScheme(value: string);
    resetAnalysisScheme(): void;
    get analysisSchemeInput(): string | undefined;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _facet?;
    get facet(): boolean | cdktn.IResolvable;
    set facet(value: boolean | cdktn.IResolvable);
    resetFacet(): void;
    get facetInput(): boolean | cdktn.IResolvable | undefined;
    private _highlight?;
    get highlight(): boolean | cdktn.IResolvable;
    set highlight(value: boolean | cdktn.IResolvable);
    resetHighlight(): void;
    get highlightInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _return?;
    get return(): boolean | cdktn.IResolvable;
    set return(value: boolean | cdktn.IResolvable);
    resetReturn(): void;
    get returnInput(): boolean | cdktn.IResolvable | undefined;
    private _search?;
    get search(): boolean | cdktn.IResolvable;
    set search(value: boolean | cdktn.IResolvable);
    resetSearch(): void;
    get searchInput(): boolean | cdktn.IResolvable | undefined;
    private _sort?;
    get sort(): boolean | cdktn.IResolvable;
    set sort(value: boolean | cdktn.IResolvable);
    resetSort(): void;
    get sortInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceFields?;
    get sourceFields(): string;
    set sourceFields(value: string);
    resetSourceFields(): void;
    get sourceFieldsInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class CloudsearchDomainIndexFieldList extends cdktn.ComplexList {
    internalValue?: CloudsearchDomainIndexField[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CloudsearchDomainIndexFieldOutputReference;
}
export interface CloudsearchDomainScalingParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#desired_instance_type CloudsearchDomain#desired_instance_type}
    */
    readonly desiredInstanceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#desired_partition_count CloudsearchDomain#desired_partition_count}
    */
    readonly desiredPartitionCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#desired_replication_count CloudsearchDomain#desired_replication_count}
    */
    readonly desiredReplicationCount?: number;
}
export declare function cloudsearchDomainScalingParametersToTerraform(struct?: CloudsearchDomainScalingParametersOutputReference | CloudsearchDomainScalingParameters): any;
export declare function cloudsearchDomainScalingParametersToHclTerraform(struct?: CloudsearchDomainScalingParametersOutputReference | CloudsearchDomainScalingParameters): any;
export declare class CloudsearchDomainScalingParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudsearchDomainScalingParameters | undefined;
    set internalValue(value: CloudsearchDomainScalingParameters | undefined);
    private _desiredInstanceType?;
    get desiredInstanceType(): string;
    set desiredInstanceType(value: string);
    resetDesiredInstanceType(): void;
    get desiredInstanceTypeInput(): string | undefined;
    private _desiredPartitionCount?;
    get desiredPartitionCount(): number;
    set desiredPartitionCount(value: number);
    resetDesiredPartitionCount(): void;
    get desiredPartitionCountInput(): number | undefined;
    private _desiredReplicationCount?;
    get desiredReplicationCount(): number;
    set desiredReplicationCount(value: number);
    resetDesiredReplicationCount(): void;
    get desiredReplicationCountInput(): number | undefined;
}
export interface CloudsearchDomainTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#create CloudsearchDomain#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#delete CloudsearchDomain#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#update CloudsearchDomain#update}
    */
    readonly update?: string;
}
export declare function cloudsearchDomainTimeoutsToTerraform(struct?: CloudsearchDomainTimeouts | cdktn.IResolvable): any;
export declare function cloudsearchDomainTimeoutsToHclTerraform(struct?: CloudsearchDomainTimeouts | cdktn.IResolvable): any;
export declare class CloudsearchDomainTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudsearchDomainTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudsearchDomainTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain aws_cloudsearch_domain}
*/
export declare class CloudsearchDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudsearch_domain";
    /**
    * Generates CDKTN code for importing a CloudsearchDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudsearchDomain to import
    * @param importFromId The id of the existing CloudsearchDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudsearchDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudsearch_domain aws_cloudsearch_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudsearchDomainConfig
    */
    constructor(scope: Construct, id: string, config: CloudsearchDomainConfig);
    get arn(): string;
    get documentServiceEndpoint(): string;
    get domainId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _multiAz?;
    get multiAz(): boolean | cdktn.IResolvable;
    set multiAz(value: boolean | cdktn.IResolvable);
    resetMultiAz(): void;
    get multiAzInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get searchServiceEndpoint(): string;
    private _endpointOptions;
    get endpointOptions(): CloudsearchDomainEndpointOptionsOutputReference;
    putEndpointOptions(value: CloudsearchDomainEndpointOptions): void;
    resetEndpointOptions(): void;
    get endpointOptionsInput(): CloudsearchDomainEndpointOptions | undefined;
    private _indexField;
    get indexField(): CloudsearchDomainIndexFieldList;
    putIndexField(value: CloudsearchDomainIndexField[] | cdktn.IResolvable): void;
    resetIndexField(): void;
    get indexFieldInput(): cdktn.IResolvable | CloudsearchDomainIndexField[] | undefined;
    private _scalingParameters;
    get scalingParameters(): CloudsearchDomainScalingParametersOutputReference;
    putScalingParameters(value: CloudsearchDomainScalingParameters): void;
    resetScalingParameters(): void;
    get scalingParametersInput(): CloudsearchDomainScalingParameters | undefined;
    private _timeouts;
    get timeouts(): CloudsearchDomainTimeoutsOutputReference;
    putTimeouts(value: CloudsearchDomainTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudsearchDomainTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
