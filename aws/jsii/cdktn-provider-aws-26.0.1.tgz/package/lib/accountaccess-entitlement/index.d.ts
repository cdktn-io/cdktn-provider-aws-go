/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountaccessEntitlementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#application_arn AccountaccessEntitlement#application_arn}
    */
    readonly applicationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#region AccountaccessEntitlement#region}
    */
    readonly region?: string;
    /**
    * entitlement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#entitlement AccountaccessEntitlement#entitlement}
    */
    readonly entitlement?: AccountaccessEntitlementEntitlement[] | cdktn.IResolvable;
}
export interface AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#group_id AccountaccessEntitlement#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#user_id AccountaccessEntitlement#user_id}
    */
    readonly userId?: string;
}
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterToTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterToHclTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter | cdktn.IResolvable | undefined);
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
}
export declare class AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterList extends cdktn.ComplexList {
    internalValue?: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterOutputReference;
}
export interface AccountaccessEntitlementEntitlementPrincipalRolePrincipal {
    /**
    * identity_center block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#identity_center AccountaccessEntitlement#identity_center}
    */
    readonly identityCenter?: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter[] | cdktn.IResolvable;
}
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalToTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementPrincipalRolePrincipalToHclTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementPrincipalRolePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipal | cdktn.IResolvable | undefined);
    private _identityCenter;
    get identityCenter(): AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenterList;
    putIdentityCenter(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter[] | cdktn.IResolvable): void;
    resetIdentityCenter(): void;
    get identityCenterInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlementPrincipalRolePrincipalIdentityCenter[] | undefined;
}
export declare class AccountaccessEntitlementEntitlementPrincipalRolePrincipalList extends cdktn.ComplexList {
    internalValue?: AccountaccessEntitlementEntitlementPrincipalRolePrincipal[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountaccessEntitlementEntitlementPrincipalRolePrincipalOutputReference;
}
export interface AccountaccessEntitlementEntitlementPrincipalRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#role_arn AccountaccessEntitlement#role_arn}
    */
    readonly roleArn: string;
    /**
    * principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#principal AccountaccessEntitlement#principal}
    */
    readonly principal?: AccountaccessEntitlementEntitlementPrincipalRolePrincipal[] | cdktn.IResolvable;
}
export declare function accountaccessEntitlementEntitlementPrincipalRoleToTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementPrincipalRoleToHclTerraform(struct?: AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementPrincipalRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlementPrincipalRole | cdktn.IResolvable | undefined);
    get accountId(): string;
    get accountName(): string;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _principal;
    get principal(): AccountaccessEntitlementEntitlementPrincipalRolePrincipalList;
    putPrincipal(value: AccountaccessEntitlementEntitlementPrincipalRolePrincipal[] | cdktn.IResolvable): void;
    resetPrincipal(): void;
    get principalInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlementPrincipalRolePrincipal[] | undefined;
}
export declare class AccountaccessEntitlementEntitlementPrincipalRoleList extends cdktn.ComplexList {
    internalValue?: AccountaccessEntitlementEntitlementPrincipalRole[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountaccessEntitlementEntitlementPrincipalRoleOutputReference;
}
export interface AccountaccessEntitlementEntitlement {
    /**
    * principal_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#principal_role AccountaccessEntitlement#principal_role}
    */
    readonly principalRole?: AccountaccessEntitlementEntitlementPrincipalRole[] | cdktn.IResolvable;
}
export declare function accountaccessEntitlementEntitlementToTerraform(struct?: AccountaccessEntitlementEntitlement | cdktn.IResolvable): any;
export declare function accountaccessEntitlementEntitlementToHclTerraform(struct?: AccountaccessEntitlementEntitlement | cdktn.IResolvable): any;
export declare class AccountaccessEntitlementEntitlementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountaccessEntitlementEntitlement | cdktn.IResolvable | undefined;
    set internalValue(value: AccountaccessEntitlementEntitlement | cdktn.IResolvable | undefined);
    private _principalRole;
    get principalRole(): AccountaccessEntitlementEntitlementPrincipalRoleList;
    putPrincipalRole(value: AccountaccessEntitlementEntitlementPrincipalRole[] | cdktn.IResolvable): void;
    resetPrincipalRole(): void;
    get principalRoleInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlementPrincipalRole[] | undefined;
}
export declare class AccountaccessEntitlementEntitlementList extends cdktn.ComplexList {
    internalValue?: AccountaccessEntitlementEntitlement[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountaccessEntitlementEntitlementOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement aws_accountaccess_entitlement}
*/
export declare class AccountaccessEntitlement extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_accountaccess_entitlement";
    /**
    * Generates CDKTN code for importing a AccountaccessEntitlement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountaccessEntitlement to import
    * @param importFromId The id of the existing AccountaccessEntitlement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountaccessEntitlement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/accountaccess_entitlement aws_accountaccess_entitlement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountaccessEntitlementConfig
    */
    constructor(scope: Construct, id: string, config: AccountaccessEntitlementConfig);
    private _applicationArn?;
    get applicationArn(): string;
    set applicationArn(value: string);
    get applicationArnInput(): string | undefined;
    get entitlementId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _entitlement;
    get entitlement(): AccountaccessEntitlementEntitlementList;
    putEntitlement(value: AccountaccessEntitlementEntitlement[] | cdktn.IResolvable): void;
    resetEntitlement(): void;
    get entitlementInput(): cdktn.IResolvable | AccountaccessEntitlementEntitlement[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
