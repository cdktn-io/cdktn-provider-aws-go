/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BackupPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#id BackupPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#name BackupPlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#region BackupPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#tags BackupPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#tags_all BackupPlan#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * advanced_backup_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#advanced_backup_setting BackupPlan#advanced_backup_setting}
    */
    readonly advancedBackupSetting?: BackupPlanAdvancedBackupSetting[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#rule BackupPlan#rule}
    */
    readonly rule: BackupPlanRule[] | cdktn.IResolvable;
    /**
    * scan_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#scan_setting BackupPlan#scan_setting}
    */
    readonly scanSetting?: BackupPlanScanSetting[] | cdktn.IResolvable;
}
export interface BackupPlanAdvancedBackupSetting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#backup_options BackupPlan#backup_options}
    */
    readonly backupOptions: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#resource_type BackupPlan#resource_type}
    */
    readonly resourceType: string;
}
export declare function backupPlanAdvancedBackupSettingToTerraform(struct?: BackupPlanAdvancedBackupSetting | cdktn.IResolvable): any;
export declare function backupPlanAdvancedBackupSettingToHclTerraform(struct?: BackupPlanAdvancedBackupSetting | cdktn.IResolvable): any;
export declare class BackupPlanAdvancedBackupSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupPlanAdvancedBackupSetting | cdktn.IResolvable | undefined;
    set internalValue(value: BackupPlanAdvancedBackupSetting | cdktn.IResolvable | undefined);
    private _backupOptions?;
    get backupOptions(): {
        [key: string]: string;
    };
    set backupOptions(value: {
        [key: string]: string;
    });
    get backupOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
}
export declare class BackupPlanAdvancedBackupSettingList extends cdktn.ComplexList {
    internalValue?: BackupPlanAdvancedBackupSetting[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupPlanAdvancedBackupSettingOutputReference;
}
export interface BackupPlanRuleCopyActionLifecycle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#cold_storage_after BackupPlan#cold_storage_after}
    */
    readonly coldStorageAfter?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#delete_after BackupPlan#delete_after}
    */
    readonly deleteAfter?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#opt_in_to_archive_for_supported_resources BackupPlan#opt_in_to_archive_for_supported_resources}
    */
    readonly optInToArchiveForSupportedResources?: boolean | cdktn.IResolvable;
}
export declare function backupPlanRuleCopyActionLifecycleToTerraform(struct?: BackupPlanRuleCopyActionLifecycleOutputReference | BackupPlanRuleCopyActionLifecycle): any;
export declare function backupPlanRuleCopyActionLifecycleToHclTerraform(struct?: BackupPlanRuleCopyActionLifecycleOutputReference | BackupPlanRuleCopyActionLifecycle): any;
export declare class BackupPlanRuleCopyActionLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupPlanRuleCopyActionLifecycle | undefined;
    set internalValue(value: BackupPlanRuleCopyActionLifecycle | undefined);
    private _coldStorageAfter?;
    get coldStorageAfter(): number;
    set coldStorageAfter(value: number);
    resetColdStorageAfter(): void;
    get coldStorageAfterInput(): number | undefined;
    private _deleteAfter?;
    get deleteAfter(): number;
    set deleteAfter(value: number);
    resetDeleteAfter(): void;
    get deleteAfterInput(): number | undefined;
    private _optInToArchiveForSupportedResources?;
    get optInToArchiveForSupportedResources(): boolean | cdktn.IResolvable;
    set optInToArchiveForSupportedResources(value: boolean | cdktn.IResolvable);
    resetOptInToArchiveForSupportedResources(): void;
    get optInToArchiveForSupportedResourcesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupPlanRuleCopyAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#destination_vault_arn BackupPlan#destination_vault_arn}
    */
    readonly destinationVaultArn: string;
    /**
    * lifecycle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#lifecycle BackupPlan#lifecycle}
    */
    readonly lifecycle?: BackupPlanRuleCopyActionLifecycle;
}
export declare function backupPlanRuleCopyActionToTerraform(struct?: BackupPlanRuleCopyAction | cdktn.IResolvable): any;
export declare function backupPlanRuleCopyActionToHclTerraform(struct?: BackupPlanRuleCopyAction | cdktn.IResolvable): any;
export declare class BackupPlanRuleCopyActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupPlanRuleCopyAction | cdktn.IResolvable | undefined;
    set internalValue(value: BackupPlanRuleCopyAction | cdktn.IResolvable | undefined);
    private _destinationVaultArn?;
    get destinationVaultArn(): string;
    set destinationVaultArn(value: string);
    get destinationVaultArnInput(): string | undefined;
    private _lifecycle;
    get lifecycle(): BackupPlanRuleCopyActionLifecycleOutputReference;
    putLifecycle(value: BackupPlanRuleCopyActionLifecycle): void;
    resetLifecycle(): void;
    get lifecycleInput(): BackupPlanRuleCopyActionLifecycle | undefined;
}
export declare class BackupPlanRuleCopyActionList extends cdktn.ComplexList {
    internalValue?: BackupPlanRuleCopyAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupPlanRuleCopyActionOutputReference;
}
export interface BackupPlanRuleLifecycle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#cold_storage_after BackupPlan#cold_storage_after}
    */
    readonly coldStorageAfter?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#delete_after BackupPlan#delete_after}
    */
    readonly deleteAfter?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#opt_in_to_archive_for_supported_resources BackupPlan#opt_in_to_archive_for_supported_resources}
    */
    readonly optInToArchiveForSupportedResources?: boolean | cdktn.IResolvable;
}
export declare function backupPlanRuleLifecycleToTerraform(struct?: BackupPlanRuleLifecycleOutputReference | BackupPlanRuleLifecycle): any;
export declare function backupPlanRuleLifecycleToHclTerraform(struct?: BackupPlanRuleLifecycleOutputReference | BackupPlanRuleLifecycle): any;
export declare class BackupPlanRuleLifecycleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BackupPlanRuleLifecycle | undefined;
    set internalValue(value: BackupPlanRuleLifecycle | undefined);
    private _coldStorageAfter?;
    get coldStorageAfter(): number;
    set coldStorageAfter(value: number);
    resetColdStorageAfter(): void;
    get coldStorageAfterInput(): number | undefined;
    private _deleteAfter?;
    get deleteAfter(): number;
    set deleteAfter(value: number);
    resetDeleteAfter(): void;
    get deleteAfterInput(): number | undefined;
    private _optInToArchiveForSupportedResources?;
    get optInToArchiveForSupportedResources(): boolean | cdktn.IResolvable;
    set optInToArchiveForSupportedResources(value: boolean | cdktn.IResolvable);
    resetOptInToArchiveForSupportedResources(): void;
    get optInToArchiveForSupportedResourcesInput(): boolean | cdktn.IResolvable | undefined;
}
export interface BackupPlanRuleScanAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#malware_scanner BackupPlan#malware_scanner}
    */
    readonly malwareScanner: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#scan_mode BackupPlan#scan_mode}
    */
    readonly scanMode: string;
}
export declare function backupPlanRuleScanActionToTerraform(struct?: BackupPlanRuleScanAction | cdktn.IResolvable): any;
export declare function backupPlanRuleScanActionToHclTerraform(struct?: BackupPlanRuleScanAction | cdktn.IResolvable): any;
export declare class BackupPlanRuleScanActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupPlanRuleScanAction | cdktn.IResolvable | undefined;
    set internalValue(value: BackupPlanRuleScanAction | cdktn.IResolvable | undefined);
    private _malwareScanner?;
    get malwareScanner(): string;
    set malwareScanner(value: string);
    get malwareScannerInput(): string | undefined;
    private _scanMode?;
    get scanMode(): string;
    set scanMode(value: string);
    get scanModeInput(): string | undefined;
}
export declare class BackupPlanRuleScanActionList extends cdktn.ComplexList {
    internalValue?: BackupPlanRuleScanAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupPlanRuleScanActionOutputReference;
}
export interface BackupPlanRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#completion_window BackupPlan#completion_window}
    */
    readonly completionWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#enable_continuous_backup BackupPlan#enable_continuous_backup}
    */
    readonly enableContinuousBackup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#recovery_point_tags BackupPlan#recovery_point_tags}
    */
    readonly recoveryPointTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#rule_name BackupPlan#rule_name}
    */
    readonly ruleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#schedule BackupPlan#schedule}
    */
    readonly schedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#schedule_expression_timezone BackupPlan#schedule_expression_timezone}
    */
    readonly scheduleExpressionTimezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#start_window BackupPlan#start_window}
    */
    readonly startWindow?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#target_logically_air_gapped_backup_vault_arn BackupPlan#target_logically_air_gapped_backup_vault_arn}
    */
    readonly targetLogicallyAirGappedBackupVaultArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#target_vault_name BackupPlan#target_vault_name}
    */
    readonly targetVaultName: string;
    /**
    * copy_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#copy_action BackupPlan#copy_action}
    */
    readonly copyAction?: BackupPlanRuleCopyAction[] | cdktn.IResolvable;
    /**
    * lifecycle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#lifecycle BackupPlan#lifecycle}
    */
    readonly lifecycle?: BackupPlanRuleLifecycle;
    /**
    * scan_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#scan_action BackupPlan#scan_action}
    */
    readonly scanAction?: BackupPlanRuleScanAction[] | cdktn.IResolvable;
}
export declare function backupPlanRuleToTerraform(struct?: BackupPlanRule | cdktn.IResolvable): any;
export declare function backupPlanRuleToHclTerraform(struct?: BackupPlanRule | cdktn.IResolvable): any;
export declare class BackupPlanRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupPlanRule | cdktn.IResolvable | undefined;
    set internalValue(value: BackupPlanRule | cdktn.IResolvable | undefined);
    private _completionWindow?;
    get completionWindow(): number;
    set completionWindow(value: number);
    resetCompletionWindow(): void;
    get completionWindowInput(): number | undefined;
    private _enableContinuousBackup?;
    get enableContinuousBackup(): boolean | cdktn.IResolvable;
    set enableContinuousBackup(value: boolean | cdktn.IResolvable);
    resetEnableContinuousBackup(): void;
    get enableContinuousBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _recoveryPointTags?;
    get recoveryPointTags(): {
        [key: string]: string;
    };
    set recoveryPointTags(value: {
        [key: string]: string;
    });
    resetRecoveryPointTags(): void;
    get recoveryPointTagsInput(): {
        [key: string]: string;
    } | undefined;
    get ruleId(): string;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    private _scheduleExpressionTimezone?;
    get scheduleExpressionTimezone(): string;
    set scheduleExpressionTimezone(value: string);
    resetScheduleExpressionTimezone(): void;
    get scheduleExpressionTimezoneInput(): string | undefined;
    private _startWindow?;
    get startWindow(): number;
    set startWindow(value: number);
    resetStartWindow(): void;
    get startWindowInput(): number | undefined;
    private _targetLogicallyAirGappedBackupVaultArn?;
    get targetLogicallyAirGappedBackupVaultArn(): string;
    set targetLogicallyAirGappedBackupVaultArn(value: string);
    resetTargetLogicallyAirGappedBackupVaultArn(): void;
    get targetLogicallyAirGappedBackupVaultArnInput(): string | undefined;
    private _targetVaultName?;
    get targetVaultName(): string;
    set targetVaultName(value: string);
    get targetVaultNameInput(): string | undefined;
    private _copyAction;
    get copyAction(): BackupPlanRuleCopyActionList;
    putCopyAction(value: BackupPlanRuleCopyAction[] | cdktn.IResolvable): void;
    resetCopyAction(): void;
    get copyActionInput(): cdktn.IResolvable | BackupPlanRuleCopyAction[] | undefined;
    private _lifecycle;
    get lifecycle(): BackupPlanRuleLifecycleOutputReference;
    putLifecycle(value: BackupPlanRuleLifecycle): void;
    resetLifecycle(): void;
    get lifecycleInput(): BackupPlanRuleLifecycle | undefined;
    private _scanAction;
    get scanAction(): BackupPlanRuleScanActionList;
    putScanAction(value: BackupPlanRuleScanAction[] | cdktn.IResolvable): void;
    resetScanAction(): void;
    get scanActionInput(): cdktn.IResolvable | BackupPlanRuleScanAction[] | undefined;
}
export declare class BackupPlanRuleList extends cdktn.ComplexList {
    internalValue?: BackupPlanRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupPlanRuleOutputReference;
}
export interface BackupPlanScanSetting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#malware_scanner BackupPlan#malware_scanner}
    */
    readonly malwareScanner: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#resource_types BackupPlan#resource_types}
    */
    readonly resourceTypes: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#scanner_role_arn BackupPlan#scanner_role_arn}
    */
    readonly scannerRoleArn: string;
}
export declare function backupPlanScanSettingToTerraform(struct?: BackupPlanScanSetting | cdktn.IResolvable): any;
export declare function backupPlanScanSettingToHclTerraform(struct?: BackupPlanScanSetting | cdktn.IResolvable): any;
export declare class BackupPlanScanSettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BackupPlanScanSetting | cdktn.IResolvable | undefined;
    set internalValue(value: BackupPlanScanSetting | cdktn.IResolvable | undefined);
    private _malwareScanner?;
    get malwareScanner(): string;
    set malwareScanner(value: string);
    get malwareScannerInput(): string | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    get resourceTypesInput(): string[] | undefined;
    private _scannerRoleArn?;
    get scannerRoleArn(): string;
    set scannerRoleArn(value: string);
    get scannerRoleArnInput(): string | undefined;
}
export declare class BackupPlanScanSettingList extends cdktn.ComplexList {
    internalValue?: BackupPlanScanSetting[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BackupPlanScanSettingOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan aws_backup_plan}
*/
export declare class BackupPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_plan";
    /**
    * Generates CDKTN code for importing a BackupPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BackupPlan to import
    * @param importFromId The id of the existing BackupPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BackupPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/backup_plan aws_backup_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BackupPlanConfig
    */
    constructor(scope: Construct, id: string, config: BackupPlanConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    private _advancedBackupSetting;
    get advancedBackupSetting(): BackupPlanAdvancedBackupSettingList;
    putAdvancedBackupSetting(value: BackupPlanAdvancedBackupSetting[] | cdktn.IResolvable): void;
    resetAdvancedBackupSetting(): void;
    get advancedBackupSettingInput(): cdktn.IResolvable | BackupPlanAdvancedBackupSetting[] | undefined;
    private _rule;
    get rule(): BackupPlanRuleList;
    putRule(value: BackupPlanRule[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | BackupPlanRule[] | undefined;
    private _scanSetting;
    get scanSetting(): BackupPlanScanSettingList;
    putScanSetting(value: BackupPlanScanSetting[] | cdktn.IResolvable): void;
    resetScanSetting(): void;
    get scanSettingInput(): cdktn.IResolvable | BackupPlanScanSetting[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
