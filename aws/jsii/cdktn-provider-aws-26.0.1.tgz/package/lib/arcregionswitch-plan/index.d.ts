/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArcregionswitchPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#description ArcregionswitchPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#execution_role ArcregionswitchPlan#execution_role}
    */
    readonly executionRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#name ArcregionswitchPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#primary_region ArcregionswitchPlan#primary_region}
    */
    readonly primaryRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#recovery_approach ArcregionswitchPlan#recovery_approach}
    */
    readonly recoveryApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#recovery_time_objective_minutes ArcregionswitchPlan#recovery_time_objective_minutes}
    */
    readonly recoveryTimeObjectiveMinutes?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region ArcregionswitchPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#regions ArcregionswitchPlan#regions}
    */
    readonly regions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#tags ArcregionswitchPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * associated_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#associated_alarms ArcregionswitchPlan#associated_alarms}
    */
    readonly associatedAlarms?: ArcregionswitchPlanAssociatedAlarms[] | cdktn.IResolvable;
    /**
    * report_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#report_configuration ArcregionswitchPlan#report_configuration}
    */
    readonly reportConfiguration?: ArcregionswitchPlanReportConfiguration[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeouts ArcregionswitchPlan#timeouts}
    */
    readonly timeouts?: ArcregionswitchPlanTimeouts;
    /**
    * triggers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#triggers ArcregionswitchPlan#triggers}
    */
    readonly triggers?: ArcregionswitchPlanTriggers[] | cdktn.IResolvable;
    /**
    * workflow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#workflow ArcregionswitchPlan#workflow}
    */
    readonly workflow?: ArcregionswitchPlanWorkflow[] | cdktn.IResolvable;
}
export interface ArcregionswitchPlanAssociatedAlarms {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#alarm_type ArcregionswitchPlan#alarm_type}
    */
    readonly alarmType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#map_block_key ArcregionswitchPlan#map_block_key}
    */
    readonly mapBlockKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#resource_identifier ArcregionswitchPlan#resource_identifier}
    */
    readonly resourceIdentifier: string;
}
export declare function arcregionswitchPlanAssociatedAlarmsToTerraform(struct?: ArcregionswitchPlanAssociatedAlarms | cdktn.IResolvable): any;
export declare function arcregionswitchPlanAssociatedAlarmsToHclTerraform(struct?: ArcregionswitchPlanAssociatedAlarms | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanAssociatedAlarmsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanAssociatedAlarms | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanAssociatedAlarms | cdktn.IResolvable | undefined);
    private _alarmType?;
    get alarmType(): string;
    set alarmType(value: string);
    get alarmTypeInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _mapBlockKey?;
    get mapBlockKey(): string;
    set mapBlockKey(value: string);
    get mapBlockKeyInput(): string | undefined;
    private _resourceIdentifier?;
    get resourceIdentifier(): string;
    set resourceIdentifier(value: string);
    get resourceIdentifierInput(): string | undefined;
}
export declare class ArcregionswitchPlanAssociatedAlarmsList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanAssociatedAlarms[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanAssociatedAlarmsOutputReference;
}
export interface ArcregionswitchPlanReportConfigurationReportOutputS3Configuration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#bucket_owner ArcregionswitchPlan#bucket_owner}
    */
    readonly bucketOwner: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#bucket_path ArcregionswitchPlan#bucket_path}
    */
    readonly bucketPath: string;
}
export declare function arcregionswitchPlanReportConfigurationReportOutputS3ConfigurationToTerraform(struct?: ArcregionswitchPlanReportConfigurationReportOutputS3Configuration | cdktn.IResolvable): any;
export declare function arcregionswitchPlanReportConfigurationReportOutputS3ConfigurationToHclTerraform(struct?: ArcregionswitchPlanReportConfigurationReportOutputS3Configuration | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanReportConfigurationReportOutputS3ConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanReportConfigurationReportOutputS3Configuration | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanReportConfigurationReportOutputS3Configuration | cdktn.IResolvable | undefined);
    private _bucketOwner?;
    get bucketOwner(): string;
    set bucketOwner(value: string);
    get bucketOwnerInput(): string | undefined;
    private _bucketPath?;
    get bucketPath(): string;
    set bucketPath(value: string);
    get bucketPathInput(): string | undefined;
}
export declare class ArcregionswitchPlanReportConfigurationReportOutputS3ConfigurationList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanReportConfigurationReportOutputS3Configuration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanReportConfigurationReportOutputS3ConfigurationOutputReference;
}
export interface ArcregionswitchPlanReportConfigurationReportOutput {
    /**
    * s3_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#s3_configuration ArcregionswitchPlan#s3_configuration}
    */
    readonly s3Configuration?: ArcregionswitchPlanReportConfigurationReportOutputS3Configuration[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanReportConfigurationReportOutputToTerraform(struct?: ArcregionswitchPlanReportConfigurationReportOutput | cdktn.IResolvable): any;
export declare function arcregionswitchPlanReportConfigurationReportOutputToHclTerraform(struct?: ArcregionswitchPlanReportConfigurationReportOutput | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanReportConfigurationReportOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanReportConfigurationReportOutput | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanReportConfigurationReportOutput | cdktn.IResolvable | undefined);
    private _s3Configuration;
    get s3Configuration(): ArcregionswitchPlanReportConfigurationReportOutputS3ConfigurationList;
    putS3Configuration(value: ArcregionswitchPlanReportConfigurationReportOutputS3Configuration[] | cdktn.IResolvable): void;
    resetS3Configuration(): void;
    get s3ConfigurationInput(): cdktn.IResolvable | ArcregionswitchPlanReportConfigurationReportOutputS3Configuration[] | undefined;
}
export declare class ArcregionswitchPlanReportConfigurationReportOutputList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanReportConfigurationReportOutput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanReportConfigurationReportOutputOutputReference;
}
export interface ArcregionswitchPlanReportConfiguration {
    /**
    * report_output block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#report_output ArcregionswitchPlan#report_output}
    */
    readonly reportOutput?: ArcregionswitchPlanReportConfigurationReportOutput[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanReportConfigurationToTerraform(struct?: ArcregionswitchPlanReportConfiguration | cdktn.IResolvable): any;
export declare function arcregionswitchPlanReportConfigurationToHclTerraform(struct?: ArcregionswitchPlanReportConfiguration | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanReportConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanReportConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanReportConfiguration | cdktn.IResolvable | undefined);
    private _reportOutput;
    get reportOutput(): ArcregionswitchPlanReportConfigurationReportOutputList;
    putReportOutput(value: ArcregionswitchPlanReportConfigurationReportOutput[] | cdktn.IResolvable): void;
    resetReportOutput(): void;
    get reportOutputInput(): cdktn.IResolvable | ArcregionswitchPlanReportConfigurationReportOutput[] | undefined;
}
export declare class ArcregionswitchPlanReportConfigurationList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanReportConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanReportConfigurationOutputReference;
}
export interface ArcregionswitchPlanTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#create ArcregionswitchPlan#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#delete ArcregionswitchPlan#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#update ArcregionswitchPlan#update}
    */
    readonly update?: string;
}
export declare function arcregionswitchPlanTimeoutsToTerraform(struct?: ArcregionswitchPlanTimeouts | cdktn.IResolvable): any;
export declare function arcregionswitchPlanTimeoutsToHclTerraform(struct?: ArcregionswitchPlanTimeouts | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArcregionswitchPlanTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ArcregionswitchPlanTriggersConditions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#associated_alarm_name ArcregionswitchPlan#associated_alarm_name}
    */
    readonly associatedAlarmName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#condition ArcregionswitchPlan#condition}
    */
    readonly condition: string;
}
export declare function arcregionswitchPlanTriggersConditionsToTerraform(struct?: ArcregionswitchPlanTriggersConditions | cdktn.IResolvable): any;
export declare function arcregionswitchPlanTriggersConditionsToHclTerraform(struct?: ArcregionswitchPlanTriggersConditions | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanTriggersConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanTriggersConditions | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanTriggersConditions | cdktn.IResolvable | undefined);
    private _associatedAlarmName?;
    get associatedAlarmName(): string;
    set associatedAlarmName(value: string);
    get associatedAlarmNameInput(): string | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
}
export declare class ArcregionswitchPlanTriggersConditionsList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanTriggersConditions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanTriggersConditionsOutputReference;
}
export interface ArcregionswitchPlanTriggers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#action ArcregionswitchPlan#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#description ArcregionswitchPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#min_delay_minutes_between_executions ArcregionswitchPlan#min_delay_minutes_between_executions}
    */
    readonly minDelayMinutesBetweenExecutions: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_region ArcregionswitchPlan#target_region}
    */
    readonly targetRegion: string;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#conditions ArcregionswitchPlan#conditions}
    */
    readonly conditions?: ArcregionswitchPlanTriggersConditions[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanTriggersToTerraform(struct?: ArcregionswitchPlanTriggers | cdktn.IResolvable): any;
export declare function arcregionswitchPlanTriggersToHclTerraform(struct?: ArcregionswitchPlanTriggers | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanTriggersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanTriggers | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanTriggers | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _minDelayMinutesBetweenExecutions?;
    get minDelayMinutesBetweenExecutions(): number;
    set minDelayMinutesBetweenExecutions(value: number);
    get minDelayMinutesBetweenExecutionsInput(): number | undefined;
    private _targetRegion?;
    get targetRegion(): string;
    set targetRegion(value: string);
    get targetRegionInput(): string | undefined;
    private _conditions;
    get conditions(): ArcregionswitchPlanTriggersConditionsList;
    putConditions(value: ArcregionswitchPlanTriggersConditions[] | cdktn.IResolvable): void;
    resetConditions(): void;
    get conditionsInput(): cdktn.IResolvable | ArcregionswitchPlanTriggersConditions[] | undefined;
}
export declare class ArcregionswitchPlanTriggersList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanTriggers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanTriggersOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#routing_control_arn ArcregionswitchPlan#routing_control_arn}
    */
    readonly routingControlArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#state ArcregionswitchPlan#state}
    */
    readonly state: string;
}
export declare function arcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlToTerraform(struct?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable | undefined);
    private _routingControlArn?;
    get routingControlArn(): string;
    set routingControlArn(value: string);
    get routingControlArnInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region ArcregionswitchPlan#region}
    */
    readonly region: string;
    /**
    * routing_control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#routing_control ArcregionswitchPlan#routing_control}
    */
    readonly routingControl?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsToTerraform(struct?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _routingControl;
    get routingControl(): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlList;
    putRoutingControl(value: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | cdktn.IResolvable): void;
    resetRoutingControl(): void;
    get routingControlInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepArcRoutingControlConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * region_and_routing_controls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_and_routing_controls ArcregionswitchPlan#region_and_routing_controls}
    */
    readonly regionAndRoutingControls?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepArcRoutingControlConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepArcRoutingControlConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepArcRoutingControlConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepArcRoutingControlConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepArcRoutingControlConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _regionAndRoutingControls;
    get regionAndRoutingControls(): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsList;
    putRegionAndRoutingControls(value: ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls[] | cdktn.IResolvable): void;
    resetRegionAndRoutingControls(): void;
    get regionAndRoutingControlsInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControls[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepArcRoutingControlConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#instance_arns ArcregionswitchPlan#instance_arns}
    */
    readonly instanceArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns ArcregionswitchPlan#region_database_cluster_arns}
    */
    readonly regionDatabaseClusterArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _instanceArns?;
    get instanceArns(): {
        [key: string]: string;
    };
    set instanceArns(value: {
        [key: string]: string;
    });
    get instanceArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _regionDatabaseClusterArns?;
    get regionDatabaseClusterArns(): {
        [key: string]: string;
    };
    set regionDatabaseClusterArns(value: {
        [key: string]: string;
    });
    get regionDatabaseClusterArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns ArcregionswitchPlan#region_database_cluster_arns}
    */
    readonly regionDatabaseClusterArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _regionDatabaseClusterArns?;
    get regionDatabaseClusterArns(): {
        [key: string]: string;
    };
    set regionDatabaseClusterArns(value: {
        [key: string]: string;
    });
    get regionDatabaseClusterArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    resetTargetPercent(): void;
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaToTerraform(struct?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
}
export declare function arcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_to_run ArcregionswitchPlan#region_to_run}
    */
    readonly regionToRun: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#retry_interval_minutes ArcregionswitchPlan#retry_interval_minutes}
    */
    readonly retryIntervalMinutes: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * lambda block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#lambda ArcregionswitchPlan#lambda}
    */
    readonly lambda?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepCustomActionLambdaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepCustomActionLambdaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig | cdktn.IResolvable | undefined);
    private _regionToRun?;
    get regionToRun(): string;
    set regionToRun(value: string);
    get regionToRunInput(): string | undefined;
    private _retryIntervalMinutes?;
    get retryIntervalMinutes(): number;
    set retryIntervalMinutes(value: number);
    get retryIntervalMinutesInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _lambda;
    get lambda(): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaList;
    putLambda(value: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda[] | cdktn.IResolvable): void;
    resetLambda(): void;
    get lambdaInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambda[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepDocumentDbConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#database_cluster_arns ArcregionswitchPlan#database_cluster_arns}
    */
    readonly databaseClusterArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepDocumentDbConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepDocumentDbConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepDocumentDbConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepDocumentDbConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepDocumentDbConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepDocumentDbConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepDocumentDbConfig | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _databaseClusterArns?;
    get databaseClusterArns(): string[];
    set databaseClusterArns(value: string[]);
    get databaseClusterArnsInput(): string[] | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepDocumentDbConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepDocumentDbConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepDocumentDbConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepDocumentDbConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgToTerraform(struct?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#minimum_success_percentage ArcregionswitchPlan#minimum_success_percentage}
    */
    readonly minimumSuccessPercentage: number;
}
export declare function arcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined);
    private _minimumSuccessPercentage?;
    get minimumSuccessPercentage(): number;
    set minimumSuccessPercentage(value: number);
    get minimumSuccessPercentageInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach ArcregionswitchPlan#capacity_monitoring_approach}
    */
    readonly capacityMonitoringApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * asg block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#asg ArcregionswitchPlan#asg}
    */
    readonly asg?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable | undefined);
    private _capacityMonitoringApproach?;
    get capacityMonitoringApproach(): string;
    set capacityMonitoringApproach(value: string);
    get capacityMonitoringApproachInput(): string | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    resetTargetPercent(): void;
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _asg;
    get asg(): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgList;
    putAsg(value: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg[] | cdktn.IResolvable): void;
    resetAsg(): void;
    get asgInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsg[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cluster_arn ArcregionswitchPlan#cluster_arn}
    */
    readonly clusterArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#service_arn ArcregionswitchPlan#service_arn}
    */
    readonly serviceArn: string;
}
export declare function arcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServiceToTerraform(struct?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServiceToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService | cdktn.IResolvable | undefined);
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    get clusterArnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServiceList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServiceOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#minimum_success_percentage ArcregionswitchPlan#minimum_success_percentage}
    */
    readonly minimumSuccessPercentage: number;
}
export declare function arcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined);
    private _minimumSuccessPercentage?;
    get minimumSuccessPercentage(): number;
    set minimumSuccessPercentage(value: number);
    get minimumSuccessPercentageInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach ArcregionswitchPlan#capacity_monitoring_approach}
    */
    readonly capacityMonitoringApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#service ArcregionswitchPlan#service}
    */
    readonly service?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig | cdktn.IResolvable | undefined);
    private _capacityMonitoringApproach?;
    get capacityMonitoringApproach(): string;
    set capacityMonitoringApproach(value: string);
    get capacityMonitoringApproachInput(): string | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    resetTargetPercent(): void;
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _service;
    get service(): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServiceList;
    putService(value: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService[] | cdktn.IResolvable): void;
    resetService(): void;
    get serviceInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigService[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cluster_arn ArcregionswitchPlan#cluster_arn}
    */
    readonly clusterArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersToTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters | cdktn.IResolvable | undefined);
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    get clusterArnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#api_version ArcregionswitchPlan#api_version}
    */
    readonly apiVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#kind ArcregionswitchPlan#kind}
    */
    readonly kind: string;
}
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypeToTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypeToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    get apiVersionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypeList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypeOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#hpa_name ArcregionswitchPlan#hpa_name}
    */
    readonly hpaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#name ArcregionswitchPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#namespace ArcregionswitchPlan#namespace}
    */
    readonly namespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#resource_name ArcregionswitchPlan#resource_name}
    */
    readonly resourceName: string;
}
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesToTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable | undefined);
    private _hpaName?;
    get hpaName(): string;
    set hpaName(value: string);
    resetHpaName(): void;
    get hpaNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#namespace ArcregionswitchPlan#namespace}
    */
    readonly namespace: string;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#resources ArcregionswitchPlan#resources}
    */
    readonly resources?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesToTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources | cdktn.IResolvable | undefined);
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _resources;
    get resources(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesList;
    putResources(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResources[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#minimum_success_percentage ArcregionswitchPlan#minimum_success_percentage}
    */
    readonly minimumSuccessPercentage: number;
}
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful | cdktn.IResolvable | undefined);
    private _minimumSuccessPercentage?;
    get minimumSuccessPercentage(): number;
    set minimumSuccessPercentage(value: number);
    get minimumSuccessPercentageInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepEksResourceScalingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach ArcregionswitchPlan#capacity_monitoring_approach}
    */
    readonly capacityMonitoringApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * eks_clusters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#eks_clusters ArcregionswitchPlan#eks_clusters}
    */
    readonly eksClusters?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters[] | cdktn.IResolvable;
    /**
    * kubernetes_resource_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type ArcregionswitchPlan#kubernetes_resource_type}
    */
    readonly kubernetesResourceType?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType[] | cdktn.IResolvable;
    /**
    * scaling_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#scaling_resources ArcregionswitchPlan#scaling_resources}
    */
    readonly scalingResources?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepEksResourceScalingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfig | cdktn.IResolvable | undefined);
    private _capacityMonitoringApproach?;
    get capacityMonitoringApproach(): string;
    set capacityMonitoringApproach(value: string);
    get capacityMonitoringApproachInput(): string | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _eksClusters;
    get eksClusters(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersList;
    putEksClusters(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters[] | cdktn.IResolvable): void;
    resetEksClusters(): void;
    get eksClustersInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClusters[] | undefined;
    private _kubernetesResourceType;
    get kubernetesResourceType(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypeList;
    putKubernetesResourceType(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType[] | cdktn.IResolvable): void;
    resetKubernetesResourceType(): void;
    get kubernetesResourceTypeInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceType[] | undefined;
    private _scalingResources;
    get scalingResources(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesList;
    putScalingResources(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources[] | cdktn.IResolvable): void;
    resetScalingResources(): void;
    get scalingResourcesInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResources[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepEksResourceScalingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepExecutionApprovalConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#approval_role ArcregionswitchPlan#approval_role}
    */
    readonly approvalRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepExecutionApprovalConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepExecutionApprovalConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepExecutionApprovalConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepExecutionApprovalConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepExecutionApprovalConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepExecutionApprovalConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepExecutionApprovalConfig | cdktn.IResolvable | undefined);
    private _approvalRole?;
    get approvalRole(): string;
    set approvalRole(value: string);
    get approvalRoleInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepExecutionApprovalConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepExecutionApprovalConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepExecutionApprovalConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepGlobalAuroraConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#database_cluster_arns ArcregionswitchPlan#database_cluster_arns}
    */
    readonly databaseClusterArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepGlobalAuroraConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepGlobalAuroraConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepGlobalAuroraConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepGlobalAuroraConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepGlobalAuroraConfig | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _databaseClusterArns?;
    get databaseClusterArns(): string[];
    set databaseClusterArns(value: string[]);
    get databaseClusterArnsInput(): string[] | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepGlobalAuroraConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepGlobalAuroraConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region ArcregionswitchPlan#region}
    */
    readonly region: string;
}
export declare function arcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingToTerraform(struct?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
}
export declare function arcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#action ArcregionswitchPlan#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * region_event_source_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_event_source_mapping ArcregionswitchPlan#region_event_source_mapping}
    */
    readonly regionEventSourceMapping?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _regionEventSourceMapping;
    get regionEventSourceMapping(): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingList;
    putRegionEventSourceMapping(value: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | cdktn.IResolvable): void;
    resetRegionEventSourceMapping(): void;
    get regionEventSourceMappingInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns ArcregionswitchPlan#region_database_cluster_arns}
    */
    readonly regionDatabaseClusterArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _regionDatabaseClusterArns?;
    get regionDatabaseClusterArns(): {
        [key: string]: string;
    };
    set regionDatabaseClusterArns(value: {
        [key: string]: string;
    });
    get regionDatabaseClusterArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#routing_control_arn ArcregionswitchPlan#routing_control_arn}
    */
    readonly routingControlArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#state ArcregionswitchPlan#state}
    */
    readonly state: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl | cdktn.IResolvable | undefined);
    private _routingControlArn?;
    get routingControlArn(): string;
    set routingControlArn(value: string);
    get routingControlArnInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    get stateInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region ArcregionswitchPlan#region}
    */
    readonly region: string;
    /**
    * routing_control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#routing_control ArcregionswitchPlan#routing_control}
    */
    readonly routingControl?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _routingControl;
    get routingControl(): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlList;
    putRoutingControl(value: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | cdktn.IResolvable): void;
    resetRoutingControl(): void;
    get routingControlInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControl[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * region_and_routing_controls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_and_routing_controls ArcregionswitchPlan#region_and_routing_controls}
    */
    readonly regionAndRoutingControls?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _regionAndRoutingControls;
    get regionAndRoutingControls(): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsList;
    putRegionAndRoutingControls(value: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls[] | cdktn.IResolvable): void;
    resetRegionAndRoutingControls(): void;
    get regionAndRoutingControlsInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControls[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#instance_arns ArcregionswitchPlan#instance_arns}
    */
    readonly instanceArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns ArcregionswitchPlan#region_database_cluster_arns}
    */
    readonly regionDatabaseClusterArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _instanceArns?;
    get instanceArns(): {
        [key: string]: string;
    };
    set instanceArns(value: {
        [key: string]: string;
    });
    get instanceArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _regionDatabaseClusterArns?;
    get regionDatabaseClusterArns(): {
        [key: string]: string;
    };
    set regionDatabaseClusterArns(value: {
        [key: string]: string;
    });
    get regionDatabaseClusterArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns ArcregionswitchPlan#region_database_cluster_arns}
    */
    readonly regionDatabaseClusterArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _regionDatabaseClusterArns?;
    get regionDatabaseClusterArns(): {
        [key: string]: string;
    };
    set regionDatabaseClusterArns(value: {
        [key: string]: string;
    });
    get regionDatabaseClusterArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    resetTargetPercent(): void;
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_to_run ArcregionswitchPlan#region_to_run}
    */
    readonly regionToRun: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#retry_interval_minutes ArcregionswitchPlan#retry_interval_minutes}
    */
    readonly retryIntervalMinutes: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * lambda block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#lambda ArcregionswitchPlan#lambda}
    */
    readonly lambda?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig | cdktn.IResolvable | undefined);
    private _regionToRun?;
    get regionToRun(): string;
    set regionToRun(value: string);
    get regionToRunInput(): string | undefined;
    private _retryIntervalMinutes?;
    get retryIntervalMinutes(): number;
    set retryIntervalMinutes(value: number);
    get retryIntervalMinutesInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _lambda;
    get lambda(): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaList;
    putLambda(value: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda[] | cdktn.IResolvable): void;
    resetLambda(): void;
    get lambdaInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambda[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#database_cluster_arns ArcregionswitchPlan#database_cluster_arns}
    */
    readonly databaseClusterArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _databaseClusterArns?;
    get databaseClusterArns(): string[];
    set databaseClusterArns(value: string[]);
    get databaseClusterArnsInput(): string[] | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#minimum_success_percentage ArcregionswitchPlan#minimum_success_percentage}
    */
    readonly minimumSuccessPercentage: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined);
    private _minimumSuccessPercentage?;
    get minimumSuccessPercentage(): number;
    set minimumSuccessPercentage(value: number);
    get minimumSuccessPercentageInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach ArcregionswitchPlan#capacity_monitoring_approach}
    */
    readonly capacityMonitoringApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * asg block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#asg ArcregionswitchPlan#asg}
    */
    readonly asg?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig | cdktn.IResolvable | undefined);
    private _capacityMonitoringApproach?;
    get capacityMonitoringApproach(): string;
    set capacityMonitoringApproach(value: string);
    get capacityMonitoringApproachInput(): string | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    resetTargetPercent(): void;
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _asg;
    get asg(): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgList;
    putAsg(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg[] | cdktn.IResolvable): void;
    resetAsg(): void;
    get asgInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsg[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cluster_arn ArcregionswitchPlan#cluster_arn}
    */
    readonly clusterArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#service_arn ArcregionswitchPlan#service_arn}
    */
    readonly serviceArn: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService | cdktn.IResolvable | undefined);
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    get clusterArnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#minimum_success_percentage ArcregionswitchPlan#minimum_success_percentage}
    */
    readonly minimumSuccessPercentage: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful | cdktn.IResolvable | undefined);
    private _minimumSuccessPercentage?;
    get minimumSuccessPercentage(): number;
    set minimumSuccessPercentage(value: number);
    get minimumSuccessPercentageInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach ArcregionswitchPlan#capacity_monitoring_approach}
    */
    readonly capacityMonitoringApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#service ArcregionswitchPlan#service}
    */
    readonly service?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig | cdktn.IResolvable | undefined);
    private _capacityMonitoringApproach?;
    get capacityMonitoringApproach(): string;
    set capacityMonitoringApproach(value: string);
    get capacityMonitoringApproachInput(): string | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    resetTargetPercent(): void;
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _service;
    get service(): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceList;
    putService(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService[] | cdktn.IResolvable): void;
    resetService(): void;
    get serviceInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigService[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cluster_arn ArcregionswitchPlan#cluster_arn}
    */
    readonly clusterArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters | cdktn.IResolvable | undefined);
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    get clusterArnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#api_version ArcregionswitchPlan#api_version}
    */
    readonly apiVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#kind ArcregionswitchPlan#kind}
    */
    readonly kind: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType | cdktn.IResolvable | undefined);
    private _apiVersion?;
    get apiVersion(): string;
    set apiVersion(value: string);
    get apiVersionInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#hpa_name ArcregionswitchPlan#hpa_name}
    */
    readonly hpaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#name ArcregionswitchPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#namespace ArcregionswitchPlan#namespace}
    */
    readonly namespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#resource_name ArcregionswitchPlan#resource_name}
    */
    readonly resourceName: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources | cdktn.IResolvable | undefined);
    private _hpaName?;
    get hpaName(): string;
    set hpaName(value: string);
    resetHpaName(): void;
    get hpaNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#namespace ArcregionswitchPlan#namespace}
    */
    readonly namespace: string;
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#resources ArcregionswitchPlan#resources}
    */
    readonly resources?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources | cdktn.IResolvable | undefined);
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _resources;
    get resources(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesList;
    putResources(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResources[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#minimum_success_percentage ArcregionswitchPlan#minimum_success_percentage}
    */
    readonly minimumSuccessPercentage: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful | cdktn.IResolvable | undefined);
    private _minimumSuccessPercentage?;
    get minimumSuccessPercentage(): number;
    set minimumSuccessPercentage(value: number);
    get minimumSuccessPercentageInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach ArcregionswitchPlan#capacity_monitoring_approach}
    */
    readonly capacityMonitoringApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#target_percent ArcregionswitchPlan#target_percent}
    */
    readonly targetPercent: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * eks_clusters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#eks_clusters ArcregionswitchPlan#eks_clusters}
    */
    readonly eksClusters?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters[] | cdktn.IResolvable;
    /**
    * kubernetes_resource_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type ArcregionswitchPlan#kubernetes_resource_type}
    */
    readonly kubernetesResourceType?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType[] | cdktn.IResolvable;
    /**
    * scaling_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#scaling_resources ArcregionswitchPlan#scaling_resources}
    */
    readonly scalingResources?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig | cdktn.IResolvable | undefined);
    private _capacityMonitoringApproach?;
    get capacityMonitoringApproach(): string;
    set capacityMonitoringApproach(value: string);
    get capacityMonitoringApproachInput(): string | undefined;
    private _targetPercent?;
    get targetPercent(): number;
    set targetPercent(value: number);
    get targetPercentInput(): number | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _eksClusters;
    get eksClusters(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersList;
    putEksClusters(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters[] | cdktn.IResolvable): void;
    resetEksClusters(): void;
    get eksClustersInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClusters[] | undefined;
    private _kubernetesResourceType;
    get kubernetesResourceType(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeList;
    putKubernetesResourceType(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType[] | cdktn.IResolvable): void;
    resetKubernetesResourceType(): void;
    get kubernetesResourceTypeInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceType[] | undefined;
    private _scalingResources;
    get scalingResources(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesList;
    putScalingResources(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources[] | cdktn.IResolvable): void;
    resetScalingResources(): void;
    get scalingResourcesInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResources[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#approval_role ArcregionswitchPlan#approval_role}
    */
    readonly approvalRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig | cdktn.IResolvable | undefined);
    private _approvalRole?;
    get approvalRole(): string;
    set approvalRole(value: string);
    get approvalRoleInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#database_cluster_arns ArcregionswitchPlan#database_cluster_arns}
    */
    readonly databaseClusterArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _databaseClusterArns?;
    get databaseClusterArns(): string[];
    set databaseClusterArns(value: string[]);
    get databaseClusterArnsInput(): string[] | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region ArcregionswitchPlan#region}
    */
    readonly region: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#action ArcregionswitchPlan#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * region_event_source_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_event_source_mapping ArcregionswitchPlan#region_event_source_mapping}
    */
    readonly regionEventSourceMapping?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | cdktn.IResolvable;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _regionEventSourceMapping;
    get regionEventSourceMapping(): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingList;
    putRegionEventSourceMapping(value: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | cdktn.IResolvable): void;
    resetRegionEventSourceMapping(): void;
    get regionEventSourceMappingInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMapping[] | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#behavior ArcregionswitchPlan#behavior}
    */
    readonly behavior: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_cluster_identifier ArcregionswitchPlan#global_cluster_identifier}
    */
    readonly globalClusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns ArcregionswitchPlan#region_database_cluster_arns}
    */
    readonly regionDatabaseClusterArns: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    get behaviorInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _globalClusterIdentifier?;
    get globalClusterIdentifier(): string;
    set globalClusterIdentifier(value: string);
    get globalClusterIdentifierInput(): string | undefined;
    private _regionDatabaseClusterArns?;
    get regionDatabaseClusterArns(): {
        [key: string]: string;
    };
    set regionDatabaseClusterArns(value: {
        [key: string]: string;
    });
    get regionDatabaseClusterArnsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#db_instance_arn_map ArcregionswitchPlan#db_instance_arn_map}
    */
    readonly dbInstanceArnMap: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _dbInstanceArnMap?;
    get dbInstanceArnMap(): {
        [key: string]: string;
    };
    set dbInstanceArnMap(value: {
        [key: string]: string;
    });
    get dbInstanceArnMapInput(): {
        [key: string]: string;
    } | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#db_instance_arn_map ArcregionswitchPlan#db_instance_arn_map}
    */
    readonly dbInstanceArnMap: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _dbInstanceArnMap?;
    get dbInstanceArnMap(): {
        [key: string]: string;
    };
    set dbInstanceArnMap(value: {
        [key: string]: string;
    });
    get dbInstanceArnMapInput(): {
        [key: string]: string;
    } | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#db_instance_arn_map ArcregionswitchPlan#db_instance_arn_map}
    */
    readonly dbInstanceArnMap: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _dbInstanceArnMap?;
    get dbInstanceArnMap(): {
        [key: string]: string;
    };
    set dbInstanceArnMap(value: {
        [key: string]: string;
    });
    get dbInstanceArnMapInput(): {
        [key: string]: string;
    } | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#record_set_identifier ArcregionswitchPlan#record_set_identifier}
    */
    readonly recordSetIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region ArcregionswitchPlan#region}
    */
    readonly region: string;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable | undefined);
    private _recordSetIdentifier?;
    get recordSetIdentifier(): string;
    set recordSetIdentifier(value: string);
    get recordSetIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#hosted_zone_id ArcregionswitchPlan#hosted_zone_id}
    */
    readonly hostedZoneId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#record_name ArcregionswitchPlan#record_name}
    */
    readonly recordName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * record_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#record_set ArcregionswitchPlan#record_set}
    */
    readonly recordSet?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _hostedZoneId?;
    get hostedZoneId(): string;
    set hostedZoneId(value: string);
    get hostedZoneIdInput(): string | undefined;
    private _recordName?;
    get recordName(): string;
    set recordName(value: string);
    get recordNameInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _recordSet;
    get recordSet(): ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetList;
    putRecordSet(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet[] | cdktn.IResolvable): void;
    resetRecordSet(): void;
    get recordSetInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSet[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfigStep {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#description ArcregionswitchPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#execution_block_type ArcregionswitchPlan#execution_block_type}
    */
    readonly executionBlockType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#name ArcregionswitchPlan#name}
    */
    readonly name: string;
    /**
    * arc_routing_control_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arc_routing_control_config ArcregionswitchPlan#arc_routing_control_config}
    */
    readonly arcRoutingControlConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig[] | cdktn.IResolvable;
    /**
    * aurora_provisioned_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config ArcregionswitchPlan#aurora_provisioned_scaling_config}
    */
    readonly auroraProvisionedScalingConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig[] | cdktn.IResolvable;
    /**
    * aurora_serverless_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config ArcregionswitchPlan#aurora_serverless_scaling_config}
    */
    readonly auroraServerlessScalingConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig[] | cdktn.IResolvable;
    /**
    * custom_action_lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config ArcregionswitchPlan#custom_action_lambda_config}
    */
    readonly customActionLambdaConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig[] | cdktn.IResolvable;
    /**
    * document_db_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#document_db_config ArcregionswitchPlan#document_db_config}
    */
    readonly documentDbConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig[] | cdktn.IResolvable;
    /**
    * ec2_asg_capacity_increase_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config ArcregionswitchPlan#ec2_asg_capacity_increase_config}
    */
    readonly ec2AsgCapacityIncreaseConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * ecs_capacity_increase_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config ArcregionswitchPlan#ecs_capacity_increase_config}
    */
    readonly ecsCapacityIncreaseConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * eks_resource_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config ArcregionswitchPlan#eks_resource_scaling_config}
    */
    readonly eksResourceScalingConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig[] | cdktn.IResolvable;
    /**
    * execution_approval_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#execution_approval_config ArcregionswitchPlan#execution_approval_config}
    */
    readonly executionApprovalConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig[] | cdktn.IResolvable;
    /**
    * global_aurora_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_aurora_config ArcregionswitchPlan#global_aurora_config}
    */
    readonly globalAuroraConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig[] | cdktn.IResolvable;
    /**
    * lambda_event_source_mapping_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config ArcregionswitchPlan#lambda_event_source_mapping_config}
    */
    readonly lambdaEventSourceMappingConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig[] | cdktn.IResolvable;
    /**
    * neptune_global_database_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#neptune_global_database_config ArcregionswitchPlan#neptune_global_database_config}
    */
    readonly neptuneGlobalDatabaseConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig[] | cdktn.IResolvable;
    /**
    * rds_create_cross_region_read_replica_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config ArcregionswitchPlan#rds_create_cross_region_read_replica_config}
    */
    readonly rdsCreateCrossRegionReadReplicaConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * rds_promote_read_replica_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config ArcregionswitchPlan#rds_promote_read_replica_config}
    */
    readonly rdsPromoteReadReplicaConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * rds_switchover_read_replica_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#rds_switchover_read_replica_config ArcregionswitchPlan#rds_switchover_read_replica_config}
    */
    readonly rdsSwitchoverReadReplicaConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * region_switch_plan_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_switch_plan_config ArcregionswitchPlan#region_switch_plan_config}
    */
    readonly regionSwitchPlanConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig[] | cdktn.IResolvable;
    /**
    * route53_health_check_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#route53_health_check_config ArcregionswitchPlan#route53_health_check_config}
    */
    readonly route53HealthCheckConfig?: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStep | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigStepToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfigStep | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfigStep | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfigStep | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionBlockType?;
    get executionBlockType(): string;
    set executionBlockType(value: string);
    get executionBlockTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _arcRoutingControlConfig;
    get arcRoutingControlConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigList;
    putArcRoutingControlConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig[] | cdktn.IResolvable): void;
    resetArcRoutingControlConfig(): void;
    get arcRoutingControlConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfig[] | undefined;
    private _auroraProvisionedScalingConfig;
    get auroraProvisionedScalingConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigList;
    putAuroraProvisionedScalingConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig[] | cdktn.IResolvable): void;
    resetAuroraProvisionedScalingConfig(): void;
    get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfig[] | undefined;
    private _auroraServerlessScalingConfig;
    get auroraServerlessScalingConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigList;
    putAuroraServerlessScalingConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig[] | cdktn.IResolvable): void;
    resetAuroraServerlessScalingConfig(): void;
    get auroraServerlessScalingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfig[] | undefined;
    private _customActionLambdaConfig;
    get customActionLambdaConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigList;
    putCustomActionLambdaConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig[] | cdktn.IResolvable): void;
    resetCustomActionLambdaConfig(): void;
    get customActionLambdaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfig[] | undefined;
    private _documentDbConfig;
    get documentDbConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigList;
    putDocumentDbConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig[] | cdktn.IResolvable): void;
    resetDocumentDbConfig(): void;
    get documentDbConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfig[] | undefined;
    private _ec2AsgCapacityIncreaseConfig;
    get ec2AsgCapacityIncreaseConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigList;
    putEc2AsgCapacityIncreaseConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig[] | cdktn.IResolvable): void;
    resetEc2AsgCapacityIncreaseConfig(): void;
    get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfig[] | undefined;
    private _ecsCapacityIncreaseConfig;
    get ecsCapacityIncreaseConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigList;
    putEcsCapacityIncreaseConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig[] | cdktn.IResolvable): void;
    resetEcsCapacityIncreaseConfig(): void;
    get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfig[] | undefined;
    private _eksResourceScalingConfig;
    get eksResourceScalingConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigList;
    putEksResourceScalingConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig[] | cdktn.IResolvable): void;
    resetEksResourceScalingConfig(): void;
    get eksResourceScalingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfig[] | undefined;
    private _executionApprovalConfig;
    get executionApprovalConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigList;
    putExecutionApprovalConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig[] | cdktn.IResolvable): void;
    resetExecutionApprovalConfig(): void;
    get executionApprovalConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfig[] | undefined;
    private _globalAuroraConfig;
    get globalAuroraConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigList;
    putGlobalAuroraConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig[] | cdktn.IResolvable): void;
    resetGlobalAuroraConfig(): void;
    get globalAuroraConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfig[] | undefined;
    private _lambdaEventSourceMappingConfig;
    get lambdaEventSourceMappingConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigList;
    putLambdaEventSourceMappingConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig[] | cdktn.IResolvable): void;
    resetLambdaEventSourceMappingConfig(): void;
    get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfig[] | undefined;
    private _neptuneGlobalDatabaseConfig;
    get neptuneGlobalDatabaseConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigList;
    putNeptuneGlobalDatabaseConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig[] | cdktn.IResolvable): void;
    resetNeptuneGlobalDatabaseConfig(): void;
    get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfig[] | undefined;
    private _rdsCreateCrossRegionReadReplicaConfig;
    get rdsCreateCrossRegionReadReplicaConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigList;
    putRdsCreateCrossRegionReadReplicaConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig[] | cdktn.IResolvable): void;
    resetRdsCreateCrossRegionReadReplicaConfig(): void;
    get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfig[] | undefined;
    private _rdsPromoteReadReplicaConfig;
    get rdsPromoteReadReplicaConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigList;
    putRdsPromoteReadReplicaConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig[] | cdktn.IResolvable): void;
    resetRdsPromoteReadReplicaConfig(): void;
    get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfig[] | undefined;
    private _rdsSwitchoverReadReplicaConfig;
    get rdsSwitchoverReadReplicaConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfigList;
    putRdsSwitchoverReadReplicaConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig[] | cdktn.IResolvable): void;
    resetRdsSwitchoverReadReplicaConfig(): void;
    get rdsSwitchoverReadReplicaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepRdsSwitchoverReadReplicaConfig[] | undefined;
    private _regionSwitchPlanConfig;
    get regionSwitchPlanConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigList;
    putRegionSwitchPlanConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig[] | cdktn.IResolvable): void;
    resetRegionSwitchPlanConfig(): void;
    get regionSwitchPlanConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfig[] | undefined;
    private _route53HealthCheckConfig;
    get route53HealthCheckConfig(): ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigList;
    putRoute53HealthCheckConfig(value: ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig[] | cdktn.IResolvable): void;
    resetRoute53HealthCheckConfig(): void;
    get route53HealthCheckConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfig[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigStepList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfigStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigStepOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepParallelConfig {
    /**
    * step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#step ArcregionswitchPlan#step}
    */
    readonly step?: ArcregionswitchPlanWorkflowStepParallelConfigStep[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepParallelConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepParallelConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepParallelConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepParallelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepParallelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepParallelConfig | cdktn.IResolvable | undefined);
    private _step;
    get step(): ArcregionswitchPlanWorkflowStepParallelConfigStepList;
    putStep(value: ArcregionswitchPlanWorkflowStepParallelConfigStep[] | cdktn.IResolvable): void;
    resetStep(): void;
    get stepInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfigStep[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepParallelConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepParallelConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepParallelConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#db_instance_arn_map ArcregionswitchPlan#db_instance_arn_map}
    */
    readonly dbInstanceArnMap: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _dbInstanceArnMap?;
    get dbInstanceArnMap(): {
        [key: string]: string;
    };
    set dbInstanceArnMap(value: {
        [key: string]: string;
    });
    get dbInstanceArnMapInput(): {
        [key: string]: string;
    } | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#db_instance_arn_map ArcregionswitchPlan#db_instance_arn_map}
    */
    readonly dbInstanceArnMap: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
}
export declare function arcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _dbInstanceArnMap?;
    get dbInstanceArnMap(): {
        [key: string]: string;
    };
    set dbInstanceArnMap(value: {
        [key: string]: string;
    });
    get dbInstanceArnMapInput(): {
        [key: string]: string;
    } | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful: string;
}
export declare function arcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngracefulToTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngracefulToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngracefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful | cdktn.IResolvable | undefined);
    private _ungraceful?;
    get ungraceful(): string;
    set ungraceful(value: string);
    get ungracefulInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngracefulList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngracefulOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#db_instance_arn_map ArcregionswitchPlan#db_instance_arn_map}
    */
    readonly dbInstanceArnMap: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * ungraceful block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ungraceful ArcregionswitchPlan#ungraceful}
    */
    readonly ungraceful?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _dbInstanceArnMap?;
    get dbInstanceArnMap(): {
        [key: string]: string;
    };
    set dbInstanceArnMap(value: {
        [key: string]: string;
    });
    get dbInstanceArnMapInput(): {
        [key: string]: string;
    } | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _ungraceful;
    get ungraceful(): ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngracefulList;
    putUngraceful(value: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful[] | cdktn.IResolvable): void;
    resetUngraceful(): void;
    get ungracefulInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigUngraceful[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arn ArcregionswitchPlan#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
}
export declare function arcregionswitchPlanWorkflowStepRegionSwitchPlanConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepRegionSwitchPlanConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#record_set_identifier ArcregionswitchPlan#record_set_identifier}
    */
    readonly recordSetIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region ArcregionswitchPlan#region}
    */
    readonly region: string;
}
export declare function arcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetToTerraform(struct?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet | cdktn.IResolvable | undefined);
    private _recordSetIdentifier?;
    get recordSetIdentifier(): string;
    set recordSetIdentifier(value: string);
    get recordSetIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetOutputReference;
}
export interface ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#cross_account_role ArcregionswitchPlan#cross_account_role}
    */
    readonly crossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#external_id ArcregionswitchPlan#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#hosted_zone_id ArcregionswitchPlan#hosted_zone_id}
    */
    readonly hostedZoneId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#record_name ArcregionswitchPlan#record_name}
    */
    readonly recordName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#timeout_minutes ArcregionswitchPlan#timeout_minutes}
    */
    readonly timeoutMinutes?: number;
    /**
    * record_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#record_set ArcregionswitchPlan#record_set}
    */
    readonly recordSet?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepRoute53HealthCheckConfigToTerraform(struct?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepRoute53HealthCheckConfigToHclTerraform(struct?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig | cdktn.IResolvable | undefined);
    private _crossAccountRole?;
    get crossAccountRole(): string;
    set crossAccountRole(value: string);
    resetCrossAccountRole(): void;
    get crossAccountRoleInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _hostedZoneId?;
    get hostedZoneId(): string;
    set hostedZoneId(value: string);
    get hostedZoneIdInput(): string | undefined;
    private _recordName?;
    get recordName(): string;
    set recordName(value: string);
    get recordNameInput(): string | undefined;
    private _timeoutMinutes?;
    get timeoutMinutes(): number;
    set timeoutMinutes(value: number);
    resetTimeoutMinutes(): void;
    get timeoutMinutesInput(): number | undefined;
    private _recordSet;
    get recordSet(): ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetList;
    putRecordSet(value: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet[] | cdktn.IResolvable): void;
    resetRecordSet(): void;
    get recordSetInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSet[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigOutputReference;
}
export interface ArcregionswitchPlanWorkflowStep {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#description ArcregionswitchPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#execution_block_type ArcregionswitchPlan#execution_block_type}
    */
    readonly executionBlockType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#name ArcregionswitchPlan#name}
    */
    readonly name: string;
    /**
    * arc_routing_control_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#arc_routing_control_config ArcregionswitchPlan#arc_routing_control_config}
    */
    readonly arcRoutingControlConfig?: ArcregionswitchPlanWorkflowStepArcRoutingControlConfig[] | cdktn.IResolvable;
    /**
    * aurora_provisioned_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config ArcregionswitchPlan#aurora_provisioned_scaling_config}
    */
    readonly auroraProvisionedScalingConfig?: ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig[] | cdktn.IResolvable;
    /**
    * aurora_serverless_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config ArcregionswitchPlan#aurora_serverless_scaling_config}
    */
    readonly auroraServerlessScalingConfig?: ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig[] | cdktn.IResolvable;
    /**
    * custom_action_lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config ArcregionswitchPlan#custom_action_lambda_config}
    */
    readonly customActionLambdaConfig?: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig[] | cdktn.IResolvable;
    /**
    * document_db_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#document_db_config ArcregionswitchPlan#document_db_config}
    */
    readonly documentDbConfig?: ArcregionswitchPlanWorkflowStepDocumentDbConfig[] | cdktn.IResolvable;
    /**
    * ec2_asg_capacity_increase_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config ArcregionswitchPlan#ec2_asg_capacity_increase_config}
    */
    readonly ec2AsgCapacityIncreaseConfig?: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * ecs_capacity_increase_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config ArcregionswitchPlan#ecs_capacity_increase_config}
    */
    readonly ecsCapacityIncreaseConfig?: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig[] | cdktn.IResolvable;
    /**
    * eks_resource_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config ArcregionswitchPlan#eks_resource_scaling_config}
    */
    readonly eksResourceScalingConfig?: ArcregionswitchPlanWorkflowStepEksResourceScalingConfig[] | cdktn.IResolvable;
    /**
    * execution_approval_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#execution_approval_config ArcregionswitchPlan#execution_approval_config}
    */
    readonly executionApprovalConfig?: ArcregionswitchPlanWorkflowStepExecutionApprovalConfig[] | cdktn.IResolvable;
    /**
    * global_aurora_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#global_aurora_config ArcregionswitchPlan#global_aurora_config}
    */
    readonly globalAuroraConfig?: ArcregionswitchPlanWorkflowStepGlobalAuroraConfig[] | cdktn.IResolvable;
    /**
    * lambda_event_source_mapping_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config ArcregionswitchPlan#lambda_event_source_mapping_config}
    */
    readonly lambdaEventSourceMappingConfig?: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig[] | cdktn.IResolvable;
    /**
    * neptune_global_database_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#neptune_global_database_config ArcregionswitchPlan#neptune_global_database_config}
    */
    readonly neptuneGlobalDatabaseConfig?: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig[] | cdktn.IResolvable;
    /**
    * parallel_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#parallel_config ArcregionswitchPlan#parallel_config}
    */
    readonly parallelConfig?: ArcregionswitchPlanWorkflowStepParallelConfig[] | cdktn.IResolvable;
    /**
    * rds_create_cross_region_read_replica_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config ArcregionswitchPlan#rds_create_cross_region_read_replica_config}
    */
    readonly rdsCreateCrossRegionReadReplicaConfig?: ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * rds_promote_read_replica_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config ArcregionswitchPlan#rds_promote_read_replica_config}
    */
    readonly rdsPromoteReadReplicaConfig?: ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * rds_switchover_read_replica_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#rds_switchover_read_replica_config ArcregionswitchPlan#rds_switchover_read_replica_config}
    */
    readonly rdsSwitchoverReadReplicaConfig?: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig[] | cdktn.IResolvable;
    /**
    * region_switch_plan_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#region_switch_plan_config ArcregionswitchPlan#region_switch_plan_config}
    */
    readonly regionSwitchPlanConfig?: ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig[] | cdktn.IResolvable;
    /**
    * route53_health_check_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#route53_health_check_config ArcregionswitchPlan#route53_health_check_config}
    */
    readonly route53HealthCheckConfig?: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowStepToTerraform(struct?: ArcregionswitchPlanWorkflowStep | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowStepToHclTerraform(struct?: ArcregionswitchPlanWorkflowStep | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowStepOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflowStep | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflowStep | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionBlockType?;
    get executionBlockType(): string;
    set executionBlockType(value: string);
    get executionBlockTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _arcRoutingControlConfig;
    get arcRoutingControlConfig(): ArcregionswitchPlanWorkflowStepArcRoutingControlConfigList;
    putArcRoutingControlConfig(value: ArcregionswitchPlanWorkflowStepArcRoutingControlConfig[] | cdktn.IResolvable): void;
    resetArcRoutingControlConfig(): void;
    get arcRoutingControlConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepArcRoutingControlConfig[] | undefined;
    private _auroraProvisionedScalingConfig;
    get auroraProvisionedScalingConfig(): ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigList;
    putAuroraProvisionedScalingConfig(value: ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig[] | cdktn.IResolvable): void;
    resetAuroraProvisionedScalingConfig(): void;
    get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfig[] | undefined;
    private _auroraServerlessScalingConfig;
    get auroraServerlessScalingConfig(): ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigList;
    putAuroraServerlessScalingConfig(value: ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig[] | cdktn.IResolvable): void;
    resetAuroraServerlessScalingConfig(): void;
    get auroraServerlessScalingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfig[] | undefined;
    private _customActionLambdaConfig;
    get customActionLambdaConfig(): ArcregionswitchPlanWorkflowStepCustomActionLambdaConfigList;
    putCustomActionLambdaConfig(value: ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig[] | cdktn.IResolvable): void;
    resetCustomActionLambdaConfig(): void;
    get customActionLambdaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepCustomActionLambdaConfig[] | undefined;
    private _documentDbConfig;
    get documentDbConfig(): ArcregionswitchPlanWorkflowStepDocumentDbConfigList;
    putDocumentDbConfig(value: ArcregionswitchPlanWorkflowStepDocumentDbConfig[] | cdktn.IResolvable): void;
    resetDocumentDbConfig(): void;
    get documentDbConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepDocumentDbConfig[] | undefined;
    private _ec2AsgCapacityIncreaseConfig;
    get ec2AsgCapacityIncreaseConfig(): ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigList;
    putEc2AsgCapacityIncreaseConfig(value: ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig[] | cdktn.IResolvable): void;
    resetEc2AsgCapacityIncreaseConfig(): void;
    get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfig[] | undefined;
    private _ecsCapacityIncreaseConfig;
    get ecsCapacityIncreaseConfig(): ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigList;
    putEcsCapacityIncreaseConfig(value: ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig[] | cdktn.IResolvable): void;
    resetEcsCapacityIncreaseConfig(): void;
    get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfig[] | undefined;
    private _eksResourceScalingConfig;
    get eksResourceScalingConfig(): ArcregionswitchPlanWorkflowStepEksResourceScalingConfigList;
    putEksResourceScalingConfig(value: ArcregionswitchPlanWorkflowStepEksResourceScalingConfig[] | cdktn.IResolvable): void;
    resetEksResourceScalingConfig(): void;
    get eksResourceScalingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepEksResourceScalingConfig[] | undefined;
    private _executionApprovalConfig;
    get executionApprovalConfig(): ArcregionswitchPlanWorkflowStepExecutionApprovalConfigList;
    putExecutionApprovalConfig(value: ArcregionswitchPlanWorkflowStepExecutionApprovalConfig[] | cdktn.IResolvable): void;
    resetExecutionApprovalConfig(): void;
    get executionApprovalConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepExecutionApprovalConfig[] | undefined;
    private _globalAuroraConfig;
    get globalAuroraConfig(): ArcregionswitchPlanWorkflowStepGlobalAuroraConfigList;
    putGlobalAuroraConfig(value: ArcregionswitchPlanWorkflowStepGlobalAuroraConfig[] | cdktn.IResolvable): void;
    resetGlobalAuroraConfig(): void;
    get globalAuroraConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepGlobalAuroraConfig[] | undefined;
    private _lambdaEventSourceMappingConfig;
    get lambdaEventSourceMappingConfig(): ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigList;
    putLambdaEventSourceMappingConfig(value: ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig[] | cdktn.IResolvable): void;
    resetLambdaEventSourceMappingConfig(): void;
    get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfig[] | undefined;
    private _neptuneGlobalDatabaseConfig;
    get neptuneGlobalDatabaseConfig(): ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigList;
    putNeptuneGlobalDatabaseConfig(value: ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig[] | cdktn.IResolvable): void;
    resetNeptuneGlobalDatabaseConfig(): void;
    get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfig[] | undefined;
    private _parallelConfig;
    get parallelConfig(): ArcregionswitchPlanWorkflowStepParallelConfigList;
    putParallelConfig(value: ArcregionswitchPlanWorkflowStepParallelConfig[] | cdktn.IResolvable): void;
    resetParallelConfig(): void;
    get parallelConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepParallelConfig[] | undefined;
    private _rdsCreateCrossRegionReadReplicaConfig;
    get rdsCreateCrossRegionReadReplicaConfig(): ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigList;
    putRdsCreateCrossRegionReadReplicaConfig(value: ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig[] | cdktn.IResolvable): void;
    resetRdsCreateCrossRegionReadReplicaConfig(): void;
    get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfig[] | undefined;
    private _rdsPromoteReadReplicaConfig;
    get rdsPromoteReadReplicaConfig(): ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigList;
    putRdsPromoteReadReplicaConfig(value: ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig[] | cdktn.IResolvable): void;
    resetRdsPromoteReadReplicaConfig(): void;
    get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfig[] | undefined;
    private _rdsSwitchoverReadReplicaConfig;
    get rdsSwitchoverReadReplicaConfig(): ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfigList;
    putRdsSwitchoverReadReplicaConfig(value: ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig[] | cdktn.IResolvable): void;
    resetRdsSwitchoverReadReplicaConfig(): void;
    get rdsSwitchoverReadReplicaConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepRdsSwitchoverReadReplicaConfig[] | undefined;
    private _regionSwitchPlanConfig;
    get regionSwitchPlanConfig(): ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfigList;
    putRegionSwitchPlanConfig(value: ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig[] | cdktn.IResolvable): void;
    resetRegionSwitchPlanConfig(): void;
    get regionSwitchPlanConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepRegionSwitchPlanConfig[] | undefined;
    private _route53HealthCheckConfig;
    get route53HealthCheckConfig(): ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigList;
    putRoute53HealthCheckConfig(value: ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig[] | cdktn.IResolvable): void;
    resetRoute53HealthCheckConfig(): void;
    get route53HealthCheckConfigInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStepRoute53HealthCheckConfig[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowStepList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflowStep[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowStepOutputReference;
}
export interface ArcregionswitchPlanWorkflow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#workflow_description ArcregionswitchPlan#workflow_description}
    */
    readonly workflowDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#workflow_target_action ArcregionswitchPlan#workflow_target_action}
    */
    readonly workflowTargetAction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#workflow_target_region ArcregionswitchPlan#workflow_target_region}
    */
    readonly workflowTargetRegion?: string;
    /**
    * step block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#step ArcregionswitchPlan#step}
    */
    readonly step?: ArcregionswitchPlanWorkflowStep[] | cdktn.IResolvable;
}
export declare function arcregionswitchPlanWorkflowToTerraform(struct?: ArcregionswitchPlanWorkflow | cdktn.IResolvable): any;
export declare function arcregionswitchPlanWorkflowToHclTerraform(struct?: ArcregionswitchPlanWorkflow | cdktn.IResolvable): any;
export declare class ArcregionswitchPlanWorkflowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArcregionswitchPlanWorkflow | cdktn.IResolvable | undefined;
    set internalValue(value: ArcregionswitchPlanWorkflow | cdktn.IResolvable | undefined);
    private _workflowDescription?;
    get workflowDescription(): string;
    set workflowDescription(value: string);
    resetWorkflowDescription(): void;
    get workflowDescriptionInput(): string | undefined;
    private _workflowTargetAction?;
    get workflowTargetAction(): string;
    set workflowTargetAction(value: string);
    get workflowTargetActionInput(): string | undefined;
    private _workflowTargetRegion?;
    get workflowTargetRegion(): string;
    set workflowTargetRegion(value: string);
    resetWorkflowTargetRegion(): void;
    get workflowTargetRegionInput(): string | undefined;
    private _step;
    get step(): ArcregionswitchPlanWorkflowStepList;
    putStep(value: ArcregionswitchPlanWorkflowStep[] | cdktn.IResolvable): void;
    resetStep(): void;
    get stepInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflowStep[] | undefined;
}
export declare class ArcregionswitchPlanWorkflowList extends cdktn.ComplexList {
    internalValue?: ArcregionswitchPlanWorkflow[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArcregionswitchPlanWorkflowOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan}
*/
export declare class ArcregionswitchPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_arcregionswitch_plan";
    /**
    * Generates CDKTN code for importing a ArcregionswitchPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArcregionswitchPlan to import
    * @param importFromId The id of the existing ArcregionswitchPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArcregionswitchPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArcregionswitchPlanConfig
    */
    constructor(scope: Construct, id: string, config: ArcregionswitchPlanConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    get executionRoleInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryRegion?;
    get primaryRegion(): string;
    set primaryRegion(value: string);
    resetPrimaryRegion(): void;
    get primaryRegionInput(): string | undefined;
    private _recoveryApproach?;
    get recoveryApproach(): string;
    set recoveryApproach(value: string);
    get recoveryApproachInput(): string | undefined;
    private _recoveryTimeObjectiveMinutes?;
    get recoveryTimeObjectiveMinutes(): number;
    set recoveryTimeObjectiveMinutes(value: number);
    resetRecoveryTimeObjectiveMinutes(): void;
    get recoveryTimeObjectiveMinutesInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _associatedAlarms;
    get associatedAlarms(): ArcregionswitchPlanAssociatedAlarmsList;
    putAssociatedAlarms(value: ArcregionswitchPlanAssociatedAlarms[] | cdktn.IResolvable): void;
    resetAssociatedAlarms(): void;
    get associatedAlarmsInput(): cdktn.IResolvable | ArcregionswitchPlanAssociatedAlarms[] | undefined;
    private _reportConfiguration;
    get reportConfiguration(): ArcregionswitchPlanReportConfigurationList;
    putReportConfiguration(value: ArcregionswitchPlanReportConfiguration[] | cdktn.IResolvable): void;
    resetReportConfiguration(): void;
    get reportConfigurationInput(): cdktn.IResolvable | ArcregionswitchPlanReportConfiguration[] | undefined;
    private _timeouts;
    get timeouts(): ArcregionswitchPlanTimeoutsOutputReference;
    putTimeouts(value: ArcregionswitchPlanTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ArcregionswitchPlanTimeouts | undefined;
    private _triggers;
    get triggers(): ArcregionswitchPlanTriggersList;
    putTriggers(value: ArcregionswitchPlanTriggers[] | cdktn.IResolvable): void;
    resetTriggers(): void;
    get triggersInput(): cdktn.IResolvable | ArcregionswitchPlanTriggers[] | undefined;
    private _workflow;
    get workflow(): ArcregionswitchPlanWorkflowList;
    putWorkflow(value: ArcregionswitchPlanWorkflow[] | cdktn.IResolvable): void;
    resetWorkflow(): void;
    get workflowInput(): cdktn.IResolvable | ArcregionswitchPlanWorkflow[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
