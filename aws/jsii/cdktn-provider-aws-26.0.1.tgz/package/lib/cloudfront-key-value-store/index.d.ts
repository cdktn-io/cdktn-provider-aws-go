/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CloudfrontKeyValueStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store#comment CloudfrontKeyValueStore#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store#name CloudfrontKeyValueStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store#tags CloudfrontKeyValueStore#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store#timeouts CloudfrontKeyValueStore#timeouts}
    */
    readonly timeouts?: CloudfrontKeyValueStoreTimeouts;
}
export interface CloudfrontKeyValueStoreTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store#create CloudfrontKeyValueStore#create}
    */
    readonly create?: string;
}
export declare function cloudfrontKeyValueStoreTimeoutsToTerraform(struct?: CloudfrontKeyValueStoreTimeouts | cdktn.IResolvable): any;
export declare function cloudfrontKeyValueStoreTimeoutsToHclTerraform(struct?: CloudfrontKeyValueStoreTimeouts | cdktn.IResolvable): any;
export declare class CloudfrontKeyValueStoreTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CloudfrontKeyValueStoreTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CloudfrontKeyValueStoreTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store aws_cloudfront_key_value_store}
*/
export declare class CloudfrontKeyValueStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_key_value_store";
    /**
    * Generates CDKTN code for importing a CloudfrontKeyValueStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CloudfrontKeyValueStore to import
    * @param importFromId The id of the existing CloudfrontKeyValueStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CloudfrontKeyValueStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/cloudfront_key_value_store aws_cloudfront_key_value_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CloudfrontKeyValueStoreConfig
    */
    constructor(scope: Construct, id: string, config: CloudfrontKeyValueStoreConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    get id(): string;
    get lastModifiedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): CloudfrontKeyValueStoreTimeoutsOutputReference;
    putTimeouts(value: CloudfrontKeyValueStoreTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CloudfrontKeyValueStoreTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
