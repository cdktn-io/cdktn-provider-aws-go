/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcorePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#description BedrockagentcorePolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#name BedrockagentcorePolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#policy_engine_id BedrockagentcorePolicy#policy_engine_id}
    */
    readonly policyEngineId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#region BedrockagentcorePolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#validation_mode BedrockagentcorePolicy#validation_mode}
    */
    readonly validationMode?: string;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#definition BedrockagentcorePolicy#definition}
    */
    readonly definition?: BedrockagentcorePolicyDefinition[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#timeouts BedrockagentcorePolicy#timeouts}
    */
    readonly timeouts?: BedrockagentcorePolicyTimeouts;
}
export interface BedrockagentcorePolicyDefinitionCedar {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#statement BedrockagentcorePolicy#statement}
    */
    readonly statement: string;
}
export declare function bedrockagentcorePolicyDefinitionCedarToTerraform(struct?: BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable): any;
export declare function bedrockagentcorePolicyDefinitionCedarToHclTerraform(struct?: BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable): any;
export declare class BedrockagentcorePolicyDefinitionCedarOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePolicyDefinitionCedar | cdktn.IResolvable | undefined);
    private _statement?;
    get statement(): string;
    set statement(value: string);
    get statementInput(): string | undefined;
}
export declare class BedrockagentcorePolicyDefinitionCedarList extends cdktn.ComplexList {
    internalValue?: BedrockagentcorePolicyDefinitionCedar[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcorePolicyDefinitionCedarOutputReference;
}
export interface BedrockagentcorePolicyDefinition {
    /**
    * cedar block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#cedar BedrockagentcorePolicy#cedar}
    */
    readonly cedar?: BedrockagentcorePolicyDefinitionCedar[] | cdktn.IResolvable;
}
export declare function bedrockagentcorePolicyDefinitionToTerraform(struct?: BedrockagentcorePolicyDefinition | cdktn.IResolvable): any;
export declare function bedrockagentcorePolicyDefinitionToHclTerraform(struct?: BedrockagentcorePolicyDefinition | cdktn.IResolvable): any;
export declare class BedrockagentcorePolicyDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcorePolicyDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePolicyDefinition | cdktn.IResolvable | undefined);
    private _cedar;
    get cedar(): BedrockagentcorePolicyDefinitionCedarList;
    putCedar(value: BedrockagentcorePolicyDefinitionCedar[] | cdktn.IResolvable): void;
    resetCedar(): void;
    get cedarInput(): cdktn.IResolvable | BedrockagentcorePolicyDefinitionCedar[] | undefined;
}
export declare class BedrockagentcorePolicyDefinitionList extends cdktn.ComplexList {
    internalValue?: BedrockagentcorePolicyDefinition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcorePolicyDefinitionOutputReference;
}
export interface BedrockagentcorePolicyTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#create BedrockagentcorePolicy#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#delete BedrockagentcorePolicy#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#update BedrockagentcorePolicy#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcorePolicyTimeoutsToTerraform(struct?: BedrockagentcorePolicyTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcorePolicyTimeoutsToHclTerraform(struct?: BedrockagentcorePolicyTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcorePolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcorePolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcorePolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy aws_bedrockagentcore_policy}
*/
export declare class BedrockagentcorePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_policy";
    /**
    * Generates CDKTN code for importing a BedrockagentcorePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcorePolicy to import
    * @param importFromId The id of the existing BedrockagentcorePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcorePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_policy aws_bedrockagentcore_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcorePolicyConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcorePolicyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyArn(): string;
    private _policyEngineId?;
    get policyEngineId(): string;
    set policyEngineId(value: string);
    get policyEngineIdInput(): string | undefined;
    get policyId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _validationMode?;
    get validationMode(): string;
    set validationMode(value: string);
    resetValidationMode(): void;
    get validationModeInput(): string | undefined;
    private _definition;
    get definition(): BedrockagentcorePolicyDefinitionList;
    putDefinition(value: BedrockagentcorePolicyDefinition[] | cdktn.IResolvable): void;
    resetDefinition(): void;
    get definitionInput(): cdktn.IResolvable | BedrockagentcorePolicyDefinition[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcorePolicyTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcorePolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcorePolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
