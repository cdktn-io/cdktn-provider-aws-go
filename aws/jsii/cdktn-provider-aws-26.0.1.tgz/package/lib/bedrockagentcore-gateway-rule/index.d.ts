/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BedrockagentcoreGatewayRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#description BedrockagentcoreGatewayRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#gateway_identifier BedrockagentcoreGatewayRule#gateway_identifier}
    */
    readonly gatewayIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#priority BedrockagentcoreGatewayRule#priority}
    */
    readonly priority: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#region BedrockagentcoreGatewayRule#region}
    */
    readonly region?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#action BedrockagentcoreGatewayRule#action}
    */
    readonly action?: BedrockagentcoreGatewayRuleAction[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#condition BedrockagentcoreGatewayRule#condition}
    */
    readonly condition?: BedrockagentcoreGatewayRuleCondition[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#timeouts BedrockagentcoreGatewayRule#timeouts}
    */
    readonly timeouts?: BedrockagentcoreGatewayRuleTimeouts;
}
export interface BedrockagentcoreGatewayRuleSystem {
}
export declare function bedrockagentcoreGatewayRuleSystemToTerraform(struct?: BedrockagentcoreGatewayRuleSystem): any;
export declare function bedrockagentcoreGatewayRuleSystemToHclTerraform(struct?: BedrockagentcoreGatewayRuleSystem): any;
export declare class BedrockagentcoreGatewayRuleSystemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleSystem | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleSystem | undefined);
    get managedBy(): string;
}
export declare class BedrockagentcoreGatewayRuleSystemList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleSystemOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#bundle_arn BedrockagentcoreGatewayRule#bundle_arn}
    */
    readonly bundleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#bundle_version BedrockagentcoreGatewayRule#bundle_version}
    */
    readonly bundleVersion: string;
}
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverrideToTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverrideToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride | cdktn.IResolvable | undefined);
    private _bundleArn?;
    get bundleArn(): string;
    set bundleArn(value: string);
    get bundleArnInput(): string | undefined;
    private _bundleVersion?;
    get bundleVersion(): string;
    set bundleVersion(value: string);
    get bundleVersionInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverrideList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverrideOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#bundle_arn BedrockagentcoreGatewayRule#bundle_arn}
    */
    readonly bundleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#bundle_version BedrockagentcoreGatewayRule#bundle_version}
    */
    readonly bundleVersion: string;
}
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleToTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle | cdktn.IResolvable | undefined);
    private _bundleArn?;
    get bundleArn(): string;
    set bundleArn(value: string);
    get bundleArnInput(): string | undefined;
    private _bundleVersion?;
    get bundleVersion(): string;
    set bundleVersion(value: string);
    get bundleVersionInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#description BedrockagentcoreGatewayRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#metadata BedrockagentcoreGatewayRule#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#name BedrockagentcoreGatewayRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#weight BedrockagentcoreGatewayRule#weight}
    */
    readonly weight: number;
    /**
    * configuration_bundle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#configuration_bundle BedrockagentcoreGatewayRule#configuration_bundle}
    */
    readonly configurationBundle?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitToTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
    private _configurationBundle;
    get configurationBundle(): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleList;
    putConfigurationBundle(value: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle[] | cdktn.IResolvable): void;
    resetConfigurationBundle(): void;
    get configurationBundleInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundle[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride {
    /**
    * traffic_split block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#traffic_split BedrockagentcoreGatewayRule#traffic_split}
    */
    readonly trafficSplit?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideToTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride | cdktn.IResolvable | undefined);
    private _trafficSplit;
    get trafficSplit(): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitList;
    putTrafficSplit(value: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit[] | cdktn.IResolvable): void;
    resetTrafficSplit(): void;
    get trafficSplitInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplit[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionConfigurationBundle {
    /**
    * static_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#static_override BedrockagentcoreGatewayRule#static_override}
    */
    readonly staticOverride?: BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride[] | cdktn.IResolvable;
    /**
    * weighted_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#weighted_override BedrockagentcoreGatewayRule#weighted_override}
    */
    readonly weightedOverride?: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleToTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundle | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionConfigurationBundleToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionConfigurationBundle | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionConfigurationBundle | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionConfigurationBundle | cdktn.IResolvable | undefined);
    private _staticOverride;
    get staticOverride(): BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverrideList;
    putStaticOverride(value: BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride[] | cdktn.IResolvable): void;
    resetStaticOverride(): void;
    get staticOverrideInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionConfigurationBundleStaticOverride[] | undefined;
    private _weightedOverride;
    get weightedOverride(): BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverrideList;
    putWeightedOverride(value: BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride[] | cdktn.IResolvable): void;
    resetWeightedOverride(): void;
    get weightedOverrideInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionConfigurationBundleWeightedOverride[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionConfigurationBundleList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionConfigurationBundle[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionConfigurationBundleOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#target_name BedrockagentcoreGatewayRule#target_name}
    */
    readonly targetName: string;
}
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetStaticRouteToTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetStaticRouteToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetStaticRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute | cdktn.IResolvable | undefined);
    private _targetName?;
    get targetName(): string;
    set targetName(value: string);
    get targetNameInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetStaticRouteList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionRouteToTargetStaticRouteOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#description BedrockagentcoreGatewayRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#metadata BedrockagentcoreGatewayRule#metadata}
    */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#name BedrockagentcoreGatewayRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#target_name BedrockagentcoreGatewayRule#target_name}
    */
    readonly targetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#weight BedrockagentcoreGatewayRule#weight}
    */
    readonly weight: number;
}
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitToTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    resetMetadata(): void;
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _targetName?;
    get targetName(): string;
    set targetName(value: string);
    get targetNameInput(): string | undefined;
    private _weight?;
    get weight(): number;
    set weight(value: number);
    get weightInput(): number | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute {
    /**
    * traffic_split block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#traffic_split BedrockagentcoreGatewayRule#traffic_split}
    */
    readonly trafficSplit?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteToTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute | cdktn.IResolvable | undefined);
    private _trafficSplit;
    get trafficSplit(): BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitList;
    putTrafficSplit(value: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit[] | cdktn.IResolvable): void;
    resetTrafficSplit(): void;
    get trafficSplitInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteTrafficSplit[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteOutputReference;
}
export interface BedrockagentcoreGatewayRuleActionRouteToTarget {
    /**
    * static_route block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#static_route BedrockagentcoreGatewayRule#static_route}
    */
    readonly staticRoute?: BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute[] | cdktn.IResolvable;
    /**
    * weighted_route block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#weighted_route BedrockagentcoreGatewayRule#weighted_route}
    */
    readonly weightedRoute?: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetToTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTarget | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionRouteToTargetToHclTerraform(struct?: BedrockagentcoreGatewayRuleActionRouteToTarget | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleActionRouteToTarget | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleActionRouteToTarget | cdktn.IResolvable | undefined);
    private _staticRoute;
    get staticRoute(): BedrockagentcoreGatewayRuleActionRouteToTargetStaticRouteList;
    putStaticRoute(value: BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute[] | cdktn.IResolvable): void;
    resetStaticRoute(): void;
    get staticRouteInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionRouteToTargetStaticRoute[] | undefined;
    private _weightedRoute;
    get weightedRoute(): BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRouteList;
    putWeightedRoute(value: BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute[] | cdktn.IResolvable): void;
    resetWeightedRoute(): void;
    get weightedRouteInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionRouteToTargetWeightedRoute[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionRouteToTargetList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleActionRouteToTarget[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionRouteToTargetOutputReference;
}
export interface BedrockagentcoreGatewayRuleAction {
    /**
    * configuration_bundle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#configuration_bundle BedrockagentcoreGatewayRule#configuration_bundle}
    */
    readonly configurationBundle?: BedrockagentcoreGatewayRuleActionConfigurationBundle[] | cdktn.IResolvable;
    /**
    * route_to_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#route_to_target BedrockagentcoreGatewayRule#route_to_target}
    */
    readonly routeToTarget?: BedrockagentcoreGatewayRuleActionRouteToTarget[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleActionToTerraform(struct?: BedrockagentcoreGatewayRuleAction | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleActionToHclTerraform(struct?: BedrockagentcoreGatewayRuleAction | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleAction | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleAction | cdktn.IResolvable | undefined);
    private _configurationBundle;
    get configurationBundle(): BedrockagentcoreGatewayRuleActionConfigurationBundleList;
    putConfigurationBundle(value: BedrockagentcoreGatewayRuleActionConfigurationBundle[] | cdktn.IResolvable): void;
    resetConfigurationBundle(): void;
    get configurationBundleInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionConfigurationBundle[] | undefined;
    private _routeToTarget;
    get routeToTarget(): BedrockagentcoreGatewayRuleActionRouteToTargetList;
    putRouteToTarget(value: BedrockagentcoreGatewayRuleActionRouteToTarget[] | cdktn.IResolvable): void;
    resetRouteToTarget(): void;
    get routeToTargetInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleActionRouteToTarget[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleActionList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleActionOutputReference;
}
export interface BedrockagentcoreGatewayRuleConditionMatchPaths {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#any_of BedrockagentcoreGatewayRule#any_of}
    */
    readonly anyOf: string[];
}
export declare function bedrockagentcoreGatewayRuleConditionMatchPathsToTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPaths | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionMatchPathsToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPaths | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionMatchPathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleConditionMatchPaths | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionMatchPaths | cdktn.IResolvable | undefined);
    private _anyOf?;
    get anyOf(): string[];
    set anyOf(value: string[]);
    get anyOfInput(): string[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleConditionMatchPathsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleConditionMatchPaths[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleConditionMatchPathsOutputReference;
}
export interface BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#arn BedrockagentcoreGatewayRule#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#operator BedrockagentcoreGatewayRule#operator}
    */
    readonly operator?: string;
}
export declare function bedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipalToTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipalToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
}
export declare class BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipalList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipalOutputReference;
}
export interface BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf {
    /**
    * iam_principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#iam_principal BedrockagentcoreGatewayRule#iam_principal}
    */
    readonly iamPrincipal?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfToTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf | cdktn.IResolvable | undefined);
    private _iamPrincipal;
    get iamPrincipal(): BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipalList;
    putIamPrincipal(value: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal[] | cdktn.IResolvable): void;
    resetIamPrincipal(): void;
    get iamPrincipalInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfIamPrincipal[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfOutputReference;
}
export interface BedrockagentcoreGatewayRuleConditionMatchPrincipals {
    /**
    * any_of block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#any_of BedrockagentcoreGatewayRule#any_of}
    */
    readonly anyOf?: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleConditionMatchPrincipalsToTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPrincipals | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionMatchPrincipalsToHclTerraform(struct?: BedrockagentcoreGatewayRuleConditionMatchPrincipals | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionMatchPrincipalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleConditionMatchPrincipals | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleConditionMatchPrincipals | cdktn.IResolvable | undefined);
    private _anyOf;
    get anyOf(): BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOfList;
    putAnyOf(value: BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf[] | cdktn.IResolvable): void;
    resetAnyOf(): void;
    get anyOfInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionMatchPrincipalsAnyOf[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleConditionMatchPrincipalsList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleConditionMatchPrincipals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleConditionMatchPrincipalsOutputReference;
}
export interface BedrockagentcoreGatewayRuleCondition {
    /**
    * match_paths block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#match_paths BedrockagentcoreGatewayRule#match_paths}
    */
    readonly matchPaths?: BedrockagentcoreGatewayRuleConditionMatchPaths[] | cdktn.IResolvable;
    /**
    * match_principals block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#match_principals BedrockagentcoreGatewayRule#match_principals}
    */
    readonly matchPrincipals?: BedrockagentcoreGatewayRuleConditionMatchPrincipals[] | cdktn.IResolvable;
}
export declare function bedrockagentcoreGatewayRuleConditionToTerraform(struct?: BedrockagentcoreGatewayRuleCondition | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleConditionToHclTerraform(struct?: BedrockagentcoreGatewayRuleCondition | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BedrockagentcoreGatewayRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleCondition | cdktn.IResolvable | undefined);
    private _matchPaths;
    get matchPaths(): BedrockagentcoreGatewayRuleConditionMatchPathsList;
    putMatchPaths(value: BedrockagentcoreGatewayRuleConditionMatchPaths[] | cdktn.IResolvable): void;
    resetMatchPaths(): void;
    get matchPathsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionMatchPaths[] | undefined;
    private _matchPrincipals;
    get matchPrincipals(): BedrockagentcoreGatewayRuleConditionMatchPrincipalsList;
    putMatchPrincipals(value: BedrockagentcoreGatewayRuleConditionMatchPrincipals[] | cdktn.IResolvable): void;
    resetMatchPrincipals(): void;
    get matchPrincipalsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleConditionMatchPrincipals[] | undefined;
}
export declare class BedrockagentcoreGatewayRuleConditionList extends cdktn.ComplexList {
    internalValue?: BedrockagentcoreGatewayRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BedrockagentcoreGatewayRuleConditionOutputReference;
}
export interface BedrockagentcoreGatewayRuleTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#create BedrockagentcoreGatewayRule#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#delete BedrockagentcoreGatewayRule#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#update BedrockagentcoreGatewayRule#update}
    */
    readonly update?: string;
}
export declare function bedrockagentcoreGatewayRuleTimeoutsToTerraform(struct?: BedrockagentcoreGatewayRuleTimeouts | cdktn.IResolvable): any;
export declare function bedrockagentcoreGatewayRuleTimeoutsToHclTerraform(struct?: BedrockagentcoreGatewayRuleTimeouts | cdktn.IResolvable): any;
export declare class BedrockagentcoreGatewayRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BedrockagentcoreGatewayRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BedrockagentcoreGatewayRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule aws_bedrockagentcore_gateway_rule}
*/
export declare class BedrockagentcoreGatewayRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_gateway_rule";
    /**
    * Generates CDKTN code for importing a BedrockagentcoreGatewayRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BedrockagentcoreGatewayRule to import
    * @param importFromId The id of the existing BedrockagentcoreGatewayRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BedrockagentcoreGatewayRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/bedrockagentcore_gateway_rule aws_bedrockagentcore_gateway_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BedrockagentcoreGatewayRuleConfig
    */
    constructor(scope: Construct, id: string, config: BedrockagentcoreGatewayRuleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get gatewayArn(): string;
    private _gatewayIdentifier?;
    get gatewayIdentifier(): string;
    set gatewayIdentifier(value: string);
    get gatewayIdentifierInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleId(): string;
    private _system;
    get systemAttribute(): BedrockagentcoreGatewayRuleSystemList;
    private _action;
    get action(): BedrockagentcoreGatewayRuleActionList;
    putAction(value: BedrockagentcoreGatewayRuleAction[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleAction[] | undefined;
    private _condition;
    get condition(): BedrockagentcoreGatewayRuleConditionList;
    putCondition(value: BedrockagentcoreGatewayRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleCondition[] | undefined;
    private _timeouts;
    get timeouts(): BedrockagentcoreGatewayRuleTimeoutsOutputReference;
    putTimeouts(value: BedrockagentcoreGatewayRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BedrockagentcoreGatewayRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
