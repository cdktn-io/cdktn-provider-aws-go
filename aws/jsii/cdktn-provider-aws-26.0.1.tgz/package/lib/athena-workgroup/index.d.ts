/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AthenaWorkgroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#description AthenaWorkgroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#force_destroy AthenaWorkgroup#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#id AthenaWorkgroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#name AthenaWorkgroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#region AthenaWorkgroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#state AthenaWorkgroup#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#tags AthenaWorkgroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#tags_all AthenaWorkgroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#configuration AthenaWorkgroup#configuration}
    */
    readonly configuration?: AthenaWorkgroupConfiguration;
}
export interface AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#kms_key AthenaWorkgroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkgroupConfigurationCustomerContentEncryptionConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationCustomerContentEncryptionConfigurationOutputReference | AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration): any;
export declare function athenaWorkgroupConfigurationCustomerContentEncryptionConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationCustomerContentEncryptionConfigurationOutputReference | AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration): any;
export declare class AthenaWorkgroupConfigurationCustomerContentEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration | undefined);
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationEngineVersion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#selected_engine_version AthenaWorkgroup#selected_engine_version}
    */
    readonly selectedEngineVersion?: string;
}
export declare function athenaWorkgroupConfigurationEngineVersionToTerraform(struct?: AthenaWorkgroupConfigurationEngineVersionOutputReference | AthenaWorkgroupConfigurationEngineVersion): any;
export declare function athenaWorkgroupConfigurationEngineVersionToHclTerraform(struct?: AthenaWorkgroupConfigurationEngineVersionOutputReference | AthenaWorkgroupConfigurationEngineVersion): any;
export declare class AthenaWorkgroupConfigurationEngineVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationEngineVersion | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationEngineVersion | undefined);
    get effectiveEngineVersion(): string;
    private _selectedEngineVersion?;
    get selectedEngineVersion(): string;
    set selectedEngineVersion(value: string);
    resetSelectedEngineVersion(): void;
    get selectedEngineVersionInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationIdentityCenterConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enable_identity_center AthenaWorkgroup#enable_identity_center}
    */
    readonly enableIdentityCenter?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#identity_center_instance_arn AthenaWorkgroup#identity_center_instance_arn}
    */
    readonly identityCenterInstanceArn?: string;
}
export declare function athenaWorkgroupConfigurationIdentityCenterConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationIdentityCenterConfigurationOutputReference | AthenaWorkgroupConfigurationIdentityCenterConfiguration): any;
export declare function athenaWorkgroupConfigurationIdentityCenterConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationIdentityCenterConfigurationOutputReference | AthenaWorkgroupConfigurationIdentityCenterConfiguration): any;
export declare class AthenaWorkgroupConfigurationIdentityCenterConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationIdentityCenterConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationIdentityCenterConfiguration | undefined);
    private _enableIdentityCenter?;
    get enableIdentityCenter(): boolean | cdktn.IResolvable;
    set enableIdentityCenter(value: boolean | cdktn.IResolvable);
    resetEnableIdentityCenter(): void;
    get enableIdentityCenterInput(): boolean | cdktn.IResolvable | undefined;
    private _identityCenterInstanceArn?;
    get identityCenterInstanceArn(): string;
    set identityCenterInstanceArn(value: string);
    resetIdentityCenterInstanceArn(): void;
    get identityCenterInstanceArnInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#kms_key AthenaWorkgroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationOutputReference | AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration): any;
export declare function athenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationOutputReference | AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration): any;
export declare class AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | undefined);
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationManagedQueryResultsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enabled AthenaWorkgroup#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#encryption_configuration AthenaWorkgroup#encryption_configuration}
    */
    readonly encryptionConfiguration?: AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration;
}
export declare function athenaWorkgroupConfigurationManagedQueryResultsConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationManagedQueryResultsConfigurationOutputReference | AthenaWorkgroupConfigurationManagedQueryResultsConfiguration): any;
export declare function athenaWorkgroupConfigurationManagedQueryResultsConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationManagedQueryResultsConfigurationOutputReference | AthenaWorkgroupConfigurationManagedQueryResultsConfiguration): any;
export declare class AthenaWorkgroupConfigurationManagedQueryResultsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationManagedQueryResultsConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationManagedQueryResultsConfiguration | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AthenaWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfiguration | undefined;
}
export interface AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#key AthenaWorkgroup#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#values AthenaWorkgroup#values}
    */
    readonly values: string[];
}
export declare function athenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogTypeToTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType | cdktn.IResolvable): any;
export declare function athenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogTypeToHclTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType | cdktn.IResolvable): any;
export declare class AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType | cdktn.IResolvable | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogTypeList extends cdktn.ComplexList {
    internalValue?: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogTypeOutputReference;
}
export interface AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enabled AthenaWorkgroup#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#log_group AthenaWorkgroup#log_group}
    */
    readonly logGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#log_stream_name_prefix AthenaWorkgroup#log_stream_name_prefix}
    */
    readonly logStreamNamePrefix?: string;
    /**
    * log_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#log_type AthenaWorkgroup#log_type}
    */
    readonly logType?: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType[] | cdktn.IResolvable;
}
export declare function athenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration): any;
export declare function athenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration): any;
export declare class AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _logGroup?;
    get logGroup(): string;
    set logGroup(value: string);
    resetLogGroup(): void;
    get logGroupInput(): string | undefined;
    private _logStreamNamePrefix?;
    get logStreamNamePrefix(): string;
    set logStreamNamePrefix(value: string);
    resetLogStreamNamePrefix(): void;
    get logStreamNamePrefixInput(): string | undefined;
    private _logType;
    get logType(): AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogTypeList;
    putLogType(value: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType[] | cdktn.IResolvable): void;
    resetLogType(): void;
    get logTypeInput(): cdktn.IResolvable | AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationLogType[] | undefined;
}
export interface AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enabled AthenaWorkgroup#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#kms_key AthenaWorkgroup#kms_key}
    */
    readonly kmsKey?: string;
}
export declare function athenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration): any;
export declare function athenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration): any;
export declare class AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enabled AthenaWorkgroup#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#kms_key AthenaWorkgroup#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#log_location AthenaWorkgroup#log_location}
    */
    readonly logLocation?: string;
}
export declare function athenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration): any;
export declare function athenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration): any;
export declare class AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _logLocation?;
    get logLocation(): string;
    set logLocation(value: string);
    resetLogLocation(): void;
    get logLocationInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationMonitoringConfiguration {
    /**
    * cloud_watch_logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#cloud_watch_logging_configuration AthenaWorkgroup#cloud_watch_logging_configuration}
    */
    readonly cloudWatchLoggingConfiguration?: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration;
    /**
    * managed_logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#managed_logging_configuration AthenaWorkgroup#managed_logging_configuration}
    */
    readonly managedLoggingConfiguration?: AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration;
    /**
    * s3_logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#s3_logging_configuration AthenaWorkgroup#s3_logging_configuration}
    */
    readonly s3LoggingConfiguration?: AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration;
}
export declare function athenaWorkgroupConfigurationMonitoringConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfiguration): any;
export declare function athenaWorkgroupConfigurationMonitoringConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationMonitoringConfigurationOutputReference | AthenaWorkgroupConfigurationMonitoringConfiguration): any;
export declare class AthenaWorkgroupConfigurationMonitoringConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationMonitoringConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationMonitoringConfiguration | undefined);
    private _cloudWatchLoggingConfiguration;
    get cloudWatchLoggingConfiguration(): AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfigurationOutputReference;
    putCloudWatchLoggingConfiguration(value: AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration): void;
    resetCloudWatchLoggingConfiguration(): void;
    get cloudWatchLoggingConfigurationInput(): AthenaWorkgroupConfigurationMonitoringConfigurationCloudWatchLoggingConfiguration | undefined;
    private _managedLoggingConfiguration;
    get managedLoggingConfiguration(): AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfigurationOutputReference;
    putManagedLoggingConfiguration(value: AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration): void;
    resetManagedLoggingConfiguration(): void;
    get managedLoggingConfigurationInput(): AthenaWorkgroupConfigurationMonitoringConfigurationManagedLoggingConfiguration | undefined;
    private _s3LoggingConfiguration;
    get s3LoggingConfiguration(): AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfigurationOutputReference;
    putS3LoggingConfiguration(value: AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration): void;
    resetS3LoggingConfiguration(): void;
    get s3LoggingConfigurationInput(): AthenaWorkgroupConfigurationMonitoringConfigurationS3LoggingConfiguration | undefined;
}
export interface AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#authentication_type AthenaWorkgroup#authentication_type}
    */
    readonly authenticationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#create_user_level_prefix AthenaWorkgroup#create_user_level_prefix}
    */
    readonly createUserLevelPrefix?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enable_s3_access_grants AthenaWorkgroup#enable_s3_access_grants}
    */
    readonly enableS3AccessGrants: boolean | cdktn.IResolvable;
}
export declare function athenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfigurationOutputReference | AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration): any;
export declare function athenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfigurationOutputReference | AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration): any;
export declare class AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration | undefined);
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    get authenticationTypeInput(): string | undefined;
    private _createUserLevelPrefix?;
    get createUserLevelPrefix(): boolean | cdktn.IResolvable;
    set createUserLevelPrefix(value: boolean | cdktn.IResolvable);
    resetCreateUserLevelPrefix(): void;
    get createUserLevelPrefixInput(): boolean | cdktn.IResolvable | undefined;
    private _enableS3AccessGrants?;
    get enableS3AccessGrants(): boolean | cdktn.IResolvable;
    set enableS3AccessGrants(value: boolean | cdktn.IResolvable);
    get enableS3AccessGrantsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AthenaWorkgroupConfigurationResultConfigurationAclConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#s3_acl_option AthenaWorkgroup#s3_acl_option}
    */
    readonly s3AclOption: string;
}
export declare function athenaWorkgroupConfigurationResultConfigurationAclConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationResultConfigurationAclConfigurationOutputReference | AthenaWorkgroupConfigurationResultConfigurationAclConfiguration): any;
export declare function athenaWorkgroupConfigurationResultConfigurationAclConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationResultConfigurationAclConfigurationOutputReference | AthenaWorkgroupConfigurationResultConfigurationAclConfiguration): any;
export declare class AthenaWorkgroupConfigurationResultConfigurationAclConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationResultConfigurationAclConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationResultConfigurationAclConfiguration | undefined);
    private _s3AclOption?;
    get s3AclOption(): string;
    set s3AclOption(value: string);
    get s3AclOptionInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#encryption_option AthenaWorkgroup#encryption_option}
    */
    readonly encryptionOption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#kms_key_arn AthenaWorkgroup#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
}
export declare function athenaWorkgroupConfigurationResultConfigurationEncryptionConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationResultConfigurationEncryptionConfigurationOutputReference | AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration): any;
export declare function athenaWorkgroupConfigurationResultConfigurationEncryptionConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationResultConfigurationEncryptionConfigurationOutputReference | AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration): any;
export declare class AthenaWorkgroupConfigurationResultConfigurationEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration | undefined);
    private _encryptionOption?;
    get encryptionOption(): string;
    set encryptionOption(value: string);
    resetEncryptionOption(): void;
    get encryptionOptionInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
}
export interface AthenaWorkgroupConfigurationResultConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#expected_bucket_owner AthenaWorkgroup#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#output_location AthenaWorkgroup#output_location}
    */
    readonly outputLocation?: string;
    /**
    * acl_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#acl_configuration AthenaWorkgroup#acl_configuration}
    */
    readonly aclConfiguration?: AthenaWorkgroupConfigurationResultConfigurationAclConfiguration;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#encryption_configuration AthenaWorkgroup#encryption_configuration}
    */
    readonly encryptionConfiguration?: AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration;
}
export declare function athenaWorkgroupConfigurationResultConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationResultConfigurationOutputReference | AthenaWorkgroupConfigurationResultConfiguration): any;
export declare function athenaWorkgroupConfigurationResultConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationResultConfigurationOutputReference | AthenaWorkgroupConfigurationResultConfiguration): any;
export declare class AthenaWorkgroupConfigurationResultConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfigurationResultConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfigurationResultConfiguration | undefined);
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _outputLocation?;
    get outputLocation(): string;
    set outputLocation(value: string);
    resetOutputLocation(): void;
    get outputLocationInput(): string | undefined;
    private _aclConfiguration;
    get aclConfiguration(): AthenaWorkgroupConfigurationResultConfigurationAclConfigurationOutputReference;
    putAclConfiguration(value: AthenaWorkgroupConfigurationResultConfigurationAclConfiguration): void;
    resetAclConfiguration(): void;
    get aclConfigurationInput(): AthenaWorkgroupConfigurationResultConfigurationAclConfiguration | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AthenaWorkgroupConfigurationResultConfigurationEncryptionConfigurationOutputReference;
    putEncryptionConfiguration(value: AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AthenaWorkgroupConfigurationResultConfigurationEncryptionConfiguration | undefined;
}
export interface AthenaWorkgroupConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#bytes_scanned_cutoff_per_query AthenaWorkgroup#bytes_scanned_cutoff_per_query}
    */
    readonly bytesScannedCutoffPerQuery?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enable_minimum_encryption_configuration AthenaWorkgroup#enable_minimum_encryption_configuration}
    */
    readonly enableMinimumEncryptionConfiguration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#enforce_workgroup_configuration AthenaWorkgroup#enforce_workgroup_configuration}
    */
    readonly enforceWorkgroupConfiguration?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#execution_role AthenaWorkgroup#execution_role}
    */
    readonly executionRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#publish_cloudwatch_metrics_enabled AthenaWorkgroup#publish_cloudwatch_metrics_enabled}
    */
    readonly publishCloudwatchMetricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#requester_pays_enabled AthenaWorkgroup#requester_pays_enabled}
    */
    readonly requesterPaysEnabled?: boolean | cdktn.IResolvable;
    /**
    * customer_content_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#customer_content_encryption_configuration AthenaWorkgroup#customer_content_encryption_configuration}
    */
    readonly customerContentEncryptionConfiguration?: AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration;
    /**
    * engine_version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#engine_version AthenaWorkgroup#engine_version}
    */
    readonly engineVersion?: AthenaWorkgroupConfigurationEngineVersion;
    /**
    * identity_center_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#identity_center_configuration AthenaWorkgroup#identity_center_configuration}
    */
    readonly identityCenterConfiguration?: AthenaWorkgroupConfigurationIdentityCenterConfiguration;
    /**
    * managed_query_results_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#managed_query_results_configuration AthenaWorkgroup#managed_query_results_configuration}
    */
    readonly managedQueryResultsConfiguration?: AthenaWorkgroupConfigurationManagedQueryResultsConfiguration;
    /**
    * monitoring_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#monitoring_configuration AthenaWorkgroup#monitoring_configuration}
    */
    readonly monitoringConfiguration?: AthenaWorkgroupConfigurationMonitoringConfiguration;
    /**
    * query_results_s3_access_grants_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#query_results_s3_access_grants_configuration AthenaWorkgroup#query_results_s3_access_grants_configuration}
    */
    readonly queryResultsS3AccessGrantsConfiguration?: AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration;
    /**
    * result_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#result_configuration AthenaWorkgroup#result_configuration}
    */
    readonly resultConfiguration?: AthenaWorkgroupConfigurationResultConfiguration;
}
export declare function athenaWorkgroupConfigurationToTerraform(struct?: AthenaWorkgroupConfigurationOutputReference | AthenaWorkgroupConfiguration): any;
export declare function athenaWorkgroupConfigurationToHclTerraform(struct?: AthenaWorkgroupConfigurationOutputReference | AthenaWorkgroupConfiguration): any;
export declare class AthenaWorkgroupConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AthenaWorkgroupConfiguration | undefined;
    set internalValue(value: AthenaWorkgroupConfiguration | undefined);
    private _bytesScannedCutoffPerQuery?;
    get bytesScannedCutoffPerQuery(): number;
    set bytesScannedCutoffPerQuery(value: number);
    resetBytesScannedCutoffPerQuery(): void;
    get bytesScannedCutoffPerQueryInput(): number | undefined;
    private _enableMinimumEncryptionConfiguration?;
    get enableMinimumEncryptionConfiguration(): boolean | cdktn.IResolvable;
    set enableMinimumEncryptionConfiguration(value: boolean | cdktn.IResolvable);
    resetEnableMinimumEncryptionConfiguration(): void;
    get enableMinimumEncryptionConfigurationInput(): boolean | cdktn.IResolvable | undefined;
    private _enforceWorkgroupConfiguration?;
    get enforceWorkgroupConfiguration(): boolean | cdktn.IResolvable;
    set enforceWorkgroupConfiguration(value: boolean | cdktn.IResolvable);
    resetEnforceWorkgroupConfiguration(): void;
    get enforceWorkgroupConfigurationInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _publishCloudwatchMetricsEnabled?;
    get publishCloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
    set publishCloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
    resetPublishCloudwatchMetricsEnabled(): void;
    get publishCloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _requesterPaysEnabled?;
    get requesterPaysEnabled(): boolean | cdktn.IResolvable;
    set requesterPaysEnabled(value: boolean | cdktn.IResolvable);
    resetRequesterPaysEnabled(): void;
    get requesterPaysEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _customerContentEncryptionConfiguration;
    get customerContentEncryptionConfiguration(): AthenaWorkgroupConfigurationCustomerContentEncryptionConfigurationOutputReference;
    putCustomerContentEncryptionConfiguration(value: AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration): void;
    resetCustomerContentEncryptionConfiguration(): void;
    get customerContentEncryptionConfigurationInput(): AthenaWorkgroupConfigurationCustomerContentEncryptionConfiguration | undefined;
    private _engineVersion;
    get engineVersion(): AthenaWorkgroupConfigurationEngineVersionOutputReference;
    putEngineVersion(value: AthenaWorkgroupConfigurationEngineVersion): void;
    resetEngineVersion(): void;
    get engineVersionInput(): AthenaWorkgroupConfigurationEngineVersion | undefined;
    private _identityCenterConfiguration;
    get identityCenterConfiguration(): AthenaWorkgroupConfigurationIdentityCenterConfigurationOutputReference;
    putIdentityCenterConfiguration(value: AthenaWorkgroupConfigurationIdentityCenterConfiguration): void;
    resetIdentityCenterConfiguration(): void;
    get identityCenterConfigurationInput(): AthenaWorkgroupConfigurationIdentityCenterConfiguration | undefined;
    private _managedQueryResultsConfiguration;
    get managedQueryResultsConfiguration(): AthenaWorkgroupConfigurationManagedQueryResultsConfigurationOutputReference;
    putManagedQueryResultsConfiguration(value: AthenaWorkgroupConfigurationManagedQueryResultsConfiguration): void;
    resetManagedQueryResultsConfiguration(): void;
    get managedQueryResultsConfigurationInput(): AthenaWorkgroupConfigurationManagedQueryResultsConfiguration | undefined;
    private _monitoringConfiguration;
    get monitoringConfiguration(): AthenaWorkgroupConfigurationMonitoringConfigurationOutputReference;
    putMonitoringConfiguration(value: AthenaWorkgroupConfigurationMonitoringConfiguration): void;
    resetMonitoringConfiguration(): void;
    get monitoringConfigurationInput(): AthenaWorkgroupConfigurationMonitoringConfiguration | undefined;
    private _queryResultsS3AccessGrantsConfiguration;
    get queryResultsS3AccessGrantsConfiguration(): AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfigurationOutputReference;
    putQueryResultsS3AccessGrantsConfiguration(value: AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration): void;
    resetQueryResultsS3AccessGrantsConfiguration(): void;
    get queryResultsS3AccessGrantsConfigurationInput(): AthenaWorkgroupConfigurationQueryResultsS3AccessGrantsConfiguration | undefined;
    private _resultConfiguration;
    get resultConfiguration(): AthenaWorkgroupConfigurationResultConfigurationOutputReference;
    putResultConfiguration(value: AthenaWorkgroupConfigurationResultConfiguration): void;
    resetResultConfiguration(): void;
    get resultConfigurationInput(): AthenaWorkgroupConfigurationResultConfiguration | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup aws_athena_workgroup}
*/
export declare class AthenaWorkgroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_athena_workgroup";
    /**
    * Generates CDKTN code for importing a AthenaWorkgroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AthenaWorkgroup to import
    * @param importFromId The id of the existing AthenaWorkgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AthenaWorkgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.71.0/docs/resources/athena_workgroup aws_athena_workgroup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AthenaWorkgroupConfig
    */
    constructor(scope: Construct, id: string, config: AthenaWorkgroupConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _configuration;
    get configuration(): AthenaWorkgroupConfigurationOutputReference;
    putConfiguration(value: AthenaWorkgroupConfiguration): void;
    resetConfiguration(): void;
    get configurationInput(): AthenaWorkgroupConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
